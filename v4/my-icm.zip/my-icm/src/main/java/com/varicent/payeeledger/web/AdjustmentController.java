package com.varicent.payeeledger.web;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import com.varicent.common.adjustment.service.AdjustmentManager;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.domain.Plan;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Parse;
import com.varicent.core.util.Validation;
import com.varicent.security.domain.UserAccount;

@Controller
@RequestMapping({ "/ledger/adjustment.html" })
public class AdjustmentController {
	private static final String VIEW = "payeeledger/adjustment";
	private static final String LEDGER_VIEW = "redirect:/ledger/summary.html";
	private final AdjustmentManager adjustmentManager;

	@Autowired
	public AdjustmentController(AdjustmentManager adjustmentManager) {
		this.adjustmentManager = adjustmentManager;
	}

	@ModelAttribute("adjPayee")
	public Payee getPayee(@ModelAttribute("command") AdjustmentCommand cmd) {
		return this.adjustmentManager.getPayee(cmd.getPayee());
	}

	@ModelAttribute("adjPlan")
	public Plan getPlan(@ModelAttribute("command") AdjustmentCommand cmd) {
		return this.adjustmentManager.getPlan(cmd.getPlan());
	}

	@ModelAttribute("adjToken")
	public String getToken() {
		return UserAccount.getCurrent().issueToken();
	}

	@RequestMapping(method = { RequestMethod.GET })
	public String prepareView(HttpServletRequest request, HttpServletResponse response, BindException errors)
			throws Exception {
		return "redirect:/ledger/summary.html";
	}

	@RequestMapping(method = { RequestMethod.POST })
	public String processForm(@ModelAttribute("command") AdjustmentCommand cmd, HttpServletRequest request) {
		if (cmd != null) {
			this.clearErrors(cmd);
		}

		if (cmd.getValue() != null && cmd.getValue().length() != 0) {
			if (!cmd.checkAndUpdateToken()) {
				return "payeeledger/adjustment";
			} else {
				BigDecimal parseValue = Parse.parseDecimal(cmd.getValue(), false);
				if (parseValue == null) {
					cmd.setErrorKey(Messages.Key.ADJUSTMENT_ERROR_INVALID_NUMERIC.toString());
					return "payeeledger/adjustment";
				} else if (BigDecimal.ZERO.compareTo(parseValue) == 0) {
					cmd.setErrorKey(Messages.Key.ADJUSTMENT_ERROR_ZERO_NUMERIC.toString());
					return "payeeledger/adjustment";
				} else if (!Validation.isValidNumeric(parseValue)) {
					cmd.setErrorKey(Messages.Key.ADJUSTMENT_ERROR_INVALID_NUMERIC.toString());
					return "payeeledger/adjustment";
				} else if (cmd.getComment() != null && cmd.getComment().length() > 1000) {
					cmd.setErrorKey(Messages.Key.ADJUSTMENT_ERROR_COMMENT_TOO_LONG.toString());
					return "payeeledger/adjustment";
				} else {
					this.adjustmentManager.addManualAdjustment(cmd.getPlan(), cmd.getPayee(), cmd.getPeriod(),
							parseValue, cmd.getComment());
					PayeeLedgerCommand plc = new PayeeLedgerCommand();
					plc.setPlanId(cmd.getPlan());
					plc.setPayeeId(cmd.getPayee());
					WebUtils.setSessionAttribute(request, "command", plc);
					return "redirect:/ledger/summary.html";
				}
			}
		} else {
			return "payeeledger/adjustment";
		}
	}

	private void clearErrors(AdjustmentCommand ac) {
		ac.setErrorKey("");
		ac.setErrorParams(new String[0]);
	}
}
