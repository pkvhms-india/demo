package com.varicent.messages.web;

import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.varicent.common.config.service.ConfigManager;
import com.varicent.core.text.Parse;
import com.varicent.messages.dao.MessagesDao;
import com.varicent.messages.service.MessagesManager;
import com.varicent.security.domain.UserAccount;

@Controller
public class MessageCenterController {
	public static final int PERIOD = 7;
	public static final String START_PARAM = "start";
	public static final String END_PARAM = "end";
	private static final String VIEW = "messages/index";
	private final MessagesManager messagesManager;
	private final ConfigManager configManager;

	@Autowired
	public MessageCenterController(MessagesManager messagesManager, ConfigManager configManager,
			MessagesDao messageDao) {
		this.messagesManager = messagesManager;
		this.configManager = configManager;
	}

	@ModelAttribute("lastCalcTime")
	public Date getLastCalcTime() {
		return this.configManager.getLastCalcTime();
	}

	@RequestMapping(method = { RequestMethod.GET }, value = { "/messages/index.html" })
	public ModelAndView prepareView(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("messages/index");
		request.getSession().setAttribute("token", UserAccount.getCurrent().issueToken());
		Calendar endCal = new GregorianCalendar();
		Calendar startCal = new GregorianCalendar();
		startCal.add(5, -7);
		Enumeration<?> e = request.getParameterNames();

		while (e.hasMoreElements()) {
			String name = (String) e.nextElement();
			String value = request.getParameter(name);
			if (name.equalsIgnoreCase("start")) {
				startCal.setTime(Parse.date(value));
			} else if (name.equalsIgnoreCase("end")) {
				endCal.setTime(Parse.date(value));
			}
		}

		Calendar var8 = this.getEndOfDay(endCal);
		Calendar var9 = this.getStartOfDay(startCal);
		if (var9.after(var8)) {
			var9 = (Calendar) var8.clone();
			var9.add(5, -7);
		}

		mav.addObject("command",
				new MessagesCommand(var9, var8, this.messagesManager.getMessages(0, var9.getTime(), var8.getTime())));
		return mav;
	}

	private Calendar getEndOfDay(Calendar calendar) {
		return new GregorianCalendar(calendar.get(1), calendar.get(2), calendar.get(5), 23, 59, 59);
	}

	private Calendar getStartOfDay(Calendar calendar) {
		return new GregorianCalendar(calendar.get(1), calendar.get(2), calendar.get(5));
	}
}
