package com.varicent.payeeledger.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.Assert;

import com.varicent.core.math.Precision;

public class RunningTotal {
	private final DisplayColumn.Operator op;
	private final String dataItem;
	private final List<BigDecimal> values;
	private BigDecimal value;

	public RunningTotal(DisplayColumn.Operator op, String dataItem) {
		this.op = op;
		this.dataItem = dataItem;
		this.values = new ArrayList();
	}

	public void evaluate(BigDecimal v) {
		this.values.add(v);
		this.value = null;
		switch (this.op) {
		case SUM:
			this.sum();
			break;
		case AVG:
			this.avg();
			break;
		case MIN:
			this.min();
			break;
		case MAX:
			this.max();
			break;
		case LAST:
			this.value = v;
			break;
		case NONE:
		default:
			Assert.state(false);
		}

	}

	public DisplayColumn.Operator getOperator() {
		return this.op;
	}

	public String getDataItem() {
		return this.dataItem;
	}

	public BigDecimal getValue() {
		return this.value;
	}

	public boolean hasValue() {
		return this.value != null;
	}

	public void reset() {
		this.values.clear();
		this.value = null;
	}

	private void avg() {
		this.sum();
		this.value = this.value.divide(BigDecimal.valueOf(this.values.size()), Precision.getCalcContext());
	}

	private void max() {
		for (BigDecimal v : this.values) {
			this.value = this.value == null ? v : this.value.max(v);
		}

	}

	private void min() {
		for (BigDecimal v : this.values) {
			this.value = this.value == null ? v : this.value.min(v);
		}

	}

	private void sum() {
		for (BigDecimal v : this.values) {
			this.value = this.value == null ? v : this.value.add(v);
		}

	}
}
