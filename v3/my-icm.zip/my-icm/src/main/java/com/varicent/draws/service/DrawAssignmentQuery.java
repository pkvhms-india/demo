package com.varicent.draws.service;

import java.util.Date;

import com.varicent.common.query.domain.AndClause;
import com.varicent.common.query.domain.Clause;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectCustom;
import com.varicent.common.query.domain.SubQueryConstraint;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.dao.jdbc.WorkflowQuery;

public class DrawAssignmentQuery {
	public static QueryDefinition getDrawAssignmentWebSettingsQuery(int drawID) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentWebSettings");
		query.selectAll();
		query.newConstraint("DrawAssignmentWebSettings", "BlockID", Constraint.Operator.Equals, drawID);
		return query;
	}

	public static QueryDefinition getWorkflowGroupsQuery(int workflowObjectID) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectID);
		query.selectDistinct();
		query.select("DescendantGroup", "ID");
		query.select("DescendantGroup", "Name");
		return query;
	}

	public static QueryDefinition getAvailablePayeesQuery(int workflowObjectID) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		Join payeejoin = new Join("Payee_", Join.Type.INNER);
		payeejoin.newConstraint("DescendantMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(payeejoin);
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectID);
		query.selectDistinct();
		query.select("Payee_", "PayeeID_");
		query.select("Payee_", "Name_");
		return query;
	}

	public static QueryDefinition getDrawTemplatesQuery(int drawID) {
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, drawID);
		query.selectAll();
		query.orderBy("Name");
		return query;
	}

	public static QueryDefinition getUnAssignedPayeesQueryAllGroups(int drawID, int workflowObjectID, Date LockedUntil,
			String effectiveDate) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("DescendantMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		addPayeeInfoQuery(query, effectiveDate);
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectID);
		return getUnAssignedPayeesQuery(query, drawID, LockedUntil);
	}

	public static QueryDefinition getUnAssignedPayeesQuery(int groupID, int drawID, Date LockedUntil,
			String effectiveDate) {
		QueryDefinition query = new QueryDefinition("WorkflowGroupMember");
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		addPayeeInfoQuery(query, effectiveDate);
		query.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, groupID);
		return getUnAssignedPayeesQuery(query, drawID, LockedUntil);
	}

	public static QueryDefinition getOngoingPayeesCountQuery(QueryDefinition query, int drawId, String timeId,
			boolean activeOnly, Date lockedDate) {
		QueryDefinition countQuery = new QueryDefinition(
				getOngoingBaseQuery(query, drawId, timeId, lockedDate, activeOnly), "_inner");
		countQuery.selectCount();
		return countQuery;
	}

	public static QueryDefinition getOngoingPayeesQuery(QueryDefinition query, int drawId, String timeId,
			boolean activeOnly, Date lockedDate, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) {
		query = getOngoingBaseQuery(query, drawId, timeId, lockedDate, activeOnly);
		return getRowNumberQuery(query, pageNumber, rowsPerPage, new String[] { sortColumn },
				new boolean[] { descending });
	}

	private static QueryDefinition getOngoingBaseQuery(QueryDefinition query, int drawId, String timeId,
			Date lockedDate, boolean activeOnly) {
		query.selectDistinct();
		query.select("DrawAssignmentOngoingTerm", "AssignmentID");
		query.select("DrawAssignmentOngoingTerm", "PayeeID");
		query.select("DrawAssignmentOngoingTerm", "StartDate");
		query.select("DrawAssignmentOngoingTerm", "EndDate");
		query.select("DrawAssignmentOngoingTerm", "Amount");
		query.select("DrawAssignmentOngoingTerm", "TemplateID");
		query.select("DrawAssignmentOngoingTerm", "_RowVersion");
		query.select("DrawTemplate", "Level");
		query.select("DrawTemplate", "Name", "TemplateName");
		query.select("DrawTemplate", "MaxDrawAmount");
		query.select("Time_", "Name_", "StartPeriod");
		query.select("Time_", "TimeID_", "TimeID");
		Join ongoingJoin = new Join("DrawAssignmentOngoingTerm", Join.Type.INNER);
		ongoingJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "DrawAssignmentOngoingTerm",
				"PayeeID");
		query.joinWith(ongoingJoin);
		Join templateJoin = new Join("DrawTemplate", Join.Type.INNER);
		templateJoin.newConstraint("DrawAssignmentOngoingTerm", "TemplateID", Constraint.Operator.Equals,
				"DrawTemplate", "ID");
		query.joinWith(templateJoin);
		Join timePeriodJoin = new Join("Time_", Join.Type.INNER);
		timePeriodJoin.newConstraint("Time_", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		timePeriodJoin.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals,
				"DrawAssignmentOngoingTerm", "StartDate");
		timePeriodJoin.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals,
				"DrawAssignmentOngoingTerm", "StartDate");
		query.joinWith(timePeriodJoin);
		query.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, drawId);
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		if (activeOnly && lockedDate != null) {
			OrClause orClause = new OrClause();
			orClause.newNullConstraint("DrawAssignmentOngoingTerm", "EndDate", true);
			orClause.newConstraint("DrawAssignmentOngoingTerm", "EndDate", Constraint.Operator.GreaterThan, lockedDate);
			query.addConstraint(orClause);
		}

		return query;
	}

	public static QueryDefinition getFixedTermPayeeCountQuery(QueryDefinition query, int drawId, String timeId,
			Date lockedDate, boolean activeOnly) {
		QueryDefinition newQuery = new QueryDefinition(
				getFixedTermBaseQuery(query, drawId, timeId, lockedDate, activeOnly), "_inner");
		newQuery.selectCount();
		return newQuery;
	}

	public static QueryDefinition getFixedTermPayeeQuery(QueryDefinition query, int drawId, String timeId,
			Date lockedDate, boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) {
		query = getFixedTermBaseQuery(query, drawId, timeId, lockedDate, activeOnly);
		return getRowNumberQuery(query, pageNumber, rowsPerPage, new String[] { sortColumn },
				new boolean[] { descending });
	}

	public static QueryDefinition getPayeeQueryByGroupId(String timeId, int groupId) {
		QueryDefinition query = new QueryDefinition("WorkflowGroupMember");
		query.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, groupId);
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		query.select("Payee_", "Name_", "PayeeName");
		return query;
	}

	public static QueryDefinition getPayeeQueryByRestrictionQuery(QueryDefinition restriction) {
		QueryDefinition query = new QueryDefinition("Payee_");
		query.select("Payee_", "Name_", "PayeeName");
		Join restrictionJoin = new Join(restriction, "CustomRestriction", Join.Type.INNER);
		restrictionJoin.newConstraint("CustomRestriction", "PayeeID_", Constraint.Operator.Equals, "Payee_",
				"PayeeID_");
		query.joinWith(restrictionJoin);
		return query;
	}

	public static QueryDefinition getPayeeQueryForAllGroups(int workflowObjectId) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("DescendantMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		query.select("Payee_", "Name_", "PayeeName");
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectId);
		return query;
	}

	private static QueryDefinition getFixedTermBaseQuery(QueryDefinition query, int drawID, String timeId,
			Date lockedDate, boolean activeOnly) {
		query.selectDistinct();
		query.select("DrawAssignmentFixedTerm", "AssignmentID");
		query.select("DrawAssignmentFixedTerm", "PayeeID");
		query.select("DrawAssignmentFixedTerm", "TemplateID");
		query.select("DrawAssignmentFixedTerm", "StartDate");
		query.select("DrawAssignmentFixedTerm", "EndDate");
		query.select("DrawAssignmentFixedTerm", "_RowVersion");
		query.select("Time_", "Name_", "StartPeriod");
		query.select("Time_", "TimeID_");
		query.select("DrawTemplate", "Name", "TemplateName");
		query.select("DrawTemplate", "MaxDuration");
		query.select("DrawTemplate", "Level");
		query.select("DrawTemplate", "DrawAmount");
		query.select("DrawTemplate", "MaxDrawAmount");
		query.select(new Literal(Literal.Type.DATE, lockedDate), "LockedDate");
		Join fixedJoin = new Join("DrawAssignmentFixedTerm", Join.Type.INNER);
		fixedJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "DrawAssignmentFixedTerm", "PayeeID");
		query.joinWith(fixedJoin);
		Join templateJoin = new Join("DrawTemplate", Join.Type.INNER);
		templateJoin.newConstraint("DrawAssignmentFixedTerm", "TemplateID", Constraint.Operator.Equals, "DrawTemplate",
				"ID");
		query.joinWith(templateJoin);
		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("Time_", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		timeJoin.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, "DrawAssignmentFixedTerm",
				"StartDate");
		timeJoin.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, "DrawAssignmentFixedTerm",
				"StartDate");
		query.joinWith(timeJoin);
		query.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, drawID);
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		if (activeOnly && lockedDate != null) {
			query.newConstraint("DrawAssignmentFixedTerm", "EndDate", Constraint.Operator.GreaterThan, lockedDate);
		}

		return query;
	}

	public static QueryDefinition getUnAssignedPayeesQuery(QueryDefinition query, int drawID, Date lockedUntil) {
		query.selectDistinct();
		QueryDefinition queryFixedTerm = new QueryDefinition("DrawAssignmentFixedTerm");
		queryFixedTerm.select("DrawAssignmentFixedTerm", "PayeeID");
		Join fixedTermtemplateJoin = new Join("DrawTemplate", Join.Type.INNER);
		fixedTermtemplateJoin.newConstraint("DrawAssignmentFixedTerm", "TemplateID", Constraint.Operator.Equals,
				"DrawTemplate", "ID");
		queryFixedTerm.joinWith(fixedTermtemplateJoin);
		queryFixedTerm.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, drawID);
		if (lockedUntil != null) {
			queryFixedTerm.newConstraint("DrawAssignmentFixedTerm", "EndDate", Constraint.Operator.GreaterThan,
					lockedUntil);
		}

		QueryDefinition queryOngoingTerm = new QueryDefinition("DrawAssignmentOngoingTerm");
		queryOngoingTerm.select("DrawAssignmentOngoingTerm", "PayeeID");
		Join ongoingTemplateJoin = new Join("DrawTemplate", Join.Type.INNER);
		ongoingTemplateJoin.newConstraint("DrawAssignmentOngoingTerm", "TemplateID", Constraint.Operator.Equals,
				"DrawTemplate", "ID");
		queryOngoingTerm.joinWith(ongoingTemplateJoin);
		queryOngoingTerm.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, drawID);
		if (lockedUntil != null) {
			OrClause orClause = new OrClause();
			orClause.newNullConstraint("DrawAssignmentOngoingTerm", "EndDate", true);
			orClause.newConstraint("DrawAssignmentOngoingTerm", "EndDate", Constraint.Operator.GreaterThan,
					lockedUntil);
			queryOngoingTerm.addConstraint(orClause);
		}

		query.addConstraint(
				new SubQueryConstraint("Payee_", "PayeeID_", SubQueryConstraint.Operator.NotIn, queryFixedTerm));
		query.addConstraint(
				new SubQueryConstraint("Payee_", "PayeeID_", SubQueryConstraint.Operator.NotIn, queryOngoingTerm));
		return query;
	}

	public static void addPayeeInfoQuery(QueryDefinition query, String effectiveDate) {
		query.select("Payee_", "PayeeID_");
		query.select("Payee_", "Name_");
		query.select("Payee_", "Email_");
		query.select("Title_", "Title_", "Title");
		query.select("Parent", "Name_", "Parent");
		query.select("ReportsTo", "Name_", "ReportsTo");
		query.select("Payee_", effectiveDate, "Date_Of_Hire");
		Join titleJoin = new Join("Title_", Join.Type.LEFT);
		titleJoin.newConstraint("Payee_", "TitleID_", Constraint.Operator.Equals, "Title_", "TitleID_");
		query.joinWith(titleJoin);
		Join parentJoin = new Join("Payee_", "Parent", Join.Type.LEFT);
		parentJoin.newConstraint("Payee_", "Parent_", Constraint.Operator.Equals, "Parent", "PayeeID_");
		query.joinWith(parentJoin);
		Join reportsToJoin = new Join("Payee_", "ReportsTo", Join.Type.LEFT);
		reportsToJoin.newConstraint("Payee_", "Reports_To_", Constraint.Operator.Equals, "ReportsTo", "PayeeID_");
		query.joinWith(reportsToJoin);
	}

	public static QueryDefinition getRowNumberQuery(QueryDefinition innerQuery, int pageNumber, int rowsPerPage,
			String[] sortColumn, boolean[] descending) {
		int index = (pageNumber - 1) * rowsPerPage;
		String rowNumberQuery = "ROW_NUMBER() OVER (ORDER BY ";

		for (int i = 0; i < sortColumn.length; ++i) {
			String sortOrder = descending[i] ? "DESC" : "ASC";
			rowNumberQuery = rowNumberQuery + "[_inner].[" + sortColumn[i] + "] " + sortOrder;
			if (i == sortColumn.length - 1) {
				rowNumberQuery = rowNumberQuery + ")";
			} else {
				rowNumberQuery = rowNumberQuery + ", ";
			}
		}

		QueryDefinition rowNumQuery = new QueryDefinition(innerQuery, "_inner");
		rowNumQuery.selectAll();
		rowNumQuery.addSelect(new SelectCustom(rowNumberQuery, "ROW_NUMBER"));
		QueryDefinition outerQuery = new QueryDefinition(rowNumQuery, "_outer");
		outerQuery.selectAll();
		outerQuery.orderBy("ROW_NUMBER");
		outerQuery.newConstraint("_outer", "ROW_NUMBER", Constraint.Operator.GreaterThan, index);
		outerQuery.limitTo(rowsPerPage);
		return outerQuery;
	}

	public static QueryDefinition getFindOverlappingAssignmentQuery(int drawId, String payeeId, Date startDate,
			Date endDate, Integer excludeAssignmentID, String table) {
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.selectCount();
		query.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, new Integer(drawId));
		query.newConstraint(table, "PayeeID", Constraint.Operator.Equals, payeeId);
		Join ongoingJoin = new Join(table, Join.Type.INNER);
		ongoingJoin.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, table, "TemplateID");
		query.joinWith(ongoingJoin);
		if (excludeAssignmentID != null) {
			query.newConstraint(table, "AssignmentID", Constraint.Operator.NotEquals, excludeAssignmentID);
		}

		OrClause orClause = new OrClause();
		Clause startDateOverlap = new AndClause();
		startDateOverlap.newConstraint(table, "StartDate", Constraint.Operator.GreaterThanEquals, startDate);
		startDateOverlap.newConstraint(table, "StartDate", Constraint.Operator.LessThanEquals, endDate);
		orClause.addConstraint(startDateOverlap);
		Clause endDateOverlap = new AndClause();
		endDateOverlap.newConstraint(table, "StartDate", Constraint.Operator.LessThanEquals, startDate);
		OrClause endDateClause = new OrClause();
		endDateClause.newConstraint(table, "EndDate", Constraint.Operator.GreaterThanEquals, startDate);
		endDateClause.newNullConstraint(table, "EndDate", true);
		endDateOverlap.addConstraint(endDateClause);
		orClause.addConstraint(endDateOverlap);
		query.addConstraint(orClause);
		return query;
	}

	public static QueryDefinition getHasOpenOngoingQuery(int drawId, String payeeId) {
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		Join ongoingJoin = new Join("DrawAssignmentOngoingTerm", Join.Type.INNER);
		ongoingJoin.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, "DrawAssignmentOngoingTerm",
				"TemplateID");
		query.joinWith(ongoingJoin);
		query.newConstraint("DrawTemplate", "BlockID", Constraint.Operator.Equals, new Integer(drawId));
		query.newNullConstraint("DrawAssignmentOngoingTerm", "EndDate", true);
		query.newConstraint("DrawAssignmentOngoingTerm", "PayeeID", Constraint.Operator.Equals, payeeId);
		query.selectCount();
		return query;
	}
}
