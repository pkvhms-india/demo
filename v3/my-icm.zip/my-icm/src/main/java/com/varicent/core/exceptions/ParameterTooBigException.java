package com.varicent.core.exceptions;

public class ParameterTooBigException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final String name;

	public ParameterTooBigException(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
