package com.varicent.draws.domain;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;

import com.varicent.core.text.Format;

public class PeriodAmount {
	private String oldAmount;
	private String newAmount;
	private boolean oldActivated;
	private boolean newActivated;
	private boolean locked;
	private String periodStart;
	private long rowVersion;

	public PeriodAmount() {
	}

	public PeriodAmount(BigDecimal amount, boolean activated, Date periodStart, boolean locked,
			NumberFormat currencyFormat, long rowVersion) {
		this.oldAmount = this.newAmount = currencyFormat.format(amount);
		this.oldActivated = this.newActivated = activated;
		this.periodStart = Format.asShortDate(periodStart);
		this.rowVersion = rowVersion;
		this.locked = locked;
	}

	public void updateOriginalValues() {
		this.oldActivated = this.newActivated;
		this.oldAmount = this.newAmount;
	}

	public boolean isDirty() {
		return this.hasActivationChanges() || this.hasAmountChanges();
	}

	public boolean hasActivationChanges() {
		return this.oldActivated != this.newActivated;
	}

	public boolean hasAmountChanges() {
		if (this.oldAmount != null && this.oldAmount.length() != 0) {
			return this.oldAmount.compareTo(this.newAmount) != 0;
		} else {
			return this.newAmount != null;
		}
	}

	public String getPeriodStart() {
		return this.periodStart;
	}

	public void setPeriodStart(String periodStart) {
		this.periodStart = periodStart;
	}

	public String getOldAmount() {
		return this.oldAmount;
	}

	public String getNewAmount() {
		return this.newAmount;
	}

	public boolean isOldActivated() {
		return this.oldActivated;
	}

	public boolean isNewActivated() {
		return this.newActivated;
	}

	public boolean isLocked() {
		return this.locked;
	}

	public void setOldAmount(String oldAmount) {
		this.oldAmount = oldAmount;
	}

	public void setNewAmount(String newAmount) {
		this.newAmount = newAmount;
	}

	public void setOldActivated(boolean oldActivated) {
		this.oldActivated = oldActivated;
	}

	public void setNewActivated(boolean newActivated) {
		this.newActivated = newActivated;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(long rowVersion) {
		this.rowVersion = rowVersion;
	}
}
