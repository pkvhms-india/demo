package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.NumericFormat;
import com.varicent.reporting.domain.ConditionalFormats;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class NumericScalarExpander extends BaseExpander {
	public NumericScalarExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("NumericScalarDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("NumericScalarDisplay")) {
			writer.writeStartElement("NumericScalarDisplay");
			this.streamReader.nextTag();
			super.copyCurrentNode(writer);
			String source = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String precisionString = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String numericStyle = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			ConditionalFormats formats = new ConditionalFormats();
			if (this.streamReader.getLocalName().equals("ConditionalFormats")) {
				this.streamReader.nextTag();

				while (this.streamReader.getEventType() == 1) {
					formats.addConditionalFormat(this.streamReader);
				}

				this.streamReader.nextTag();
			}

			if (this.streamReader.getLocalName().equals("Link")) {
				LinkExpander link = new LinkExpander(this.streamReader);
				link.read(writer, scope, permitted, editable);
			}

			BigDecimal value = new BigDecimal(0);
			if (!scope.isNull(source)) {
				value = scope.getDecimal(source);
				writer.writeStartElement("SourceName");
				writer.writeCharacters(source);
				writer.writeEndElement();
			}

			writer.writeStartElement("IsFromParameter");
			writer.writeCharacters(scope.isValFromScalarParameter(source) ? "true" : "false");
			writer.writeEndElement();
			NumericFormat format = formats.getNumericFormatWithValue(value);
			if (format == null) {
				int style = Integer.parseInt(numericStyle);
				int precision = Integer.parseInt(precisionString);
				format = new NumericFormat(style, precision);
			}

			String formattedValue = format.asString(value);
			writer.writeStartElement("SourceData");
			writer.writeCharacters(formattedValue);
			writer.writeEndElement();
			writer.writeStartElement("RawValue");
			writer.writeCharacters(value.toString());
			writer.writeEndElement();
			String styleName = formats.getConditionalStyle((DataTable) null, 0, scope);
			if (styleName == null) {
				super.copyCurrentNode(writer);
			} else {
				writer.writeStartElement("StyleName");
				writer.writeCharacters(styleName);
				writer.writeEndElement();
				XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			writer.writeStartElement("NumericStyle");
			writer.writeCharacters(String.valueOf(format.getStyle().ordinal()));
			writer.writeEndElement();
			writer.writeStartElement("Precision");
			writer.writeCharacters(String.valueOf(format.getScale()));
			writer.writeEndElement();
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
