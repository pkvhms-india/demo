package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

public class StylesExpander extends BaseExpander {
	public StylesExpander(XMLStreamReader stream) {
		super(stream);
	}

	public void expandStylesNode(XMLStreamWriter writer) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		this.expandStylesNode(sb);
		writer.writeCharacters(sb.toString());
	}

	public void expandStylesNode(StringBuilder sb) throws XMLStreamException {
		if (!this.streamReader.getLocalName().equals("styles")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			sb.append("<styles>");
			sb.append("<definition>");
			this.streamReader.nextTag();
			this.streamReader.nextTag();

			while (this.streamReader.getLocalName().equals("style")) {
				sb.append("<style ");
				String[] attributes = new String[8];
				attributes[0] = this.streamReader.getAttributeValue((String) null, "name");
				attributes[1] = this.streamReader.getAttributeValue((String) null, "type");
				attributes[2] = this.streamReader.getAttributeValue((String) null, "font");
				attributes[3] = this.streamReader.getAttributeValue((String) null, "size");
				attributes[4] = this.streamReader.getAttributeValue((String) null, "color");
				attributes[5] = this.streamReader.getAttributeValue((String) null, "bold");
				attributes[6] = this.streamReader.getAttributeValue((String) null, "italic");
				attributes[7] = this.streamReader.getAttributeValue((String) null, "underline");
				if (attributes[0] != null) {
					sb.append("name='" + attributes[0] + "' ");
				}

				if (attributes[1] != null) {
					sb.append("type='" + attributes[1] + "' ");
				}

				if (attributes[2] != null) {
					sb.append("font='" + attributes[2] + "' ");
				}

				if (attributes[3] != null) {
					sb.append("size='" + attributes[3] + "' ");
				}

				if (attributes[4] != null) {
					sb.append("color='" + attributes[4] + "' ");
				}

				if (attributes[5] != null) {
					sb.append("bold='" + attributes[5] + "' ");
				}

				if (attributes[6] != null) {
					sb.append("italic='" + attributes[6] + "' ");
				}

				if (attributes[7] != null) {
					sb.append("underline='" + attributes[7] + "' ");
				}

				sb.append("/>");
				this.streamReader.nextTag();
				this.streamReader.nextTag();
			}

			sb.append("</definition>");
			sb.append("<application>");
			this.streamReader.nextTag();
			this.streamReader.nextTag();

			while (this.streamReader.getLocalName().equals("apply")) {
				sb.append("<apply ");
				String[] attributes = new String[2];
				attributes[0] = this.streamReader.getAttributeValue((String) null, "toObject");
				attributes[1] = this.streamReader.getAttributeValue((String) null, "styles");
				if (attributes[0] != null) {
					sb.append("toObject='" + attributes[0] + "' ");
				}

				if (attributes[1] != null) {
					sb.append("styles='" + attributes[1] + "' ");
				}

				sb.append(" />");
				this.streamReader.nextTag();
				this.streamReader.nextTag();
			}

			this.streamReader.nextTag();
			sb.append("</application>");
			sb.append("</styles>");
		}
	}
}
