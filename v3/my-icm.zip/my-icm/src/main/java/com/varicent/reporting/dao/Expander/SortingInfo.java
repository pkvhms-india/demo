package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.varicent.reporting.domain.XMLStreamUtility;

public class SortingInfo {
	String timeID;
	String levelID;
	boolean sortDescending;

	public SortingInfo(String timeID, String levelID, boolean sortDes) {
		this.levelID = levelID;
		this.timeID = timeID;
		this.sortDescending = sortDes;
	}

	public static SortingInfo extract(XMLStreamReader streamReader) throws XMLStreamException {
		if (!streamReader.getLocalName().equals("SortingInfo")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			streamReader.nextTag();
			String timeID = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String levelID = XMLStreamUtility.getCurrentNodeValue(streamReader);
			boolean descending = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(streamReader));
			return new SortingInfo(timeID, levelID, descending);
		}
	}
}
