package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;

import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.Database;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.database.support.PortSourceMapper;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.util.Entry;
import com.varicent.customize.domain.CustomType;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.reporting.web.ReportingCommand;

public class PickListExpander extends BaseExpander {
	private final JdbcOperations operations;
	private ReportingCommand command;

	public PickListExpander(XMLStreamReader streamReader, DataSource ds, ReportingCommand command) {
		super(streamReader);
		this.operations = Database.getOperations(ds);
		this.command = command;
		if (!streamReader.getLocalName().equals("PickListControl")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	public PickListExpander(XMLStreamReader streamReader, DataSource ds) {
		super(streamReader);
		this.operations = Database.getOperations(ds);
		this.command = null;
		if (!streamReader.getLocalName().equals("PickListControl")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, DataAccessException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("PickListControl")) {
			String hideId = this.streamReader.getAttributeValue((String) null, "HideID");
			String sortColVal = this.streamReader.getAttributeValue((String) null, "SortByID");
			String sortVal = this.streamReader.getAttributeValue((String) null, "SortAscending");
			this.streamReader.nextTag();
			writer.writeStartElement("PickListControl");
			boolean isHideID = false;
			if (hideId != null) {
				writer.writeAttribute("HideID", hideId);
				isHideID = Boolean.parseBoolean(hideId);
			}

			String plName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String idColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String descColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String parameter = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String hideValueExport = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String styleName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			List<String> sourceParams = scope.getActionParameterDependency(sourceName);
			if (sourceName.startsWith("_Port") && scope.getPorts().containsKey(sourceName)) {
				sourceName = scope.getPorts().get(sourceName).getSourceTable();
			}

			String sortCol = sortColVal != null && sortColVal.equals("false") ? descColumn : idColumn;
			boolean sortDescending = sortVal != null && sortVal.equals("false");
			List<SelectOption> options = getOptions(scope, sourceName, idColumn, descColumn, this.operations, sortCol,
					sortDescending, false);
			writer.writeStartElement("SourceData");
			List<Entry<String, String>> idColumnValues = new ArrayList();
			int i = 0;

			for (int n = options.size(); i < n; ++i) {
				String value = options.get(i).getValue();
				String name = options.get(i).getName();
				idColumnValues.add(new Entry(value, name));
				writer.writeStartElement("ID");
				writer.writeStartElement("Name");
				writer.writeCharacters(name);
				writer.writeEndElement();
				writer.writeStartElement("Value");
				writer.writeCharacters(value);
				writer.writeEndElement();
				writer.writeStartElement("StyleName");
				writer.writeCharacters(styleName);
				writer.writeEndElement();
				writer.writeEndElement();
			}

			if (this.command != null && sourceName != null && this.command.getUsesPayeeTable(sourceName)) {
				this.command.setPayeePicklistCount(this.command.getPayeePicklistCount() + 1);
				this.command.setPayeePicklistIDs(idColumnValues);
				this.command.setPayeePicklistParameter(parameter);
			}

			writer.writeEndElement();
			String paramAsId = scope.getString(parameter);
			String paramAsName = options.size() == 0 ? null : "";

			for (SelectOption o : options) {
				if (o.getValue().equals(paramAsId)) {
					paramAsName = o.getName();
					break;
				}
			}

			writer.writeStartElement("ParameterValue");
			if (paramAsId != null) {
				writer.writeCharacters(paramAsId);
			}

			writer.writeEndElement();
			writer.writeStartElement("ParameterDisplay");
			if (paramAsName != null) {
				if (isHideID) {
					writer.writeCharacters(paramAsName);
				} else {
					String charsToWrite;
					if (paramAsId != null && paramAsId.isEmpty() && paramAsName.isEmpty()) {
						charsToWrite = "";
					} else {
						charsToWrite = String.format("(%s) %s", paramAsId, paramAsName);
					}

					writer.writeCharacters(charsToWrite);
				}
			}

			writer.writeEndElement();
			writer.writeStartElement("Parameter");
			writer.writeCharacters("P_" + parameter);
			writer.writeEndElement();
			writer.writeStartElement("HideValueForExport");
			writer.writeCharacters(hideValueExport);
			writer.writeEndElement();
			writer.writeStartElement("ReadOnly");
			writer.writeCharacters(editable ? "0" : "1");
			writer.writeEndElement();
			writer.writeStartElement("StyleName");
			writer.writeCharacters(styleName);
			writer.writeEndElement();
			writer.writeStartElement("PLName");
			writer.writeCharacters(plName);
			writer.writeEndElement();
			writer.writeStartElement("SourceTable");
			writer.writeCharacters(sourceName == null ? "" : sourceName);
			writer.writeEndElement();
			writer.writeStartElement("SourceIDColumn");
			writer.writeCharacters(idColumn);
			writer.writeEndElement();
			writer.writeStartElement("SourceNameColumn");
			writer.writeCharacters(descColumn);
			writer.writeEndElement();
			writer.writeStartElement("SortCol");
			writer.writeCharacters(sortCol);
			writer.writeEndElement();
			writer.writeStartElement("SortDescending");
			writer.writeCharacters(sortDescending ? "true" : "false");
			writer.writeEndElement();
			writer.writeStartElement("HideId");
			writer.writeCharacters(hideId == null ? "false" : "true");
			writer.writeEndElement();
			HashSet<String> paramNames = new HashSet(scope.getParameterNames());
			if (sourceParams != null && sourceParams.size() > 0) {
				for (String si : sourceParams) {
					if (!si.equals("WebUser_") && !si.equals("Current Date") && paramNames.contains(si)) {
						writer.writeStartElement("SourceParam");
						if (scope.hasString(si)) {
							writer.writeAttribute("DefaultValue",
									scope.getString(si) == null ? "" : scope.getString(si));
						}

						writer.writeCharacters(si);
						writer.writeEndElement();
					}

					if (scope.getActionParameterDependency(si) != null) {
						for (String a : scope.getActionParameterDependency(si)) {
							if (paramNames.contains(a)) {
								writer.writeStartElement("SourceParam");
								writer.writeCharacters(a);
								writer.writeEndElement();
							}
						}
					}
				}
			}

			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}

	public static List<SelectOption> getOptions(Scope scope, String sourceName, String idColumn, String descColumn,
			JdbcOperations operations, String sortCol, boolean sortDescending, boolean includeStatus)
			throws DataAccessException, ReportOverLimitException {
		List<SelectOption> options = new ArrayList();
		if (sourceName != null && !sourceName.equals("")) {
			boolean useDescription = sortCol.equals(descColumn);
			boolean useNumeric = false;
			boolean rowLimitReached = false;
			boolean hasDataTable = false;

			try {
				hasDataTable = scope.hasDataTable(sourceName);
			} catch (ReportOverLimitException var16) {
				rowLimitReached = true;
			}

			if (!hasDataTable && !rowLimitReached) {
				QueryBuilder qb = Database.getQueryBuilder();
				QueryDefinition query = new QueryDefinition(sourceName);
				query.select(sourceName, idColumn);
				query.select(sourceName, descColumn);
				query = PortSourceMapper.mapQuery(query, scope.getPorts(), scope.getPortResolver());
				options = operations.query(qb.toSql(query), RowMapperUtil.getOptionMapper());
				useNumeric = ColumnDefinition.getColumnCustomType(sourceName, sortCol,
						operations) == CustomType.NUMERIC;
			} else {
				DataTable dataTable = scope.getDataTable(sourceName);

				for (DataRow row : dataTable.getRows()) {
					options.add(new SelectOption(row.getValue(dataTable.getColumnIndex(descColumn)),
							row.getValue(dataTable.getColumnIndex(idColumn))));
				}

				useNumeric = dataTable.getColumn(sortCol).isNumeric();
			}

			Collections.sort(options, new SelectOptionComparator(useDescription, useNumeric));
			if (sortDescending) {
				Collections.reverse(options);
			}

			if (includeStatus) {
				options.add(0, new SelectOption("_RowLimitReached", rowLimitReached ? "true" : "false"));
			}

			return options;
		} else {
			return options;
		}
	}
}
