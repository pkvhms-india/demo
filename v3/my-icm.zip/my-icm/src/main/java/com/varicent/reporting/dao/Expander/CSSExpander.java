package com.varicent.reporting.dao.Expander;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class CSSExpander {
	StringBuilder m_sb;

	public CSSExpander(XMLStreamReader stream) throws XMLStreamException {
		String StyleNamePrefix = ".DisplayStyle";
		String StyleNamePrefixTD = "td";
		String StyleNameSuffixOdd = "_Odd";
		String StyleNameSuffixEven = "_Even";
		String StyleNameSuffixInput = "input";
		String PatternFormat = String.format("(%s|)%s[0-9]*(%s|%s|) %s", "td", ".DisplayStyle", "_Odd", "_Even",
				"input");
		String PickList = "select";
		this.m_sb = new StringBuilder();
		stream.next();

		for (Pattern patternUsed = Pattern.compile(PatternFormat); stream.getEventType() == 4; stream.next()) {
			String txt = stream.getText();
			Matcher m = patternUsed.matcher(txt);
			if (m.find()) {
				this.m_sb.append(txt.substring(0, m.end()) + ", "
						+ txt.substring(m.start(), m.end()).replace("input", "select") + txt.substring(m.end()));
			} else {
				this.m_sb.append(txt);
			}
		}

		stream.nextTag();
	}

	public String getStyle() {
		return this.m_sb.toString();
	}
}
