package com.varicent.core.math.expressions;

import java.math.BigDecimal;

public class Assignable {
	private String name;
	private NodeNumber valueNode;

	protected Assignable(String Name, String alias, int suffix) {
		this.name = Name;
		this.valueNode = new NodeNumber(new BigDecimal(0), alias, suffix);
	}

	public String getName() {
		return this.name;
	}

	public EvaluateNode getNode() {
		return this.valueNode;
	}

	protected void setNumericValue(BigDecimal value) {
		this.valueNode.setValue(value);
	}
}
