package com.varicent.BPM.domain;

import com.varicent.common.query.domain.SourceDefinition;

public class BPMSwimLane {
	private int swimLaneID;
	private int workflowID;
	private String name;
	private boolean systemLane;
	private boolean firstUserLane;
	private boolean byRestriction;
	private SourceDefinition memberDefinition;
	private String[] payeeIDs;

	public BPMSwimLane(int swimLaneID, int workflowID, String name, boolean systemLane, boolean firstUserLane,
			boolean byRestriction, SourceDefinition memberDefinition, String[] payeeIDs) {
		this.swimLaneID = swimLaneID;
		this.workflowID = workflowID;
		this.name = name;
		this.systemLane = systemLane;
		this.firstUserLane = firstUserLane;
		this.byRestriction = byRestriction;
		this.memberDefinition = memberDefinition;
		this.payeeIDs = payeeIDs;
	}

	public String[] getPayeeIDs() {
		return this.payeeIDs;
	}

	public void setPayeeIDs(String[] payeeIDs) {
		this.payeeIDs = payeeIDs;
	}

	public int getSwimLaneID() {
		return this.swimLaneID;
	}

	public int getWorkflowID() {
		return this.workflowID;
	}

	public String getName() {
		return this.name;
	}

	public boolean isSystemLane() {
		return this.systemLane;
	}

	public boolean isFirstUserLane() {
		return this.firstUserLane;
	}

	public boolean isByRestriction() {
		return this.byRestriction;
	}

	public SourceDefinition getMemberDefinition() {
		return this.memberDefinition;
	}
}
