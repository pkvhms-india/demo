package com.varicent.customize.service;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.PeriodLockedException;
import com.varicent.customize.domain.CustomColumn;
import com.varicent.customize.domain.EditRow;

public interface CustomizeManager {
	List<CustomColumn> getColumns(String var1);

	List<DataRow> getData(String var1, List<String> var2);

	List<EditRow> getPendingRows(String var1, List<String> var2);

	Set<String> getViewableTables();

	void submitInsert(String var1, List<String> var2) throws DataSubmitException, PeriodLockedException;

	void submitUpdate(String var1, List<String> var2, List<String> var3) throws DataSubmitException;

	boolean isDateValidForTable(String var1, Date var2, String var3);
}
