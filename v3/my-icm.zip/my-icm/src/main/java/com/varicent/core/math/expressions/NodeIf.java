package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.util.Assert;

public class NodeIf extends JavascriptNode implements EvaluateNode {
	private EvaluateNode condition;
	private EvaluateNode trueExpr;
	private EvaluateNode falseExpr;

	public NodeIf(List<EvaluateNode> args, int suffix) {
		super(suffix);
		Assert.state(args.size() == 3);
		this.condition = args.get(0);
		this.trueExpr = args.get(1);
		this.falseExpr = args.get(2);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal test = this.condition.evaluate();
		BigDecimal trueValue = this.trueExpr.evaluate();
		BigDecimal falseValue = this.falseExpr.evaluate();
		return test.compareTo(new BigDecimal(0)) == 0 ? falseValue : trueValue;
	}

	@Override
	public void reset() {
		this.condition.reset();
		this.trueExpr.reset();
		this.falseExpr.reset();
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function");
		sb.append(" ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(((JavascriptNode) this.condition).getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.trueExpr).getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.falseExpr).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.condition).toJavascript(jsUtil));
		sb.append(((JavascriptNode) this.trueExpr).toJavascript(jsUtil));
		sb.append(((JavascriptNode) this.falseExpr).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "ifFunc";
	}
}
