package com.varicent.payeeledger.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.varicent.core.text.NumericFormat;

public class TraceReport extends Report {
	private final String payeeTable;
	private final String payeeColumn;
	private final String timeLevel;
	private final String resetLevel;
	private final String sourceTable;
	private final int reportTraceDataID;
	private final String traceTable;
	private final int keyColumns;
	private final List<DisplayColumn> displayColumns;
	private final List<String> resultColumns;

	public TraceReport(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, String sourceTable, String payeeTable, String payeeColumn, String timeLevel,
			String resetLevel, int reportTraceDataID, String traceTable, int keyColumns,
			List<DisplayColumn> displayColumns, List<String> resultColumns, boolean showHeader,
			boolean showPriorPeriods, boolean suppressEmptyReports, boolean suppressSummary) {
		super(reportId, calculationId, name, resultName, calendar, format, showHeader, showPriorPeriods,
				suppressEmptyReports, suppressSummary);
		this.sourceTable = sourceTable;
		this.payeeTable = payeeTable;
		this.payeeColumn = payeeColumn;
		this.timeLevel = timeLevel;
		this.resetLevel = resetLevel;
		this.reportTraceDataID = reportTraceDataID;
		this.traceTable = traceTable;
		this.keyColumns = keyColumns;
		this.displayColumns = new ArrayList(displayColumns);
		this.resultColumns = new ArrayList(resultColumns);
	}

	public List<DisplayColumn> getDisplayColumns() {
		return Collections.unmodifiableList(this.displayColumns);
	}

	public int getKeyColumns() {
		return this.keyColumns;
	}

	public int getOperatorColumnCount() {
		int count = 0;

		for (DisplayColumn column : this.displayColumns) {
			if (column.getOperator() != DisplayColumn.Operator.NONE) {
				break;
			}

			++count;
		}

		return this.displayColumns.size() - count;
	}

	public List<String> getResultColumns() {
		return this.resultColumns;
	}

	public String getPayeeColumn() {
		return this.payeeColumn;
	}

	public String getPayeeTable() {
		return this.payeeTable;
	}

	public String getResetLevel() {
		return this.resetLevel;
	}

	public String getSourceTable() {
		return this.sourceTable;
	}

	public String getTimeLevel() {
		return this.timeLevel;
	}

	public String getTraceSourceTable() {
		return "_TraceSource" + this.reportTraceDataID;
	}

	public String getTraceTable() {
		return this.traceTable;
	}

	public boolean hasPayeeColumn() {
		return this.payeeColumn != null;
	}

	public class Table {
		public static final String TRACE_SOURCE_PREFIX = "_TraceSource";
	}

	public class ColumnPrefixes {
		public static final String DISPLAY = "_Display";
		public static final String KEY = "_Key";
		public static final String SOURCE = "_Src_";
		public static final String TRACE = "_Trace_";
	}
}
