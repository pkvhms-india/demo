package com.varicent.BPM.domain;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SourceDefinition;

public class GenerateBPMHistoryDataStore {
	public static SourceDefinition GenerateBPMHistoryDS() {
		QueryDefinition query = new QueryDefinition("BPMNodeHistory");
		query.select("BPMWorkflow", "Name", "Workflow_");
		query.select("BPMNodeHistory", "NodeName", "NodeName_");
		query.select("BPMNodeHistory", "Initiator", "Initiator_");
		query.select("BPMNodeHistory", "Actor", "Actor_");
		query.select("BPMNodeHistory", "Action", "Action_");
		query.select("BPMNodeHistory", "DateActioned", "DateActioned_");
		query.select("BPMNodeHistory", "IsForcedBy", "IsForcedBy_");
		Join join = new Join("BPMWorkflow", Join.Type.INNER);
		join.newConstraint("BPMNodeHistory", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow", "WorkflowID");
		query.joinWith(join);
		SourceDefinition sd = new SourceDefinition(query);
		return sd;
	}

	public static Integer GetID() {
		return -1;
	}
}
