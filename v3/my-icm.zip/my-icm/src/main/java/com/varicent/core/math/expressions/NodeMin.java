package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeMin extends PolyNode implements EvaluateNode {
	public NodeMin(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal min = this.args.get(0).evaluate();

		for (int i = 1; i < this.args.size(); ++i) {
			BigDecimal value = this.args.get(i).evaluate();
			if (min == null || value != null && value.compareTo(min) < 0) {
				min = value;
			}
		}

		return min;
	}

	@Override
	public void reset() {
		for (EvaluateNode arg : this.args) {
			arg.reset();
		}

	}

	@Override
	public String getJSMathFunctionName() {
		return "min";
	}
}
