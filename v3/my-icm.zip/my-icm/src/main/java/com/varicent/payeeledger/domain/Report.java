package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;

public abstract class Report {
	private final int reportId;
	private final int calculationId;
	private final String name;
	private final String resultName;
	private final String calendar;
	private final NumericFormat format;
	private final boolean showHeader;
	private final boolean showPriorPeriods;
	private final boolean suppressEmptyReports;
	private final boolean suppressSummary;
	private ReportTheme theme;

	public Report(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, boolean showHeader, boolean showPriorPeriods, boolean suppressEmptyReports,
			boolean suppressSummary) {
		this.reportId = reportId;
		this.calculationId = calculationId;
		this.name = name;
		this.resultName = resultName;
		this.calendar = calendar;
		this.format = format;
		this.showHeader = showHeader;
		this.showPriorPeriods = showPriorPeriods;
		this.suppressEmptyReports = suppressEmptyReports;
		this.suppressSummary = suppressSummary;
	}

	public int getCalculationId() {
		return this.calculationId;
	}

	public String getCalendar() {
		return this.calendar;
	}

	public NumericFormat getFormat() {
		return this.format;
	}

	public String getName() {
		return this.name;
	}

	public int getReportId() {
		return this.reportId;
	}

	public String getResultName() {
		return this.resultName;
	}

	public ReportTheme getTheme() {
		return this.theme;
	}

	public boolean hasTimePartition() {
		return this.calendar != null;
	}

	public void setTheme(ReportTheme theme) {
		this.theme = theme;
	}

	public boolean showHeader() {
		return this.showHeader;
	}

	public boolean showPriorPeriods() {
		return this.showPriorPeriods;
	}

	public boolean suppressEmptyReports() {
		return this.suppressEmptyReports;
	}

	public boolean suppressSummary() {
		return this.suppressSummary;
	}
}
