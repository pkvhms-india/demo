package com.varicent.draws.domain;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.varicent.core.text.Format;

public class DrawAssignmentFixedTerm {
	private int assignmentId;
	private String payeeId;
	private String payeeName;
	private String startPeriod;
	private String newStartDateFormatted;
	private String oldStartDateFormatted;
	private boolean unassigned;
	private int templateId;
	private String templateName;
	private String timeId;
	private String level;
	private String defaultAmount;
	private List<PeriodAmount> periodAmounts;
	private long rowVersion;
	private boolean active;
	private boolean lockedStartDate;
	private boolean fixedDuration;
	private boolean fixedAmount;

	public DrawAssignmentFixedTerm() {
	}

	public DrawAssignmentFixedTerm(int assignmentId, String payeeId, String payeeName, String startPeriod,
			Date startDate, int templateId, String templateName, String timeId, String level, BigDecimal defaultAmount,
			boolean active, boolean lockedStartDate, boolean fixedDuration, boolean fixedAmount, long rowVersion,
			NumberFormat currencyFormat) {
		this.assignmentId = assignmentId;
		this.payeeId = payeeId;
		this.payeeName = payeeName;
		this.startPeriod = startPeriod;
		this.newStartDateFormatted = this.oldStartDateFormatted = Format.asShortDate(startDate);
		this.templateId = templateId;
		this.templateName = templateName;
		this.timeId = timeId;
		this.level = level;
		this.rowVersion = rowVersion;
		this.active = active;
		this.fixedDuration = fixedDuration;
		this.lockedStartDate = lockedStartDate;
		this.fixedAmount = fixedAmount;
		this.defaultAmount = defaultAmount == null ? null : currencyFormat.format(defaultAmount);
		this.periodAmounts = new LinkedList();
	}

	public void updateOriginalValues() {
		this.oldStartDateFormatted = this.newStartDateFormatted;

		for (PeriodAmount amount : this.periodAmounts) {
			if (amount != null) {
				amount.updateOriginalValues();
			}
		}

	}

	public long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public int getPeriodAmountCount() {
		return this.periodAmounts.size();
	}

	public int getLastActivePeriodIndex() {
		return this.calculateOldPeriodCount();
	}

	public int getLastLockedPeriodIndex() {
		int count = 0;
		if (this.periodAmounts == null) {
			return count;
		} else {
			Iterator i$ = this.periodAmounts.iterator();
			if (i$.hasNext()) {
				PeriodAmount periodAmount = (PeriodAmount) i$.next();
				if (periodAmount.isLocked()) {
					++count;
				}

				return count;
			} else {
				return 0;
			}
		}
	}

	public String getTimeId() {
		return this.timeId;
	}

	public String getDefaultAmount() {
		return this.defaultAmount;
	}

	public void setDefaultAmount(String defaultAmount) {
		this.defaultAmount = defaultAmount;
	}

	public String getLevel() {
		return this.level;
	}

	public void setTimeId(String timeId) {
		this.timeId = timeId;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public boolean isDirty() {
		return this.hasStartDateChange() || this.hasPeriodAmountChanges();
	}

	private boolean hasPeriodAmountChanges() {
		if (this.periodAmounts == null) {
			return false;
		} else {
			for (PeriodAmount periodAmount : this.periodAmounts) {
				if (periodAmount.isDirty()) {
					return true;
				}
			}

			return false;
		}
	}

	public boolean hasStartDateChange() {
		return this.oldStartDateFormatted.compareTo(this.newStartDateFormatted) != 0;
	}

	public int calculateOldPeriodCount() {
		int count = 0;
		if (this.periodAmounts == null) {
			return count;
		} else {
			for (PeriodAmount periodAmount : this.periodAmounts) {
				if (periodAmount.isOldActivated()) {
					++count;
				}
			}

			return count;
		}
	}

	public int calculateNewPeriodCount() {
		int count = 0;
		if (this.periodAmounts == null) {
			return 0;
		} else {
			for (PeriodAmount periodAmount : this.periodAmounts) {
				if (periodAmount.isNewActivated()) {
					++count;
				}
			}

			return count;
		}
	}

	public int getAssignmentId() {
		return this.assignmentId;
	}

	public String getPayeeId() {
		return this.payeeId;
	}

	public String getPayeeName() {
		return this.payeeName;
	}

	public String getStartPeriod() {
		return this.startPeriod;
	}

	public void setNewStartDateFormatted(String date) {
		this.newStartDateFormatted = date;
	}

	public void setOldStartDateFormatted(String date) {
		this.oldStartDateFormatted = date;
	}

	public String getNewStartDateFormatted() {
		return this.newStartDateFormatted;
	}

	public String getOldStartDateFormatted() {
		return this.oldStartDateFormatted;
	}

	public boolean isUnassigned() {
		return this.unassigned;
	}

	public int getTemplateId() {
		return this.templateId;
	}

	public String getTemplateName() {
		return this.templateName;
	}

	public List<PeriodAmount> getPeriodAmounts() {
		return this.periodAmounts;
	}

	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}

	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public void setStartPeriod(String startPeriod) {
		this.startPeriod = startPeriod;
	}

	public void setUnassigned(boolean unassigned) {
		this.unassigned = unassigned;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public void setPeriodAmounts(List<PeriodAmount> periodAmounts) {
		this.periodAmounts = periodAmounts;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isLockedStartDate() {
		return this.lockedStartDate;
	}

	public boolean isFixedDuration() {
		return this.fixedDuration;
	}

	public void setLockedStartDate(boolean lockedStartDate) {
		this.lockedStartDate = lockedStartDate;
	}

	public void setFixedDuration(boolean fixedDuration) {
		this.fixedDuration = fixedDuration;
	}

	public boolean isFixedAmount() {
		return this.fixedAmount;
	}

	public void setFixedAmount(boolean fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
}
