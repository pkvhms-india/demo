package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;

public class ResultReport extends Report {
	private final String resultTable;
	private final String payeeColumn;

	public ResultReport(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, String resultTable, String payeeColumn, boolean showHeader, boolean showPriorPeriods,
			boolean suppressEmptyReports, boolean suppressSummary) {
		super(reportId, calculationId, name, resultName, calendar, format, showHeader, showPriorPeriods,
				suppressEmptyReports, suppressSummary);
		this.resultTable = resultTable;
		this.payeeColumn = payeeColumn;
	}

	public String getPayeeColumn() {
		return this.payeeColumn;
	}

	public String getResultTable() {
		return this.resultTable;
	}

	public boolean hasPayeeColumn() {
		return this.payeeColumn != null;
	}
}
