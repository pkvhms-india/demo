package com.varicent.customize.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.PeriodLockedException;
import com.varicent.customize.service.CustomizeManager;

@Controller("customizeInsertController")
@RequestMapping({ "/dataedit/add.do" })
public class InsertController extends EditController {
	@Autowired
	public InsertController(CustomizeManager customizeManager, CustomizeValidator validator) {
		super(customizeManager, validator);
	}

	@Override
	protected void submitEdit(CustomizeCommand cmd, BindingResult result)
			throws DataSubmitException, PeriodLockedException {
		try {
			if (!result.hasErrors() && cmd.checkAndUpdateToken()) {
				this.customizeManager.submitInsert(cmd.getTable(), cmd.getFilterValues());
			}
		} finally {
			cmd.clear();
		}

	}
}
