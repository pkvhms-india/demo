package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeMax extends PolyNode implements EvaluateNode {
	public NodeMax(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal max = this.args.get(0).evaluate();

		for (int i = 1; i < this.args.size(); ++i) {
			BigDecimal value = this.args.get(i).evaluate();
			if (max == null || value != null && value.compareTo(max) > 0) {
				max = value;
			}
		}

		return max;
	}

	@Override
	public void reset() {
		for (EvaluateNode arg : this.args) {
			arg.reset();
		}

	}

	@Override
	public String getJSMathFunctionName() {
		return "max";
	}
}
