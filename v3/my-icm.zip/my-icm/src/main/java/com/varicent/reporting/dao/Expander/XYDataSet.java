package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class XYDataSet {
	private String series;
	private String color;
	List<XYSet> sets;
	private ColumnLink link;
	private boolean isPercentage;
	private String xCol;
	private String yCol;

	public XYDataSet(String series, String xColumn, String yColumn, ColumnLink link) {
		this.series = series;
		this.color = null;
		this.sets = new ArrayList();
		this.xCol = xColumn;
		this.yCol = yColumn;
		this.link = link;
	}

	public String getYColumn() {
		return this.yCol;
	}

	public String getXColumn() {
		return this.xCol;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setLink(ColumnLink link) {
		this.link = link;
	}

	public String getName() {
		return this.series;
	}

	public void setPercentage(boolean isPerc) {
		this.isPercentage = isPerc;
	}

	public void add(String x, String y) {
		this.sets.add(new XYSet(x, y));
	}

	public void writeStartElements(XMLStreamWriter writer) throws XMLStreamException {
		if (this.color == null) {
			writer.writeCharacters("<dataset seriesName='" + this.series + "' >");
		} else {
			writer.writeCharacters("<dataset seriesName='" + this.series + "' color='" + this.color + "' >");
		}

	}

	public void writeSet(XMLStreamWriter writer, int index, DataTable data, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.sets.get(index).writeSet(writer, index, data, scope, this.link, this.series, this.isPercentage);
	}

	public void writeEndElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</dataset>");
	}
}
