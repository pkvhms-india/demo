package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

public class NodeGroupAvg extends UnaryNode implements EvaluateNode, AggregateNode {
	private BigDecimal total = null;
	private BigDecimal count;
	private boolean isFinalized;
	private BigDecimal currentValue;

	public NodeGroupAvg(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
		this.count = BigDecimal.ZERO;
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.currentValue;
		} else {
			BigDecimal value = this.arg.evaluate();
			if (value != null) {
				if (this.total == null) {
					this.total = value;
				} else {
					this.total = this.total.add(value);
				}

				this.count = this.count.add(BigDecimal.ONE);
			}

			if (this.count == BigDecimal.ZERO) {
				this.currentValue = null;
			} else {
				this.currentValue = this.total.divide(this.count, new MathContext(28));
			}

			return this.currentValue;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.arg.reset();
			this.total = null;
			this.count = BigDecimal.ZERO;
		}
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append(JavascriptUtil.getFunctionSigniture(this.getJSFunctionName(jsUtil)));
		sb.append("if(");
		sb.append(this.getJSCountName(jsUtil));
		sb.append("  === undefined) {");
		sb.append(this.getJSCountName(jsUtil));
		sb.append(" = 0;}");
		sb.append("if(");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(" !== undefined) {");
		sb.append(this.getJSCountName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSCountName(jsUtil));
		sb.append(" + 1; }");
		sb.append(this.getJSTotalName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSTotalFunctionName());
		sb.append("(");
		sb.append(this.getJSTotalName(jsUtil));
		sb.append(" , ");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSCountName(jsUtil));
		sb.append(" , ");
		sb.append(this.getJSTotalName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupAvg";
	}

	public String getJSCountName(JavascriptUtil jsUtil) {
		return jsUtil.getCountPrefix() + this.getSuffix();
	}

	public String getJSTotalName(JavascriptUtil jsUtil) {
		return jsUtil.getTotalPrefix() + this.getSuffix();
	}

	private String getJSTotalFunctionName() {
		return "total";
	}
}
