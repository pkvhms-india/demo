package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.reporting.dao.jdbc.ExpandedXml;
import com.varicent.reporting.domain.Scope;

public class HtmlSnippetExpander extends BaseExpander {
	public HtmlSnippetExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("HtmlSnippet")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable) {
		if (this.streamReader.getLocalName().equals("HtmlSnippet")) {
			this.copyCurrentNodeAddStack(writer, scope);
		}
	}

	private int copyCurrentNodeAddStack(XMLStreamWriter writer, Scope scope) {
		try {
			if (this.streamReader.getEventType() != 1) {
				return 0;
			} else {
				int length = 0;
				String nodeName = this.streamReader.getLocalName();
				writer.writeStartElement(nodeName);
				length += nodeName.length();
				int i = 0;

				for (int n = this.streamReader.getAttributeCount(); i < n; ++i) {
					String attribName = this.streamReader.getAttributeLocalName(i);
					String attribValue = this.streamReader.getAttributeValue(i);
					writer.writeAttribute(attribName, attribValue);
					length += 1 + attribName.length() + 1 + attribValue.length();
				}

				this.streamReader.next();
				if (this.streamReader.isWhiteSpace()) {
					this.streamReader.nextTag();
				}

				while (this.streamReader.getEventType() == 1) {
					length += this.copyCurrentNodeAddStack(writer, scope);
					if (this.streamReader.isWhiteSpace()) {
						this.streamReader.nextTag();
					}
				}

				String xmlText = "";

				while (this.streamReader.getEventType() == 4) {
					xmlText = xmlText + this.streamReader.getText();
					this.streamReader.next();
				}

				if (!xmlText.equals("")) {
					length = this.setUpLayoutStack(xmlText, scope, length, writer);
				}

				if (this.streamReader.getEventType() == 2) {
					writer.writeEndElement();
					length += 3 + nodeName.length();
				}

				this.streamReader.next();
				return length;
			}
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	private int setUpLayoutStack(String xmlTextAll, Scope scope, int length, XMLStreamWriter writer)
			throws XMLStreamException {
		String[] xmlTextArray = xmlTextAll.split("<");

		for (String xmlText : xmlTextArray) {
			if (xmlText.contains("/TABLE")) {
				scope.popLayoutStack();
			}

			String layoutTable = "_LayoutPlaceholder";
			int hasId = xmlText.indexOf("id =");
			if ((xmlText.startsWith("TABLE") || xmlText.contains("<TABLE")) && xmlText.contains("layoutTable")) {
				if (hasId > 0) {
					String shortXmlText = xmlText.substring(hasId + "id =".length() + 2);
					layoutTable = shortXmlText.substring(0, shortXmlText.indexOf("\""));
				}

				scope.addLayoutToStack(layoutTable);
			}

			if (!ExpandedXml.checkViewPermission(scope.getLayoutStack(), scope.getViewableMap())
					&& xmlText.startsWith("TD") && xmlText.indexOf("border-") != -1) {
				xmlText = xmlText.substring(0, xmlText.lastIndexOf(";") + 1) + "border:none;" + "\"";
			}

			if (xmlText.length() > 0) {
				String toWrite = "<" + xmlText;
				writer.writeCharacters(toWrite);
				length += toWrite.length();
				if (!xmlText.endsWith(">")) {
					writer.writeCharacters(">");
					++length;
				}
			}
		}

		return length;
	}
}
