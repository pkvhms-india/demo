package com.varicent.core.text;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.validator.routines.BigDecimalValidator;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.Constants;

public class Parse {
	private static final DateTimeFormatter DATE_FORMAT_ISO = ISODateTimeFormat.date();
	private static final DateTimeFormatter DATE_FORMAT_US;
	private static final DateTimeFormatter DATE_FORMAT_EU;
	private static final String DateSeperatorPattern = "[/\\-\\.]\\s?";
	private static final String DateDigitPattern = "(\\d+)";
	private static final String DateSeperatorAndDigitPattern = "[/\\-\\.]\\s?(\\d+)";
	private static final Pattern DATE_PATTERN;

	public static Date date(String value) {
		Matcher matcher = DATE_PATTERN.matcher(value.trim());
		if (!matcher.matches()) {
			return null;
		} else {
			String g1 = matcher.group(1);
			String g2 = matcher.group(2);
			String g3 = matcher.group(4);
			if (g3 == null) {
				g3 = Integer.toString(Calendar.getInstance().get(1));
			}

			String dateEntered = g1 + "/" + g2 + "/" + g3;
			DateTime date;
			if (g1.length() == 4) {
				date = tryISODate(value.trim());
				if (date == null) {
					date = tryISODate(dateEntered.trim());
				}

				if (date == null) {
					date = tryLocaleDate(value.trim());
				}
			} else {
				date = tryLocaleDate(value.trim());
				if (date == null) {
					date = tryLocaleDate(dateEntered.trim());
				}
			}

			if (date == null) {
				return null;
			} else {
				GregorianCalendar calendar = new GregorianCalendar(date.getYear(), date.getMonthOfYear() - 1,
						date.getDayOfMonth(), 0, 0, 0);
				return calendar.getTime();
			}
		}
	}

	public static BigDecimal parseDecimal(String value, boolean isInInvariantCulture) {
		try {
			if (isInInvariantCulture) {
				if (BigDecimalValidator.getInstance().isValid(value)) {
					return new BigDecimal(value);
				}
			} else {
				Locale locale = LocaleContextHolder.getLocale();
				if (locale.getLanguage() == Locale.FRANCE.getLanguage() && value != null) {
					value = value.replace(' ', ' ');
				}

				if (BigDecimalValidator.getInstance().isValid(value, locale)) {
					DecimalFormat localizedFormat = (DecimalFormat) NumberFormat.getNumberInstance(locale);
					localizedFormat.setParseBigDecimal(true);
					ParsePosition start = new ParsePosition(0);
					BigDecimal parseResult = (BigDecimal) localizedFormat.parse(value, start);
					if (start.getIndex() == value.length()) {
						return parseResult;
					}
				}
			}
		} catch (NumberFormatException var6) {
		}

		return null;
	}

	public static BigDecimal parseCurrency(String value, NumberFormat currencyFormat) {
		DecimalFormat format = (DecimalFormat) currencyFormat;
		format.setParseBigDecimal(true);
		ParsePosition start = new ParsePosition(0);
		BigDecimal parseResult = (BigDecimal) format.parse(value, start);
		return parseResult != null && start.getIndex() == value.length() ? parseResult : null;
	}

	public static double parsePercentage(String value) {
		if (value.endsWith("%")) {
			value = value.substring(0, value.length() - 1);
		}

		if (value.length() == 0) {
			return Double.NaN;
		} else {
			double toReturn;
			try {
				toReturn = Double.parseDouble(value) / 100.0F;
			} catch (Exception var4) {
				toReturn = Double.NaN;
			}

			return toReturn;
		}
	}

	public static DateTime tryISODate(String value) {
		DateTime date;
		try {
			date = DATE_FORMAT_ISO.withZone(DateTimeZone.UTC).parseDateTime(value);
		} catch (Exception var3) {
			date = null;
		}

		if (date != null && !isValidDateRange(date)) {
			date = null;
		}

		return date;
	}

	public static DateTime tryLocaleDate(String value) {
		DateTime date;
		try {
			DateTimeFormatter currentFormat = DateTimeFormat
					.forPattern(DateTimeFormat.patternForStyle("S-", LocaleContextHolder.getLocale()));
			if (LocaleContextHolder.getLocale().getLanguage() == Locale.KOREA.getLanguage() && !value.contains(" ")) {
				value = value.replace(".", ". ");
			}

			date = currentFormat.withZone(DateTimeZone.UTC).parseDateTime(value);
		} catch (Exception var7) {
			try {
				date = DATE_FORMAT_US.withZone(DateTimeZone.UTC).parseDateTime(value);
			} catch (Exception var6) {
				try {
					date = DATE_FORMAT_EU.withZone(DateTimeZone.UTC).parseDateTime(value);
				} catch (Exception var5) {
					date = null;
				}
			}
		}

		if (date != null && !isValidDateRange(date)) {
			date = null;
		}

		return date;
	}

	private static boolean isValidDateRange(DateTime date) {
		Date compare = new Date(date.getMillis());
		return Constants.MIN_DATE.compareTo(compare) != 1 && compare.compareTo(Constants.MAX_DATE) != 1;
	}

	private Parse() {
	}

	static {
		DATE_FORMAT_US = DateTimeFormat.forPattern(DateTimeFormat.patternForStyle("S-", Locale.US));
		DATE_FORMAT_EU = DateTimeFormat.forPattern(DateTimeFormat.patternForStyle("S-", Locale.FRANCE));
		DATE_PATTERN = Pattern.compile(
				"^(\\d+)[/\\-\\.]\\s?(\\d+)([/\\-\\.]\\s?(\\d+))?(\\s(\\d+)[/\\-\\.]\\s?(\\d+)[/\\-\\.]\\s?(\\d+))?$");
	}
}
