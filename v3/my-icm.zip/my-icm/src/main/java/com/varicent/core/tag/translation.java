package com.varicent.core.tag;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.varicent.core.i18n.Messages;

public class translation extends SimpleTagSupport {
	private static Messages tMessages;
	private final String TABLE_PREFIX = "table.";
	private final String COLUMN_PREFIX = "column.";

	@Override
	public void doTag() throws JspException, IOException {
		PageContext lPageContext = (PageContext) this.getJspContext();
		WebApplicationContext springContext = WebApplicationContextUtils
				.getWebApplicationContext(lPageContext.getServletContext());
		tMessages = (Messages) springContext.getBean("messages");
		JspWriter out = this.getJspContext().getOut();
		StringWriter beforeTranslation = new StringWriter();
		this.getJspBody().invoke(beforeTranslation);
		String temp = beforeTranslation.toString();
		Messages.Key translatedKey = tMessages.hasKey("table." + temp);
		if (translatedKey != null) {
			String tr = tMessages.getMessage(translatedKey, lPageContext.getResponse().getLocale());
			out.print(tr);
		} else {
			translatedKey = tMessages.hasKey("column." + temp);
			if (translatedKey != null) {
				String tr = tMessages.getMessage(translatedKey, lPageContext.getResponse().getLocale());
				out.print(tr);
			} else {
				out.print(temp);
			}
		}

	}
}
