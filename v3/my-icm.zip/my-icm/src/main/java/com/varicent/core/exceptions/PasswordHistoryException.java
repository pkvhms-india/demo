package com.varicent.core.exceptions;

public class PasswordHistoryException extends PasswordException {
	private static final long serialVersionUID = 1L;

	public PasswordHistoryException() {
	}

	public PasswordHistoryException(String message) {
		super(message);
	}

	public PasswordHistoryException(String message, Throwable cause) {
		super(message, cause);
	}

	public PasswordHistoryException(Throwable cause) {
		super(cause);
	}
}
