package com.varicent.draws.web;

public class PeriodStartJson {
	private String periodStart;

	public PeriodStartJson(String periodStart) {
		this.periodStart = periodStart;
	}

	public String getPeriodStart() {
		return this.periodStart;
	}

	public void setPeriodStart(String periodStart) {
		this.periodStart = periodStart;
	}
}
