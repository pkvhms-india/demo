package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.common.time.domain.Frequency;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.SortColumn;
import com.varicent.reporting.domain.XMLStreamUtility;

public class MSDisplayValueSourceExpander extends BaseExpander {
	private int currentDataSet;
	private int currentSubSet;
	private List<DataSet> dataSets;
	private List<Category> categories;
	boolean isPercentage = false;
	boolean ignoreZero = false;
	private Messages messages;

	public MSDisplayValueSourceExpander(XMLStreamReader stream, boolean ignoreZero, Messages messages) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("MSDisplayValueSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.currentDataSet = -1;
			this.currentSubSet = -1;
			this.dataSets = new ArrayList();
			this.categories = new ArrayList();
			this.ignoreZero = ignoreZero;
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentDataSet != -2) {
			if (this.currentDataSet == -1) {
				this.initializeDisplayValueSource(writer, scope);
				++this.currentDataSet;
			} else if (this.currentDataSet < this.dataSets.size()) {
				this.writeSet(writer, scope);
			} else {
				this.writeEndElements(writer);
				this.currentDataSet = -2;
			}

		}
	}

	private void initializeDisplayValueSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String sourceName = "";
		String displayColumn = "";
		String valueColumn = "";
		String sourceAlias = "";

		List<DataSetInfo> dataSetInfo;
		for (dataSetInfo = new ArrayList(); this.streamReader.getLocalName().equals("Source"); this.streamReader
				.nextTag()) {
			this.streamReader.nextTag();
			sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			displayColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			valueColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			if (this.streamReader.getLocalName().equals("SourceAlias")) {
				sourceAlias = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			SortingInfo sortInfo = null;
			ColumnLink link = null;
			if (this.streamReader.getLocalName().equals("Link")) {
				link = new ColumnLink(this.streamReader);
			}

			if (this.streamReader.getLocalName().equals("SortingInfo")) {
				sortInfo = SortingInfo.extract(this.streamReader);
				this.streamReader.nextTag();
			}

			DataTable table = scope.getDataTable(sourceName).copy();
			if (sortInfo != null) {
				DataSetInfo dsInfo = new DataSetInfo(sourceName, displayColumn, valueColumn, sourceAlias, table,
						(String) null, (String) null, sortInfo, link);
				dataSetInfo.add(dsInfo);
			} else {
				DataSet dataSet = this.getDataSet(sourceName, displayColumn, valueColumn, sourceAlias, table,
						(SortingInfo) null, (Scope) null, link);
				this.dataSets.add(dataSet);
			}
		}

		if (dataSetInfo.size() > 0) {
			this.addCategories(dataSetInfo, scope);

			for (DataSetInfo info : dataSetInfo) {
				this.dataSets.add(this.getDataSet(info.sourceName, info.displayColumn, info.valueColumn,
						info.sourceAlias, info.source, info.sortingInfo, scope, info.link));
			}
		}

		this.streamReader.nextTag();
		writer.writeStartElement("Xml");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		ChartExpander chartEx = new ChartExpander(this.streamReader, this.messages);
		chartEx.expandChartNode(writer);
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("customColors")) {
			this.expandColorsNode(writer);
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.createCategoriesNode(writer);

		for (DataSet dataSet : this.dataSets) {
			dataSet.setIsPercentage(this.isPercentage);
		}

		XMLStreamUtility.MoveStreamForwardToTag(this.streamReader, "MSDisplayValueSource");
	}

	private void writeSet(XMLStreamWriter writer, Scope scope) throws XMLStreamException, ReportOverLimitException {
		DataSet currentSet = this.dataSets.get(this.currentDataSet);
		if (this.currentSubSet == -1) {
			currentSet.writeDataSetStartElement(writer);
			++this.currentSubSet;
		} else if (this.currentSubSet < this.categories.size()) {
			currentSet.writeDataSetElement(writer, this.categories, scope);
			++this.currentSubSet;
		} else {
			currentSet.writeDataSetEndElement(writer);
			++this.currentDataSet;
			this.currentSubSet = -1;
		}

	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void addCategories(List<DataSetInfo> datasets, Scope scope) {
		List<String> categoryNames = new ArrayList();
		DataTable mergedNames = new DataTable("merged");
		DataSetInfo dummySet = datasets.get(0);
		mergedNames.addColumn(dummySet.displayColumn, dummySet.source.getColumn(dummySet.displayColumn).getType());

		for (DataSetInfo setInfo : datasets) {
			if (!setInfo.source.getRows().isEmpty()) {
				List<String> setCategoryNames = new ArrayList();

				for (DataRow row : setInfo.source.getRows()) {
					String categoryName = row.getValue(setInfo.source.getColumnIndex(setInfo.displayColumn));
					if (!categoryNames.contains(categoryName)) {
						setCategoryNames.add(categoryName);
						DataRow newRow = new DataRow();
						newRow.add(row.getObject(setInfo.source.getColumnIndex(setInfo.displayColumn)));
						mergedNames.addRow(newRow);
					}
				}

				categoryNames.removeAll(setCategoryNames);
				categoryNames.addAll(setCategoryNames);
			}
		}

		this.sortCategoryNames(scope, mergedNames, dummySet);

		for (DataRow row : mergedNames.getRows()) {
			String name = row.getValue(0);
			this.categories.add(new Category(this.categories.size(), name));
		}

	}

	private void sortCategoryNames(Scope scope, DataTable mergedNames, DataSetInfo dummySet) {
		if (dummySet.sortingInfo.levelID.equals("") && dummySet.sortingInfo.timeID.equals("")) {
			List<String> columns = new ArrayList();
			columns.add(dummySet.displayColumn);
			mergedNames.sort(columns, dummySet.sortingInfo.sortDescending);
		} else {
			Frequency freq = new Frequency(dummySet.sortingInfo.timeID, dummySet.sortingInfo.levelID);
			SortColumn column = new SortColumn(dummySet.displayColumn, dummySet.sortingInfo.sortDescending, freq);
			List<SortColumn> columns = new ArrayList();
			columns.add(column);
			mergedNames.sort(columns, scope.getCalendars());
		}

	}

	private void createCategoriesNode(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<categories>");

		for (Category element : this.categories) {
			element.writeXMLElement(writer);
		}

		writer.writeCharacters("</categories>");
	}

	private DataSet getDataSet(String sourceName, String displayCol, String valueCol, String sourceAlias,
			DataTable table, SortingInfo sortingInfo, Scope scope, ColumnLink link) {
		String seriesName = sourceAlias != null && !sourceAlias.equals("") ? sourceAlias : sourceName;
		HashMap<String, Integer> nextIndexMap = new HashMap();
		DataSet dataSet = new DataSet(seriesName, table, displayCol, valueCol, this.ignoreZero, link);
		DataTable mergedNames = null;
		if (table.getColumn(valueCol) != null) {
			mergedNames = new DataTable("merged");
			mergedNames.addColumn(displayCol, table.getColumn(displayCol).getType());
			mergedNames.addColumn(valueCol, table.getColumn(valueCol).getType());
		}

		for (int i = 0; i < table.getRows().size(); ++i) {
			String categoryName = table.getValue(i, displayCol);
			BigDecimal value = table.getObject(i, valueCol) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(table.getObject(i, valueCol));
			if (nextIndexMap.containsKey(categoryName)) {
				Integer count = nextIndexMap.get(categoryName);
				nextIndexMap.remove(categoryName);
				nextIndexMap.put(categoryName, new Integer(count + 1));
			} else {
				nextIndexMap.put(categoryName, new Integer(0));
			}

			Integer temp = nextIndexMap.get(categoryName);
			int categoryIndex = this.findCategoryIndex(categoryName, temp);
			if (categoryIndex < 0 && mergedNames != null) {
				DataRow newRow = new DataRow();
				newRow.add(table.getObject(i, displayCol));
				newRow.add(value);
				mergedNames.addRow(newRow);
			} else {
				Category category = this.categories.get(categoryIndex);
				dataSet.add(new Set(value, category, this.ignoreZero));
			}
		}

		if (sortingInfo != null) {
			this.sortCategoryNames(scope, mergedNames,
					new DataSetInfo(sourceName, displayCol, valueCol, sourceAlias, table, "", "", sortingInfo, link));
		}

		if (mergedNames != null) {
			for (DataRow row : mergedNames.getRows()) {
				Category category = new Category(this.categories.size(), row.getValue(0));
				this.categories.add(category);
				dataSet.add(new Set((BigDecimal) row.getObject(1), category, this.ignoreZero));
			}
		}

		dataSet.sortSets();
		return dataSet;
	}

	private int findCategoryIndex(String name, int temp) {
		for (int i = 0; i < this.categories.size(); ++i) {
			if (this.categories.get(i).label.equals(name) && temp-- == 0) {
				return i;
			}
		}

		return -1;
	}
}
