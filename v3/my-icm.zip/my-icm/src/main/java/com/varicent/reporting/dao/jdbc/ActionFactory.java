package com.varicent.reporting.dao.jdbc;

import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.springframework.util.Assert;

import com.varicent.common.concurrency.dao.ConcurrencyDao;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.xml.QueryDefinitionParser;
import com.varicent.common.query.xml.SourceDefinitionParser;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.core.math.expressions.ExpressionEvaluator;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.reporting.dao.jdbc.ActionParser.ExpressionParser;
import com.varicent.reporting.domain.LiteralConstraint;
import com.varicent.reporting.domain.ScalarConstraint;
import com.varicent.reporting.domain.ScopeConstraint;
import com.varicent.reporting.domain.ValueScalar;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.reporting.web.ReportingCommand;

public class ActionFactory {
	public static StaticScalarFill getStaticScalarFill(XMLStreamReader streamReader) throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String literalType = streamReader.getAttributeValue(0);
		String literalValue = XMLStreamUtility.getCurrentNodeValue(streamReader);
		Literal literal = getLiteralValue(literalType, literalValue);
		return new StaticScalarFill(name, literal);
	}

	public static ComputeAggregate getComputeAggregate(XMLStreamReader streamReader, ReportingCommand command)
			throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String dependency = XMLStreamUtility.getCurrentNodeValue(streamReader);
		ExpressionParser parser = new ExpressionParser();
		ExpressionEvaluator expression = parser.getExpression(streamReader);
		streamReader.nextTag();
		List<String> partitions = new ArrayList();

		while (streamReader.getEventType() == 1) {
			partitions.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		String timePartition = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (timePartition.length() == 0) {
			timePartition = null;
		}

		String level = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (level.length() == 0) {
			level = null;
		}

		String timeId = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (timeId.length() == 0) {
			timeId = null;
		}

		String startDateString = XMLStreamUtility.getCurrentNodeValue(streamReader).substring(0, 10);
		String endDateString = XMLStreamUtility.getCurrentNodeValue(streamReader).substring(0, 10);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		Date startDate;
		Date endDate;
		try {
			startDate = df.parse(startDateString);
			endDate = df.parse(endDateString);
		} catch (ParseException var16) {
			startDate = new Date();
			endDate = new Date();
		}

		streamReader.nextTag();
		List<String> variables = new ArrayList();

		while (streamReader.getEventType() == 1) {
			variables.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		if (command.getUsesPayeeTable(dependency)) {
			command.setUsesPayeeTable(name);
		}

		return new ComputeAggregate(name, dependency, expression, partitions, timePartition, level, variables, timeId,
				startDate, endDate);
	}

	public static ComputeColumn getComputeColumn(XMLStreamReader streamReader, ReportingCommand command)
			throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String newColumn = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String sourceName = XMLStreamUtility.getCurrentNodeValue(streamReader);
		ExpressionParser parser = new ExpressionParser();
		ExpressionEvaluator expression = parser.getExpression(streamReader);
		streamReader.nextTag();
		List<String> variables = new ArrayList();

		while (streamReader.getEventType() == 1) {
			variables.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		if (command.getUsesPayeeTable(sourceName)) {
			command.setUsesPayeeTable(name);
		}

		return new ComputeColumn(name, newColumn, sourceName, expression, variables);
	}

	public static ComputeScalar getComputeScalar(XMLStreamReader streamReader) throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		ExpressionParser parser = new ExpressionParser();
		ExpressionEvaluator expression = parser.getExpression(streamReader);
		return new ComputeScalar(name, expression);
	}

	public static ScalarParameter getScalarParameter(XMLStreamReader streamReader) throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String source = XMLStreamUtility.getCurrentNodeValue(streamReader);
		return new ScalarParameter(name, source);
	}

	public static GroupScalarFetch getGroupScalarFetch(SchemaDao schemaDao, ConcurrencyDao concurrencyDao,
			XMLStreamReader streamReader, DataSource ds) throws XMLStreamException {
		List<ValueScalar> valueScalars = new ArrayList();

		while (streamReader.getEventType() == 1) {
			streamReader.nextTag();
			String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String table = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String valueColumn = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String type = XMLStreamUtility.getCurrentNodeValue(streamReader);
			List<ScalarConstraint> constraints = new ArrayList();
			streamReader.nextTag();

			for (; streamReader.getEventType() == 1; streamReader.nextTag()) {
				String constraintType = streamReader.getAttributeValue(0);
				streamReader.nextTag();
				String column = XMLStreamUtility.getCurrentNodeValue(streamReader);
				if (constraintType.equals("Literal")) {
					String literalType = streamReader.getAttributeValue(0);
					String literalValue = XMLStreamUtility.getCurrentNodeValue(streamReader);
					Literal literal = getLiteralValue(literalType, literalValue);
					constraints.add(new LiteralConstraint(constraintType, column, literal));
				} else {
					String scopeValue = XMLStreamUtility.getCurrentNodeValue(streamReader);
					constraints.add(new ScopeConstraint(constraintType, column, scopeValue));
				}
			}

			valueScalars.add(new ValueScalar(name, table, valueColumn, type,
					(ScalarConstraint[]) constraints.toArray(new ScalarConstraint[constraints.size()])));
			streamReader.nextTag();
			streamReader.nextTag();
		}

		return new GroupScalarFetch(schemaDao, concurrencyDao, ds,
				(ValueScalar[]) valueScalars.toArray(new ValueScalar[valueScalars.size()]));
	}

	public static QueryFetch getQueryFetch(XMLStreamReader streamReader, DataSource ds, SchemaDao schemaDao,
			ConcurrencyDao concurrencyDao) throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String queryString = XMLStreamUtility.getCurrentNodeValue(streamReader);
		int end = queryString.indexOf("/query");
		String begin = queryString.substring(0, end - 1);
		begin = begin.concat("<fakeTag></fakeTag>");
		begin = begin.concat(queryString.substring(end));
		XMLInputFactory factory = XMLInputFactory.newInstance();
		StringReader reader = new StringReader(begin);
		XMLStreamReader newReader = factory.createXMLStreamReader(reader);
		newReader.nextTag();
		QueryDefinition query = QueryDefinitionParser.getQueryDefinition(newReader);
		reader.close();
		newReader.close();
		return new QueryFetch(ds, name, query, schemaDao, concurrencyDao);
	}

	public static QuerySourceFetch getQuerySourceFetch(CustomizeDao customizeDao, XMLStreamReader streamReader,
			DataSource ds, ReportingCommand command, SchemaDao schemaDao, ConcurrencyDao concurrencyDao)
			throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		streamReader.nextTag();
		List<String> dependencies = new ArrayList();

		while (streamReader.getEventType() == 1) {
			String variable = XMLStreamUtility.getCurrentNodeValue(streamReader);
			dependencies.add(variable);
		}

		streamReader.nextTag();
		SourceDefinition sd = SourceDefinitionParser.getSourceDefinition(streamReader);
		streamReader.nextTag();
		streamReader.nextTag();
		streamReader.nextTag();
		List<String> columnNames = new ArrayList();

		while (streamReader.getEventType() == 1) {
			String column = XMLStreamUtility.getCurrentNodeValue(streamReader);
			columnNames.add(column);
		}

		streamReader.nextTag();
		return new QuerySourceFetch(customizeDao, ds, name, dependencies, sd, columnNames, command, schemaDao,
				concurrencyDao);
	}

	public static InputRowDataEntry getInputRowDataEntry(CustomizeDao customizeDao, SchemaDao schemaDao,
			ConcurrencyDao concurrencyDao, XMLStreamReader streamReader, DataSource ds, ReportingCommand command)
			throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		List<String> dependencies = new ArrayList();
		SourceDefinition sd = SourceDefinitionParser.getSourceDefinition(streamReader);
		streamReader.nextTag();
		streamReader.nextTag();
		streamReader.nextTag();
		List<String> columnNames = new ArrayList();

		while (streamReader.getEventType() == 1) {
			String column = XMLStreamUtility.getCurrentNodeValue(streamReader);
			columnNames.add(column);
		}

		streamReader.nextTag();
		return new InputRowDataEntry(customizeDao, schemaDao, concurrencyDao, ds, name, dependencies, sd, columnNames,
				command);
	}

	public static Transpose getTranspose(XMLStreamReader streamReader) throws XMLStreamException {
		String name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String source = XMLStreamUtility.getCurrentNodeValue(streamReader);
		streamReader.nextTag();
		List<String> newColumns = new ArrayList();

		while (streamReader.getEventType() == 1) {
			newColumns.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		streamReader.nextTag();
		List<String> primaryKeyColumns = new ArrayList();

		while (streamReader.getEventType() == 1) {
			primaryKeyColumns.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		String transposeColumn = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String newColumnName = XMLStreamUtility.getCurrentNodeValue(streamReader);
		streamReader.nextTag();
		List<String> columnNames = new ArrayList();

		while (streamReader.getEventType() == 1) {
			columnNames.add(XMLStreamUtility.getCurrentNodeValue(streamReader));
		}

		streamReader.nextTag();
		return new Transpose(name, source, newColumns, primaryKeyColumns, transposeColumn, newColumnName, columnNames);
	}

	public static ValidateListParameter getValidateListParameter(XMLStreamReader streamReader)
			throws XMLStreamException {
		String sourceName = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String idColumn = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String paramName = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String defaultValue = XMLStreamUtility.getCurrentNodeValue(streamReader);
		return new ValidateListParameter(sourceName, idColumn, paramName, defaultValue);
	}

	private static Literal getLiteralValue(String literalType, String literal) {
		Literal.Type type = Literal.Type.valueOf(literalType.toUpperCase());
		Object value;
		switch (type) {
		case STRING:
			value = literal;
			break;
		case DECIMAL:
			value = new BigDecimal(literal);
			break;
		case DATE:
			value = java.sql.Date.valueOf(literal);
			break;
		case DATETIME:
			java.sql.Date date = java.sql.Date.valueOf(literal);
			value = new Timestamp(date.getTime());
			break;
		case INTEGER:
			value = new Integer(literal);
			break;
		default:
			Assert.state(false);
			value = null;
		}

		return new Literal(type, value);
	}
}
