package com.varicent.core.exceptions;

import com.varicent.core.i18n.Message;

public class InvalidWebFormException extends Exception {
	private static final long serialVersionUID = 1L;
	private final Message message;

	public InvalidWebFormException(Message message) {
		super(message.getKey().toString());
		this.message = message;
	}

	public Message getMessageObject() {
		return this.message;
	}
}
