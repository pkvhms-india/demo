package com.varicent.BPM.dao.jdbc;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.varicent.BPM.dao.BPMDao;
import com.varicent.BPM.domain.BPMAlertNode;
import com.varicent.BPM.domain.BPMConditionalPath;
import com.varicent.BPM.domain.BPMExternalEmail;
import com.varicent.BPM.domain.BPMNode;
import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMProcessNode;
import com.varicent.BPM.domain.BPMSwimLane;
import com.varicent.BPM.domain.BPMToken;
import com.varicent.BPM.domain.BPMTokenParameter;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflow;
import com.varicent.BPM.domain.BPMWorkflowParameter;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.common.concurrency.dao.ConcurrencyDao;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.CustomConstraint;
import com.varicent.common.query.domain.DeleteDefinition;
import com.varicent.common.query.domain.ISelectItem;
import com.varicent.common.query.domain.InsertDefinition;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectCustom;
import com.varicent.common.query.domain.SelectLiteral;
import com.varicent.common.query.domain.SqlDataSource;
import com.varicent.common.query.domain.UpdateDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.query.sql.delete.DeleteBuilder;
import com.varicent.common.query.sql.insert.InsertBuilder;
import com.varicent.common.query.sql.update.UpdateBuilder;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.core.Constants;
import com.varicent.core.context.VaricentContext;
import com.varicent.core.database.Database;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.exceptions.IllegalValueException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.core.text.Parse;
import com.varicent.reporting.dao.ReportingDao;
import com.varicent.reporting.dao.jdbc.ExpandedXml;
import com.varicent.reporting.domain.Scope;
import com.varicent.security.domain.UserAccount;

@Repository("bpmDao")
public class JdbcBPMDaoImpl implements BPMDao {
	private final String BPM_PENDING_TABLE_PREFIX = "_BPMPending_";
	private final RowMapper<String> payeeIDMapper = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new String(rs.getString("PayeeID_"));
		}
	};
	private final RowMapper<String> sourceTableMapper = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new String(rs.getString("Table"));
		}
	};
	private final JdbcOperations operations;
	private final SchemaDao schemaDao;
	private final ReportingDao reportingDao;
	private final ConcurrencyDao concurrencyDao;

	@Autowired
	public JdbcBPMDaoImpl(DataSource ds, SchemaDao schemaDao, ReportingDao reportingDao,
			ConcurrencyDao concurrencyDao) {
		this.operations = Database.getOperations(ds);
		this.schemaDao = schemaDao;
		this.reportingDao = reportingDao;
		this.concurrencyDao = concurrencyDao;
	}

	@Override
	public BPMWorkflow getWorkflow(int workflowID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		query.select("BPMWorkflow", "WorkflowID");
		query.select("BPMWorkflow", "Name");
		query.select("BPMWorkflow", "WebReportID");
		query.select("BPMWorkflow", "IsSingleInstance");
		query.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, workflowID);
		List<BPMWorkflow> workflows = this.operations.query(qb.toSql(query), BPMMapper.getWorkflowMapper());
		if (workflows.size() == 0) {
			return null;
		} else {
			BPMWorkflow workflow = workflows.get(0);
			BPMWorkflowParameter[] parameters = this.getWorkflowParameters(workflow.getID());
			workflow.setParameters(parameters);
			return workflow;
		}
	}

	@Override
	public BPMNodeHistoryStatus[] getBPMPendingTokenHistory(int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMNodeHistory");
		Join tokenHistory = new Join("BPMPendingTokenHistory", Join.Type.INNER);
		tokenHistory.newConstraint("BPMNodeHistory", "ID", Constraint.Operator.Equals, "BPMPendingTokenHistory",
				"NodeHistoryID");
		query.joinWith(tokenHistory);
		query.select("BPMNodeHistory", "ID");
		query.select("BPMNodeHistory", "WorkflowID");
		query.select("BPMNodeHistory", "NodeName");
		query.select("BPMNodeHistory", "Initiator");
		query.select("BPMNodeHistory", "Actor");
		query.select("BPMNodeHistory", "Action");
		query.select("BPMNodeHistory", "DateActioned");
		query.select("BPMNodeHistory", "IsForcedBy");
		query.newConstraint("BPMPendingTokenHistory", "TokenID", Constraint.Operator.Equals, tokenID);
		query.orderBy("DateActioned", true);
		List<BPMNodeHistoryStatus> workflowHistory = this.operations.query(qb.toSql(query),
				BPMMapper.getBPMNodeHistoryStatusRowMapper());
		return (BPMNodeHistoryStatus[]) workflowHistory.toArray(new BPMNodeHistoryStatus[0]);
	}

	@Override
	public BPMNodeHistoryStatus[] getBPMDeletedTokenHistory(int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMDeletedCompletedToken");
		Join tokenHistory = new Join("BPMDeletedCompletedTokensHistory", Join.Type.INNER);
		tokenHistory.newConstraint("BPMDeletedCompletedToken", "ID", Constraint.Operator.Equals,
				"BPMDeletedCompletedTokensHistory", "DeletedCompletedTokenID");
		query.joinWith(tokenHistory);
		Join nodeHistory = new Join("BPMNodeHistory", Join.Type.INNER);
		nodeHistory.newConstraint("BPMNodeHistory", "ID", Constraint.Operator.Equals,
				"BPMDeletedCompletedTokensHistory", "NodeHistoryID");
		query.joinWith(nodeHistory);
		query.select("BPMNodeHistory", "ID");
		query.select("BPMNodeHistory", "WorkflowID");
		query.select("BPMNodeHistory", "NodeName");
		query.select("BPMNodeHistory", "Initiator");
		query.select("BPMNodeHistory", "Actor");
		query.select("BPMNodeHistory", "Action");
		query.select("BPMNodeHistory", "DateActioned");
		query.select("BPMNodeHistory", "IsForcedBy");
		query.newConstraint("BPMDeletedCompletedToken", "ID", Constraint.Operator.Equals, tokenID);
		query.orderBy("DateActioned", true);
		List<BPMNodeHistoryStatus> workflowHistory = this.operations.query(qb.toSql(query),
				BPMMapper.getBPMNodeHistoryStatusRowMapper());
		return (BPMNodeHistoryStatus[]) workflowHistory.toArray(new BPMNodeHistoryStatus[0]);
	}

	@Override
	public void deleteFromBPMPendingTable(String bufferTable, int formId) {
		DeleteDefinition delete = new DeleteDefinition(bufferTable);
		DeleteBuilder db = Database.getDeleteBuilder();
		delete.newConstraint(bufferTable, "_FormID", Constraint.Operator.Equals, formId);
		this.operations.execute(db.toSql(delete));
	}

	@Override
	public List<String> getBPMPendingTables() {
		String tableName = "SourceTable";
		String columnName = "Table";
		String query = "SELECT * FROM [" + tableName + "] WHERE [" + columnName + "] LIKE '" + "_BPMPending_" + "%'";
		return this.operations.query(query, this.sourceTableMapper);
	}

	@Override
	public List<Object> getPendingValues(String table, ColumnDefinition column, int formId) {
		QueryDefinition qd = new QueryDefinition(table);
		qd.select(table, column.getName());
		qd.newConstraint(table, "_FormID", Constraint.Operator.Equals, formId);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Map<String, Object>> result = this.operations.queryForList(qb.toSql(qd));
		List<Object> values = new ArrayList();

		for (Map<String, Object> row : result) {
			values.add(row.get(column.getName()));
		}

		return values;
	}

	@Override
	public Message updateBPMPendingTableSource(String bufferTableName, HashMap<BPMToken, BPMWorkflow> tokenMap)
			throws IllegalValueException, DataSubmitException {
		String sourceTableName = bufferTableName.substring("_BPMPending_".length());
		List<ColumnDefinition> allSourceColumns = this.schemaDao.getColumns(sourceTableName);
		int i = 0;
		int[] reportIds = new int[tokenMap.size()];
		Set<BPMToken> tokens = tokenMap.keySet();
		List<Integer> formIdsList = new ArrayList();

		for (BPMToken token : tokens) {
			formIdsList.add(token.getFormID());
			reportIds[i++] = tokenMap.get(token).getReportID();
		}

		String formIds = Arrays.toString(formIdsList.toArray());
		boolean globalLocked = this.concurrencyDao.isGlobalLocked();
		if (globalLocked) {
			for (int formId : formIdsList) {
				UpdateDefinition ud = new UpdateDefinition(bufferTableName);
				ud.newConstraint(bufferTableName, "_FormID", Constraint.Operator.Equals, formId);
				ud.set("_AwaitingFlush", 1);
				this.operations.update(ud.toSql());
			}

			return null;
		} else {
			QueryDefinition bufferQuery = new QueryDefinition(bufferTableName);
			bufferQuery.addConstraint(
					new CustomConstraint("[_FormID] IN (" + formIds.substring(1, formIds.length() - 1) + ")"));
			bufferQuery.orderBy("_TimeStamp");
			List<Map<String, Object>> bufferRows = this.operations.queryForList(bufferQuery.toSql());
			List<InsertDefinition> inserts = new ArrayList();
			List<UpdateDefinition> updates = new ArrayList();

			for (Map<String, Object> row : bufferRows) {
				QueryDefinition sourceQuery = new QueryDefinition(sourceTableName);
				sourceQuery.selectCount();

				for (ColumnDefinition col : allSourceColumns) {
					if (col.isKey()) {
						sourceQuery.newConstraint(sourceTableName, col.getName(), Constraint.Operator.Equals,
								row.get(col.getName()));
					}
				}

				if (this.operations.queryForObject(sourceQuery.toSql(), Integer.class) > 0) {
					UpdateDefinition update = new UpdateDefinition(sourceTableName);

					for (ColumnDefinition col : allSourceColumns) {
						if (col.isKey()) {
							update.newConstraint(sourceTableName, col.getName(), Constraint.Operator.Equals,
									row.get(col.getName()));
						} else {
							Object colValue = row.get(col.getName());
							if (colValue != null) {
								update.set(col, colValue.toString());
							} else {
								update.setNull(col.getName());
							}
						}
					}

					updates.add(update);
				} else {
					InsertDefinition insert = new InsertDefinition(sourceTableName);

					for (ColumnDefinition col : allSourceColumns) {
						insert.addColumn(col.getName());
						this.addInsertVal(insert, sourceTableName, col, row.get(col.getName()), true);
					}

					inserts.add(insert);
				}
			}

			Message errorMsg = this.reportingDao.runInsertsAndUpdatesInSingleRevisionBlock(inserts, updates, reportIds,
					false);

			for (BPMToken token : tokens) {
				this.deleteFromBPMPendingTable(bufferTableName, token.getFormID());
			}

			return errorMsg;
		}
	}

	void addInsertVal(InsertDefinition insert, String table, ColumnDefinition colDef, Object obj,
			boolean capitalizeStringKeyColumns) throws IllegalValueException {
		if (obj == null) {
			if (colDef.isNullable()) {
				insert.addNullValue();
			} else {
				insert.addValue(colDef, "");
			}
		} else if (colDef.isDateTime()) {
			if (obj instanceof Date) {
				insert.addValue((Date) obj);
			} else if (obj instanceof java.sql.Date) {
				insert.addValue((java.sql.Date) obj);
			} else if (obj instanceof Timestamp) {
				insert.addValue((Timestamp) obj);
			} else if (Parse.date(obj.toString()) != null) {
				insert.addValue(Parse.date(obj.toString()));
			} else {
				insert.addValue(colDef, obj.toString());
			}
		} else if (colDef.isNumeric() && obj instanceof BigDecimal) {
			insert.addValue((BigDecimal) obj);
		} else {
			insert.addValue(colDef, obj.toString(), capitalizeStringKeyColumns);
		}

	}

	@Override
	public BPMWorkflow getWorkflowUsingTokenID(int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, "BPMSwimLane",
				"WorkflowID");
		query.joinWith(swimLaneJoin);
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMSwimLane", "SwimLaneID", Constraint.Operator.Equals, "BPMNode", "SwimLaneID");
		query.joinWith(nodeJoin);
		Join tokenJoin = new Join("BPMToken", Join.Type.INNER);
		tokenJoin.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, "BPMToken", "NodeID");
		query.joinWith(tokenJoin);
		query.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, tokenID);
		query.select("BPMWorkflow", "WorkflowID");
		query.select("BPMWorkflow", "Name");
		query.select("BPMWorkflow", "WebReportID");
		query.select("BPMWorkflow", "IsSingleInstance");
		List<BPMWorkflow> workflows = this.operations.query(qb.toSql(query), BPMMapper.getWorkflowMapper());
		if (workflows.size() == 0) {
			return null;
		} else {
			BPMWorkflow workflow = workflows.get(0);
			BPMWorkflowParameter[] parameters = this.getWorkflowParameters(workflow.getID());
			workflow.setParameters(parameters);
			return workflow;
		}
	}

	@Override
	public BPMToken insertToken(int formID, int nodeID, String ownerID, String lastActorID, int pathID,
			boolean isWaiting) {
		InsertDefinition insert = new InsertDefinition("BPMToken", new String[] { "FormID", "NodeID", "OwnerID",
				"LastActorID", "PathID", "Waiting", "CreatedAt", "LastModified" });
		insert.addValue(formID);
		insert.addValue(nodeID);
		insert.addValue(ownerID);
		insert.addValue(lastActorID);
		insert.addValue(pathID);
		insert.addValue(isWaiting);
		insert.addSystemDateTime();
		insert.addSystemDateTime();
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition idQuery = getTokenIdQuery();
		int id = (Integer) this.operations.queryForObject(qb.toSql(idQuery), Integer.class);
		return this.getToken(id);
	}

	@Override
	public BPMTokenView getBPMTokenView(int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition qd = this.getBPMTokenViewQueryDefinition(tokenID);
		List<BPMTokenView> activeTokenList = this.operations.query(qb.toSql(qd),
				BPMMapper.getCompletedTokenViewMapper());
		if (activeTokenList.size() > 0) {
			return activeTokenList.get(0);
		} else {
			QueryDefinition query = this.buildDeletedCompletedTokenViewQuery(tokenID);
			List<BPMTokenView> completedTokens = this.operations.query(qb.toSql(query),
					BPMMapper.getCompletedTokenViewMapper());
			return completedTokens.size() > 0 ? (BPMTokenView) completedTokens.get(0) : null;
		}
	}

	private QueryDefinition getBPMTokenViewQueryDefinition(int tokenID) {
		QueryDefinition query = new QueryDefinition("BPMToken");
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		Join swimlaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimlaneJoin.newConstraint("BPMNode", "SwimLaneID", Constraint.Operator.Equals, "BPMSwimLane", "SwimLaneID");
		query.joinWith(swimlaneJoin);
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		query.joinWith(workflowJoin);
		Join webreportJoin = new Join("WebReport", Join.Type.INNER);
		webreportJoin.newConstraint("BPMWorkflow", "WebReportID", Constraint.Operator.Equals, "WebReport",
				"WebReportID");
		query.joinWith(webreportJoin);
		Join formJoin = new Join("BPMForm", Join.Type.INNER);
		formJoin.newConstraint("BPMToken", "FormID", Constraint.Operator.Equals, "BPMForm", "FormID");
		query.joinWith(formJoin);
		query.select("BPMToken", "TokenID", "ID");
		query.select("BPMForm", "PayeeID", "Initiator");
		query.select("BPMToken", "LastActorID", "LastActor");
		query.select("BPMToken", "CreatedAt", "InitiationDate");
		query.select("BPMToken", "LastModified", "CompletionDate");
		query.select("BPMWorkflow", "Name", "WorkflowName");
		query.select("WebReport", "Name", "WebReportName");
		query.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, tokenID);
		return query;
	}

	public static QueryDefinition getTokenIdQuery() {
		QueryDefinition query = new QueryDefinition("BPMToken");
		query.selectMax("BPMToken", "TokenID", "NextDisputeID");
		return query;
	}

	public static QueryDefinition getNodeHistoryIdQuery() {
		QueryDefinition query = new QueryDefinition("BPMNodeHistory");
		query.selectMax("BPMNodeHistory", "ID", "NextDisputeID");
		return query;
	}

	private BPMWorkflowParameter[] getWorkflowParameters(int workflowID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMWorkflowParameter");
		query.newConstraint("BPMWorkflowParameter", "WorkflowID", Constraint.Operator.Equals, workflowID);
		query.select("BPMWorkflowParameter", "WorkflowID");
		query.select("BPMWorkflowParameter", "ParamName");
		query.select("BPMWorkflowParameter", "Value");
		query.select("BPMWorkflowParameter", "ParamType");
		query.select("BPMWorkflowParameter", "ValueType");
		query.select("BPMWorkflowParameter", "IsReportDefaultValue");
		List<BPMWorkflowParameter> parameters = this.operations.query(qb.toSql(query),
				BPMMapper.GetWorkflowParameterMapper());
		return (BPMWorkflowParameter[]) parameters.toArray(new BPMWorkflowParameter[0]);
	}

	@Override
	public BPMSwimLane getSwimLane(int swimLaneID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMSwimLane");
		query.newConstraint("BPMSwimLane", "SwimLaneID", Constraint.Operator.Equals, swimLaneID);
		query.select("BPMSwimLane", "SwimLaneID");
		query.select("BPMSwimLane", "Order");
		query.select("BPMSwimLane", "WorkflowID");
		query.select("BPMSwimLane", "Name");
		query.select("BPMSwimLane", "IsSystemLane");
		query.select("BPMSwimLane", "IsByRestriction");
		query.select("BPMSwimLane", "MemberDefinition");
		List<BPMSwimLane> swimLanes = this.operations.query(qb.toSql(query), BPMMapper.getSwimLaneMapper());
		if (swimLanes.size() == 0) {
			return null;
		} else {
			BPMSwimLane swimLane = swimLanes.get(0);
			String[] payeeIDs = this.getSwimLanePayeeIDs(swimLane.getSwimLaneID());
			swimLane.setPayeeIDs(payeeIDs);
			return swimLane;
		}
	}

	private String[] getSwimLanePayeeIDs(int swimLaneID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMSwimLanePayee");
		query.newConstraint("BPMSwimLanePayee", "SwimLaneID", Constraint.Operator.Equals, swimLaneID);
		query.select("BPMSwimLanePayee", "PayeeID", "PayeeID_");
		List<String> payeeIDs = this.operations.query(qb.toSql(query), this.payeeIDMapper);
		return (String[]) payeeIDs.toArray(new String[0]);
	}

	@Override
	public BPMNode getNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMNode");
		query.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.select("BPMNode", "NodeID");
		query.select("BPMNode", "SwimLaneID");
		query.select("BPMNode", "Name");
		List<BPMNode> nodes = this.operations.query(qb.toSql(query), BPMMapper.getNodeMapper());
		if (nodes.size() == 0) {
			return null;
		} else {
			BPMNode node = nodes.get(0);
			BPMPath[] paths = this.getPaths(node.getNodeID());
			node.setPaths(paths);
			return node;
		}
	}

	@Override
	public BPMNode getStartNode(int workflowID) {
		QueryDefinition query = new QueryDefinition("BPMStartNode");
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMStartNode", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMNode", "SwimLaneID", Constraint.Operator.Equals, "BPMSwimLane", "SwimLaneID");
		query.joinWith(swimLaneJoin);
		query.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, workflowID);
		query.select("BPMNode", "NodeID");
		query.select("BPMNode", "SwimLaneID");
		query.select("BPMNode", "Name");
		QueryBuilder qb = Database.getQueryBuilder();
		List<BPMNode> nodes = this.operations.query(qb.toSql(query), BPMMapper.getNodeMapper());

		assert nodes.size() == 1;

		BPMNode startNode = nodes.get(0);
		BPMPath[] paths = this.getPaths(startNode.getNodeID());

		assert paths.length == 1;

		startNode.setPaths(paths);
		return startNode;
	}

	@Override
	public BPMAlertNode getAlertNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMAlertNode");
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMAlertNode", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		query.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.select("BPMNode", "NodeID");
		query.select("BPMNode", "SwimLaneID");
		query.select("BPMNode", "Name");
		query.select("BPMAlertNode", "Subject");
		query.select("BPMAlertNode", "Body");
		query.select("BPMAlertNode", "AlertType");
		List<BPMAlertNode> alertNodes = this.operations.query(qb.toSql(query), BPMMapper.getAlertNodeMapper());
		if (alertNodes.size() == 0) {
			return null;
		} else {
			BPMAlertNode alertNode = alertNodes.get(0);
			BPMPath[] paths = this.getPaths(alertNode.getNodeID());
			alertNode.setPaths(paths);
			BPMExternalEmail[] externalEmails = this.getExternalEmails(nodeID);
			alertNode.setExternalEmails(externalEmails);
			return alertNode;
		}
	}

	private BPMExternalEmail[] getExternalEmails(int alertNodeID) {
		QueryDefinition query = new QueryDefinition("BPMExternalEmail");
		query.select("BPMExternalEmail", "Email");
		query.select("BPMExternalEmail", "IsCC");
		query.newConstraint("BPMExternalEmail", "AlertNodeID", Constraint.Operator.Equals, alertNodeID);
		QueryBuilder qb = Database.getQueryBuilder();
		List<BPMExternalEmail> externalEmails = this.operations.query(qb.toSql(query),
				BPMMapper.getExternalEmailMapper());
		return (BPMExternalEmail[]) externalEmails.toArray(new BPMExternalEmail[0]);
	}

	@Override
	public BPMProcessNode getProcessNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMProcessNode");
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMProcessNode", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		query.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.select("BPMNode", "NodeID");
		query.select("BPMNode", "SwimLaneID");
		query.select("BPMNode", "Name");
		query.select("BPMProcessNode", "SchedulerFolderID");
		List<BPMProcessNode> processNodes = this.operations.query(qb.toSql(query), BPMMapper.getProcessNodeMapper());
		if (processNodes.size() == 0) {
			return null;
		} else {
			BPMProcessNode processNode = processNodes.get(0);
			BPMPath[] paths = this.getPaths(processNode.getNodeID());
			processNode.setPaths(paths);
			return processNode;
		}
	}

	private BPMPath[] getPaths(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMPath");
		query.newConstraint("BPMPath", "OriginNodeID", Constraint.Operator.Equals, nodeID);
		query.select("BPMPath", "PathID");
		query.select("BPMPath", "OriginNodeID");
		query.select("BPMPath", "DestinationNodeID");
		query.select("BPMPath", "Name");
		query.select("BPMPath", "AllMember");
		query.select("BPMPath", "SaveAndSubmit");
		query.select("BPMPath", "AllSubmit");
		query.select("BPMPath", "ReviewResult");
		List<BPMPath> paths = this.operations.query(qb.toSql(query), BPMMapper.getPathMapper());
		return (BPMPath[]) paths.toArray(new BPMPath[0]);
	}

	@Override
	public boolean isConditionalNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMConditionalNode");
		query.selectCount();
		query.newConstraint("BPMConditionalNode", "NodeID", Constraint.Operator.Equals, nodeID);
		int rows = this.operations.queryForInt(qb.toSql(query));
		return rows > 0;
	}

	@Override
	public boolean isConditionalPath(int pathID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMConditionalPath");
		query.selectCount();
		query.newConstraint("BPMConditionalPath", "PathID", Constraint.Operator.Equals, pathID);
		int rows = this.operations.queryForInt(qb.toSql(query));
		return rows > 0;
	}

	private QueryDefinition buildGetPathQuery(int pathID) {
		QueryDefinition query = new QueryDefinition("BPMPath");
		query.newConstraint("BPMPath", "PathID", Constraint.Operator.Equals, pathID);
		query.select("BPMPath", "PathID");
		query.select("BPMPath", "OriginNodeID");
		query.select("BPMPath", "DestinationNodeID");
		query.select("BPMPath", "Name");
		query.select("BPMPath", "AllMember");
		query.select("BPMPath", "SaveAndSubmit");
		query.select("BPMPath", "AllSubmit");
		query.select("BPMPath", "ReviewResult");
		return query;
	}

	private QueryDefinition buildConditionalPathQuery(int pathID) {
		QueryDefinition query = this.buildGetPathQuery(pathID);
		Join join = new Join("BPMConditionalPath", Join.Type.INNER);
		join.newConstraint("BPMPath", "PathID", Constraint.Operator.Equals, "BPMConditionalPath", "PathID");
		query.joinWith(join);
		query.select("BPMConditionalPath", "Position");
		query.select("BPMConditionalPath", "Condition");
		query.select("BPMConditionalPath", "IsDefault");
		return query;
	}

	@Override
	public BPMPath getPath(int pathID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildGetPathQuery(pathID);
		List<BPMPath> paths = this.operations.query(qb.toSql(query), BPMMapper.getPathMapper());
		return paths.size() == 0 ? null : (BPMPath) paths.get(0);
	}

	@Override
	public BPMPath getPath(int pathID, int originNodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildGetPathQuery(pathID);
		query.newConstraint("BPMPath", "OriginNodeID", Constraint.Operator.Equals, originNodeID);
		List<BPMPath> paths = this.operations.query(qb.toSql(query), BPMMapper.getPathMapper());
		return paths.size() == 0 ? null : (BPMPath) paths.get(0);
	}

	@Override
	public BPMConditionalPath getConditionalPath(int pathID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildConditionalPathQuery(pathID);
		List<BPMConditionalPath> paths = this.operations.query(qb.toSql(query), BPMMapper.getConditionalPathMapper());
		return paths.size() == 0 ? null : (BPMConditionalPath) paths.get(0);
	}

	@Override
	public ArrayList<BPMConditionalPath> getConditionalPaths(int originNode) {
		QueryDefinition query = new QueryDefinition("BPMPath");
		query.select("BPMPath", "PathID");
		query.newConstraint("BPMPath", "OriginNodeID", Constraint.Operator.Equals, originNode);
		List<Integer> paths = this.operations.query(Database.getQueryBuilder().toSql(query),
				RowMapperUtil.getIntegerMapper());
		ArrayList<BPMConditionalPath> conditionalPaths = new ArrayList();

		for (Integer pathID : paths) {
			conditionalPaths.add(this.getConditionalPath(pathID));
		}

		Collections.sort(conditionalPaths);
		return conditionalPaths;
	}

	private QueryDefinition buildGetTokenQuery(int tokenID) {
		QueryDefinition query = new QueryDefinition("BPMToken");
		query.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, tokenID);
		query.select("BPMToken", "TokenID");
		query.select("BPMToken", "FormID");
		query.select("BPMToken", "NodeID");
		query.select("BPMToken", "OwnerID");
		query.select("BPMToken", "LastActorID");
		query.select("BPMToken", "PathID");
		query.select("BPMToken", "Waiting");
		query.select("BPMToken", "_RowVersion");
		return query;
	}

	@Override
	public int getWorkflowIDFromForm(int formid) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMForm");
		query.newConstraint("BPMForm", "FormID", Constraint.Operator.Equals, formid);
		query.select("BPMForm", "WorkflowID");
		int wfid = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return wfid;
	}

	public int getFirstSwimLaneID(int nodeID) {
		QueryDefinition query = new QueryDefinition("BPMNode");
		Join slJoin = new Join("BPMSwimLane", Join.Type.INNER);
		query.joinWith(slJoin);
		slJoin.newConstraint("BPMSwimLane", "SwimLaneID", Constraint.Operator.Equals, "BPMNode", "SwimLaneID");
		Join rootJoin = new Join("BPMSwimLane", "_root", Join.Type.INNER);
		query.joinWith(rootJoin);
		rootJoin.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, "_root", "WorkflowID");
		query.newConstraint("_root", "Order", Constraint.Operator.Equals, 1);
		query.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.select("_root", "SwimLaneID");
		QueryBuilder qb = Database.getQueryBuilder();
		String queryString = qb.toSql(query);
		return (Integer) this.operations.queryForObject(queryString, Integer.class);
	}

	@Override
	public BPMToken getToken(int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildGetTokenQuery(tokenID);
		List<BPMToken> tokens = this.operations.query(qb.toSql(query), BPMMapper.getTokenMapper());
		return tokens.size() == 0 ? null : (BPMToken) tokens.get(0);
	}

	@Override
	public BPMToken getToken(int tokenID, String payeeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildGetTokenQuery(tokenID);
		Join tokenAssigneeJoin = new Join("BPMTokenAssignee", Join.Type.INNER);
		tokenAssigneeJoin.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, "BPMTokenAssignee",
				"TokenID");
		query.joinWith(tokenAssigneeJoin);
		query.newConstraint("BPMTokenAssignee", "Assignee", Constraint.Operator.Equals, payeeID);
		List<BPMToken> tokens = this.operations.query(qb.toSql(query), BPMMapper.getTokenMapper());
		return tokens.size() == 0 ? null : (BPMToken) tokens.get(0);
	}

	@Override
	public BPMToken[] getTokens(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMToken");
		query.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, nodeID);
		query.select("BPMToken", "TokenID");
		query.select("BPMToken", "FormID");
		query.select("BPMToken", "NodeID");
		query.select("BPMToken", "OwnerID");
		query.select("BPMToken", "LastActorID");
		query.select("BPMToken", "PathID");
		query.select("BPMToken", "Waiting");
		query.select("BPMToken", "_RowVersion");
		List<BPMToken> tokens = this.operations.query(qb.toSql(query), BPMMapper.getTokenMapper());
		return (BPMToken[]) tokens.toArray(new BPMToken[0]);
	}

	@Override
	public BPMToken updateToken(BPMToken token) throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("BPMToken");
		update.set("NodeID", token.getNodeID());
		update.set("LastActorID", token.getLastActorID());
		update.set("PathID", token.getPathID());
		update.set("Waiting", token.isWaiting() ? 1 : 0);
		update.setSystemDateTime("LastModified");
		update.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, token.getTokenID());
		update.newCustomConstraint(this.getRowVersionConstraint("BPMToken", "_RowVersion", token.getRowVersion()));
		UpdateBuilder ub = Database.getUpdateBuilder();
		int count = this.operations.update(ub.toSql(update));
		if (count == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			return this.getToken(token.getTokenID());
		}
	}

	@Override
	public int insertNodeHistory(int workflowID, String nodeName, String initiator, String actor, String action) {
		InsertDefinition insert = new InsertDefinition("BPMNodeHistory", new String[] { "WorkflowID", "NodeName",
				"Initiator", "Actor", "Action", "DateActioned", "IsForcedBy", "WebReportName" });
		insert.addValue(workflowID);
		insert.addValue(nodeName);
		insert.addValue(initiator);
		insert.addValue(actor);
		insert.addValue(action);
		insert.addSystemDateTime();
		insert.addNullValue();
		insert.addValue(this.GetReportName(workflowID));
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
		QueryBuilder qb2 = Database.getQueryBuilder();
		QueryDefinition qd2 = getNodeHistoryIdQuery();
		int id = (Integer) this.operations.queryForObject(qb2.toSql(qd2), Integer.class);
		return id;
	}

	private String GetReportName(int workflowID) {
		Join join = new Join("WebReport", Join.Type.INNER);
		join.newConstraint("WebReport", "WebReportID", Constraint.Operator.Equals, "BPMWorkflow", "WebReportID");
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		query.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, workflowID);
		query.joinWith(join);
		query.select("WebReport", "Name");
		List<String> result = this.operations.query(query.toSql(), RowMapperUtil.getStringMapper());
		return result.isEmpty() ? "" : (String) result.get(0);
	}

	@Override
	public void insertNodeError(int nodeID, String errorMessage) {
		InsertDefinition insert = new InsertDefinition("BPMNodeError",
				new String[] { "NodeID", "ErrorMessage", "Time" });
		insert.addValue(nodeID);
		insert.addValue(errorMessage);
		insert.addSystemDateTime();
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
	}

	@Override
	public void insertAlertError(int nodeID, int tokenID, String nodeName, String initiator, String errorMessage) {
		InsertDefinition ib = new InsertDefinition("BPMAlertNodeError",
				new String[] { "TokenID", "NodeID", "Initiator", "Date", "Error" });
		ib.addValue(tokenID);
		ib.addValue(nodeID);
		if (initiator == null) {
			ib.addNullValue();
		} else {
			ib.addValue(initiator);
		}

		ib.addSystemDateTime();
		ib.addValue(errorMessage);
		InsertBuilder i = Database.getInsertBuilder();
		this.operations.execute(i.toSql(ib));
	}

	@Override
	public int getScopeIdentity() {
		return (Integer) this.operations.queryForObject("SELECT SCOPE_IDENTITY()", Integer.class);
	}

	@Override
	public void insertTokenError(int tokenID) {
		InsertDefinition insert = new InsertDefinition("BPMTokenError", new String[] { "TokenID", "Time" });
		insert.addValue(tokenID);
		insert.addSystemDateTime();
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
	}

	@Override
	public void insertTokenHistory(int nodeHistoryID, int tokenID) {
		InsertDefinition insert = new InsertDefinition("BPMPendingTokenHistory",
				new String[] { "NodeHistoryID", "TokenID" });
		insert.addValue(nodeHistoryID);
		insert.addValue(tokenID);
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
	}

	private CustomConstraint getRowVersionConstraint(String table, String rowVersionColumn, long rowVersion) {
		return new CustomConstraint("CONVERT(BIGINT, " + table + "." + rowVersionColumn + ") = " + rowVersion);
	}

	@Override
	public void batchUpdateToken(int nodeID, int targetNodeID, int pathID, boolean waiting) {
		UpdateDefinition update = new UpdateDefinition("BPMToken");
		update.set("NodeID", targetNodeID);
		update.set("PathID", pathID);
		update.set("Waiting", waiting ? 1 : 0);
		update.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, nodeID);
		UpdateBuilder ub = Database.getUpdateBuilder();
		this.operations.update(ub.toSql(update));
	}

	@Override
	public boolean checkAllTokensAreWaiting(int nodeID) {
		BPMNode node = this.getNode(nodeID);
		BPMSwimLane swimLane = this.getSwimLane(node.getSwimLaneID());
		QueryDefinition query = new QueryDefinition("BPMToken");
		query.selectCount();
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMNode", "SwimLaneID", Constraint.Operator.Equals, "BPMSwimLane", "SwimLaneID");
		query.joinWith(swimLaneJoin);
		query.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, swimLane.getWorkflowID());
		OrClause or = new OrClause();
		or.newConstraint("BPMToken", "NodeID", Constraint.Operator.NotEquals, nodeID);
		or.newConstraint("BPMToken", "Waiting", Constraint.Operator.NotEquals, 1);
		query.addConstraint(or);
		QueryBuilder qb = Database.getQueryBuilder();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count == 0;
	}

	@Override
	public boolean checkAllAssignessSubmitted(int tokenID) {
		QueryDefinition query = new QueryDefinition("BPMTokenAssignee");
		query.selectCount();
		query.newConstraint("BPMTokenAssignee", "TokenID", Constraint.Operator.Equals, tokenID);
		QueryBuilder qb = Database.getQueryBuilder();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count == 0;
	}

	@Override
	public boolean isAlertNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMAlertNode");
		query.newConstraint("BPMAlertNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.selectCount();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	@Override
	public boolean isEndNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMEndNode");
		query.newConstraint("BPMEndNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.selectCount();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	@Override
	public boolean isProcessNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMProcessNode");
		query.newConstraint("BPMProcessNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.selectCount();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	@Override
	public boolean isActionNode(int nodeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMActionNode");
		query.newConstraint("BPMActionNode", "NodeID", Constraint.Operator.Equals, nodeID);
		query.selectCount();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	public String[] getFirstSwimLaneMembers(int swimLaneID) {
		BPMSwimLane swimLane = this.getSwimLane(swimLaneID);
		List<String> members = new ArrayList();
		if (swimLane.getMemberDefinition() != null) {
			for (Join j : new ArrayList<Join>()) {
				swimLane.getMemberDefinition().getQuery().getJoins().add(0, j);
			}

			QueryBuilder qb = Database.getQueryBuilder();
			QueryDefinition query = swimLane.getMemberDefinition().getQuery();
			query.selectDistinct();
			members.addAll(this.operations.query(qb.toSql(query), this.payeeIDMapper));
		}

		for (String member : swimLane.getPayeeIDs()) {
			members.add(member);
		}

		return (String[]) members.toArray(new String[0]);
	}

	@Override
	public String[] getInitiator(int tokenID) {
		BPMToken token = this.getToken(tokenID);
		int nodeID = token.getNodeID();
		int firstSLID = this.getFirstSwimLaneID(nodeID);
		return this.getFirstSwimLaneMembers(firstSLID);
	}

	@Override
	public String getTokenOwner(int tokenID) {
		BPMToken token = this.getToken(tokenID);
		return token == null ? null : token.getOwnerID();
	}

	@Override
	public String[] getSwimLaneMembers(int swimLaneID, int tokenID) {
		BPMToken token = this.getToken(tokenID);
		BPMNode node = this.getNode(token.getNodeID());
		BPMSwimLane swimLane = this.getSwimLane(swimLaneID);
		if (swimLane.isSystemLane()) {
			return new String[0];
		} else if (swimLane.isFirstUserLane()) {
			return new String[] { token.getOwnerID() };
		} else {
			List<String> overriddenPayeeIDs = this.getOverriddenPayeeIDs(node.getNodeID(), token.getTokenID());
			if (overriddenPayeeIDs.size() > 0) {
				return (String[]) overriddenPayeeIDs.toArray(new String[0]);
			} else {
				List<String> members = new ArrayList();
				if (swimLane.getMemberDefinition() != null) {
					int formInitiatorJoinPosition = this.findJoin(swimLane.getMemberDefinition().getQuery(),
							"Form Initiator");
					if (formInitiatorJoinPosition > -1) {
						Join formInitiatorJoin = this.stripSourceJoin(swimLane.getMemberDefinition().getQuery(),
								formInitiatorJoinPosition);
						QueryDefinition formInitiatorQuery = new QueryDefinition("Payee_",
								formInitiatorJoin.getSource().getAlias());
						formInitiatorQuery.selectAll();
						formInitiatorQuery.newConstraint(formInitiatorJoin.getSource().getAlias(), "PayeeID_",
								Constraint.Operator.Equals, token.getOwnerID());
						formInitiatorJoin.getSource().getQuery().setSource(
								new SqlDataSource(formInitiatorQuery, formInitiatorJoin.getSource().getAlias()));
						swimLane.getMemberDefinition().getQuery().getJoins().add(formInitiatorJoinPosition,
								formInitiatorJoin);
					}

					this.updateLiteralValue(swimLane.getMemberDefinition().getQuery(), "WorkflowFormID_",
							token.getFormID());
					List<Join> scalarJoins = new ArrayList();
					BPMTokenParameter[] parameters = this.reportingDao.getTokenParameters(tokenID);
					Join aliasJoin = null;

					for (BPMTokenParameter parameter : parameters) {
						aliasJoin = null;
						int position = this.findJoin(swimLane.getMemberDefinition().getQuery(),
								"_Local_" + parameter.getName());
						if (position > -1) {
							aliasJoin = this.stripSourceJoin(swimLane.getMemberDefinition().getQuery(), position);
							Literal variableLiteral = null;
							if (parameter.getParamType().equals(Scope.Type.DATE.toString())) {
								variableLiteral = new Literal(Literal.Type.DATETIME, Parse.date(parameter.getValue()));
							} else if (parameter.getParamType().equals(Scope.Type.DECIMAL.toString())) {
								variableLiteral = new Literal(Literal.Type.DECIMAL,
										Parse.parseDecimal(parameter.getValue(), false));
							} else {
								variableLiteral = new Literal(Literal.Type.STRING, parameter.getValue());
							}

							QueryDefinition variableQuery = new QueryDefinition();
							if (variableLiteral.getType() == Literal.Type.STRING) {
								String s = variableLiteral.getValue().toString();
								int length = s.length() > 100 ? 1000 : 100;
								String sqlServer = null;
								if (VaricentContext.isModelUnicode()) {
									sqlServer = "CAST(N'" + s.replaceAll("'", "''") + "' AS NVARCHAR(" + length + "))";
								} else {
									sqlServer = "CAST('" + s.replaceAll("'", "''") + "' AS VARCHAR(" + length + "))";
								}

								SelectCustom item = new SelectCustom(sqlServer, parameter.getName());
								variableQuery.addSelect(item);
							} else {
								variableQuery.select(variableLiteral, parameter.getName());
							}

							Join variableCrossjoin = new Join(variableQuery, aliasJoin.getSource().getName(),
									Join.Type.CROSS);
							scalarJoins.add(variableCrossjoin);
						}

						if (aliasJoin == null) {
						}
					}

					for (Join j : scalarJoins) {
						swimLane.getMemberDefinition().getQuery().getJoins().add(0, j);
					}

					QueryBuilder qb = Database.getQueryBuilder();
					QueryDefinition query = swimLane.getMemberDefinition().getQuery();
					query.selectDistinct();
					members.addAll(this.operations.query(qb.toSql(query), this.payeeIDMapper));
				}

				for (String member : swimLane.getPayeeIDs()) {
					members.add(member);
				}

				return (String[]) members.toArray(new String[0]);
			}
		}
	}

	private List<String> getOverriddenPayeeIDs(int nodeID, int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("BPMNodeOverride");
		query.select("BPMNodeOverride", "PayeeID", "PayeeID_");
		query.newConstraint("BPMNodeOverride", "NodeID", Constraint.Operator.Equals, nodeID);
		query.newConstraint("BPMNodeOverride", "TokenID", Constraint.Operator.Equals, tokenID);
		return this.operations.query(qb.toSql(query), this.payeeIDMapper);
	}

	private Join stripSourceJoin(QueryDefinition query, int position) {
		Join join = query.getJoins().get(position);
		query.getJoins().remove(position);
		return join;
	}

	int findJoin(QueryDefinition query, String variable) {
		for (int i = 0; i < query.getJoins().size(); ++i) {
			Join join = query.getJoins().get(i);
			if (query.getTableName(join.getSource().getName()).equals(variable)) {
				return i;
			}
		}

		return -1;
	}

	private void updateLiteralValue(QueryDefinition query, String variable, int value) {
		for (Join element : query.getJoins()) {
			Join join = element;
			if (join.getSource().isQuery()) {
				QueryDefinition subQuery = join.getSource().getQuery();
				if (subQuery.getSource().isQuery()) {
					subQuery = subQuery.getSource().getQuery();
					if (subQuery.getSelect().size() == 1) {
						ISelectItem select = subQuery.getSelect().get(0);
						if (select instanceof SelectLiteral) {
							SelectLiteral temp_select = (SelectLiteral) select;
							if (temp_select.getAlias().equals(variable)) {
								Literal newLiteral = new Literal(Literal.Type.INTEGER, value);
								subQuery.clearSelects();
								subQuery.select(newLiteral, variable);
								return;
							}
						}
					}
				}
			}
		}

	}

	@Override
	public boolean canViewToken(int tokenID, String payeeID) {
		QueryDefinition query = new QueryDefinition("BPMTokenAssignee");
		query.selectCount();
		query.newConstraint("BPMTokenAssignn", "TokenID", Constraint.Operator.Equals, tokenID);
		query.newConstraint("BPMTokenAssignee", "Assignee", Constraint.Operator.Equals, payeeID);
		QueryBuilder qb = Database.getQueryBuilder();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	@Override
	public void scheduleProcessNode(int processNodeID, int tokenID) {
		InsertDefinition insert = new InsertDefinition("BPMScheduledProcess",
				new String[] { "ProcessNodeID", "TokenID", "Status" });
		insert.addValue(processNodeID);
		insert.addValue(tokenID);
		insert.addValue(0);
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.update(ib.toSql(insert));
	}

	public static QueryDefinition getRowNumberQuery(QueryDefinition innerQuery, int pageNumber, int rowsPerPage,
			String[] sortColumn, boolean[] descending) {
		int index = (pageNumber - 1) * rowsPerPage;
		String rowNumberQuery = "ROW_NUMBER() OVER (ORDER BY ";

		for (int i = 0; i < sortColumn.length; ++i) {
			String sortOrder = descending[i] ? "DESC" : "ASC";
			rowNumberQuery = rowNumberQuery + "[_inner].[" + sortColumn[i] + "] " + sortOrder;
			if (i == sortColumn.length - 1) {
				rowNumberQuery = rowNumberQuery + ")";
			} else {
				rowNumberQuery = rowNumberQuery + ", ";
			}
		}

		QueryDefinition rowNumQuery = new QueryDefinition(innerQuery, "_inner");
		rowNumQuery.selectAll();
		rowNumQuery.addSelect(new SelectCustom(rowNumberQuery, "ROW_NUMBER"));
		QueryDefinition outerQuery = new QueryDefinition(rowNumQuery, "_outer");
		outerQuery.selectAll();
		outerQuery.orderBy("ROW_NUMBER");
		outerQuery.newConstraint("_outer", "ROW_NUMBER", Constraint.Operator.GreaterThan, index);
		outerQuery.limitTo(rowsPerPage);
		return outerQuery;
	}

	@Override
	public BPMTokenView[] getBPMTokenViews(String payeeID, int pageNumber, int rowsPerPage) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition innerQuery = this.buildBPMTokenViewsInnerQuery(payeeID);
		QueryDefinition limitedQuery = getRowNumberQuery(innerQuery, pageNumber, rowsPerPage,
				new String[] { "LastModified" }, new boolean[] { true });
		List<BPMTokenView> tokenViews = this.operations.query(qb.toSql(limitedQuery),
				BPMMapper.getTokenViewMapperWithRowNumbers());
		return (BPMTokenView[]) tokenViews.toArray(new BPMTokenView[0]);
	}

	@Override
	public BPMTokenView[] getBPMTokenViews(String payeeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition innerQuery = this.buildBPMTokenViewsInnerQuery(payeeID);
		List<BPMTokenView> tokenViews = this.operations.query(qb.toSql(innerQuery), BPMMapper.getTokenViewMapper());
		return (BPMTokenView[]) tokenViews.toArray(new BPMTokenView[0]);
	}

	@Override
	public int getBPMTokenViewsCount(String payeeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition(this.buildBPMTokenViewsInnerQuery(payeeID), "_inner");
		query.selectCount();
		return (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
	}

	private QueryDefinition buildBPMTokenViewsInnerQuery(String payeeID) {
		QueryDefinition query = new QueryDefinition("BPMTokenAssignee");
		Join tokenJoin = new Join("BPMToken", Join.Type.INNER);
		tokenJoin.newConstraint("BPMTokenAssignee", "TokenID", Constraint.Operator.Equals, "BPMToken", "TokenID");
		query.joinWith(tokenJoin);
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		Join actionNodeJoin = new Join("BPMActionNode", Join.Type.INNER);
		actionNodeJoin.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, "BPMActionNode", "NodeID");
		query.joinWith(actionNodeJoin);
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMNode", "SwimLaneID", Constraint.Operator.Equals, "BPMSwimLane", "SwimLaneID");
		query.joinWith(swimLaneJoin);
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		query.joinWith(workflowJoin);
		Join reportJoin = new Join("WebReport", Join.Type.INNER);
		reportJoin.newConstraint("BPMWorkflow", "WebReportID", Constraint.Operator.Equals, "WebReport", "WebReportID");
		query.joinWith(reportJoin);
		Join payeeJoin = new Join("Payee_", Join.Type.LEFT);
		payeeJoin.newConstraint("BPMToken", "OwnerID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(payeeJoin);
		query.select("BPMToken", "TokenID");
		query.select("BPMToken", "OwnerID");
		query.select("BPMWorkflow", "Name", "WorkflowName");
		query.select("BPMWorkflow", "WorkflowID", "WorkflowID");
		query.select("BPMNode", "Description", "Description");
		query.select("BPMNode", "Name", "NodeName");
		query.select("WebReport", "Name", "ReportName");
		query.select("BPMToken", "CreatedAt");
		query.select("BPMToken", "LastModified");
		query.select("Payee_", "Name_", "PayeeName");
		query.newConstraint("BPMTokenAssignee", "Assignee", Constraint.Operator.Equals, payeeID);
		query.newConstraint("BPMToken", "Waiting", Constraint.Operator.Equals, 0);
		return query;
	}

	@Override
	public BPMTokenView getBPMTokenView(String payeeID, int tokenID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildBPMTokenViewsInnerQuery(payeeID);
		query.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, tokenID);
		query.limitTo(1);
		List<BPMTokenView> results = this.operations.query(qb.toSql(query), BPMMapper.getTokenViewMapper());
		return results.size() < 1 ? null : (BPMTokenView) results.get(0);
	}

	@Override
	public BPMTokenView[] getCompletedTokenViews(String payeeId, int page, int rowPerPage) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition deletedTokenQuery = this.buildDeletedCompletedTokenCountQuery(payeeId);
		QueryDefinition activeTokenQuery = this.buildActiveCompletedTokenCountQuery(payeeId);
		deletedTokenQuery.union(activeTokenQuery);
		QueryDefinition query = new QueryDefinition(deletedTokenQuery, "_deletedTokens");
		query.select("_deletedTokens", "ID");
		query.select("_deletedTokens", "Initiator");
		query.select("_deletedTokens", "InitiatorName");
		query.select("_deletedTokens", "InitiationDate");
		query.select("_deletedTokens", "CompletionDate");
		query.select("_deletedTokens", "WorkFlowName");
		QueryDefinition rowNumberQuery = getRowNumberQuery(query, page, rowPerPage, new String[] { "CompletionDate" },
				new boolean[] { true });
		List<BPMTokenView> completedTokens = this.operations.query(qb.toSql(rowNumberQuery),
				BPMMapper.getCompletedTokenListViewWithRowMapper());
		return (BPMTokenView[]) completedTokens.toArray(new BPMTokenView[0]);
	}

	@Override
	public BPMTokenView[] getCompletedTokenViews(String payeeId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition deletedTokenQuery = this.buildDeletedCompletedTokenCountQuery(payeeId);
		QueryDefinition activeTokenQuery = this.buildActiveCompletedTokenCountQuery(payeeId);
		deletedTokenQuery.union(activeTokenQuery);
		QueryDefinition query = new QueryDefinition(deletedTokenQuery, "_deletedTokens");
		query.select("_deletedTokens", "ID");
		query.select("_deletedTokens", "Initiator");
		query.select("_deletedTokens", "InitiatorName");
		query.select("_deletedTokens", "InitiationDate");
		query.select("_deletedTokens", "CompletionDate");
		query.select("_deletedTokens", "WorkFlowName");
		query.orderBy("_deletedTokens", "CompletionDate", true);
		List<BPMTokenView> completedTokens = this.operations.query(qb.toSql(query),
				BPMMapper.getCompletedTokenListViewMapper());
		return (BPMTokenView[]) completedTokens.toArray(new BPMTokenView[0]);
	}

	@Override
	public void insertTokenAssignee(int tokenID, String payeeID) {
		InsertDefinition insert = new InsertDefinition("BPMTokenAssignee", new String[] { "TokenID", "Assignee" });
		insert.addValue(tokenID);
		insert.addValue(payeeID);
		InsertBuilder ib = Database.getInsertBuilder();
		this.operations.execute(ib.toSql(insert));
	}

	@Override
	public void deleteTokenAssignee(int tokenID) {
		DeleteDefinition delete = new DeleteDefinition("BPMTokenAssignee");
		delete.newConstraint("BPMTokenAssignee", "TokenID", Constraint.Operator.Equals, tokenID);
		DeleteBuilder db = Database.getDeleteBuilder();
		this.operations.execute(db.toSql(delete));
	}

	@Override
	public void deleteTokenAssignee(int tokenID, String assignee) {
		DeleteDefinition delete = new DeleteDefinition("BPMTokenAssignee");
		delete.newConstraint("BPMTokenAssignee", "TokenID", Constraint.Operator.Equals, tokenID);
		delete.newConstraint("BPMTokenAssignee", "Assignee", Constraint.Operator.Equals, assignee);
		DeleteBuilder db = Database.getDeleteBuilder();
		this.operations.execute(db.toSql(delete));
	}

	@Override
	public String[] getTokenAssignees(int tokenID) {
		QueryDefinition query = new QueryDefinition("BPMTokenAssignee");
		query.select("BPMTokenAssignee", "Assignee", "PayeeID_");
		query.newConstraint("BPMTokenAssignee", "TokenID", Constraint.Operator.Equals, tokenID);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> assignees = this.operations.query(qb.toSql(query), this.payeeIDMapper);
		return (String[]) assignees.toArray(new String[0]);
	}

	@Override
	public String[] getWorkflowInitiators(int workflowID) {
		QueryDefinition query = new QueryDefinition("WorkflowInitiator");
		query.select("WorkflowInitiator", "PayeeID", "PayeeID_");
		query.newConstraint("WorkflowInitiator", "WorkflowID", Constraint.Operator.Equals, workflowID);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> initiators = this.operations.query(qb.toSql(query), this.payeeIDMapper);
		return (String[]) initiators.toArray(new String[0]);
	}

	@Override
	public BPMWorkflowView[] getInitiatableWorkflows(String payeeID) {
		QueryDefinition query = this.buildInitiatableWorkflowsInnerQuery(payeeID);
		QueryBuilder qb = Database.getQueryBuilder();
		List<BPMWorkflowView> workflows = this.operations.query(qb.toSql(query), BPMMapper.getWorkflowViewMapper());
		return (BPMWorkflowView[]) workflows.toArray(new BPMWorkflowView[0]);
	}

	@Override
	public BPMWorkflowView[] getInitiatableWorkflows(String payeeID, int pageNumber, int rowsPerPage,
			boolean sortDescending) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition innerQuery = this.buildInitiatableWorkflowsInnerQuery(payeeID);
		QueryDefinition limitedQuery = getRowNumberQuery(innerQuery, pageNumber, rowsPerPage, new String[] { "Name" },
				new boolean[] { sortDescending });
		List<BPMWorkflowView> workflowViews = this.operations.query(qb.toSql(limitedQuery),
				BPMMapper.getWorkflowViewMapperWithRowNumbers());
		return (BPMWorkflowView[]) workflowViews.toArray(new BPMWorkflowView[0]);
	}

	@Override
	public boolean canInitiateWorkflow(String payeeID, int workflowID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.buildInitiatableWorkflowsInnerQuery(payeeID);
		query.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, workflowID);
		QueryDefinition countQuery = new QueryDefinition(query, "_inner");
		countQuery.selectCount();
		int numRows = (Integer) this.operations.queryForObject(qb.toSql(countQuery), Integer.class);
		return numRows != 0;
	}

	@Override
	public int getInitiatableWorkflowsCount(String payeeID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition(this.buildInitiatableWorkflowsInnerQuery(payeeID), "_inner");
		query.selectCount();
		return (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
	}

	@Override
	public int BPMCompletedTokenCount(boolean countActiveToken, boolean countDeletedToken, String payeeId) {
		int activeTokenCount = 0;
		int deletedTokenCount = 0;
		QueryBuilder qb = Database.getQueryBuilder();
		if (countActiveToken) {
			QueryDefinition query = this.buildBPMCompletedTokenCountOuterQuery(
					this.buildActiveCompletedTokenCountQuery(payeeId), "_countQuery");
			activeTokenCount = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		}

		if (countDeletedToken) {
			QueryDefinition query = this.buildBPMCompletedTokenCountOuterQuery(
					this.buildDeletedCompletedTokenCountQuery(payeeId), "_countQuery");
			deletedTokenCount = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		}

		return activeTokenCount + deletedTokenCount;
	}

	private QueryDefinition buildBPMCompletedTokenCountOuterQuery(QueryDefinition mainsource, String alias) {
		QueryDefinition query = new QueryDefinition(mainsource, alias);
		query.selectCount();
		return query;
	}

	private QueryDefinition buildActiveCompletedTokenCountQuery(String payeeId) {
		QueryDefinition query = new QueryDefinition("BPMToken");
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, "BPMNode", "NodeID");
		query.joinWith(nodeJoin);
		Join endNodeJoin = new Join("BPMEndNode", Join.Type.INNER);
		endNodeJoin.newConstraint("BPMToken", "NodeID", Constraint.Operator.Equals, "BPMEndNode", "NodeID");
		query.joinWith(endNodeJoin);
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMNode", "SwimLaneID", Constraint.Operator.Equals, "BPMSwimLane", "SwimLaneID");
		query.joinWith(swimLaneJoin);
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMSwimLane", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		query.joinWith(workflowJoin);
		Join reportJoin = new Join("WebReport", Join.Type.INNER);
		reportJoin.newConstraint("BPMWorkflow", "WebReportID", Constraint.Operator.Equals, "WebReport", "WebReportID");
		query.joinWith(reportJoin);
		Join formJoin = new Join("BPMForm", Join.Type.INNER);
		formJoin.newConstraint("BPMForm", "FormID", Constraint.Operator.Equals, "BPMToken", "FormID");
		query.joinWith(formJoin);
		query.select("BPMToken", "TokenID", "ID");
		query.select("BPMForm", "PayeeID", "Initiator");
		query.selectCustom("(select Payee_.Name_ from Payee_ where Payee_.PayeeID_ = [BPMForm].[PayeeID])",
				"InitiatorName");
		query.select("BPMToken", "CreatedAt", "InitiationDate");
		query.select("BPMToken", "LastModified", "CompletionDate");
		query.select("BPMWorkflow", "Name", "WorkFlowName");
		query.newConstraint("BPMForm", "PayeeID", Constraint.Operator.Equals, payeeId);
		return query;
	}

	private QueryDefinition buildDeletedCompletedTokenCountQuery(String payeeId) {
		QueryDefinition query = new QueryDefinition("BPMDeletedCompletedToken");
		query.select("BPMDeletedCompletedToken", "ID");
		query.select("BPMDeletedCompletedToken", "Initiator");
		query.selectCustom(
				"(select Payee_.Name_ from Payee_ where Payee_.PayeeID_ = [BPMDeletedCompletedToken].[Initiator])",
				"InitiatorName");
		query.select("BPMDeletedCompletedToken", "InitiationDate");
		query.select("BPMDeletedCompletedToken", "CompletionDate");
		query.select("BPMWorkflow", "Name", "WorkFlowName");
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMDeletedCompletedToken", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		query.joinWith(workflowJoin);
		query.newConstraint("BPMDeletedCompletedToken", "Initiator", Constraint.Operator.Equals, payeeId);
		return query;
	}

	private QueryDefinition buildDeletedCompletedTokenViewQuery(int tokenID) {
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMDeletedCompletedToken", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		Join tokenHistoryJoin = new Join("BPMDeletedCompletedTokensHistory", Join.Type.INNER);
		tokenHistoryJoin.newConstraint("BPMDeletedCompletedTokensHistory", "DeletedCompletedTokenID",
				Constraint.Operator.Equals, "BPMDeletedCompletedToken", "ID");
		Join reportJoin = new Join("BPMNodeHistory", Join.Type.INNER);
		reportJoin.newConstraint("BPMNodeHistory", "ID", Constraint.Operator.Equals, "BPMDeletedCompletedTokensHistory",
				"NodeHistoryID");
		QueryDefinition query = new QueryDefinition("BPMDeletedCompletedToken");
		query.select("BPMDeletedCompletedToken", "ID");
		query.select("BPMDeletedCompletedToken", "Initiator");
		query.select("BPMDeletedCompletedToken", "LastActor");
		query.select("BPMDeletedCompletedToken", "InitiationDate");
		query.select("BPMDeletedCompletedToken", "CompletionDate");
		query.select("BPMWorkflow", "Name", "WorkflowName");
		query.select("BPMNodeHistory", "WebReportName");
		query.joinWith(workflowJoin);
		query.joinWith(tokenHistoryJoin);
		query.joinWith(reportJoin);
		query.newConstraint("BPMDeletedCompletedToken", "ID", Constraint.Operator.Equals, tokenID);
		return query;
	}

	private QueryDefinition buildInitiatableWorkflowsInnerQuery(String payeeID) {
		QueryDefinition query = new QueryDefinition("BPMWorkflowInitiator");
		Join workflowJoin = new Join("BPMWorkflow", Join.Type.INNER);
		workflowJoin.newConstraint("BPMWorkflowInitiator", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflow",
				"WorkflowID");
		query.joinWith(workflowJoin);
		query.select("BPMWorkflow", "WorkflowID");
		query.select("BPMWorkflow", "Name");
		query.select("BPMWorkflow", "Description");
		query.newConstraint("BPMWorkflowInitiator", "PayeeID", Constraint.Operator.Equals, payeeID);
		return query;
	}

	@Override
	public BPMWorkflowView getWorkflowView(int workflowID) {
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		query.select("BPMWorkflow", "WorkflowID");
		query.select("BPMWorkflow", "Name");
		query.select("BPMWorkflow", "Description");
		query.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, workflowID);
		QueryBuilder qb = Database.getQueryBuilder();
		List<BPMWorkflowView> workflows = this.operations.query(qb.toSql(query), BPMMapper.getWorkflowViewMapper());

		assert workflows.size() == 1;

		return workflows.get(0);
	}

	@Override
	public boolean isViewableReport(int reportID) {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition subQuery = BPMQuery.getActionableReportsQuery(user.getPayeeId());
		subQuery.union(BPMQuery.getInitializableReportsQuery(user.getPayeeId()));
		QueryDefinition query = new QueryDefinition(subQuery, "ViewableReports");
		query.selectCount();
		query.newConstraint("ViewableReports", "WebReportID", Constraint.Operator.Equals, reportID);
		QueryBuilder qb = Database.getQueryBuilder();
		int count = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
		return count > 0;
	}

	@Override
	public HashMap<String, Boolean> getWorkflowLayoutVisibilityMap(int workflowID) {
		QueryDefinition query = new QueryDefinition("BPMWorkflowReportLayoutAssignment");
		query.select("BPMWorkflowReportLayoutAssignment", "LayoutName");
		query.select("BPMWorkflowReportLayoutAssignment", "IsViewable");
		query.newConstraint("BPMWorkflowReportLayoutAssignment", "WorkflowID", Constraint.Operator.Equals, workflowID);
		QueryBuilder qb = Database.getQueryBuilder();
		HashMap<String, Boolean> map = new HashMap();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			String layoutName = result.getString("LayoutName");
			Boolean isViewable = result.getInt("IsViewable") == 1;
			map.put(layoutName, isViewable);
		}

		return map;
	}

	@Override
	public HashMap<String, Boolean> getWorkflowLayoutEditabilityMap(int workflowID) {
		QueryDefinition query = new QueryDefinition("BPMWorkflowReportLayoutAssignment");
		query.select("BPMWorkflowReportLayoutAssignment", "LayoutName");
		query.select("BPMWorkflowReportLayoutAssignment", "IsEditable");
		query.newConstraint("BPMWorkflowReportLayoutAssignment", "WorkflowID", Constraint.Operator.Equals, workflowID);
		QueryBuilder qb = Database.getQueryBuilder();
		HashMap<String, Boolean> map = new HashMap();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			String layoutName = result.getString("LayoutName");
			Boolean isEditable = result.getInt("IsEditable") == 1;
			map.put(layoutName, isEditable);
		}

		return map;
	}

	@Override
	public HashMap<String, Boolean> getActionNodeLayoutVisibilityMap(int nodeID) {
		QueryDefinition query = new QueryDefinition("BPMActionNodeReportLayoutAssignment");
		query.select("BPMActionNodeReportLayoutAssignment", "LayoutName");
		query.select("BPMActionNodeReportLayoutAssignment", "IsViewable");
		query.newConstraint("BPMActionNodeReportLayoutAssignment", "NodeID", Constraint.Operator.Equals, nodeID);
		QueryBuilder qb = Database.getQueryBuilder();
		HashMap<String, Boolean> map = new HashMap();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			String layoutName = result.getString("LayoutName");
			Boolean isViewable = result.getInt("IsViewable") == 1;
			map.put(layoutName, isViewable);
		}

		return map;
	}

	@Override
	public HashMap<String, Boolean> getActionNodeLayoutEditabilityMap(int nodeID) {
		QueryDefinition query = new QueryDefinition("BPMActionNodeReportLayoutAssignment");
		query.select("BPMActionNodeReportLayoutAssignment", "LayoutName");
		query.select("BPMActionNodeReportLayoutAssignment", "IsEditable");
		query.newConstraint("BPMActionNodeReportLayoutAssignment", "NodeID", Constraint.Operator.Equals, nodeID);
		QueryBuilder qb = Database.getQueryBuilder();
		HashMap<String, Boolean> map = new HashMap();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			String layoutName = result.getString("LayoutName");
			Boolean isEditable = result.getInt("IsEditable") == 1;
			map.put(layoutName, isEditable);
		}

		return map;
	}

	@Override
	public void markFormAsInitiated(int formID) {
		UpdateDefinition update = new UpdateDefinition("BPMForm");
		update.set("Initiated", 1);
		update.newConstraint("BPMForm", "FormID", Constraint.Operator.Equals, formID);
		UpdateBuilder ub = Database.getUpdateBuilder();
		this.operations.update(ub.toSql(update));
	}

	@Override
	public int getUninitiatedFormID(int workflowID, String payeeID, boolean createNewIfNotExists)
			throws DatabaseConcurrencyException {
		QueryDefinition lock = new QueryDefinition("BPMForm");
		lock.limitTo(1);
		lock.select("BPMForm", "FormID");
		QueryBuilder lockQb = Database.getQueryBuilder();
		String lockQuery = lockQb.toSql(lock);
		lockQuery = lockQuery + " WITH (HOLDLOCK, TABLOCKX)";
		this.operations.execute(lockQuery);
		QueryDefinition count = new QueryDefinition("BPMForm");
		count.selectCount();
		count.newConstraint("BPMForm", "WorkflowID", Constraint.Operator.Equals, workflowID);
		count.newConstraint("BPMForm", "PayeeID", Constraint.Operator.Equals, payeeID);
		count.newConstraint("BPMForm", "Initiated", Constraint.Operator.Equals, 0);
		QueryBuilder countQb = Database.getQueryBuilder();
		int formCount = (Integer) this.operations.queryForObject(countQb.toSql(count), Integer.class);
		if (formCount == 1) {
			QueryDefinition query = new QueryDefinition("BPMForm");
			query.select("BPMForm", "FormID");
			query.newConstraint("BPMForm", "WorkflowID", Constraint.Operator.Equals, workflowID);
			query.newConstraint("BPMForm", "PayeeID", Constraint.Operator.Equals, payeeID);
			query.newConstraint("BPMForm", "Initiated", Constraint.Operator.Equals, 0);
			QueryBuilder qb = Database.getQueryBuilder();
			int formID = (Integer) this.operations.queryForObject(qb.toSql(query), Integer.class);
			return formID;
		} else if (formCount == 0 && createNewIfNotExists) {
			InsertDefinition insert = new InsertDefinition("BPMForm",
					new String[] { "WorkflowID", "PayeeID", "Initiated" });
			insert.addValue(workflowID);
			insert.addValue(payeeID);
			insert.addValue(0);
			InsertBuilder ib = Database.getInsertBuilder();
			this.operations.execute(ib.toSql(insert));
			QueryDefinition idQuery = new QueryDefinition("BPMForm");
			idQuery.selectMax("BPMForm", "FormID", "FormID");
			QueryBuilder idQb = Database.getQueryBuilder();
			int formID = (Integer) this.operations.queryForObject(idQb.toSql(idQuery), Integer.class);
			return formID;
		} else {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void UpdateBPMPreviousParameters(HashMap<String, Object> parameters, int token)
			throws DatabaseConcurrencyException {
		if (parameters != null && token >= 0) {
			String tableName = "BPMPreviousParameter";
			List<ColumnDefinition> columns = this.schemaDao.getColumns(tableName);
			BPMWorkflow workflow = this.getWorkflowUsingTokenID(token);
			if (workflow == null) {
				throw new DatabaseConcurrencyException(
						new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
			} else {
				int reportID = workflow.getReportID();

				for (String parameter : parameters.keySet()) {
					if (!ExpandedXml.isReservedName(parameter)) {
						boolean isParameter = this.isReportParameter(parameter, reportID);
						if (isParameter) {
							boolean parameterInitiated = this.reportingDao.BPMParameterInitiated(tableName, token,
									parameter);
							String paramType = this.getParameterType(parameter, reportID);
							if (parameterInitiated) {
								UpdateDefinition ud = new UpdateDefinition(tableName);

								try {
									if (paramType.equals("DATE")) {
										if (parameters.get(parameter).toString().equals("")) {
											ud.set(this.getDefinition(columns, "Value"),
													Format.asISODate(Constants.MIN_DATE));
										} else {
											ud.set(this.getDefinition(columns, "Value"),
													Format.asISODate(Parse.date(parameters.get(parameter).toString())));
										}
									} else if (paramType.equals("DECIMAL")) {
										ud.set(this.getDefinition(columns, "Value"),
												this.getDecimalString(parameters.get(parameter)));
									} else {
										ud.set(this.getDefinition(columns, "Value"),
												parameters.get(parameter).toString());
									}

									ud.newConstraint(tableName, "TokenId", Constraint.Operator.Equals, token);
									ud.newConstraint(tableName, "ParamName", Constraint.Operator.Equals, parameter);
									UpdateBuilder ub = Database.getUpdateBuilder();
									this.operations.update(ub.toSql(ud));
								} catch (Exception var16) {
									throw new DatabaseConcurrencyException(
											new Message(Messages.Key.CONCURRENCY_ERROR_DATAINTEGRITY, new Object[0]));
								}
							} else {
								List<String> columnNames = new ArrayList();

								for (int i = 0; i < columns.size(); ++i) {
									columnNames.add(columns.get(i).getName());
								}

								try {
									InsertDefinition id = new InsertDefinition(tableName, columnNames);
									id.addValue(token);
									id.addValue(parameter);
									id.addValue(paramType);
									if (paramType.equals("DATE")) {
										if (parameters.get(parameter).toString().equals("")) {
											id.addValue(Format.asISODate(Constants.MIN_DATE));
										} else {
											id.addValue(
													Format.asISODate(Parse.date(parameters.get(parameter).toString())));
										}
									} else if (paramType.equals("DECIMAL")) {
										id.addValue(this.getDecimalString(parameters.get(parameter)));
									} else {
										id.addValue(parameters.get(parameter).toString());
									}

									InsertBuilder ib = Database.getInsertBuilder();
									this.operations.update(ib.toSql(id));
								} catch (DataIntegrityViolationException var15) {
									throw new DatabaseConcurrencyException(
											new Message(Messages.Key.CONCURRENCY_ERROR_DATAINTEGRITY, new Object[0]));
								}
							}
						}
					}
				}

			}
		}
	}

	String getDecimalString(Object input) {
		if (input instanceof BigDecimal) {
			return input.toString();
		} else {
			String decimalString = input.toString();
			return decimalString.equals("") ? (new BigDecimal(0)).toString()
					: Parse.parseDecimal(decimalString, false).toString();
		}
	}

	String getParameterType(String parameter, int reportID) {
		QueryDefinition qd = new QueryDefinition("LinkTarget");
		qd.select("LinkTarget", "Type");
		qd.newConstraint("LinkTarget", "WebReportID", Constraint.Operator.Equals, reportID);
		qd.newConstraint("LinkTarget", "ParameterName", Constraint.Operator.Equals, parameter);
		qd.newConstraint("LinkTarget", "Type", Constraint.Operator.NotEquals, "Report");
		QueryBuilder qb = Database.getQueryBuilder();
		String type = this.operations.query(qb.toSql(qd), RowMapperUtil.getStringMapper()).get(0);
		if (type.equals("DateTime")) {
			type = "Date";
		}

		return type.toUpperCase();
	}

	boolean isReportParameter(String name, int reportID) {
		QueryDefinition qd = new QueryDefinition("LinkTarget");
		qd.selectCount();
		qd.newConstraint("LinkTarget", "WebReportID", Constraint.Operator.Equals, reportID);
		qd.newConstraint("LinkTarget", "ParameterName", Constraint.Operator.Equals, name);
		qd.newConstraint("LinkTarget", "Type", Constraint.Operator.NotEquals, "Report");
		QueryBuilder qb = Database.getQueryBuilder();
		int count = (Integer) this.operations.queryForObject(qb.toSql(qd), Integer.class);
		return count > 0;
	}

	ColumnDefinition getDefinition(List<ColumnDefinition> definitions, String column) {
		for (ColumnDefinition def : definitions) {
			if (def.getName().equals(column)) {
				return def;
			}
		}

		return null;
	}

	@Override
	public void insertAlertNodeErrorAssignees(int id, Iterable<String> undeliveredPayees) {
		for (String payee : undeliveredPayees) {
			InsertDefinition definition = new InsertDefinition("BPMAlertNodeErrorAssignee");
			definition.addValue(id);
			definition.addValue(payee);
			InsertBuilder builder = Database.getInsertBuilder();
			this.operations.execute(builder.toSql(definition));
		}

	}

	public String getPayeeIDFromEmail(String email) {
		QueryDefinition qd = new QueryDefinition("Payee_");
		qd.select("Payee_", "PayeeID_");
		qd.newConstraint("Payee_", "Email_", Constraint.Operator.Equals, email);
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(qd));
		return !result.next() ? null : result.getString("PayeeID_");
	}

	@Override
	public Set<String> getPayeeIDsFromEmails(Iterable<BPMExternalEmail> emails) {
		HashSet<String> payeeIds = new HashSet();

		for (BPMExternalEmail email : emails) {
			String payeeId = this.getPayeeIDFromEmail(email.getEmail());
			if (payeeId != null) {
				payeeIds.add(payeeId);
			}
		}

		return payeeIds;
	}
}
