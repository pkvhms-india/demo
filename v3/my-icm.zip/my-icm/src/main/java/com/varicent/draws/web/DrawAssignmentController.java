package com.varicent.draws.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.tab.domain.Tab;
import com.varicent.common.tab.domain.TabObject;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.draws.service.DrawAssignmentManager;
import com.varicent.workflow.domain.WorkflowObject;

@Controller
public class DrawAssignmentController {
	public static final String VIEW = "drawassignment/index";
	public static final String UNASSIGNED_VIEW = "drawassignment/unassigned";
	public static final String FIXED_TERM_VIEW = "drawassignment/fixedterm";
	public static final String ONGOING_VIEW = "drawassignment/ongoing";
	protected static final String ACTIVE_TAB_ATTRIBUTE = "activeTab";
	private final DrawAssignmentManager drawAssignmentManager;

	@Autowired
	public DrawAssignmentController(DrawAssignmentManager drawAssignmentManager) {
		this.drawAssignmentManager = drawAssignmentManager;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Date.class, (String) null,
				new CustomDateEditor(new SimpleDateFormat("dd/MM/yyyy"), true));
	}

	@RequestMapping(value = { "/drawassignment/index.html" }, method = { RequestMethod.GET })
	public ModelAndView prepareView(HttpServletRequest request) {
		UnassignedDrawCommand cmd = new UnassignedDrawCommand();
		ModelAndView mav = new ModelAndView("drawassignment/index");
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		int drawId = getDrawId(activeTab);
		if (drawId == Integer.MIN_VALUE) {
			String drawIdString = request.getParameter("id");
			if (drawIdString == null || drawIdString.compareTo("0") == 0) {
				if (this.isWebModule(request)) {
					cmd = new UnassignedDrawCommand();
					mav.addObject("command", cmd);
					mav.addObject("viewableDraws", this.drawAssignmentManager.getViewableDraws());
				}

				return mav;
			}

			drawId = Integer.parseInt(drawIdString);
		}

		if (!this.drawAssignmentManager.drawExists(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_DOES_NOT_EXIST.toString(), request);
		} else if (!this.drawAssignmentManager.isViwableDrawAssignment(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_LACK_OF_ACCESS.toString(), request);
		} else {
			int workflowObjectId = this.drawAssignmentManager.getWorkflowObjectId(Integer.toString(drawId),
					WorkflowObject.Type.DRAW_ASSIGNMENT);
			cmd.setDrawId(drawId);
			this.populateModel(mav, cmd, drawId, workflowObjectId, this.isWebModule(request));
			return mav;
		}
	}

	@RequestMapping(value = { "/drawassignment/unassigned.html" }, method = { RequestMethod.GET })
	public ModelAndView prepareUnassignedView(HttpServletRequest request) {
		UnassignedDrawCommand cmd = (UnassignedDrawCommand) WebUtils.getSessionAttribute(request, "command");
		ModelAndView mav = new ModelAndView("drawassignment/unassigned");
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		int drawId = getDrawId(activeTab);
		if (drawId == Integer.MIN_VALUE) {
			String drawIdString = request.getParameter("id");
			if (drawIdString == null) {
				return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_INVALIDDRAW.toString(), request);
			}

			drawId = Integer.parseInt(drawIdString);
			if (drawId == 0) {
				this.clearSession(request);
				return this.prepareView(request);
			}
		}

		if (!this.drawAssignmentManager.drawExists(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_DOES_NOT_EXIST.toString(), request);
		} else if (!this.drawAssignmentManager.isViwableDrawAssignment(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_LACK_OF_ACCESS.toString(), request);
		} else {
			int workflowObjectId = this.drawAssignmentManager.getWorkflowObjectId(Integer.toString(drawId),
					WorkflowObject.Type.DRAW_ASSIGNMENT);
			if (cmd == null) {
				cmd = new UnassignedDrawCommand();
				String selectedPayeeId = null;
				int selectedGroupId = 0;
				if (request.getParameterMap().containsKey("selectedPayeeId")) {
					selectedPayeeId = request.getParameter("selectedPayeeId");
				}

				if (request.getParameterMap().containsKey("selectedGroupId")
						&& this.drawAssignmentManager.isGroupSelectionAllowed(drawId)) {
					selectedGroupId = Integer.parseInt(request.getParameter("selectedGroupId"));
				}

				cmd.setSelectedGroupId(selectedGroupId);
				cmd.setSelectedPayeeId(selectedPayeeId);
				cmd.setDescending(false);
				cmd.setClientLocale(Format.getShortDateFormatString());
				cmd.setPageNumber(1);
				cmd.setRowsPerPage(this.drawAssignmentManager.getRowsPerPage(drawId));
				cmd.setTotalPages(this.drawAssignmentManager.getUnAssignedPayeesPageCount(drawId, cmd.getRowsPerPage(),
						workflowObjectId, selectedPayeeId, selectedGroupId));
				cmd.setSortColumn("PayeeID_");
				cmd.setDrawId(drawId);
				cmd.setWorkflowObjectId(workflowObjectId);
				cmd.setUnassignedPayees(
						this.drawAssignmentManager.getUnAssignedPayees(drawId, workflowObjectId, selectedPayeeId,
								selectedGroupId, cmd.getPageNumber(), cmd.getRowsPerPage(), "PayeeID_", false));
			} else {
				BindingResult result = (BindingResult) WebUtils.getSessionAttribute(request, "errors");
				mav.addAllObjects(result.getModel());
				this.clearSession(request);
			}

			List<DrawTemplateName> availableTemplates = this.drawAssignmentManager.getDrawTemplates(drawId);
			mav.addObject("availableTemplates", availableTemplates);
			this.populateModel(mav, cmd, drawId, workflowObjectId, this.isWebModule(request));
			return mav;
		}
	}

	@RequestMapping(value = { "/drawassignment/ongoing.html" }, method = { RequestMethod.GET })
	public ModelAndView prepareOngoingView(HttpServletRequest request) {
		DrawAssignmentOngoingCommand cmd = (DrawAssignmentOngoingCommand) WebUtils.getSessionAttribute(request,
				"command");
		ModelAndView mav = new ModelAndView("drawassignment/ongoing");
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		int drawId = getDrawId(activeTab);
		if (drawId == Integer.MIN_VALUE) {
			String drawIdString = request.getParameter("id");
			if (drawIdString == null) {
				return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_INVALIDDRAW.toString(), request);
			}

			drawId = Integer.parseInt(drawIdString);
			if (drawId == 0) {
				this.clearSession(request);
				return this.prepareView(request);
			}
		}

		if (!this.drawAssignmentManager.drawExists(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_DOES_NOT_EXIST.toString(), request);
		} else if (!this.drawAssignmentManager.isViwableDrawAssignment(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_LACK_OF_ACCESS.toString(), request);
		} else {
			int workflowObjectId = this.drawAssignmentManager.getWorkflowObjectId(Integer.toString(drawId),
					WorkflowObject.Type.DRAW_ASSIGNMENT);
			if (cmd == null) {
				String selectedPayeeId = null;
				int selectedGroupId = 0;
				if (request.getParameterMap().containsKey("selectedPayeeId")) {
					selectedPayeeId = request.getParameter("selectedPayeeId");
				}

				if (request.getParameterMap().containsKey("selectedGroupId")
						&& this.drawAssignmentManager.isGroupSelectionAllowed(drawId)) {
					selectedGroupId = Integer.parseInt(request.getParameter("selectedGroupId"));
				}

				cmd = new DrawAssignmentOngoingCommand();
				cmd.setSelectedGroupId(selectedGroupId);
				cmd.setSelectedPayeeId(selectedPayeeId);
				cmd.setDrawId(drawId);
				cmd.setWorkflowObjectId(workflowObjectId);
				cmd.setDescending(false);
				cmd.setClientLocale(Format.getShortDateFormatString());
				cmd.setPageNumber(1);
				cmd.setRowsPerPage(this.drawAssignmentManager.getRowsPerPage(drawId));
				cmd.setTotalPages(this.drawAssignmentManager.getOngoingPayeesPageCount(drawId, cmd.getRowsPerPage(),
						workflowObjectId, selectedPayeeId, selectedGroupId, false));
				cmd.setSortColumn("PayeeID");
				cmd.setOngoingAssignments(
						this.drawAssignmentManager.getOngoingPayees(drawId, workflowObjectId, selectedPayeeId,
								selectedGroupId, false, cmd.getPageNumber(), cmd.getRowsPerPage(), "PayeeID", false));
			} else {
				BindingResult result = (BindingResult) WebUtils.getSessionAttribute(request, "errors");
				this.clearSession(request);
				if (result != null) {
					mav.addAllObjects(result.getModel());
				} else {
					if (!this.drawAssignmentManager.isGroupSelectionAllowed(drawId)) {
						cmd.setSelectedGroupId(0);
					}

					cmd.setPageNumber(1);
					cmd.setOngoingAssignments(this.drawAssignmentManager.getOngoingPayees(drawId, workflowObjectId,
							cmd.getSelectedPayeeId(), cmd.getSelectedGroupId(), cmd.isHideInactivePayees(),
							cmd.getPageNumber(), cmd.getRowsPerPage(), cmd.getSortColumn(), cmd.isDescending()));
				}
			}

			this.populateModel(mav, cmd, drawId, workflowObjectId, this.isWebModule(request));
			return mav;
		}
	}

	@RequestMapping(value = { "/drawassignment/fixedterm.html" }, method = { RequestMethod.GET })
	public ModelAndView prepareFixedTermView(HttpServletRequest request) {
		DrawAssignmentFixedTermCommand cmd = (DrawAssignmentFixedTermCommand) WebUtils.getSessionAttribute(request,
				"command");
		ModelAndView mav = new ModelAndView("drawassignment/fixedterm");
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		int drawId = getDrawId(activeTab);
		if (drawId == Integer.MIN_VALUE) {
			String drawIdString = request.getParameter("id");
			if (drawIdString == null) {
				return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_INVALIDDRAW.toString(), request);
			}

			drawId = Integer.parseInt(drawIdString);
			if (drawId == 0) {
				this.clearSession(request);
				return this.prepareView(request);
			}
		}

		if (!this.drawAssignmentManager.drawExists(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_DOES_NOT_EXIST.toString(), request);
		} else if (!this.drawAssignmentManager.isViwableDrawAssignment(drawId)) {
			return this.errorView(Messages.Key.DRAW_ASSIGN_ERROR_LACK_OF_ACCESS.toString(), request);
		} else {
			int workflowObjectId = this.drawAssignmentManager.getWorkflowObjectId(Integer.toString(drawId),
					WorkflowObject.Type.DRAW_ASSIGNMENT);
			if (cmd == null) {
				String selectedPayeeId = null;
				int selectedGroupId = 0;
				if (request.getParameterMap().containsKey("selectedPayeeId")) {
					selectedPayeeId = request.getParameter("selectedPayeeId");
				}

				if (request.getParameterMap().containsKey("selectedGroupId")
						&& this.drawAssignmentManager.isGroupSelectionAllowed(drawId)) {
					selectedGroupId = Integer.parseInt(request.getParameter("selectedGroupId"));
				}

				cmd = new DrawAssignmentFixedTermCommand();
				cmd.setSelectedGroupId(selectedGroupId);
				cmd.setSelectedPayeeId(selectedPayeeId);
				cmd.setDrawId(drawId);
				cmd.setWorkflowObjectId(workflowObjectId);
				cmd.setDescending(false);
				cmd.setClientLocale(Format.getShortDateFormatString());
				cmd.setPageNumber(1);
				cmd.setRowsPerPage(this.drawAssignmentManager.getRowsPerPage(drawId));
				cmd.setTotalPages(this.drawAssignmentManager.getFixedTermPayeesPageCount(drawId, cmd.getRowsPerPage(),
						workflowObjectId, selectedPayeeId, selectedGroupId, false));
				cmd.setSortColumn("PayeeID");
				cmd.setFixedTermAssignments(
						this.drawAssignmentManager.getFixedTermPayees(drawId, workflowObjectId, selectedPayeeId,
								selectedGroupId, false, cmd.getPageNumber(), cmd.getRowsPerPage(), "PayeeID", false));
			} else {
				BindingResult result = (BindingResult) WebUtils.getSessionAttribute(request, "errors");
				this.clearSession(request);
				if (result != null) {
					mav.addAllObjects(result.getModel());
				} else {
					if (!this.drawAssignmentManager.isGroupSelectionAllowed(drawId)) {
						cmd.setSelectedGroupId(0);
					}

					cmd.setPageNumber(1);
					cmd.setFixedTermAssignments(this.drawAssignmentManager.getFixedTermPayees(drawId, workflowObjectId,
							cmd.getSelectedPayeeId(), cmd.getSelectedGroupId(), cmd.isHideInactivePayees(),
							cmd.getPageNumber(), cmd.getRowsPerPage(), cmd.getSortColumn(), cmd.isDescending()));
				}
			}

			this.populateModel(mav, cmd, drawId, workflowObjectId, this.isWebModule(request));
			return mav;
		}
	}

	private void populateModel(ModelAndView mav, DrawAssignmentCommand cmd, int drawId, int workflowObjectId,
			boolean isModule) {
		List<Payee> filterPayees = this.drawAssignmentManager.getFilterPayees(drawId, workflowObjectId);
		List<WorkflowGroupName> filterGroups = this.drawAssignmentManager.getfilterWorkflowGroups(drawId,
				workflowObjectId);
		mav.addObject("filterPayees", filterPayees);
		mav.addObject("filterGroups", filterGroups);
		mav.addObject("drawAssignmentMessage", "");
		if (isModule) {
			mav.addObject("viewableDraws", this.drawAssignmentManager.getViewableDraws());
		}

		cmd.updateToken();
		mav.addObject("command", cmd);
	}

	private void clearSession(HttpServletRequest request) {
		WebUtils.setSessionAttribute(request, "command", (Object) null);
		WebUtils.setSessionAttribute(request, "errors", (Object) null);
	}

	protected static int getDrawId(Tab activeTab) {
		String drawId = null;
		if (activeTab != null && activeTab.isDrawAssignment()) {
			TabObject tabObject = (TabObject) activeTab;
			drawId = tabObject.getObjectId();
		}

		return drawId != null ? Integer.parseInt(drawId) : Integer.MIN_VALUE;
	}

	private boolean isWebModule(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		return activeTab != null && activeTab.isModule();
	}

	public ModelAndView errorView(String messageID, HttpServletRequest request) {
		this.clearSession(request);
		ModelAndView mav = new ModelAndView("drawassignment/index");
		mav.addObject("messageKey", messageID);
		return mav;
	}
}
