package com.varicent.BPM.web;

import com.varicent.BPM.domain.BPMTokenView;

public class BPMTokensCommand extends BPMPagedItemsCommand<BPMTokenView> {
	public final String NOT_AVAILABLE = "";

	public BPMTokensCommand(int start, int itemsPerPage, int totalItems, BPMTokenView[] items) {
		super(start, itemsPerPage, totalItems, items, "tokenlist.html?start=%s");
	}
}
