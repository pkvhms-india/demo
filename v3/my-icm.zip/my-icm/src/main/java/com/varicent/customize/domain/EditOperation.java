package com.varicent.customize.domain;

public enum EditOperation {
	UPDATE, INSERT;
}
