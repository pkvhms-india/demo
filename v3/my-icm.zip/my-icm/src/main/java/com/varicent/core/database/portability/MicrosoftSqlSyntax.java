package com.varicent.core.database.portability;

import java.math.BigInteger;
import java.util.Date;

import org.apache.commons.lang.StringEscapeUtils;

import com.varicent.common.query.domain.Literal;
import com.varicent.core.database.Database;
import com.varicent.core.text.Format;

public class MicrosoftSqlSyntax extends SqlSyntax {
	protected static final String EMPTY_STRING = "";
	protected static final String SYSTEM_PREFIX = "_";
	protected static final String TEMP_TABLE_PREFIX = "#";
	protected static final String NULL_STRING = "NULL";

	@Override
	public String cast(String s) {
		return s == null ? "NULL" : "'" + StringEscapeUtils.escapeSql(s) + "'";
	}

	@Override
	public String getDate() {
		return "CONVERT(DATETIME, FLOOR(CONVERT(FLOAT, GETDATE())))";
	}

	@Override
	public String getDateTime() {
		return "GETDATE()";
	}

	@Override
	public String getDateUtc() {
		return "CONVERT(DATETIME, FLOOR(CONVERT(FLOAT, GETUTCDATE())))";
	}

	@Override
	public String getDateTimeUtc() {
		return "GETUTCDATE()";
	}

	@Override
	public String getEmptyString() {
		return "";
	}

	@Override
	public String getSystemPrefix() {
		return "_";
	}

	@Override
	public String getTempTablePrefix() {
		return "#";
	}

	@Override
	public String getUnicodeSQL() {
		return String.format(
				"SELECT DATA_TYPE FROM \"%s\".INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = N'Config' AND COLUMN_NAME = N'Key' AND DATA_TYPE = N'nvarchar'",
				Database.getName());
	}

	@Override
	public boolean isEmptyString(String s) {
		return "".equals(s);
	}

	@Override
	public String quote(String identifier) {
		return "[" + identifier + "]";
	}

	@Override
	public String toDatabaseType(Literal.Type type) {
		switch (type) {
		case INTEGER:
			return "INT";
		case DECIMAL:
			return "DECIMAL(28,14)";
		case DATE:
		case DATETIME:
			return "DATETIME";
		case STRING:
			return "VARCHAR(100)";
		case LONG_STRING:
			return "VARCHAR(1000)";
		case BLOB:
			return "VARBINARY(max)";
		default:
			return "NULL";
		}
	}

	@Override
	public String toDate(Object date) {
		return date != null && !date.toString().isEmpty() ? this.cast(Format.asISODate((Date) date)) : "NULL";
	}

	@Override
	public String toDateTime(Object date) {
		return date == null ? "NULL" : this.cast(Format.asISODateTime((Date) date));
	}

	@Override
	public String getDefaultNameSpace() {
		return "dbo";
	}

	@Override
	public String toValidIdentifier(String identifier) {
		return identifier;
	}

	@Override
	protected SqlSyntax.DatabaseType getDatabaseType() {
		return SqlSyntax.DatabaseType.SQL_SERVER;
	}

	public static String decode2BVarBinary(String value) {
		return "CAST('' AS XML).value('xs:base64Binary(\"" + value + "\")', 'VARBINARY(MAX)')";
	}

	@Override
	public String toBlob(byte[] data) {
		return String.format("0x%032x", new BigInteger(1, data));
	}
}
