package com.varicent.core.exceptions;

public class BadReportParameterException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final String name;
	private final String formatStyle;

	public BadReportParameterException(String name, String formatStyle) {
		this.name = name;
		this.formatStyle = formatStyle;
	}

	public String getName() {
		return this.name;
	}

	public String getFormatStyle() {
		return this.formatStyle;
	}
}
