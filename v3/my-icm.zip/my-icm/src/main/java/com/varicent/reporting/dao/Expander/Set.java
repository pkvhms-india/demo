package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class Set implements Comparable<Set> {
	BigDecimal value;
	public Category category;
	boolean ignoreZero;

	public Set(BigDecimal value, Category category, boolean ignoreZero) {
		this.value = value;
		this.category = category;
		this.ignoreZero = ignoreZero;
	}

	public void writeXMLElement(XMLStreamWriter writer, int currentset, DataTable data, Scope scope, String seriesName,
			ColumnLink link, boolean isPercentage) throws XMLStreamException, ReportOverLimitException {
		if (isPercentage) {
			this.value = this.value.multiply(new BigDecimal(100));
		}

		String valueString = !this.ignoreZero
				|| !this.value.equals(BigDecimal.ZERO) && !this.value.toString().equals("0E-14")
						? this.value.toPlainString()
						: "";
		if (link != null) {
			writer.writeCharacters("<set ");
			writer.writeCharacters("value ='" + valueString + "' ");

			try {
				String linkurl = link.getLinkAttribute(currentset, data, scope, false);
				writer.writeCharacters("link='" + linkurl + "' /> ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		} else {
			writer.writeCharacters("<set value='" + valueString + "' />");
		}

	}

	public static void writeEmptyXMLElement(XMLStreamWriter writer, boolean ignoreZero) throws XMLStreamException {
		if (ignoreZero) {
			writer.writeCharacters("<set value='' />");
		} else {
			writer.writeCharacters("<set value='0' />");
		}

	}

	@Override
	public int compareTo(Set other) {
		if (this.category.order < other.category.order) {
			return -1;
		} else {
			return this.category.order > other.category.order ? 1 : 0;
		}
	}
}
