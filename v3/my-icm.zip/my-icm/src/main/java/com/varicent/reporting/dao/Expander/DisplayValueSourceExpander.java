package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.common.time.domain.Frequency;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.SortColumn;
import com.varicent.reporting.domain.XMLStreamUtility;

public class DisplayValueSourceExpander extends BaseExpander {
	boolean hasColours = false;
	boolean hasHoverText = false;
	boolean sortByValue = false;
	boolean hasLink = false;
	String sourceName;
	String displayColumn;
	String valueColumn;
	String chartNode;
	DataTable data;
	boolean isPercentage = false;
	Messages messages;
	static String[] Colors = new String[] { "AFD8F8", "F6BD0F", "8BBA00", "FF8E46", "008E8E", "D64646", "8E468E",
			"588526", "B3AA00", "008ED6", "9D080D", "A186BE" };
	ColumnLink chartlink;
	int currentSet;

	public DisplayValueSourceExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("DisplayValueSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.currentSet = 0;
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentSet == 0) {
			this.initializeDisplayValueSource(writer, scope);
		}

		if (this.currentSet != -1) {
			if (this.currentSet == this.data.getRows().size()) {
				this.writeEndElements(writer);
				this.currentSet = -1;
			} else {
				this.generateSet(writer, scope);
				++this.currentSet;
			}

		}
	}

	private void generateSet(XMLStreamWriter writer, Scope scope) throws XMLStreamException, ReportOverLimitException {
		writer.writeCharacters("<set ");
		String name = this.data.getValue(this.currentSet, this.displayColumn);
		writer.writeCharacters("name= '" + Format.sanitizeForChart(name) + "' ");
		BigDecimal value = this.data.getObject(this.currentSet, this.valueColumn) == null ? BigDecimal.ZERO
				: Converter.ConvertToBigDecimal(this.data.getObject(this.currentSet, this.valueColumn));
		if (this.isPercentage) {
			value = value.multiply(new BigDecimal(100));
		}

		writer.writeCharacters("value= '" + value.toString() + "' ");
		if (this.hasColours) {
			String color = Colors[this.currentSet % Colors.length];
			writer.writeCharacters("color ='" + color.toString() + "' ");
		}

		if (this.hasHoverText) {
			String hoverText = this.data.getValue(this.currentSet, this.displayColumn);
			writer.writeCharacters("hoverText= '" + Format.sanitizeForChart(hoverText) + "' ");
		}

		if (this.hasLink) {
			try {
				String linkurl = this.chartlink.getLinkAttribute(this.currentSet, this.data, scope, false);
				writer.writeCharacters("link='" + linkurl + "' ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		}

		writer.writeCharacters("/>");
	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void initializeDisplayValueSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.displayColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.valueColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		SortingInfo sortInfo = null;
		if (this.streamReader.getLocalName().equals("SortingInfo")) {
			sortInfo = SortingInfo.extract(this.streamReader);
			this.streamReader.nextTag();
		}

		this.data = scope.getDataTable(this.sourceName).copy();
		if (sortInfo != null) {
			if (sortInfo.levelID.equals("") && sortInfo.timeID.equals("")) {
				List<String> columns = new ArrayList();
				columns.add(this.displayColumn);
				this.data.sort(columns, sortInfo.sortDescending);
			} else {
				Frequency freq = new Frequency(sortInfo.timeID, sortInfo.levelID);
				SortColumn column = new SortColumn(this.displayColumn, sortInfo.sortDescending, freq);
				List<SortColumn> columns = new ArrayList();
				columns.add(column);
				this.data.sort(columns, scope.getCalendars());
			}
		}

		writer.writeStartElement("Xml");
		ChartExpander chartEx = new ChartExpander(this.streamReader, this.messages);
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		chartEx.expandChartNode(writer);
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("customColors")) {
			this.expandColorsNode(writer);
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String att = this.streamReader.getAttributeValue((String) null, "HasColors");
		int attInt = 0;
		if (att != null) {
			attInt = Integer.parseInt(att);
			this.hasColours = this.numberToBoolean(attInt);
		}

		att = this.streamReader.getAttributeValue((String) null, "HasHoverText");
		if (att != null) {
			attInt = Integer.parseInt(att);
			this.hasHoverText = this.numberToBoolean(attInt);
		}

		att = this.streamReader.getAttributeValue((String) null, "SortByValue");
		if (att != null) {
			attInt = Integer.parseInt(att);
			this.sortByValue = this.numberToBoolean(attInt);
		}

		if (this.sortByValue) {
			List<String> sortColumns = new ArrayList();
			sortColumns.add(this.valueColumn);
			this.data.sort(sortColumns, true);
		}

		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("Link")) {
			this.chartlink = new ColumnLink(this.streamReader);
			this.hasLink = true;
		} else {
			this.hasLink = false;
		}

		this.streamReader.nextTag();
	}

	private boolean numberToBoolean(int boolStr) {
		return boolStr == 1;
	}
}
