package com.varicent.payeeledger.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.varicent.payeeledger.dao.PayeeLedgerDao;

@Service
public class DetailLedger extends AbstractPayeeLedger {
	@Autowired
	protected DetailLedger(@Qualifier("detailLedgerDao") PayeeLedgerDao payeeLedgerDao) {
		super(payeeLedgerDao);
	}

	@Override
	public boolean isDetail() {
		return true;
	}

	@Override
	public boolean isSummary() {
		return false;
	}
}
