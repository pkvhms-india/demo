package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.Scope;

public class DocumentLinkExpander extends BaseExpander {
	public DocumentLinkExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("DocumentLinkDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("DocumentLinkDisplay")) {
			this.streamReader.nextTag();
			writer.writeStartElement("DocumentLinkDisplay");
			super.copyCurrentNode(writer);
			super.copyCurrentNode(writer);
			super.copyCurrentNode(writer);
			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
