package com.varicent.core.database.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.SqlRowSetResultSetExtractor;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class SchemaAwareSqlRowSetResultSetExtractor extends SqlRowSetResultSetExtractor {
	@Override
	public SqlRowSet extractData(ResultSet rs) throws SQLException {
		return super.extractData(new SchemaAwareResultSet(rs));
	}
}
