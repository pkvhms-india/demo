package com.varicent.core.math.expressions;

public interface Predicate<T> {
	boolean test(T var1, T var2);
}
