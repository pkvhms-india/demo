package com.varicent.api.compression;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GZipFilter implements Filter {
	static Logger logger = LoggerFactory.getLogger(GZipFilter.class);

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		String acceptEncoding = httpRequest.getHeader("Accept-Encoding");
		if (acceptEncoding != null && acceptEncoding.indexOf("gzip") >= 0) {
			GZipResponseWrapper gzipResponse = new GZipResponseWrapper(httpResponse);
			logger.debug("Compressing output for " + httpRequest.getRequestURI());
			chain.doFilter(request, gzipResponse);
			gzipResponse.finish();
		} else {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}
}
