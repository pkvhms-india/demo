package com.varicent.BPM.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.varicent.BPM.domain.BPMAlertNode;
import com.varicent.BPM.domain.BPMConditionalPath;
import com.varicent.BPM.domain.BPMExternalEmail;
import com.varicent.BPM.domain.BPMNode;
import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMProcessNode;
import com.varicent.BPM.domain.BPMSwimLane;
import com.varicent.BPM.domain.BPMToken;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflow;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.exceptions.IllegalValueException;
import com.varicent.core.i18n.Message;

public interface BPMDao {
	BPMWorkflow getWorkflow(int var1);

	BPMWorkflow getWorkflowUsingTokenID(int var1);

	BPMToken insertToken(int var1, int var2, String var3, String var4, int var5, boolean var6);

	BPMToken getToken(int var1);

	BPMToken getToken(int var1, String var2);

	BPMToken[] getTokens(int var1);

	BPMToken updateToken(BPMToken var1) throws DatabaseConcurrencyException;

	BPMNodeHistoryStatus[] getBPMPendingTokenHistory(int var1);

	BPMNodeHistoryStatus[] getBPMDeletedTokenHistory(int var1);

	int insertNodeHistory(int var1, String var2, String var3, String var4, String var5);

	void insertNodeError(int var1, String var2);

	void insertAlertError(int var1, int var2, String var3, String var4, String var5);

	void insertTokenError(int var1);

	void insertTokenHistory(int var1, int var2);

	void batchUpdateToken(int var1, int var2, int var3, boolean var4);

	boolean checkAllTokensAreWaiting(int var1);

	boolean checkAllAssignessSubmitted(int var1);

	boolean isAlertNode(int var1);

	boolean isProcessNode(int var1);

	boolean isActionNode(int var1);

	boolean isEndNode(int var1);

	BPMNode getNode(int var1);

	BPMNode getStartNode(int var1);

	BPMAlertNode getAlertNode(int var1);

	BPMProcessNode getProcessNode(int var1);

	BPMSwimLane getSwimLane(int var1);

	BPMPath getPath(int var1);

	BPMPath getPath(int var1, int var2);

	String[] getSwimLaneMembers(int var1, int var2);

	void scheduleProcessNode(int var1, int var2);

	boolean canViewToken(int var1, String var2);

	BPMTokenView[] getBPMTokenViews(String var1, int var2, int var3);

	int BPMCompletedTokenCount(boolean var1, boolean var2, String var3);

	BPMTokenView[] getBPMTokenViews(String var1);

	BPMTokenView[] getCompletedTokenViews(String var1);

	BPMTokenView[] getCompletedTokenViews(String var1, int var2, int var3);

	BPMTokenView getBPMTokenView(String var1, int var2);

	BPMTokenView getBPMTokenView(int var1);

	int getBPMTokenViewsCount(String var1);

	int getWorkflowIDFromForm(int var1);

	void insertTokenAssignee(int var1, String var2);

	void deleteTokenAssignee(int var1);

	void deleteTokenAssignee(int var1, String var2);

	String[] getTokenAssignees(int var1);

	String[] getWorkflowInitiators(int var1);

	BPMWorkflowView[] getInitiatableWorkflows(String var1);

	BPMWorkflowView[] getInitiatableWorkflows(String var1, int var2, int var3, boolean var4);

	int getInitiatableWorkflowsCount(String var1);

	boolean canInitiateWorkflow(String var1, int var2);

	BPMWorkflowView getWorkflowView(int var1);

	boolean isViewableReport(int var1);

	HashMap<String, Boolean> getWorkflowLayoutVisibilityMap(int var1);

	HashMap<String, Boolean> getWorkflowLayoutEditabilityMap(int var1);

	HashMap<String, Boolean> getActionNodeLayoutVisibilityMap(int var1);

	HashMap<String, Boolean> getActionNodeLayoutEditabilityMap(int var1);

	String[] getInitiator(int var1);

	String getTokenOwner(int var1);

	void markFormAsInitiated(int var1);

	int getUninitiatedFormID(int var1, String var2, boolean var3) throws DatabaseConcurrencyException;

	void UpdateBPMPreviousParameters(HashMap<String, Object> var1, int var2) throws DatabaseConcurrencyException;

	int getScopeIdentity();

	void insertAlertNodeErrorAssignees(int var1, Iterable<String> var2);

	Set<String> getPayeeIDsFromEmails(Iterable<BPMExternalEmail> var1);

	boolean isConditionalNode(int var1);

	boolean isConditionalPath(int var1);

	ArrayList<BPMConditionalPath> getConditionalPaths(int var1);

	BPMConditionalPath getConditionalPath(int var1);

	void deleteFromBPMPendingTable(String var1, int var2);

	List<String> getBPMPendingTables();

	Message updateBPMPendingTableSource(String var1, HashMap<BPMToken, BPMWorkflow> var2)
			throws IllegalValueException, DataSubmitException;

	List<Object> getPendingValues(String var1, ColumnDefinition var2, int var3);
}
