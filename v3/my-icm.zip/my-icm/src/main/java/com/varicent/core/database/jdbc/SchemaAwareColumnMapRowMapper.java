package com.varicent.core.database.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.springframework.jdbc.core.ColumnMapRowMapper;

public class SchemaAwareColumnMapRowMapper extends ColumnMapRowMapper {
	@Override
	public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
		return super.mapRow(new SchemaAwareResultSet(rs), rowNum);
	}
}
