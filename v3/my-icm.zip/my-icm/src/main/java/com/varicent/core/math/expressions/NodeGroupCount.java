package com.varicent.core.math.expressions;

import java.math.BigDecimal;

public class NodeGroupCount extends JavascriptNode implements EvaluateNode, AggregateNode {
	private BigDecimal count = new BigDecimal(0);
	private boolean isFinalized;

	public NodeGroupCount(int suffix) {
		super(suffix);
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.count;
		} else {
			this.count = this.count.add(new BigDecimal(1));
			return this.count;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.count = new BigDecimal(0);
		}
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupCount";
	}
}
