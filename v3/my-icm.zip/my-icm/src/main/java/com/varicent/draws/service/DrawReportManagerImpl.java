package com.varicent.draws.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.draws.dao.DrawReportDao;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.draws.web.DrawReportCommand;

@Service("drawReportManager")
@Transactional(readOnly = true)
public class DrawReportManagerImpl implements DrawReportManager {
	private final TimeDao timeDao;
	private final PayeeDao payeeDao;
	private final DrawReportDao drawReportDao;

	@Autowired
	public DrawReportManagerImpl(DrawReportDao drawReportDao, PayeeDao payeeDao, TimeDao timeDao) {
		this.drawReportDao = drawReportDao;
		this.payeeDao = payeeDao;
		this.timeDao = timeDao;
	}

	@Override
	public List<Payee> getPayees(int DrawId, int workflowObjectId) {
		return this.drawReportDao.getPayees(DrawId, workflowObjectId);
	}

	@Override
	public List<WorkflowGroupName> getWorkflowGroups(int workflowObjectId) {
		return this.drawReportDao.getWorflowGroups(workflowObjectId);
	}

	@Override
	public List<DrawTemplateName> getTemplates(int drawID) {
		return this.drawReportDao.getTemplates(drawID);
	}

	@Override
	public String getCalendar(int DrawId) throws InvalidDrawException {
		return this.drawReportDao.getCalendar(DrawId);
	}

	@Override
	public List<TimePeriod> getPeriods(int DrawId, int templateId) throws InvalidDrawException {
		return this.drawReportDao.getPeriods(DrawId, templateId);
	}

	@Override
	public int getAssignmentsPageCount(DrawReportCommand filter, int rowsPerPage) throws InvalidDrawException {
		return this.getPageCount(this.getAssignmentsCount(filter), rowsPerPage);
	}

	private int getAssignmentsCount(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getAssignmentsCount(DrawId, templateId, payee, group, start, end);
		} else {
			return 0;
		}
	}

	@Override
	public List<DataRow> getAssignments(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getAssignments(DrawId, templateId, payee, group, start, end,
					filter.getSortColumn(), filter.isDescending());
		} else {
			return new ArrayList();
		}
	}

	@Override
	public List<DataRow> getAssignments(DrawReportCommand filter, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getAssignments(DrawId, templateId, payee, group, start, end, pageNumber,
					rowsPerPage, sortColumn, descending);
		} else {
			return new ArrayList();
		}
	}

	@Override
	public int getYTDPayoutDetailsPageCount(DrawReportCommand filter, int rowsPerPage) throws InvalidDrawException {
		return this.getPageCount(this.getYTDPayoutDetailsCount(filter), rowsPerPage);
	}

	private int getYTDPayoutDetailsCount(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getYTDPayoutDetailsCount(DrawId, templateId, payee, group, start, end);
		} else {
			return 0;
		}
	}

	@Override
	public List<DataRow> getYTDPayoutDetails(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getYTDPayoutDetails(DrawId, templateId, payee, group, start, end,
					filter.getSortColumn(), filter.isDescending());
		} else {
			return new ArrayList();
		}
	}

	@Override
	public List<DataRow> getYTDPayoutDetails(DrawReportCommand filter, int pageNumber, int rowsPerPage,
			String sortColumn, boolean descending) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getYTDPayoutDetails(DrawId, templateId, payee, group, start, end, pageNumber,
					rowsPerPage, sortColumn, descending);
		} else {
			return new ArrayList();
		}
	}

	@Override
	public int getByPeriodPayoutDetailsPageCount(DrawReportCommand filter, int rowsPerPage)
			throws InvalidDrawException {
		return this.getPageCount(this.getByPeriodPayoutDetailsCount(filter), rowsPerPage);
	}

	private int getByPeriodPayoutDetailsCount(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getByPeriodPayoutDetailsCount(DrawId, templateId, payee, group, start, end);
		} else {
			return 0;
		}
	}

	@Override
	public List<DataRow> getByPeriodPayoutDetails(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getByPeriodPayoutDetails(DrawId, templateId, payee, group, start, end,
					filter.getSortColumn(), filter.isDescending());
		} else {
			return new ArrayList();
		}
	}

	@Override
	public List<DataRow> getByPeriodPayoutDetails(DrawReportCommand filter, int pageNumber, int rowsPerPage,
			String sortColumn, boolean descending) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getByPeriodPayoutDetails(DrawId, templateId, payee, group, start, end, pageNumber,
					rowsPerPage, sortColumn, descending);
		} else {
			return new ArrayList();
		}
	}

	@Override
	public BigDecimal getPayeesAssignedPercent(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int drawId = filter.getId();
			int workflowObjectId = filter.getWorkflowObjectId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(drawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getPayeesAssignedPercent(drawId, templateId, workflowObjectId, payee, group,
					start, end);
		} else {
			return null;
		}
	}

	@Override
	public BigDecimal getOutstandingBalancePercent(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int drawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(drawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getOutstandingBalancePercent(drawId, templateId, payee, group, start, end);
		} else {
			return null;
		}
	}

	@Override
	public Map<String, BigDecimal> getAveragePayoutPercentByPeriod(DrawReportCommand filter)
			throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int drawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(drawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getAveragePayoutPercentByPeriod(drawId, templateId, payee, group, start, end);
		} else {
			return null;
		}
	}

	@Override
	public List<DataRow> getDrawsVsCommissionsByPeriod(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int drawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(drawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getDrawsVsCommissionsByPeriod(drawId, templateId, payee, group, start, end);
		} else {
			return null;
		}
	}

	@Override
	public byte[] getLogo(int drawID) {
		return this.drawReportDao.getLogo(drawID);
	}

	@Override
	public DataRow getYTDPayoutTotals(DrawReportCommand filter) throws InvalidDrawException {
		if (filter.getSelectedTemplate() != null && !filter.getSelectedTemplate().isEmpty()) {
			int DrawId = filter.getId();
			int templateId = Integer.parseInt(filter.getSelectedTemplate());
			String payee = filter.getSelectedPayeeId();
			if (payee != null && payee.isEmpty()) {
				payee = null;
			}

			String group = payee == null ? filter.getSelectedGroupId() : null;
			if (group != null && group.isEmpty()) {
				group = null;
			}

			String periodName = filter.getSelectedPeriod();
			TimePeriod period = null;
			if (periodName != null && !periodName.isEmpty()) {
				period = this.timeDao.getTimePeriod(this.getCalendar(DrawId), filter.getSelectedPeriodLevel(),
						periodName);
			}

			Date start = period == null ? null : period.getStarting();
			Date end = period == null ? null : period.getEnding();
			return this.drawReportDao.getYTDPayoutTotals(DrawId, templateId, payee, group, start, end);
		} else {
			return new DataRow();
		}
	}

	@Override
	public String getPayee(String payeeId) {
		Payee payee = this.payeeDao.getPayee(payeeId);
		return payee == null ? null : payee.getName();
	}

	@Override
	public String getGroup(String groupId) {
		WorkflowGroupName group = this.drawReportDao.getWorkflowGroup(Integer.parseInt(groupId));
		return group == null ? null : group.getName();
	}

	@Override
	public DrawReportWebSettings getSettings(int drawId) throws InvalidDrawException {
		return this.drawReportDao.getDrawReportWebSettings(drawId);
	}

	private int getPageCount(int rowCount, int rowsPerPage) {
		return (new Double(Math.ceil((double) rowCount / (double) rowsPerPage))).intValue();
	}

	@Override
	public boolean exists(int drawId) {
		return this.drawReportDao.exists(drawId);
	}

	@Override
	public boolean isViewable(int drawId) {
		return this.drawReportDao.isViewableDraw(drawId);
	}

	@Override
	public List<DrawName> getViewableDraws() {
		return this.drawReportDao.getViewableDraws();
	}
}
