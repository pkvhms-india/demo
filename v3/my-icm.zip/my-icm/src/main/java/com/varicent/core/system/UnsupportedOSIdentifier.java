package com.varicent.core.system;

class UnsupportedOSIdentifier implements OSIdentifier {
	@Override
	public boolean isOS(String osName) {
		return true;
	}
}
