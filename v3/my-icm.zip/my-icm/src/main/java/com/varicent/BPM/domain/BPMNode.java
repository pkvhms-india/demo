package com.varicent.BPM.domain;

public class BPMNode {
	private int nodeID;
	private int swimLaneID;
	private String name;
	private BPMPath[] paths;

	public BPMNode(int nodeID, int swimLaneID, String name, BPMPath[] paths) {
		this.nodeID = nodeID;
		this.swimLaneID = swimLaneID;
		this.name = name;
		this.paths = paths;
	}

	public BPMPath[] getPaths() {
		return this.paths;
	}

	public void setPaths(BPMPath[] paths) {
		this.paths = paths;
	}

	public int getNodeID() {
		return this.nodeID;
	}

	public int getSwimLaneID() {
		return this.swimLaneID;
	}

	public String getName() {
		return this.name;
	}
}
