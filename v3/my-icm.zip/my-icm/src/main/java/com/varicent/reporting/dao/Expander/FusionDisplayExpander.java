package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.FusionMapStrings1;
import com.varicent.core.i18n.FusionMapStrings2;
import com.varicent.core.i18n.FusionMapStrings3;
import com.varicent.core.i18n.FusionMapStrings4;
import com.varicent.core.i18n.FusionMapStrings5;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class FusionDisplayExpander extends BaseExpander {
	public static final String FUSION_DISPLAY_PREFIX = "CHART_";
	private static final String[] D3Files = new String[] { "Column2D", "Pie2D", "Doughnut2D", "Area2D", "Bar2D",
			"SplineArea", "Waterfall2D", "MSBar2D", "StackedBar2D", "Pyramid", "Funnel", "Line", "Spline", "Kagi",
			"Bubble", "Scatter", "Radar", "MSColumn2D", "StackedColumn2D", "InverseMSColumn2D", "LogMSColumn2D",
			"MSLine", "MSSpline", "InverseMSLine", "LogMSLine", "MSArea", "InverseMSArea", "MSSplineArea", "MSCombi2D",
			"StackedArea2D", "MSCombiDY2D", "MSCombi3D", "StackedColumn3D.swf", "MSColumn3D.swf", "Column3D", "Pie3D",
			"Doughnut3D", "StackedBar3D", "MSColumn3DLineDY", "MSColumnLine3D", "StackedColumn3DLineDY",
			"AngularGauge.swf", "Cylinder", "HLinearGauge", "ScrollLine2D", "ScrollColumn2D", "ScrollArea2D",
			"ScrollStackedColumn2D" };
	boolean initialized = false;
	boolean done = false;
	boolean ignoreZero = false;
	BaseExpander chartSourceExpander;
	private final Messages messages;
	private final FusionMapStrings1 fusion1;
	private final FusionMapStrings2 fusion2;
	private final FusionMapStrings3 fusion3;
	private final FusionMapStrings4 fusion4;
	private final FusionMapStrings5 fusion5;

	public FusionDisplayExpander(XMLStreamReader stream, Messages messages, FusionMapStrings1 fusion1,
			FusionMapStrings2 fusion2, FusionMapStrings3 fusion3, FusionMapStrings4 fusion4,
			FusionMapStrings5 fusion5) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("FusionDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.messages = messages;
			this.fusion1 = fusion1;
			this.fusion2 = fusion2;
			this.fusion3 = fusion3;
			this.fusion4 = fusion4;
			this.fusion5 = fusion5;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		String mapName = "";
		if (!this.done) {
			if (!this.initialized) {
				mapName = this.initializeFusionDisplay(writer, scope);
				this.initialized = true;
			}

			if (this.chartSourceExpander == null) {
				this.setSourceType(mapName);
			}

			this.chartSourceExpander.read(writer, scope, permitted, editable);
			if (this.streamReader.getLocalName().equals("StyleName")) {
				super.copyCurrentNode(writer);
				this.writeEndElements(writer);
				this.done = true;
			}

		}
	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void setSourceType(String mapName) {
		if (this.streamReader.getLocalName().equals("DisplayValueSource")) {
			this.chartSourceExpander = new DisplayValueSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("MapSource")) {
			this.chartSourceExpander = new MapSourceExpander(this.streamReader, this.messages, mapName, this.fusion1,
					this.fusion2, this.fusion3, this.fusion4, this.fusion5);
		} else if (this.streamReader.getLocalName().equals("MSDisplayValueSource")) {
			this.chartSourceExpander = new MSDisplayValueSourceExpander(this.streamReader, this.ignoreZero,
					this.messages);
		} else if (this.streamReader.getLocalName().equals("MSXYSource")) {
			this.chartSourceExpander = new MSXYSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("MSComboSource")) {
			this.chartSourceExpander = new MSComboSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("MSDYComboSource")) {
			this.chartSourceExpander = new MSDYComboSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("MSXYZSource")) {
			this.chartSourceExpander = new MSXYZSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("AngularGaugeSource")) {
			this.chartSourceExpander = new GaugeSourceExpander(this.streamReader, this.messages);
		} else if (this.streamReader.getLocalName().equals("HLinearGaugeSource")) {
			this.chartSourceExpander = new GaugeSourceExpander(this.streamReader, this.messages);
		} else {
			if (!this.streamReader.getLocalName().equals("CylinderGaugeSource")) {
				throw new RuntimeException("Unexpected Source Type.");
			}

			this.chartSourceExpander = new GaugeSourceExpander(this.streamReader, this.messages);
		}

	}

	private String initializeFusionDisplay(XMLStreamWriter writer, Scope scope) throws XMLStreamException {
		writer.writeStartElement("FusionDisplay");
		this.streamReader.nextTag();
		writer.writeStartElement("Name");
		writer.writeCharacters("CHART_" + Format.asMD5Hash(XMLStreamUtility.getCurrentNodeValue(this.streamReader)));
		writer.writeEndElement();
		super.copyCurrentNode(writer);
		super.copyCurrentNode(writer);
		String fileName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		writer.writeStartElement("IsD3");
		writer.writeCharacters(this.isD3(fileName) ? "true" : "false");
		writer.writeEndElement();
		this.ignoreZero = fileName.startsWith("LogMSColumn2D.swf") || fileName.startsWith("LogMSLine.swf");
		fileName = "../charts/" + fileName;
		fileName = this.localizeFusionMessage(fileName);
		writer.writeStartElement("FilePath");
		writer.writeCharacters(fileName);
		writer.writeEndElement();
		return fileName.contains("FCMap_") ? fileName.substring(fileName.indexOf("FCMap_"), fileName.indexOf(".swf"))
				: "";
	}

	private boolean isD3(String fileName) {
		for (String f : D3Files) {
			if (fileName.indexOf(f) == 0) {
				return true;
			}
		}

		return false;
	}

	private String localizeFusionMessage(String fileName) {
		String loading = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_LOADING,
				LocaleContextHolder.getLocale());
		String xmlLoading = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_XML_LOADING,
				LocaleContextHolder.getLocale());
		String parsing = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_PARSING_ERROR,
				LocaleContextHolder.getLocale());
		String noDataMsg = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_NO_DATA,
				LocaleContextHolder.getLocale());
		String rendering = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_RENDERING,
				LocaleContextHolder.getLocale());
		String loadError = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_LOAD_ERROR,
				LocaleContextHolder.getLocale());
		String invalidXml = this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_INVALID_XML,
				LocaleContextHolder.getLocale());
		String localized = fileName.replace("{0}", loading).replace("{1}", xmlLoading).replace("{2}", parsing)
				.replace("{3}", noDataMsg).replace("{4}", rendering).replace("{5}", loadError)
				.replace("{6}", invalidXml);
		return localized;
	}
}
