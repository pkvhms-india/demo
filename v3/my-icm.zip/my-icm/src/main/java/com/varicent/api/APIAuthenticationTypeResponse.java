package com.varicent.api;

public class APIAuthenticationTypeResponse {
	private APIAuthenticationType authenticationType;

	public APIAuthenticationTypeResponse(APIAuthenticationType authenticationType) {
		this.authenticationType = authenticationType;
	}

	public APIAuthenticationType getAuthenticationType() {
		return this.authenticationType;
	}
}
