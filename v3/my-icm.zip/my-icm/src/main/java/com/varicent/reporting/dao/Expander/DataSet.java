package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class DataSet {
	private String series;
	List<Set> sets;
	private int index;
	private int currentCategory;
	private ColumnLink link;
	DataTable data;
	private boolean isPercentage;
	private String dispCol;
	private String valCol;
	private boolean ignoreZero;

	public DataSet(String series, DataTable table, String displayColumn, String valueColumn, boolean ignoreZero,
			ColumnLink link) {
		this.series = series;
		this.sets = new ArrayList();
		this.index = 0;
		this.currentCategory = 0;
		this.link = link;
		this.data = table;
		this.valCol = valueColumn;
		this.dispCol = displayColumn;
		this.ignoreZero = ignoreZero;
	}

	public String getValueColumn() {
		return this.valCol;
	}

	public String getDisplayColumn() {
		return this.dispCol;
	}

	public void add(Set set) {
		this.sets.add(set);
	}

	public void sortSets() {
		Collections.sort(this.sets);
	}

	public void setLink(ColumnLink link) {
		this.link = link;
	}

	public String getDataSetName() {
		return this.series;
	}

	public void setIsPercentage(boolean isPerc) {
		this.isPercentage = isPerc;
	}

	public void writeDataSetStartElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<dataset seriesName='" + this.series + "' >");
	}

	public void writeDataSetElement(XMLStreamWriter writer, List<Category> categories, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		Category category = categories.get(this.currentCategory);
		if (this.index < this.sets.size() && category == this.sets.get(this.index).category
				&& this.index < this.data.getRows().size()) {
			this.sets.get(this.index).writeXMLElement(writer, this.index, this.data, scope, this.series, this.link,
					this.isPercentage);
			++this.index;
		} else {
			Set.writeEmptyXMLElement(writer, this.ignoreZero);
		}

		++this.currentCategory;
	}

	public void writeDataSetEndElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</dataset>");
	}
}
