package com.varicent.errors.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.varicent.common.config.service.ConfigManager;
import com.varicent.common.theme.service.ThemeManager;
import com.varicent.core.context.VaricentContext;

@Controller
public class ErrorController {
	private static final String VIEW401 = "errors/401";
	private static final String VIEW403 = "errors/403";
	private static final String VIEW404 = "errors/404";
	private static final String VIEW500 = "errors/500";
	private final ConfigManager configManager;
	private final ThemeManager themeManager;

	@Autowired
	public ErrorController(ConfigManager configManager, ThemeManager themeManager) {
		this.configManager = configManager;
		this.themeManager = themeManager;
	}

	@RequestMapping({ "/errors/401.html" })
	public ModelAndView showError401(HttpServletRequest request) {
		VaricentContext.initialize(this.configManager.getHelpEmail(), this.themeManager.getTheme());
		request.setAttribute("adminEmail", VaricentContext.getAdminEmail());
		return new ModelAndView("errors/401");
	}

	@RequestMapping({ "/errors/403.html" })
	public ModelAndView showError403(HttpServletRequest request) {
		return new ModelAndView("errors/403");
	}

	@RequestMapping({ "/errors/404.html" })
	public ModelAndView showError404(HttpServletRequest request) {
		return new ModelAndView("errors/404");
	}

	@RequestMapping({ "/errors/500.html" })
	public ModelAndView showError500(HttpServletRequest request) {
		return new ModelAndView("errors/500");
	}
}
