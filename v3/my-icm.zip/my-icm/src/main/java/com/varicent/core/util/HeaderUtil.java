package com.varicent.core.util;

import javax.servlet.http.HttpServletRequest;

import com.varicent.domain.BrowserInfo;

public class HeaderUtil {
	public static final String USER_AGENT_HEADER = "User-Agent";
	private static final String BROWSER_IE = "MSIE";
	private static final String BROWSER_CHROME = "Chrome";
	private static final String BROWSER_SAFARI = "Safari";
	private static final String BROWSER_FIREFOX = "Firefox";

	public static BrowserInfo getBrowserInfo(HttpServletRequest request) {
		return getBrowserInfo(request.getHeader("User-Agent"));
	}

	public static BrowserInfo getBrowserInfo(String userAgentHeaderString) {
		BrowserInfo info = null;
		int index = -1;
		if (userAgentHeaderString != null) {
			if ((index = userAgentHeaderString.indexOf("MSIE")) != -1) {
				String version = getBrowserVersionHelper(userAgentHeaderString, "[\\s;]", 1, index);
				info = new BrowserInfo(BrowserInfo.Type.IE, version);
			} else if ((index = userAgentHeaderString.indexOf("Firefox")) != -1) {
				String version = getBrowserVersionHelper(userAgentHeaderString, "[\\s/]", 1, index);
				info = new BrowserInfo(BrowserInfo.Type.FireFox, version);
			} else if ((index = userAgentHeaderString.indexOf("Chrome")) != -1) {
				String version = getBrowserVersionHelper(userAgentHeaderString, "[\\s/]", 1, index);
				info = new BrowserInfo(BrowserInfo.Type.Chrome, version);
			} else if ((index = userAgentHeaderString.indexOf("Safari")) != -1) {
				String version = getBrowserVersionHelper(userAgentHeaderString, "[\\s/]", 1, index);
				info = new BrowserInfo(BrowserInfo.Type.Safari, version);
			}
		}

		return info;
	}

	private static String getBrowserVersionHelper(String input, String regexDelimiter, int position, int offset) {
		String[] tmp = input.substring(offset).split(regexDelimiter, position + 2);
		String version = null;
		if (tmp.length >= position + 1) {
			version = tmp[position];
		}

		return version;
	}
}
