package com.varicent.core.math;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class Precision {
	private static final MathContext CALC_CONTEXT;
	private static final MathContext MONEY_CONTEXT;

	public static MathContext getCalcContext() {
		return CALC_CONTEXT;
	}

	public static MathContext getMoneyContext() {
		return MONEY_CONTEXT;
	}

	public static BigDecimal roundMoney(BigDecimal decimal) {
		return decimal.setScale(MONEY_CONTEXT.getPrecision(), MONEY_CONTEXT.getRoundingMode());
	}

	private Precision() {
	}

	static {
		CALC_CONTEXT = new MathContext(14, RoundingMode.HALF_EVEN);
		MONEY_CONTEXT = new MathContext(2, RoundingMode.HALF_EVEN);
	}
}
