package com.varicent.BPM.service;

import java.util.HashMap;
import java.util.Map;

import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.exceptions.IllegalValueException;
import com.varicent.core.exceptions.ReportOverLimitException;

public interface BPMManager {
	boolean canViewToken(int var1);

	void moveToken(int var1, long var2, int var4, Map<String, Object> var5) throws DatabaseConcurrencyException;

	int getReportID(int var1);

	long getBPMTokenVersion(int var1) throws DatabaseConcurrencyException;

	BPMPath[] getPaths(int var1);

	BPMTokenView[] getBPMTokenViews(int var1, int var2);

	BPMTokenView[] getCompletedTokenViews();

	BPMTokenView[] getCompletedTokenViews(int var1, int var2);

	BPMTokenView getBPMTokenView(int var1) throws DatabaseConcurrencyException;

	BPMTokenView getBPMDeletedTokenView(int var1);

	BPMTokenView getBPMToken(int var1);

	int getBPMTokenViewsCount();

	BPMWorkflowView[] getInitiatableWorkflows();

	BPMWorkflowView[] getInitiatableWorkflows(int var1, int var2, boolean var3);

	int getInitiatableWorkflowsCount();

	boolean canInitiateWorkflow(int var1);

	int initiateWorkflow(int var1, HashMap<String, Object> var2, Map<Integer, Integer> var3)
			throws DatabaseConcurrencyException, ReportOverLimitException, IllegalValueException;

	Map<String, Object> getWorkflowParams(int var1);

	Map<String, Object> getWorkflowParamsForInitialize(int var1);

	int getWorkflowReportID(int var1);

	BPMWorkflowView getWorkflowView(int var1);

	int BPMCompletedTokenCount(boolean var1, boolean var2);

	BPMNodeHistoryStatus[] getBPMPendingTokenHistory(int var1);

	BPMNodeHistoryStatus[] getBPMDeletedTokenHistory(int var1);

	boolean isViewableReport(int var1);

	HashMap<String, Boolean> getWorkflowLayoutVisibilityMap(int var1);

	HashMap<String, Boolean> getWorkflowLayoutEditabilityMap(int var1);

	HashMap<String, Boolean> getTokenLayoutVisibilityMap(int var1);

	HashMap<String, Boolean> getTokenLayoutEditabilityMap(int var1);

	void sendErrorToInitiator(int var1, String var2, String var3);

	int getUninitiatedFormID(int var1, boolean var2) throws DatabaseConcurrencyException;

	int getFormID(int var1);

	void updateBPMPreviousParameters(HashMap<String, Object> var1, int var2) throws DatabaseConcurrencyException;

	boolean isStartNodeSaveAndSubmit(int var1);

	int getWorkFlowID(int var1);

	boolean getPendingWorkflowStatus();
}
