package com.varicent.draws.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.draws.web.DrawReportCommand;

public interface DrawReportManager {
	boolean exists(int var1);

	boolean isViewable(int var1);

	List<DrawName> getViewableDraws();

	DrawReportWebSettings getSettings(int var1) throws InvalidDrawException;

	byte[] getLogo(int var1);

	List<Payee> getPayees(int var1, int var2);

	List<WorkflowGroupName> getWorkflowGroups(int var1);

	String getCalendar(int var1) throws InvalidDrawException;

	List<DrawTemplateName> getTemplates(int var1);

	List<TimePeriod> getPeriods(int var1, int var2) throws InvalidDrawException;

	String getPayee(String var1);

	String getGroup(String var1);

	int getAssignmentsPageCount(DrawReportCommand var1, int var2) throws InvalidDrawException;

	List<DataRow> getAssignments(DrawReportCommand var1) throws InvalidDrawException;

	List<DataRow> getAssignments(DrawReportCommand var1, int var2, int var3, String var4, boolean var5)
			throws InvalidDrawException;

	int getYTDPayoutDetailsPageCount(DrawReportCommand var1, int var2) throws InvalidDrawException;

	List<DataRow> getYTDPayoutDetails(DrawReportCommand var1) throws InvalidDrawException;

	List<DataRow> getYTDPayoutDetails(DrawReportCommand var1, int var2, int var3, String var4, boolean var5)
			throws InvalidDrawException;

	DataRow getYTDPayoutTotals(DrawReportCommand var1) throws InvalidDrawException;

	int getByPeriodPayoutDetailsPageCount(DrawReportCommand var1, int var2) throws InvalidDrawException;

	List<DataRow> getByPeriodPayoutDetails(DrawReportCommand var1) throws InvalidDrawException;

	List<DataRow> getByPeriodPayoutDetails(DrawReportCommand var1, int var2, int var3, String var4, boolean var5)
			throws InvalidDrawException;

	BigDecimal getPayeesAssignedPercent(DrawReportCommand var1) throws InvalidDrawException;

	BigDecimal getOutstandingBalancePercent(DrawReportCommand var1) throws InvalidDrawException;

	Map<String, BigDecimal> getAveragePayoutPercentByPeriod(DrawReportCommand var1) throws InvalidDrawException;

	List<DataRow> getDrawsVsCommissionsByPeriod(DrawReportCommand var1) throws InvalidDrawException;
}
