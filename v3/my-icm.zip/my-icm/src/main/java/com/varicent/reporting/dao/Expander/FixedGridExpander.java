package com.varicent.reporting.dao.Expander;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.reporting.dao.jdbc.ExpandedXml;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.reporting.web.ReportingCommand;

public class FixedGridExpander extends BaseExpander {
	private final DataSource ds;
	private ReportingCommand command;
	private final Messages messages;

	public FixedGridExpander(XMLStreamReader streamReader, DataSource ds, ReportingCommand command, Messages messages) {
		super(streamReader);
		this.ds = ds;
		this.command = command;
		this.messages = messages;
		if (!streamReader.getLocalName().equals("FixedGridDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("FixedGridDisplay")) {
			writer.writeStartElement("FixedGridDisplay");
			this.streamReader.nextTag();

			while (this.streamReader.getEventType() == 1) {
				if (this.streamReader.getLocalName().equals("StyleName")) {
					super.copyCurrentNode(writer);
					break;
				}

				writer.writeStartElement("GridRow");
				this.streamReader.nextTag();

				while (this.streamReader.getEventType() == 1) {
					writer.writeStartElement("GridCell");
					writer.writeAttribute("Width", this.streamReader.getAttributeValue(0));
					this.streamReader.nextTag();
					String displayType = this.streamReader.getLocalName();
					if (this.streamReader.getEventType() == 1) {
						BaseExpander expander = ExpandedXml.getSimpleExpander(displayType, this.streamReader, this.ds,
								this.command, this.messages, true);
						expander.read(writer, scope, permitted, editable);
					}

					writer.writeEndElement();
					this.streamReader.nextTag();
				}

				writer.writeEndElement();
				this.streamReader.nextTag();
			}

			super.copyCurrentNode(writer);
			String enableExportToExcelString = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("EnableExportToExcel");
			writer.writeCharacters(enableExportToExcelString.toLowerCase());
			writer.writeEndElement();
			writer.writeStartElement("FixedGridDisplayTooltip");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_FIXEDGRID_OPTIONS_TITLE,
					LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("ExportToExcelXLS");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_EXTENSION_XLS,
					LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("ExportToExcelXLSX");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_EXTENSION_XLSX,
					LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("ExcelXlsTooltipTitle");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_TOOLTIP_XLS,
					LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("ExcelXlsxTooltipTitle");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_TOOLTIP_XLSX,
					LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
