package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.text.Format;

class ComboCategory {
	public int order;
	public String label;

	public ComboCategory(int order, String label) {
		this.order = order;
		this.label = label;
	}

	public void writeXMLElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<category label='" + Format.sanitizeForChart(this.label) + "' />");
	}
}
