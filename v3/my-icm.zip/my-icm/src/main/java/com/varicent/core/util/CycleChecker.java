package com.varicent.core.util;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.reference.dao.ReferenceDao;
import com.varicent.common.reference.domain.Reference;
import com.varicent.core.database.Database;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.database.support.RowUtils;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.reporting.domain.DataTable;

public class CycleChecker {
	private final List<String> targetTableTypes = Arrays.asList("Dimension", "Structural");
	private final CustomizeDao customizeDao;
	private final JdbcOperations operations;
	private final ReferenceDao referenceDao;

	public CycleChecker(JdbcOperations operations, CustomizeDao customizeDao, ReferenceDao referenceDao) {
		this.operations = operations;
		this.customizeDao = customizeDao;
		this.referenceDao = referenceDao;
	}

	public boolean createsCycle(DataTable primarySource, String secondarySource, String tableName,
			List<ColumnDefinition> columns, Map<Object, Map<String, String>> changedRows) {
		String customType = this.customizeDao.getCustomTableType(tableName);
		if (!this.targetTableTypes.contains(customType)) {
			return false;
		} else {
			ColumnDefinition idColumn = columns.get(0);

			for (ColumnDefinition column : columns) {
				Reference reference = this.referenceDao.getReference(tableName, column.getName());
				if (reference != null && reference.getReferencedTable().equals(tableName)) {
					for (Object key : changedRows.keySet()) {
						Map<String, String> changedColumns = changedRows.get(key);
						if (changedColumns.containsKey(column.getName())) {
							Object newValue = changedColumns.get(column.getName());
							if (this.createsCycle(tableName, idColumn, column, key, newValue, primarySource,
									secondarySource)) {
								return true;
							}
						}
					}
				}
			}

			return false;
		}
	}

	private boolean createsCycle(String tableName, ColumnDefinition idColumn, ColumnDefinition parentColumn, Object id,
			Object newParent, DataTable primarySource, String bufferTable) {
		String parentId = (String) newParent;

		do {
			Object parent = this.getParentOf(tableName, idColumn, parentId, parentColumn, primarySource, bufferTable);
			if (parent == null) {
				return false;
			}

			if (parentId.equals(parent)) {
				return true;
			}

			parentId = (String) parent;
		} while (!parentId.equals(id));

		return true;
	}

	private Object getParentOf(String tableName, ColumnDefinition idColumn, String id, ColumnDefinition parentColumn,
			DataTable primarySource, String bufferTable) {
		for (DataRow row : primarySource.getRows()) {
			String currId = (String) row.getObject(idColumn.getIndex());
			if (id.equals(currId)) {
				return row.getObject(parentColumn.getIndex());
			}
		}

		SqlRowSet resultData = null;
		if (bufferTable != null) {
			resultData = this.getFromDb(bufferTable, idColumn.getName(), parentColumn.getName(), id);
			if (resultData.next()) {
				return RowUtils.getObject(resultData, parentColumn.getName());
			}
		}

		resultData = this.getFromDb(tableName, idColumn.getName(), parentColumn.getName(), id);
		return resultData.next() ? RowUtils.getObject(resultData, parentColumn.getName()) : null;
	}

	private SqlRowSet getFromDb(String tableName, String idColumn, String parentColumn, String parentColumnId) {
		QueryDefinition qd = new QueryDefinition(tableName);
		qd.select(tableName, parentColumn);
		qd.newConstraint(tableName, idColumn, Constraint.Operator.Equals, parentColumnId);
		return this.operations.queryForRowSet(Database.getQueryBuilder().toSql(qd));
	}
}
