package com.varicent.core.util;

public class JavascriptFormatInfo {
	private String format;
	private String locale;
	private boolean useNegativeBrackets;

	public JavascriptFormatInfo(String format, String locale, boolean useNegativeBrackets) {
		this.format = format;
		this.locale = locale;
		this.useNegativeBrackets = useNegativeBrackets;
	}

	public String getFormat() {
		return this.format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getLocale() {
		return this.locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public boolean isUseNegativeBrackets() {
		return this.useNegativeBrackets;
	}

	public void setUseNegativeBrackets(boolean useNegativeBrackets) {
		this.useNegativeBrackets = useNegativeBrackets;
	}
}
