package com.varicent.core.math.expressions;

import java.math.BigDecimal;

public class NodePrevious implements EvaluateNode {
	private EvaluateNode root;
	private NodeNumber previous;
	private BigDecimal value;

	public NodePrevious(EvaluateNode root, NodeNumber previous) {
		this.root = root;
		this.previous = previous;
		this.value = new BigDecimal(0);
	}

	@Override
	public BigDecimal evaluate() {
		this.previous.setValue(this.value);
		this.value = this.root.evaluate();
		return this.value;
	}

	@Override
	public void reset() {
		this.value = new BigDecimal(0);
		this.root.reset();
	}
}
