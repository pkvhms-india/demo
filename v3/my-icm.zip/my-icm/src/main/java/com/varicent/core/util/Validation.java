package com.varicent.core.util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.varicent.core.Constants;
import com.varicent.core.text.Parse;
import com.varicent.customize.domain.CustomType;

public class Validation {
	private static final int MAX_PRECISION = 28;
	private static final int SCALE = 14;
	private static final BigDecimal MAX_DECIMAL_VALUE = new BigDecimal("79228162514264337593543950335");
	private static final BigDecimal MIN_DECIMAL_VALUE = new BigDecimal("-79228162514264337593543950335");
	private static final Pattern URL_PATTERN = Pattern.compile("^(http|https|ftp)\\://(.)+", 2);

	public static boolean isValid(CustomType type, String value) {
		switch (type) {
		case EMAIL:
			return isValidEmail(value);
		case TEXT:
			return isValidText(value);
		case URL:
			return isValidUrl(value);
		case COMMENT:
			return isValidComment(value);
		case NUMERIC:
			return isValidNumeric(Parse.parseDecimal(value, false));
		default:
			return true;
		}
	}

	public static boolean isValidNumeric(BigDecimal num) {
		if (num == null) {
			return false;
		} else {
			int precision = num.precision();
			int scale = num.scale();
			int lhs = precision - scale;
			if (precision <= 28 && lhs <= 14 && scale <= 14) {
				return num.compareTo(MAX_DECIMAL_VALUE) != 1 && num.compareTo(MIN_DECIMAL_VALUE) != -1;
			} else {
				return false;
			}
		}
	}

	public static boolean isNullDate(Date date) {
		return Constants.MIN_DATE.compareTo(date) > 0;
	}

	public static boolean isValidDate(Date date) {
		return date == null ? false
				: date.compareTo(Constants.MIN_DATE) >= 0 && date.compareTo(Constants.MAX_DATE) <= 0;
	}

	public static boolean isValidEmail(String email) {
		if (email.isEmpty()) {
			return true;
		} else if (email.length() > 100) {
			return false;
		} else if (!isValidString(email)) {
			return false;
		} else {
			try {
				(new InternetAddress(email)).validate();
				return true;
			} catch (AddressException var2) {
				return false;
			}
		}
	}

	public static boolean isValidText(String text) {
		return text.length() <= 100 && isValidString(text);
	}

	public static boolean isValidUrl(String url) {
		if (url.isEmpty()) {
			return true;
		} else {
			Matcher m = URL_PATTERN.matcher(url);
			return m.matches() && url.length() <= 1000 && isValidString(url);
		}
	}

	public static boolean isValidComment(String comment) {
		return comment.length() <= 1000 && isValidString(comment);
	}

	public static boolean isStrongPassword(String password) {
		if (password.length() < 8) {
			return false;
		} else {
			int charTypes = 0;
			if (password.matches(".*[a-z].*")) {
				++charTypes;
			}

			if (password.matches(".*[A-Z].*")) {
				++charTypes;
			}

			if (password.matches(".*\\d.*")) {
				++charTypes;
			}

			if (password.matches(".*[^a-zA-Z0-9].*")) {
				++charTypes;
			}

			return charTypes >= 3;
		}
	}

	private static boolean isValidString(String s) {
		return !s.startsWith(" ") && !s.endsWith(" ");
	}

	private Validation() {
	}
}
