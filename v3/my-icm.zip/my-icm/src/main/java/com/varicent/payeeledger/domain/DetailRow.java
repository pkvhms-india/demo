package com.varicent.payeeledger.domain;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.varicent.core.database.support.DataRow;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.text.Parse;

public class DetailRow extends DataRow {
	private final Type type;
	private final Map<String, String> sourceColumns;
	private String comment;
	private ReportTheme theme;
	private NumericFormat resultFormat;
	private NumericFormat[] columnNumericFormats;

	public static DetailRow newHeaderRow() {
		return new DetailRow(DetailRow.Type.HEADER);
	}

	public static DetailRow newReportRow() {
		return new DetailRow(DetailRow.Type.REPORT);
	}

	public static DetailRow newResultRow() {
		return new DetailRow(DetailRow.Type.RESULT);
	}

	public static DetailRow newSortRow() {
		return new DetailRow(DetailRow.Type.SORT);
	}

	public static DetailRow newTraceRow() {
		return new DetailRow(DetailRow.Type.TRACE);
	}

	private DetailRow(Type type) {
		this.type = type;
		this.sourceColumns = new LinkedHashMap();
	}

	public void addSource(String key, Object value) {
		this.sourceColumns.put(key, this.format(value, (NumericFormat) null));
	}

	public String getComment() {
		return this.comment;
	}

	public NumericFormat getResultFormat() {
		return this.resultFormat;
	}

	public NumericFormat[] getColumnNumericFormats() {
		return this.columnNumericFormats;
	}

	public Map<String, String> getSourceColumns() {
		return Collections.unmodifiableMap(this.sourceColumns);
	}

	public ReportTheme getTheme() {
		return this.theme;
	}

	public Type getType() {
		return this.type;
	}

	public void setComment(String text) {
		this.comment = text;
	}

	public void setResultFormat(NumericFormat resultFormat) {
		this.resultFormat = resultFormat;
	}

	public void setColumnNumericFormats(NumericFormat[] columnNumericFormats) {
		this.columnNumericFormats = columnNumericFormats;
	}

	public void setTheme(ReportTheme theme) {
		this.theme = theme;
	}

	public String[] getFormattedValues() {
		CellData[] cellData = this.getCellData();
		int resultSize = cellData.length;
		String[] result = new String[resultSize];

		for (int i = 0; i < resultSize; ++i) {
			Object cellValue = cellData[i].getObj();
			if (cellValue instanceof BigDecimal) {
				NumericFormat cellFormat = cellData[i].getFormat();
				if (cellFormat != null) {
					result[i] = cellFormat.asString((BigDecimal) cellValue);
				}
			}

			if (result[i] == null) {
				result[i] = cellValue.toString();
			}
		}

		return result;
	}

	public CellData[] getCellData() {
		int resultSize = this.getObjects().size();
		CellData[] result = new CellData[resultSize];
		int j = 0;

		for (int numCols = resultSize; j < numCols; ++j) {
			Object value = this.getObject(j);
			if (value instanceof BigDecimal) {
				int scale = 0;
				boolean isStylePercent = false;
				NumericFormat columnNumericFormat = null;
				if (this.getType() != DetailRow.Type.TRACE && this.getType() != DetailRow.Type.RESULT) {
					scale = this.resultFormat.getScale();
					isStylePercent = this.resultFormat.getStyle() == NumericFormat.Style.PERCENT;
				} else {
					int formatIndex = this.columnNumericFormats != null ? j - numCols + this.columnNumericFormats.length
							: -1;
					if (formatIndex >= 0) {
						columnNumericFormat = this.columnNumericFormats[formatIndex];
					} else {
						columnNumericFormat = this.resultFormat;
					}

					if (columnNumericFormat != null) {
						scale = columnNumericFormat.getScale();
						isStylePercent = columnNumericFormat.getStyle() == NumericFormat.Style.PERCENT;
					}
				}

				BigDecimal formattedValue = getScaledValueForNumericCell((BigDecimal) value, scale, isStylePercent);
				result[j] = new CellData(formattedValue, columnNumericFormat);
			} else {
				result[j] = new CellData(this.getValue(j), (NumericFormat) null);
			}
		}

		return result;
	}

	private static BigDecimal getScaledValueForNumericCell(BigDecimal val, int scale, boolean isPercent) {
		NumericFormat tempFormat = new NumericFormat(NumericFormat.Style.NUMBER, scale);
		if (isPercent) {
			String formatted = tempFormat.asString(val.multiply(new BigDecimal(100)), false);
			BigDecimal formattedDecimal = Parse.parseDecimal(formatted, false);
			return formattedDecimal.divide(new BigDecimal(100));
		} else {
			String formatted = tempFormat.asString(val, false);
			return Parse.parseDecimal(formatted, false);
		}
	}

	public static class CellData {
		private Object obj;
		private NumericFormat format;

		public CellData(Object obj, NumericFormat format) {
			this.obj = obj;
			this.format = format;
		}

		public Object getObj() {
			return this.obj;
		}

		public NumericFormat getFormat() {
			return this.format;
		}
	}

	public static enum Type {
		RESULT, TRACE, SORT, REPORT, HEADER;
	}
}
