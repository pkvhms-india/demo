package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class MSXYSourceExpander extends BaseExpander {
	String[] deepColors = new String[] { "000000", "800000", "000080", "228B22", "FFA500" };
	private BigDecimal xMax;
	private BigDecimal xMin;
	private int currentDataSet;
	private int currentSet;
	private List<XYDataSet> dataSets;
	private boolean isPercentage;
	private boolean isMinMaxSet;
	private Messages messages;
	private List<DataTable> data;

	public MSXYSourceExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("MSXYSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.xMax = BigDecimal.TEN;
			this.xMin = BigDecimal.ZERO;
			this.currentDataSet = -1;
			this.currentSet = 0;
			this.dataSets = new ArrayList();
			this.data = new ArrayList();
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentDataSet != -2) {
			if (this.currentDataSet == -1) {
				this.initializeMSXYSource(writer, scope);
				++this.currentDataSet;
			}

			if (this.currentDataSet < this.dataSets.size()) {
				this.writeSet(writer, this.data, scope);
			} else {
				this.writeEndTags(writer);
				this.currentDataSet = -2;
			}

		}
	}

	private void writeSet(XMLStreamWriter writer, List<DataTable> data, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		XYDataSet current = this.dataSets.get(this.currentDataSet);
		if (this.currentSet == 0) {
			current.writeStartElements(writer);
		}

		if (this.currentSet < current.sets.size()) {
			current.writeSet(writer, this.currentSet, data.get(this.currentDataSet), scope);
			++this.currentSet;
		} else {
			current.writeEndElement(writer);
			this.currentSet = 0;
			++this.currentDataSet;
		}

	}

	private void writeEndTags(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void initializeMSXYSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String sourceName = "";
		String xColumn = "";
		String yColumn = "";
		String sourceAlias = "";

		while (this.streamReader.getLocalName().equals("Source")) {
			this.streamReader.nextTag();
			sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			xColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			yColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			if (this.streamReader.getLocalName().equals("SourceAlias")) {
				sourceAlias = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			ColumnLink link = null;
			if (this.streamReader.getLocalName().equals("Link")) {
				link = new ColumnLink(this.streamReader);
			}

			this.data.add(scope.getDataTable(sourceName).copy());
			this.dataSets.add(this.getDataSet(sourceName, xColumn, yColumn, sourceAlias,
					scope.getDataTable(sourceName).copy(), link));
			this.streamReader.nextTag();
		}

		for (int i = 0; i < Math.min(this.dataSets.size(), this.deepColors.length); ++i) {
			this.dataSets.get(i).setColor(this.deepColors[i]);
		}

		this.streamReader.nextTag();
		writer.writeStartElement("Xml");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		ChartExpander chartEx = new ChartExpander(this.streamReader, this.messages);
		chartEx.expandChartNode(writer);
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("customColors")) {
			this.expandColorsNode(writer);
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String width = this.streamReader.getAttributeValue((String) null, "width");
		this.createCategoriesNode(writer, Integer.parseInt(width));
		XMLStreamUtility.MoveStreamForwardToTag(this.streamReader, "MSXYSource");
	}

	private XYDataSet getDataSet(String sourceName, String xColumn, String yColumn, String sourceAlias, DataTable data,
			ColumnLink link) {
		String seriesName = sourceAlias != null && !sourceAlias.equals("") ? sourceAlias : sourceName;
		XYDataSet dataSet = new XYDataSet(seriesName, xColumn, yColumn, link);

		for (int i = 0; i < data.getRows().size(); ++i) {
			BigDecimal x = data.getObject(i, xColumn) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(data.getObject(i, xColumn));
			BigDecimal y = data.getObject(i, yColumn) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(data.getObject(i, yColumn));
			if (!this.isMinMaxSet) {
				this.xMax = x.max(BigDecimal.TEN);
				this.xMin = x.min(BigDecimal.ZERO);
				this.isMinMaxSet = true;
			} else {
				this.xMax = this.xMax.max(x);
				this.xMin = this.xMin.min(x);
			}

			dataSet.add(x.toPlainString(), y.toPlainString());
		}

		return dataSet;
	}

	private void createCategoriesNode(XMLStreamWriter writer, int width) throws XMLStreamException {
		if (this.isPercentage) {
			this.xMax = this.xMax.multiply(new BigDecimal(100));
			this.xMin = this.xMin.multiply(new BigDecimal(100));
		}

		int numCategories = (int) Math.floor(width / 65);
		numCategories = Math.max(2, numCategories);
		BigDecimal increment = BigDecimal.ONE
				.max(this.xMax.subtract(this.xMin).divide(new BigDecimal(numCategories - 1), 2, 6));
		BigDecimal xCurrent = this.xMin.subtract(this.xMin.remainder(increment));
		writer.writeCharacters("<categories verticalLineThickness='1' >");

		for (int i = 0; i < numCategories; ++i) {
			BigDecimal rounded = xCurrent.setScale(0, 6);
			writer.writeCharacters("<category ");
			writer.writeCharacters("label='" + rounded.toPlainString() + "' ");
			writer.writeCharacters("x='" + rounded.toPlainString() + "' ");
			writer.writeCharacters("showVerticalLine='1' />");
			xCurrent = xCurrent.add(increment);
		}

		writer.writeCharacters("</categories>");
	}
}
