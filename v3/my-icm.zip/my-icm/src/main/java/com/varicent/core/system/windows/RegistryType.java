package com.varicent.core.system.windows;

public enum RegistryType {
	REG_SZ(new StringValueRegistryParser()), REG_MULTI_SZ(new MultiStringRegistryParser());

	private RegistryEntryParser parser;

	private RegistryType(RegistryEntryParser parser) {
		this.parser = parser;
	}

	public static Object parse(String typeSymbol, String value) {
		return valueOf(typeSymbol).parser.parse(value);
	}

	public static String GetRegistryTypeName(String line) {
		if (line == null) {
			return null;
		} else {
			line.trim();
			if (line.length() == 0) {
				return null;
			} else {
				int index = line.indexOf(REG_SZ.name());
				if (index >= 0) {
					return REG_SZ.name();
				} else {
					index = line.indexOf(REG_MULTI_SZ.name());
					return index >= 0 ? REG_MULTI_SZ.name() : null;
				}
			}
		}
	}
}
