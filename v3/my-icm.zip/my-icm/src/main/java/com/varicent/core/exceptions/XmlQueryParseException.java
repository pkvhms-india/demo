package com.varicent.core.exceptions;

public class XmlQueryParseException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public XmlQueryParseException() {
	}

	public XmlQueryParseException(String message) {
		super(message);
	}

	public XmlQueryParseException(String message, Throwable cause) {
		super(message, cause);
	}

	public XmlQueryParseException(Throwable cause) {
		super(cause);
	}
}
