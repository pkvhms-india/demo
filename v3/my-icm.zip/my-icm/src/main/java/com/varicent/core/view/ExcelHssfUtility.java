package com.varicent.core.view;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

public class ExcelHssfUtility extends ExcelUtility {
	private static int HSSFExcelRowLimit = 65536;
	private HSSFPalette m_palette;
	private List<Short> unusedColourIndices;

	public ExcelHssfUtility(HSSFWorkbook wb) {
		super(wb);
		this.m_palette = wb.getCustomPalette();
		this.unusedColourIndices = new ArrayList();

		for (short i = 9; i <= 64; ++i) {
			this.unusedColourIndices.add(i);
		}

	}

	@Override
	public void ApplyFillColour(CellStyle cellStyle, Color color, short foregroundStyle) {
		short colourIndex = this.GetPaletteColourIndex(color);
		cellStyle.setFillForegroundColor(colourIndex);
		cellStyle.setFillPattern(foregroundStyle);
	}

	@Override
	public void ApplyFontColour(Font font, Color color) {
		short colourIndex = this.GetPaletteColourIndex(color);
		font.setColor(colourIndex);
	}

	private short GetPaletteColourIndex(Color color) {
		byte r = (byte) color.getRed();
		byte g = (byte) color.getGreen();
		byte b = (byte) color.getBlue();
		HSSFColor colour = this.m_palette.findColor(r, g, b);
		if (colour == null) {
			if (!this.unusedColourIndices.isEmpty()) {
				short index = this.unusedColourIndices.remove(0);
				this.m_palette.setColorAtIndex(index, r, g, b);
				colour = this.m_palette.getColor(index);
			} else {
				colour = this.m_palette.findSimilarColor(r, g, b);
			}
		}

		if (this.unusedColourIndices.contains(colour.getIndex())) {
			this.unusedColourIndices.remove(colour.getIndex());
		}

		return colour.getIndex();
	}

	@Override
	public int getRowLimit() {
		return HSSFExcelRowLimit;
	}
}
