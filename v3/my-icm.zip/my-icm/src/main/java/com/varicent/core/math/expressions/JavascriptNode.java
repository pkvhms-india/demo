package com.varicent.core.math.expressions;

public abstract class JavascriptNode {
	private int suffix;

	public JavascriptNode(int suffix) {
		this.suffix = suffix;
	}

	public int getSuffix() {
		return this.suffix;
	}

	public String getJSFunctionName(JavascriptUtil jsUtil) {
		return jsUtil.getFunctionPrefix() + this.suffix;
	}

	public String getJSResultVariableName(JavascriptUtil jsUtil) {
		return jsUtil.getResultPrefix() + this.suffix;
	}

	public boolean isJSFunctionCreated() {
		return true;
	}

	public abstract String getJSMathFunctionName();

	public abstract String toJavascript(JavascriptUtil var1);

	public static enum ComparisonType {
		Equal, NotEqual, Greater, GreaterEq, Less, LessEq;
	}
}
