package com.varicent.messages.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.varicent.common.admin.dao.jdbc.AdminQuery;
import com.varicent.common.attachment.dao.jdbc.AttachmentQuery;
import com.varicent.common.query.domain.AndClause;
import com.varicent.common.query.domain.Clause;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.util.MessageNavigation;
import com.varicent.messages.dao.MessagesDao;
import com.varicent.messages.domain.Message;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.dao.jdbc.WorkflowInquiryQuery;
import com.varicent.workflow.dao.jdbc.WorkflowSignoffQuery;
import com.varicent.workflow.domain.WorkflowInquiry;

@Repository("homeDao")
public class JdbcMessagesDaoImpl implements MessagesDao {
	private final RowMapper<Message> messageMapper = new RowMapper<Message>() {
		@Override
		public Message mapRow(ResultSet rs, int rowNumber) throws SQLException {
			Timestamp time = rs.getTimestamp("Time");
			Timestamp startTime = rs.getTimestamp("StartTime");
			Timestamp timeToUse = startTime == null ? time : startTime;
			return new Message(timeToUse, Message.Category.toCategory(rs.getInt("Category")), rs.getString("ID"),
					rs.getString("From"), rs.getString("Summary"));
		}
	};
	private final RowMapper<Message> messageMapperForInquiriesNavigation = new RowMapper<Message>() {
		@Override
		public Message mapRow(ResultSet rs, int rowNumber) throws SQLException {
			Timestamp time = null;
			if (rs.getTimestamp("LastCommentDate") == null) {
				time = rs.getTimestamp("Time");
			} else if (rs.getTimestamp("LastCommentDate").after(rs.getTimestamp("Time"))) {
				time = rs.getTimestamp("LastCommentDate");
			} else {
				time = rs.getTimestamp("Time");
			}

			Timestamp startTime = rs.getTimestamp("StartTime");
			Timestamp timeToUse = startTime == null ? time : startTime;
			return new Message(timeToUse, Message.Category.toCategory(rs.getInt("Category")), rs.getString("ID"),
					rs.getString("From"), rs.getString("Summary"));
		}
	};
	private final JdbcOperations operations;

	@Autowired
	public JdbcMessagesDaoImpl(DataSource ds) {
		this.operations = Database.getOperations(ds);
	}

	@Override
	public List<Message> getMessages(int limit, Date start, Date end) {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition query = this.getAllMessageQuery(user);
		query.orderBy("Time", true);
		if (limit > 0) {
			query.limitTo(limit);
		}

		if (start != null) {
			Clause clause = new OrClause();
			clause.newConstraint("_Messages", "Time", Constraint.Operator.GreaterThanEquals, start);
			clause.newConstraint("_Messages", "StartTime", Constraint.Operator.GreaterThanEquals, start);
			query.addConstraint(clause);
		}

		if (end != null) {
			Clause clause = new OrClause();
			clause.newConstraint("_Messages", "Time", Constraint.Operator.LessThanEquals, end);
			clause.newConstraint("_Messages", "StartTime", Constraint.Operator.LessThanEquals, end);
			query.addConstraint(clause);
		}

		QueryBuilder qb = Database.getQueryBuilder();
		List<Message> messages = this.operations.query(qb.toSql(query), this.messageMapper);
		return this.markMessages(messages);
	}

	@Override
	public int getNewMessageCount() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition adminMessagesQuery = new QueryDefinition(AdminQuery.getAdminMessageQuery(), "_Messages");
		QueryDefinition workflowAndSignOffMessagesQuery = AttachmentQuery.getWorkflowAttachmentMessageQuery();
		workflowAndSignOffMessagesQuery.union(WorkflowSignoffQuery.getAssignedSignoffMessageQuery());
		workflowAndSignOffMessagesQuery = new QueryDefinition(workflowAndSignOffMessagesQuery, "_Messages");
		if (user.getLastLogin() != null) {
			Clause clause = new OrClause();
			clause.newConstraint("_Messages", "Time", Constraint.Operator.GreaterThan, user.getLastLogin().toString());
			clause.newConstraint("_Messages", "StartTime", Constraint.Operator.GreaterThan,
					user.getLastLogin().toString());
			adminMessagesQuery.setRestriction(clause);
			workflowAndSignOffMessagesQuery.setRestriction(clause);
		}

		adminMessagesQuery.selectCount();
		workflowAndSignOffMessagesQuery.selectCount();
		QueryBuilder qb = Database.getQueryBuilder();
		int numNew = (Integer) this.operations.queryForObject(qb.toSql(adminMessagesQuery), Integer.class);
		numNew += this.operations.queryForObject(qb.toSql(workflowAndSignOffMessagesQuery), Integer.class);
		numNew += this.getNewInquiryMessagesCount(user);
		return numNew;
	}

	private QueryDefinition getAllMessageQuery(UserAccount user) {
		QueryDefinition query = AdminQuery.getAdminMessageQuery();
		query.union(AttachmentQuery.getWorkflowAttachmentMessageQuery());
		query.union(WorkflowSignoffQuery.getAssignedSignoffMessageQuery());
		query.union(WorkflowInquiryQuery.getAllInquiriesMessageQuery());
		query.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForSubmitter());
		query.union(WorkflowInquiryQuery.getActiveInquiryMessageAssignedQuery());
		query.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForAssignee());
		query = new QueryDefinition(query, "_Messages");
		return query;
	}

	private QueryDefinition getAllNavigableMessageQuery(UserAccount user, boolean seeLogInquiries) {
		QueryDefinition query = AdminQuery.getAdminMessageQuery();
		if (seeLogInquiries) {
			query.union(WorkflowInquiryQuery.getAllInquiriesMessageQueryForInquiriesPage());
		} else {
			query.union(WorkflowInquiryQuery.getAllInquiriesMessageQuery());
		}

		query.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForSubmitter());
		query.union(WorkflowInquiryQuery.getActiveInquiryMessageAssignedQuery());
		query.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForAssignee());
		if (seeLogInquiries) {
			query.union(this.getLogInquiries());
		}

		query = new QueryDefinition(query, "_Messages");
		return query;
	}

	private QueryDefinition getLogInquiries() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition lQuery = WorkflowInquiryQuery.getInquiryLogQuery(user.getPayeeId());
		lQuery.getOrder().clear();
		lQuery.getSelect().clear();
		lQuery.select("WorkflowDispute", "Created");
		lQuery.select("WorkflowDispute", "Updated");
		lQuery.select("WorkflowDispute", "DisputeID");
		lQuery.select("WorkflowDispute", "Creator");
		lQuery.select("WorkflowDispute", "Status");
		QueryDefinition query = new QueryDefinition(lQuery, "_LogInq");
		QueryDefinition subQuery1 = new QueryDefinition("WorkflowDisputeComment");
		subQuery1.selectMax("WorkflowDisputeComment", "Created", "LastCommentDate");
		subQuery1.newConstraint("WorkflowDisputeComment", "DisputeID", Constraint.Operator.Equals, "_LogInq",
				"DisputeID");
		query.selectCustom("(" + subQuery1.toSql() + ")", "LastCommentDate");
		query.select("_LogInq", "Updated", "Time");
		query.select(Literal.newNullLiteral(), "StartTime");
		query.select(Literal.newLiteral(4), "Category");
		query.select("_LogInq", "DisputeID", "ID");
		query.select("_LogInq", "Creator", "From");
		query.select("Payee_", "Name_", "Summary");
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("_LogInq", "Creator", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		return query;
	}

	private int getNewInquiryMessagesCount(UserAccount user) {
		QueryDefinition inquiryMessages = WorkflowInquiryQuery.getAllInquiriesMessageQuery();
		inquiryMessages.union(WorkflowInquiryQuery.getActiveInquiryMessageAssignedQuery());
		inquiryMessages.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForSubmitter());
		inquiryMessages.union(WorkflowInquiryQuery.getInquiryCommentsMessageQueryForAssignee());
		inquiryMessages = new QueryDefinition(inquiryMessages, "_InquiryMessagesQuery");
		if (user.getLastLogin() != null) {
			inquiryMessages.newConstraint("_InquiryMessagesQuery", "Time", Constraint.Operator.GreaterThan,
					user.getLastLogin().toString());
		}

		inquiryMessages.orderBy("Time", true);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Message> messages = this.operations.query(qb.toSql(inquiryMessages), this.messageMapper);
		return messages.size();
	}

	private List<Message> markMessages(List<Message> messages) {
		UserAccount user = UserAccount.getCurrent();
		List<Message> markedMessages = new ArrayList();

		for (int i = 0; i < messages.size(); ++i) {
			if (user.getLastLogin() != null) {
				markedMessages.add(new Message(messages.get(i), messages.get(i).getDate().after(user.getLastLogin())));
			} else {
				markedMessages.add(new Message(messages.get(i), true));
			}
		}

		List<Message> newMessages = new ArrayList();
		List<Message> oldMessages = new ArrayList();

		for (int i = 0; i < markedMessages.size(); ++i) {
			if (markedMessages.get(i).getIsNew()) {
				newMessages.add(markedMessages.get(i));
			} else {
				oldMessages.add(markedMessages.get(i));
			}
		}

		newMessages.addAll(oldMessages);
		return newMessages;
	}

	private Boolean checkNewCommentedInquiryMessage(String Id, UserAccount user) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition needsNotificationQuery = WorkflowInquiryQuery
				.getInquiryNeedsCommentMessageNotificationQuery(Id);
		needsNotificationQuery = new QueryDefinition(needsNotificationQuery, "q1");
		needsNotificationQuery.selectCount();
		if (this.operations.queryForObject(qb.toSql(needsNotificationQuery), Integer.class) == 0) {
			return false;
		} else {
			QueryDefinition lastCommentQuery = WorkflowInquiryQuery.getLastCommentQuery(Id);
			lastCommentQuery = new QueryDefinition(lastCommentQuery, "q2");
			String lastCommentAuthor = "";
			List<String> authors = this.operations.query(qb.toSql(lastCommentQuery), RowMapperUtil.getStringMapper());
			if (!authors.isEmpty()) {
				lastCommentAuthor = authors.get(0);
			}

			return lastCommentAuthor == null || !lastCommentAuthor.equals(user.getPayeeId());
		}
	}

	@Override
	public Message getMessage(int messageId, Message.Category category, MessageNavigation.ListType listType,
			boolean forInquiries) {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition query = new QueryDefinition(
				this.getAllNavigableMessageQuery(user, listType == MessageNavigation.ListType.INQUIRY), "_AllNav");
		query.selectAll();
		Clause clause = new AndClause();
		clause.newConstraint("_AllNav", "ID", Constraint.Operator.Equals, messageId);
		if (category != Message.Category.INQUIRY_RETURNED && category != Message.Category.INQUIRY_OPEN
				&& category != Message.Category.INQUIRY_COMMENTED && category != Message.Category.INQUIRY_ESCALATED
				&& category != Message.Category.INQUIRY_RESUBMITTED && category != Message.Category.INQUIRY_CLOSED) {
			clause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals, category.ordinal());
		} else {
			Clause orClause = new OrClause();
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_RETURNED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_OPEN.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_COMMENTED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_ESCALATED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_RESUBMITTED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_CLOSED.ordinal());
			clause.addConstraint(orClause);
		}

		query.addConstraint(clause);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Message> messages;
		if (forInquiries) {
			messages = this.operations.query(qb.toSql(query), this.messageMapperForInquiriesNavigation);
		} else {
			messages = this.operations.query(qb.toSql(query), this.messageMapper);
		}

		if (messages.size() == 0) {
			QueryDefinition qd = new QueryDefinition(WorkflowInquiryQuery.getInquiryQuery(messageId), "_Closed");
			qd.select("_Closed", "Updated", "Time");
			qd.select(Literal.newNullLiteral(), "StartTime");
			qd.select(Literal.newLiteral(category.ordinal()), "Category");
			qd.select("_Closed", "DisputeID", "ID");
			qd.select("_Closed", "Creator", "From");
			qd.select("Payee_", "Name_", "Summary");
			qd.select(Literal.newNullLiteral(), "LastCommentDate");
			Join join = new Join("Payee_", Join.Type.LEFT);
			join.newConstraint("_Closed", "Creator", Constraint.Operator.Equals, "Payee_", "PayeeID_");
			qd.joinWith(join);
			Clause var12 = new AndClause();
			var12.newConstraint("_Closed", "DisputeID", Constraint.Operator.Equals, messageId);
			qd.addConstraint(var12);
			messages = this.operations.query(qb.toSql(qd), this.messageMapperForInquiriesNavigation);
		}

		return messages.get(0);
	}

	@Override
	public Message getMessageNext(Date date, int messageId, MessageNavigation.ListType listType,
			MessagesDao.NextDirection nextDir) {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition navMessages = this.getAllNavigableMessageQuery(user,
				listType == MessageNavigation.ListType.INQUIRY);
		QueryDefinition query = new QueryDefinition(navMessages, "_AllNav");
		query.limitTo(1);
		query.selectAll();
		Clause clause = new AndClause();
		clause.newConstraint("_AllNav", "ID", Constraint.Operator.NotEquals, messageId);
		if (nextDir == MessagesDao.NextDirection.DOWN) {
			Clause dateClause = new OrClause();
			Clause dateEqualClause = new AndClause();
			dateEqualClause.newConstraint("_AllNav", "Time", Constraint.Operator.Equals, date.toString());
			dateEqualClause.newConstraint("_AllNav", "ID", Constraint.Operator.LessThan, messageId);
			dateClause.addConstraint(dateEqualClause);
			dateClause.newConstraint("_AllNav", "Time", Constraint.Operator.LessThan, date.toString());
			clause.addConstraint(dateClause);
			query.orderBy("Time", true);
			query.orderBy("ID", true);
		} else {
			Clause dateClause = new OrClause();
			Clause dateEqualClause = new AndClause();
			dateEqualClause.newConstraint("_AllNav", "Time", Constraint.Operator.Equals, date.toString());
			dateEqualClause.newConstraint("_AllNav", "ID", Constraint.Operator.GreaterThan, messageId);
			dateClause.addConstraint(dateEqualClause);
			dateClause.newConstraint("_AllNav", "Time", Constraint.Operator.GreaterThan, date.toString());
			clause.addConstraint(dateClause);
			query.orderBy("Time", false);
			query.orderBy("ID", false);
		}

		if (listType == MessageNavigation.ListType.ADMIN_MESSAGE) {
			Clause orClause = new OrClause();
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.ADMIN_MESSAGE.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.ADMIN_PAYEE_MESSAGE.ordinal());
			clause.addConstraint(orClause);
		} else if (listType == MessageNavigation.ListType.INQUIRY) {
			Clause orClause = new OrClause();
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_RETURNED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_OPEN.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_COMMENTED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_ESCALATED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_RESUBMITTED.ordinal());
			orClause.newConstraint("_AllNav", "Category", Constraint.Operator.Equals,
					Message.Category.INQUIRY_CLOSED.ordinal());
			clause.addConstraint(orClause);
		}

		query.addConstraint(clause);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Message> messages = this.operations.query(qb.toSql(query), this.messageMapper);
		return messages.size() == 0 ? null : (Message) messages.get(0);
	}

	@Override
	public Message getInquiryMessageNext(Date date, int messageId, int messageStatus, MessageNavigation.SubType subType,
			int status, MessagesDao.NextDirection nextDir) {
		QueryDefinition navMessages;
		switch (subType) {
		case UNASSIGNED:
			navMessages = WorkflowInquiryQuery.getActiveInquiriesQuery();
			navMessages.newNullConstraint("WorkflowDispute", "Assignee", true);
			break;
		case ASSIGNED:
			navMessages = WorkflowInquiryQuery.getActiveInquiriesQuery();
			navMessages.newNullConstraint("WorkflowDispute", "Assignee", false);
			break;
		case CREATED:
			navMessages = WorkflowInquiryQuery.getAllInquiriesMessageQueryForInquiriesPage();
			navMessages.select("WorkflowDispute", "Status");
			break;
		case LOG:
			navMessages = WorkflowInquiryQuery.getInquiryLogQueryForInquiriesPage();
			break;
		default:
			navMessages = WorkflowInquiryQuery.getAllInquiriesMessageQueryForInquiriesPage();
		}

		QueryDefinition queryAllNav = new QueryDefinition(navMessages, "_AllNav");
		queryAllNav.selectAll();
		queryAllNav.selectCustom(
				"CASE WHEN [_AllNav].[LastCommentDate] > [_AllNav].[Time] OR [_AllNav].[Time] IS NULL THEN [_AllNav].[LastCommentDate] ELSE [_AllNav].[Time] END",
				"SortingTime");
		QueryDefinition query = new QueryDefinition(queryAllNav, "_AllQuery");
		query.limitTo(1);
		query.selectAll();
		Clause orClause = new OrClause();
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_RETURNED.ordinal());
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_OPEN.ordinal());
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_COMMENTED.ordinal());
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_ESCALATED.ordinal());
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_RESUBMITTED.ordinal());
		orClause.newConstraint("_AllQuery", "Category", Constraint.Operator.Equals,
				Message.Category.INQUIRY_CLOSED.ordinal());
		query.addConstraint(orClause);
		if (status == 1) {
			query.newConstraint("_AllQuery", "Status", Constraint.Operator.Equals,
					WorkflowInquiry.Status.OPEN.ordinal());
		} else if (status == 2) {
			query.newConstraint("_AllQuery", "Status", Constraint.Operator.NotEquals,
					WorkflowInquiry.Status.OPEN.ordinal());
		}

		query.getOrder().clear();
		String dateString = date.toString();
		OrClause innerOr = new OrClause();
		AndClause and1 = new AndClause();
		AndClause and2 = new AndClause();
		Constraint.Operator op = nextDir == MessagesDao.NextDirection.UP ? Constraint.Operator.LessThan
				: Constraint.Operator.GreaterThan;
		Constraint.Operator timeOp = nextDir == MessagesDao.NextDirection.DOWN ? Constraint.Operator.LessThan
				: Constraint.Operator.GreaterThan;
		and1.newConstraint("_AllQuery", "Status", Constraint.Operator.Equals, messageStatus);
		and1.newConstraint("_AllQuery", "SortingTime", timeOp, dateString);
		and2.newConstraint("_AllQuery", "Status", Constraint.Operator.Equals, messageStatus);
		and2.newConstraint("_AllQuery", "SortingTime", Constraint.Operator.Equals, dateString);
		and2.newConstraint("_AllQuery", "ID", op, messageId);
		innerOr.newConstraint("_AllQuery", "Status", op, messageStatus);
		innerOr.addConstraint(and1);
		innerOr.addConstraint(and2);
		boolean sortStatusIDDescending = nextDir == MessagesDao.NextDirection.UP;
		boolean sortTimeDescending = !sortStatusIDDescending;
		query.orderBy("Status", sortStatusIDDescending);
		query.orderBy("SortingTime", sortTimeDescending);
		query.orderBy("ID", sortStatusIDDescending);
		query.addConstraint(innerOr);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Message> messages = this.operations.query(qb.toSql(query), this.messageMapperForInquiriesNavigation);
		return messages.size() == 0 ? null : (Message) messages.get(0);
	}
}
