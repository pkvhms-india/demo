package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class MSComboSourceExpander extends BaseExpander {
	private int currentDataSet;
	private int currentSubSet;
	private List<ComboDataSet> dataSets;
	private List<ComboCategory> categories;
	private boolean isPercentage;
	private Messages messages;

	public MSComboSourceExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("MSComboSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.dataSets = new ArrayList();
			this.categories = new ArrayList();
			this.currentDataSet = -1;
			this.currentSubSet = -1;
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentDataSet != -2) {
			if (this.currentDataSet == -1) {
				this.initializeMSComboSource(writer, scope);
				++this.currentDataSet;
			} else if (this.currentDataSet < this.dataSets.size()) {
				this.writeSet(writer, scope);
			} else {
				this.writeEndElements(writer);
				this.currentDataSet = -2;
			}

		}
	}

	private void initializeMSComboSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String sourceName = "";
		String displayColumn = "";
		String valueColumn = "";
		String renderType = "";
		String sourceAlias = "";

		List<DataSetInfo> dataSetInfo;
		for (dataSetInfo = new ArrayList(); this.streamReader.getLocalName().equals("Source"); this.streamReader
				.nextTag()) {
			this.streamReader.nextTag();
			sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			displayColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			valueColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			renderType = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			if (this.streamReader.getLocalName().equals("SourceAlias")) {
				sourceAlias = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			ColumnLink link = null;
			if (this.streamReader.getLocalName().equals("Link")) {
				link = new ColumnLink(this.streamReader);
			}

			SortingInfo sortInfo = null;
			if (this.streamReader.getLocalName().equals("SortingInfo")) {
				sortInfo = SortingInfo.extract(this.streamReader);
				this.streamReader.nextTag();
			}

			if (sortInfo != null) {
				dataSetInfo.add(new DataSetInfo(sourceName, displayColumn, valueColumn, sourceAlias,
						scope.getDataTable(sourceName).copy(), renderType, (String) null, sortInfo, link));
			} else {
				this.dataSets.add(this.getDataSet(sourceName, displayColumn, valueColumn, sourceAlias,
						scope.getDataTable(sourceName).copy(), renderType, link));
			}
		}

		if (dataSetInfo.size() > 0) {
			this.addCategories(dataSetInfo, scope);

			for (DataSetInfo info : dataSetInfo) {
				this.dataSets.add(this.getDataSet(info.sourceName, info.displayColumn, info.valueColumn,
						info.sourceAlias, info.source, info.renderType, info.link));
			}
		}

		this.streamReader.nextTag();
		writer.writeStartElement("Xml");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		ChartExpander chartEx = new ChartExpander(this.streamReader, this.messages);
		chartEx.expandChartNode(writer);
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("customColors")) {
			this.expandColorsNode(writer);
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.createCategoriesNode(writer);
		XMLStreamUtility.MoveStreamForwardToTag(this.streamReader, "MSComboSource");
	}

	private void writeSet(XMLStreamWriter writer, Scope scope) throws XMLStreamException, ReportOverLimitException {
		ComboDataSet currentSet = this.dataSets.get(this.currentDataSet);
		if (this.currentSubSet == -1) {
			currentSet.writeDataSetStartElement(writer);
			++this.currentSubSet;
		} else if (this.currentSubSet < this.categories.size()) {
			currentSet.writeDataSetElement(writer, this.categories, scope);
			++this.currentSubSet;
		} else {
			currentSet.writeDataSetEndElement(writer);
			++this.currentDataSet;
			this.currentSubSet = -1;
		}

	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void addCategories(List<DataSetInfo> datasets, Scope scope) {
		List<DataSetInfo> other;
		for (List<DataSetInfo> dataSetsTemp = new ArrayList(datasets); dataSetsTemp.size() != 0; dataSetsTemp = other) {
			DataSetInfo temp = dataSetsTemp.get(0);
			List<DataSetInfo> matches = new ArrayList();
			other = new ArrayList();

			for (DataSetInfo info : dataSetsTemp) {
				if (info.matches(temp)) {
					matches.add(info);
				} else {
					other.add(info);
				}
			}

			List<String> existingCategories = new ArrayList();

			for (ComboCategory category : this.categories) {
				existingCategories.add(category.label);
			}

			for (String name : DataSetInfo.combineMatchingSets(matches, existingCategories, scope)) {
				this.categories.add(new ComboCategory(this.categories.size(), name));
			}
		}

	}

	private void createCategoriesNode(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<categories>");

		for (ComboCategory element : this.categories) {
			element.writeXMLElement(writer);
		}

		writer.writeCharacters("</categories>");
	}

	private ComboDataSet getDataSet(String sourceName, String displayCol, String valueCol, String sourceAlias,
			DataTable table, String renderType, ColumnLink link) {
		HashMap<String, Integer> nextIndexMap = new HashMap();
		String seriesName = sourceAlias != null && !sourceAlias.equals("") ? sourceAlias : sourceName;
		ComboDataSet dataSet = new ComboDataSet(seriesName, renderType, table, displayCol, valueCol, link);

		for (int i = 0; i < table.getRows().size(); ++i) {
			String categoryName = table.getValue(i, displayCol);
			BigDecimal value = table.getObject(i, valueCol) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(table.getObject(i, valueCol));
			if (nextIndexMap.containsKey(categoryName)) {
				Integer count = nextIndexMap.get(categoryName);
				nextIndexMap.remove(categoryName);
				nextIndexMap.put(categoryName, new Integer(count + 1));
			} else {
				nextIndexMap.put(categoryName, new Integer(0));
			}

			Integer temp = nextIndexMap.get(categoryName);
			int categoryIndex = this.findCategoryIndex(categoryName, temp);
			ComboCategory category;
			if (categoryIndex < 0) {
				category = new ComboCategory(this.categories.size(), categoryName);
				this.categories.add(category);
			} else {
				category = this.categories.get(categoryIndex);
			}

			dataSet.add(new ComboSet(value, category));
		}

		dataSet.sortSets();
		return dataSet;
	}

	private int findCategoryIndex(String name, int temp) {
		for (int i = 0; i < this.categories.size(); ++i) {
			if (this.categories.get(i).label.equals(name) && temp-- == 0) {
				return i;
			}
		}

		return -1;
	}
}
