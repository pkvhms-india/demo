package com.varicent.core.exceptions;

public class InvalidCurrentPasswordException extends PasswordException {
	private static final long serialVersionUID = 1L;

	public InvalidCurrentPasswordException() {
	}

	public InvalidCurrentPasswordException(String message) {
		super(message);
	}

	public InvalidCurrentPasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidCurrentPasswordException(Throwable cause) {
		super(cause);
	}
}
