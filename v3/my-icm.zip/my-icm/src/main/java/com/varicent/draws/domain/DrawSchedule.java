package com.varicent.draws.domain;

import java.io.Serializable;
import java.math.BigDecimal;

public class DrawSchedule implements Serializable {
	private static final long serialVersionUID = 1L;
	private int period;
	private BigDecimal amount;

	public DrawSchedule(int period, BigDecimal amount) {
		this.period = period;
		this.amount = amount;
	}

	public int getPeriod() {
		return this.period;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
}
