package com.varicent.payeeledger.domain;

public class ReportTheme {
	private final String alternatingColor;
	private final String headerColor;
	private final String summaryColor;

	public ReportTheme(String alternatingColor, String headerColor, String summaryColor) {
		this.alternatingColor = alternatingColor;
		this.headerColor = headerColor;
		this.summaryColor = summaryColor;
	}

	public String getAlternatingColor() {
		return this.alternatingColor;
	}

	public String getHeaderColor() {
		return this.headerColor;
	}

	public String getSummaryColor() {
		return this.summaryColor;
	}
}
