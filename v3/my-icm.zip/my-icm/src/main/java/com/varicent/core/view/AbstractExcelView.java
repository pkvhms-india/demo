package com.varicent.core.view;

import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.POIXMLProperties;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.internal.PackagePropertiesPart;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.officeDocument.x2006.extendedProperties.CTProperties;
import org.springframework.web.servlet.view.AbstractView;

import com.varicent.core.util.Download;

public abstract class AbstractExcelView extends AbstractView {

	private static final String GENERATOR = "";

	protected abstract void buildExcelDocument(Map<String, Object> var1, Workbook var2, HttpServletRequest var3,
			HttpServletResponse var4) throws Exception;

	@Override
	protected boolean generatesDownloadContent() {
		return true;
	}

	@Override
	protected void renderMergedOutputModel(Map model, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		Boolean isXLSXExport = (Boolean) model.get("isXLSXExport");
		String fileName = (String) model.get("fileName");
		isXLSXExport = isXLSXExport != null ? isXLSXExport : false;
		Workbook wb;
		if (isXLSXExport) {
			wb = new XSSFWorkbook();
		} else {
			wb = new HSSFWorkbook();
		}

		OutputStream out = response.getOutputStream();

		try {
			this.buildExcelDocument(model, wb, request, response);
			scrubGeneratorMetadata(wb);
			Download.asAttachment(response, request,
					isXLSXExport ? Download.FileType.EXCEL2007 : Download.FileType.EXCEL, fileName);
			wb.write(out);
			out.flush();
		} catch (Exception var9) {
		}

	}

	private static void scrubGeneratorMetadata(Workbook wb) {
		if (!(wb instanceof XSSFWorkbook)) {
			return;
		}
		POIXMLProperties properties = ((XSSFWorkbook) wb).getProperties();
		CTProperties extended = properties.getExtendedProperties().getUnderlyingProperties();
		extended.setApplication(GENERATOR);
		if (extended.isSetAppVersion()) {
			extended.unsetAppVersion();
		}
		if (extended.isSetCompany()) {
			extended.unsetCompany();
		}
		if (extended.isSetManager()) {
			extended.unsetManager();
		}

		PackagePropertiesPart core = properties.getCoreProperties().getUnderlyingProperties();
		core.setCreatorProperty(GENERATOR);
		core.setLastModifiedByProperty(GENERATOR);
	}
}
