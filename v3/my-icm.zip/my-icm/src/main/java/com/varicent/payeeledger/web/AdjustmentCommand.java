package com.varicent.payeeledger.web;

import com.varicent.security.domain.CSRFCommand;

public class AdjustmentCommand extends CSRFCommand {
	private String plan;
	private String payee;
	private String period;
	private String value;
	private String comment;
	private String errorKey = "";
	private String[] errorParams = new String[0];

	public String getComment() {
		return this.comment;
	}

	public String getPayee() {
		return this.payee;
	}

	public String getPeriod() {
		return this.period;
	}

	public String getPlan() {
		return this.plan;
	}

	public String getValue() {
		return this.value;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getErrorKey() {
		return this.errorKey;
	}

	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}

	public String[] getErrorParams() {
		return this.errorParams;
	}

	public void setErrorParams(String[] errorParams) {
		this.errorParams = errorParams;
	}
}
