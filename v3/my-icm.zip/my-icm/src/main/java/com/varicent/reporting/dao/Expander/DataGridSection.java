package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.common.time.domain.Frequency;
import com.varicent.common.ui.domain.CellStyle;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;
import com.varicent.reporting.domain.ColumnInfo;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.ConditionalFormats;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.PRDateFormat;
import com.varicent.reporting.domain.PicklistDisplayOptions;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class DataGridSection {
	private final String name;
	private final int sectionWidth;
	private final Frequency freq;
	private final List<SectionSource> sources;
	private final String sectionDisplayStyleName;

	public DataGridSection(XMLStreamReader streamReader) throws XMLStreamException {
		streamReader.nextTag();
		this.name = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (streamReader.getLocalName().equals("Frequency")) {
			streamReader.nextTag();
			String timeId = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String levelId = XMLStreamUtility.getCurrentNodeValue(streamReader);
			this.freq = new Frequency(timeId, levelId);
			streamReader.nextTag();
		} else {
			this.freq = null;
		}

		String width = XMLStreamUtility.getCurrentNodeValue(streamReader);
		this.sectionWidth = Integer.parseInt(width);
		streamReader.nextTag();
		this.sources = new ArrayList();

		while (streamReader.getEventType() == 1) {
			this.sources.add(new SectionSource(streamReader));
		}

		streamReader.nextTag();
		this.sectionDisplayStyleName = XMLStreamUtility.getCurrentNodeValue(streamReader);
	}

	public String getName() {
		return this.name;
	}

	public Frequency getFrequency() {
		return this.freq;
	}

	private void WriteSections(XMLStreamWriter writer, SectionCell[] sectionCells, boolean enableShowHideColumns,
			boolean enableInquiryCopy, List<ColumnInfo> columnInfo) throws XMLStreamException {
		writer.writeStartElement("DataRow");
		writer.writeStartElement("Section");
		if (enableInquiryCopy) {
			DataGridExpander.addBlankInquiryElement(writer);
		}

		for (int i = 0; i < this.sectionWidth; ++i) {
			SectionCell sectionCell = sectionCells[i];
			if (sectionCell != null) {
				writer.writeStartElement("SectionCell");
				String cellValue = sectionCell.getCellValue();
				Object val = sectionCell.getVal();
				SectionSource source = sectionCell.getSource();
				String rawValue;
				if (val instanceof BigDecimal) {
					NumericFormat numericFormat = source.getNumericFormat();
					int scale = numericFormat == null ? NumericFormat.DECIMAL_FIXED.getScale()
							: numericFormat.getScale();
					if (numericFormat != null && numericFormat.getStyle() == NumericFormat.Style.PERCENT) {
						scale += 2;
					}

					BigDecimal bd = (new BigDecimal(val.toString())).setScale(scale, RoundingMode.HALF_EVEN);
					rawValue = ExpanderUtilities.getRawValueAsString(bd);
				} else if (cellValue.equals("") && val instanceof Date) {
					rawValue = "";
				} else {
					rawValue = ExpanderUtilities.getRawValueAsString(val);
				}

				writer.writeStartElement("RawValue");
				writer.writeCharacters(rawValue);
				writer.writeEndElement();
				writer.writeStartElement("SectionValue");
				writer.writeAttribute("DataType", ExpanderUtilities.getDataType(val));
				writer.writeCharacters(cellValue);
				writer.writeEndElement();
				if (source != null) {
					writer.writeStartElement("StyleName");
					writer.writeCharacters(source.getStylename());
					writer.writeEndElement();
				} else {
					writer.writeStartElement("StyleName");
					writer.writeCharacters(this.sectionDisplayStyleName);
					writer.writeEndElement();
				}

				if (source != null) {
					NumericFormat numericFormat = source.getNumericFormat();
					if (numericFormat != null) {
						writer.writeStartElement("NumericFormat");
						writer.writeAttribute("Precision", Integer.toString(numericFormat.getScale()));
						NumericFormat.Style[] styles = NumericFormat.Style.values();

						for (int k = 0; k < styles.length; ++k) {
							if (numericFormat.getStyle() == styles[k]) {
								writer.writeAttribute("Style", Integer.toString(k));
								break;
							}
						}

						writer.writeEndElement();
					}

					if (source.dateFormat != null) {
						writer.writeStartElement("DateFormat");
						writer.writeCharacters(Integer.toString(source.dateFormat.getDateStyle().ordinal()));
						writer.writeEndElement();
					}
				}

				if (columnInfo != null && columnInfo.size() > i) {
					writer.writeStartElement("InitiallyShow");
					writer.writeCharacters(
							(new Boolean(!enableShowHideColumns || columnInfo.get(i).getInitiallyShow())).toString());
					writer.writeEndElement();
				}

				writer.writeEndElement();
			}
		}

		writer.writeEndElement();
		writer.writeEndElement();
	}

	public void generateSection(XMLStreamWriter writer, DataGridExpander.Partition currentPartition, Scope scope,
			List<Boolean> colsToHide, boolean enableShowHideColumns, boolean enableInquiryCopy,
			List<ColumnInfo> columnInfo) throws XMLStreamException, ReportOverLimitException {
		SectionCell[] sectionCells = new SectionCell[this.sectionWidth];
		boolean hasValue = false;

		for (int i = 0; i < this.sectionWidth; ++i) {
			if (colsToHide != null && colsToHide.size() > i) {
				Boolean hide = colsToHide.get(i);
				if (hide != null && hide) {
					continue;
				}
			}

			String cellValue = "";
			Object val = null;
			SectionSource source = this.getSourceAt(i);
			if (source != null) {
				String sourceName = source.getSourceName();
				if (scope.getType(sourceName) == Scope.Type.DATATABLE) {
					Map<String, String> columnNames = new HashMap();
					List<ColumnInfo> mapNodes = source.getColumnMap();
					String valueColumn = source.getValueColumn();

					for (ColumnInfo column : mapNodes) {
						columnNames.put(column.getColumnName(), column.getDisplayName());
					}

					DataTable table = scope.getDataTable(sourceName);
					String result = "";
					List<ColumnDefinition> columns = table.getColumns();
					int rowIndex = 0;

					for (int n = table.getRows().size(); rowIndex < n; ++rowIndex) {
						boolean matchFound = true;

						for (ColumnDefinition column : columns) {
							String columnName = columnNames.containsKey(column.getName())
									? (String) columnNames.get(column.getName())
									: column.getName();
							if (currentPartition.getValue(columnName) != null
									&& !table.getValue(rowIndex, column.getName())
											.equals(currentPartition.getValue(columnName))) {
								matchFound = false;
								break;
							}
						}

						if (matchFound) {
							val = table.getObject(rowIndex, valueColumn);
							result = Format.asValueString(val, source.format);
							break;
						}
					}

					cellValue = result;
				} else if (scope.isNull(sourceName)) {
					cellValue = "";
				} else if (scope.getType(sourceName) == Scope.Type.STRING) {
					val = scope.getString(sourceName);
					cellValue = (String) val;
				} else if (scope.getType(sourceName) == Scope.Type.DECIMAL) {
					val = scope.getDecimal(sourceName);
					cellValue = Format.asValueString(val, source.format);
				} else if (scope.getType(sourceName) == Scope.Type.DATE) {
					val = scope.getDateTime(sourceName);
					cellValue = Format.asPRValueString(val, source.format, source.dateFormat);
				} else {
					cellValue = scope.getType(sourceName).toString() + " not implemented.";
				}
			}

			SectionCell sectionCell = new SectionCell(cellValue, val, source);
			sectionCells[i] = sectionCell;
			if (!hasValue && !cellValue.isEmpty()) {
				hasValue = true;
			}
		}

		if (hasValue) {
			this.WriteSections(writer, sectionCells, enableShowHideColumns, enableInquiryCopy, columnInfo);
		}

	}

	private SectionSource getSourceAt(int x) {
		for (SectionSource source : this.sources) {
			if (source.x == x) {
				return source;
			}
		}

		return null;
	}

	private class SectionCell {
		private final String cellValue;
		private final Object val;
		private final SectionSource source;

		public SectionCell(String cellValue, Object val, SectionSource source) {
			this.cellValue = cellValue;
			this.val = val;
			this.source = source;
		}

		public String getCellValue() {
			return this.cellValue;
		}

		public Object getVal() {
			return this.val;
		}

		public SectionSource getSource() {
			return this.source;
		}
	}

	private class SectionSource {
		private final String sourceName;
		private final int x;
		private final String styleName;
		private final String valueColumn;
		private final List<ColumnInfo> columnMap;
		private final NumericFormat format;
		private final PRDateFormat dateFormat;

		public SectionSource(XMLStreamReader streamReader) throws XMLStreamException {
			streamReader.nextTag();
			this.sourceName = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String x = XMLStreamUtility.getCurrentNodeValue(streamReader);
			String styleName = XMLStreamUtility.getCurrentNodeValue(streamReader);
			this.x = Integer.parseInt(x);
			this.styleName = styleName;
			this.columnMap = new ArrayList();
			streamReader.nextTag();

			while (streamReader.getEventType() == 1) {
				streamReader.nextTag();
				String columnName = XMLStreamUtility.getCurrentNodeValue(streamReader);
				String displayName = XMLStreamUtility.getCurrentNodeValue(streamReader);
				String width = XMLStreamUtility.getCurrentNodeValue(streamReader);
				this.columnMap.add(
						new ColumnInfo(columnName, displayName, new BigDecimal(width), (String) null, (ColumnLink) null,
								(NumericFormat) null, (PRDateFormat) null, (ConditionalFormats) null, (Frequency) null,
								(ColumnInfo.Type) null, (Boolean) null, "", false, (PicklistDisplayOptions) null, 0,
								true, CellStyle.Alignment.LEFT, false, 0, CellStyle.VerticalAlignment.MIDDLE));
				streamReader.nextTag();
			}

			streamReader.nextTag();
			this.valueColumn = XMLStreamUtility.getCurrentNodeValue(streamReader);
			if (streamReader.getLocalName().equals("NumericFormat")) {
				this.format = NumericFormat.ReadNumericFormatFromXml(streamReader);
			} else {
				this.format = null;
			}

			if (streamReader.getLocalName().equals("DateFormat")) {
				this.dateFormat = PRDateFormat.ReadPRDateFormatFromXml(streamReader);
			} else {
				this.dateFormat = null;
			}

			streamReader.nextTag();
		}

		public String getSourceName() {
			return this.sourceName;
		}

		public String getStylename() {
			return this.styleName;
		}

		public String getValueColumn() {
			return this.valueColumn;
		}

		public List<ColumnInfo> getColumnMap() {
			return this.columnMap;
		}

		public NumericFormat getNumericFormat() {
			return this.format;
		}
	}
}
