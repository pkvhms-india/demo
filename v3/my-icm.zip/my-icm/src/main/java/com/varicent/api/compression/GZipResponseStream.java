package com.varicent.api.compression;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPOutputStream;

import javax.servlet.ServletOutputStream;

class GZipResponseStream extends ServletOutputStream {
	GZIPOutputStream gzipStream;
	final AtomicBoolean open = new AtomicBoolean(true);
	OutputStream output;

	public GZipResponseStream(OutputStream output) throws IOException {
		this.output = output;
		this.gzipStream = new GZIPOutputStream(output);
	}

	@Override
	public void close() throws IOException {
		if (this.open.compareAndSet(true, false)) {
			this.gzipStream.close();
		}

	}

	@Override
	public void flush() throws IOException {
		this.gzipStream.flush();
	}

	@Override
	public void write(byte[] b) throws IOException {
		this.write(b, 0, b.length);
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		if (!this.open.get()) {
			throw new IOException("Stream closed!");
		} else {
			this.gzipStream.write(b, off, len);
		}
	}

	@Override
	public void write(int b) throws IOException {
		if (!this.open.get()) {
			throw new IOException("Stream closed!");
		} else {
			this.gzipStream.write(b);
		}
	}
}
