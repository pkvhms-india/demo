package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.HashMap;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.FusionMapStrings1;
import com.varicent.core.i18n.FusionMapStrings2;
import com.varicent.core.i18n.FusionMapStrings3;
import com.varicent.core.i18n.FusionMapStrings4;
import com.varicent.core.i18n.FusionMapStrings5;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class MapSourceExpander extends BaseExpander {
	String sourceName;
	String entityColumn;
	String valueColumn;
	String mapString;
	HashMap<String, ColumnLink> linkMap;
	ColumnLink defaultLink;
	DataTable data;
	int currentSet;
	boolean isPercentage;
	String mapName;
	private FusionMapStrings1 fusion1;
	private FusionMapStrings2 fusion2;
	private FusionMapStrings3 fusion3;
	private FusionMapStrings4 fusion4;
	private FusionMapStrings5 fusion5;
	private Messages messages;

	public MapSourceExpander(XMLStreamReader stream, Messages messages, String mapName, FusionMapStrings1 fusion1,
			FusionMapStrings2 fusion2, FusionMapStrings3 fusion3, FusionMapStrings4 fusion4,
			FusionMapStrings5 fusion5) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("MapSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.currentSet = 0;
			this.linkMap = new HashMap();
			this.defaultLink = null;
			this.messages = messages;
			this.mapName = mapName;
			this.fusion1 = fusion1;
			this.fusion2 = fusion2;
			this.fusion3 = fusion3;
			this.fusion4 = fusion4;
			this.fusion5 = fusion5;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentSet != -1) {
			if (this.currentSet == 0) {
				this.initializeMapSource(writer, scope);
			}

			if (this.currentSet < this.data.getRows().size()) {
				this.readEntityRow(writer, scope);
				++this.currentSet;
			} else {
				this.writeEndElements(writer);
				this.currentSet = -1;
			}

		}
	}

	private void readEntityRow(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		writer.writeCharacters("<entity ");
		String entId = this.data.getValue(this.currentSet, this.entityColumn);
		writer.writeCharacters("id='" + Format.sanitizeForChart(entId) + "' ");
		Object valueObj = this.data.getObject(this.currentSet, this.valueColumn);
		BigDecimal value = Converter.ConvertToBigDecimal(valueObj == null ? new Integer(0) : valueObj);
		value = this.isPercentage ? value.multiply(new BigDecimal(100)) : value;
		writer.writeCharacters("value='" + value.toPlainString() + "' ");
		ColumnLink tempLink = this.linkMap.containsKey(entId) ? (ColumnLink) this.linkMap.get(entId) : this.defaultLink;
		if (tempLink != null) {
			try {
				String linkUrl = tempLink.getLinkAttribute(this.currentSet, this.data, scope, false);
				writer.writeCharacters("link='" + linkUrl + "' ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		}

		writer.writeCharacters("/>");
	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</data>");
		writer.writeCharacters("</map>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void initializeMapSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.entityColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.valueColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.data = scope.getDataTable(this.sourceName).copy();
		writer.writeStartElement("Xml");
		this.writeMapNode(writer);
		this.streamReader.nextTag();
		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		writer.writeCharacters("<data>");
		this.buildLinkMap();
		this.streamReader.nextTag();
	}

	private void writeMapNode(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<map ");
		String captureAttribute = "exportDialogMessage='"
				+ this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_CAPTURING, LocaleContextHolder.getLocale())
				+ "' ";
		writer.writeCharacters(captureAttribute);
		writer.writeCharacters("showCanvasBorder='0' ");
		writer.writeCharacters("bgColor='#FFFFFF' ");
		writer.writeCharacters("bgAlpha='0' ");
		writer.writeCharacters("exportAction='save' ");
		writer.writeCharacters("exportAtClient='0' ");
		writer.writeCharacters("exportEnabled='1' ");
		writer.writeCharacters("exportFormats='JPG=JPG' ");
		writer.writeCharacters("exportShowMenuItem='0' ");
		writer.writeCharacters("exportHandler='Placeholder' ");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		String[] attributeNames = new String[] { "numberPrefix", "numberSuffix", "includeValueInLabels", "showLegend",
				"legendPosition", "decimals", "decimalSeparator", "thousandSeparator", "formatNumberScale" };

		for (String attributeName : attributeNames) {
			String currentAttributeValue = this.streamReader.getAttributeValue((String) null, attributeName);
			if (currentAttributeValue != null) {
				try {
					String toWrite = URLDecoder.decode(currentAttributeValue, "UTF-8");
					toWrite = toWrite.replaceAll("%", "%25");
					toWrite = toWrite.replaceAll("'", "&apos;");
					toWrite = attributeName + "='" + toWrite + "' ";
					writer.writeCharacters(toWrite);
				} catch (UnsupportedEncodingException var9) {
					writer.writeCharacters(attributeName + "='" + currentAttributeValue + "' ");
				}
			}
		}

		this.streamReader.nextTag();
		writer.writeCharacters(">");
		this.writeEntityDefs(writer);
		writer.writeCharacters("<colorRange>");
		this.streamReader.nextTag();

		while (this.streamReader.getLocalName().equals("color")) {
			writer.writeCharacters("<color ");
			String[] colorAttributes = new String[4];
			colorAttributes[0] = this.streamReader.getAttributeValue((String) null, "minValue");
			colorAttributes[1] = this.streamReader.getAttributeValue((String) null, "maxValue");
			colorAttributes[2] = this.streamReader.getAttributeValue((String) null, "displayValue");
			colorAttributes[3] = this.streamReader.getAttributeValue((String) null, "color");
			if (colorAttributes[0] != null) {
				writer.writeCharacters("minValue='" + colorAttributes[0] + "' ");
			}

			if (colorAttributes[1] != null) {
				writer.writeCharacters("maxValue='" + colorAttributes[1] + "' ");
			}

			if (colorAttributes[2] != null) {
				try {
					String toWrite = URLDecoder.decode(colorAttributes[2], "UTF-8");
					toWrite = toWrite.replaceAll("%", "%25");
					toWrite = toWrite.replaceAll("'", "&apos;");
					toWrite = "displayValue='" + toWrite + "' ";
					writer.writeCharacters(toWrite);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}

			if (colorAttributes[3] != null) {
				writer.writeCharacters("color='" + colorAttributes[3] + "' ");
			}

			writer.writeCharacters("/>");
			this.streamReader.nextTag();
			this.streamReader.nextTag();
		}

		writer.writeCharacters("</colorRange>");
	}

	private void writeEntityDefs(XMLStreamWriter writer) throws XMLStreamException {
		if (!this.mapName.equals("")) {
			writer.writeCharacters("<entityDef>");
			String entityDefs = "";

			for (FusionMapStrings1.Key key : FusionMapStrings1.Key.values()) {
				String stringMapName = key.name().substring(key.name().indexOf("FCMap_") + "FCMap_".length());
				String entityId = stringMapName.substring(stringMapName.indexOf("_") + 1).replace("_dot", ".");
				stringMapName = "FCMap_" + stringMapName.substring(0, stringMapName.indexOf("_"));
				if (stringMapName.equals(this.mapName)) {
					String tooltip = this.fusion1.getMessage(key, LocaleContextHolder.getLocale());
					entityDefs = this.buildEntityDefXml(stringMapName, entityDefs, entityId, tooltip);
				}
			}

			for (FusionMapStrings2.Key key : FusionMapStrings2.Key.values()) {
				String stringMapName = key.name().substring(key.name().indexOf("FCMap_") + "FCMap_".length());
				String entityId = stringMapName.substring(stringMapName.indexOf("_") + 1).replace("_dot", ".");
				stringMapName = "FCMap_" + stringMapName.substring(0, stringMapName.indexOf("_"));
				if (stringMapName.equals(this.mapName)) {
					String tooltip = this.fusion2.getMessage(key, LocaleContextHolder.getLocale());
					entityDefs = this.buildEntityDefXml(stringMapName, entityDefs, entityId, tooltip);
				}
			}

			for (FusionMapStrings3.Key key : FusionMapStrings3.Key.values()) {
				String stringMapName = key.name().substring(key.name().indexOf("FCMap_") + "FCMap_".length());
				String entityId = stringMapName.substring(stringMapName.indexOf("_") + 1).replace("_dot", ".");
				stringMapName = "FCMap_" + stringMapName.substring(0, stringMapName.indexOf("_"));
				if (stringMapName.equals(this.mapName)) {
					String tooltip = this.fusion3.getMessage(key, LocaleContextHolder.getLocale());
					entityDefs = this.buildEntityDefXml(stringMapName, entityDefs, entityId, tooltip);
				}
			}

			for (FusionMapStrings4.Key key : FusionMapStrings4.Key.values()) {
				String stringMapName = key.name().substring(key.name().indexOf("FCMap_") + "FCMap_".length());
				String entityId = stringMapName.substring(stringMapName.indexOf("_") + 1).replace("_dot", ".");
				stringMapName = "FCMap_" + stringMapName.substring(0, stringMapName.indexOf("_"));
				if (stringMapName.equals(this.mapName)) {
					String tooltip = this.fusion4.getMessage(key, LocaleContextHolder.getLocale());
					entityDefs = this.buildEntityDefXml(stringMapName, entityDefs, entityId, tooltip);
				}
			}

			for (FusionMapStrings5.Key key : FusionMapStrings5.Key.values()) {
				String stringMapName = key.name().substring(key.name().indexOf("FCMap_") + "FCMap_".length());
				String entityId = stringMapName.substring(stringMapName.indexOf("_") + 1).replace("_dot", ".");
				stringMapName = "FCMap_" + stringMapName.substring(0, stringMapName.indexOf("_"));
				if (stringMapName.equals(this.mapName)) {
					String tooltip = this.fusion5.getMessage(key, LocaleContextHolder.getLocale());
					entityDefs = this.buildEntityDefXml(stringMapName, entityDefs, entityId, tooltip);
				}
			}

			writer.writeCharacters(entityDefs);
			writer.writeCharacters("</entityDef>");
		}
	}

	private String buildEntityDefXml(String map, String entityDefs, String entityId, String tooltip) {
		tooltip = tooltip.replace("'", "&apos;");
		return (!map.equals("FCMap_Zambia") || !entityId.equals("ZM.CE"))
				&& (!map.equals("FCMap_Guyana") || !entityId.equals("GY.CU"))
						? entityDefs + "<entity internalId='" + entityId + "'" + " lName='" + tooltip + "' />"
						: entityDefs + "<entity internalId='" + entityId + "&#009;'" + " lName='" + tooltip + "' />";
	}

	private void buildLinkMap() throws XMLStreamException {
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("Link")) {
			this.defaultLink = new ColumnLink(this.streamReader);
		}

		this.streamReader.nextTag();

		while (this.streamReader.getLocalName().equals("MapLink")) {
			String tempEntity = this.streamReader.getAttributeValue((String) null, "Entity");
			this.streamReader.nextTag();
			ColumnLink tempLink = null;
			if (this.streamReader.getLocalName().equals("Link")) {
				tempLink = new ColumnLink(this.streamReader);
			}

			this.linkMap.put(tempEntity, tempLink);
			this.streamReader.nextTag();
		}

	}
}
