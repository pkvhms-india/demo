package com.varicent.core.exceptions;

public abstract class PasswordException extends Exception {
	private static final long serialVersionUID = 1L;

	public PasswordException() {
	}

	public PasswordException(String message) {
		super(message);
	}

	public PasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public PasswordException(Throwable cause) {
		super(cause);
	}
}
