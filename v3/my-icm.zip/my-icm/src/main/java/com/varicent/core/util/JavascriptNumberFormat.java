package com.varicent.core.util;

import java.util.Locale;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.Assert;

import com.varicent.core.text.NumericFormat;

public class JavascriptNumberFormat {
	private static String[] SupportedLocales = new String[] { "us", "ae", "eg", "il", "jp", "kr", "th", "cn", "hk",
			"tw", "au", "ca", "gb", "in", "de", "vn", "es", "dk", "at", "gr", "br", "cz", "fr", "fi", "ru", "se", "ch",
			"pt" };
	private static String[] commaUsers = new String[] { "al", "ad", "ao", "ar", "am", "at", "az", "be", "bo", "ba",
			"br", "bg", "cm", "cl", "co", "cr", "hr", "cu", "cy", "cz", "dk", "Ec", "Es", "fi", "fr", "de", "ge", "gr",
			"gl", "is", "id", "it", "kz", "kg", "lv", "lb", "lt", "md", "mn", "ma", "mz", "na", "nl", "no", "py", "pe",
			"pl", "pt", "ro", "ru", "rs", "sk", "sl", "za", "es", "ch", "se", "tn", "tr", "ua", "uy", "uz", "ve",
			"vn" };

	public static char getDecimalPointChar(String countryCode) {
		for (String commaUser : commaUsers) {
			if (commaUser.compareTo(countryCode) == 0) {
				return ',';
			}
		}

		return '.';
	}

	public static JavascriptFormatInfo getNumberFormat(NumericFormat numericFormat) {
		String locale = LocaleContextHolder.getLocale().getLanguage().toLowerCase();
		boolean isSupported = false;

		for (String supportedLocale : SupportedLocales) {
			if (supportedLocale.compareTo(locale) == 0) {
				isSupported = true;
				break;
			}
		}

		if (!isSupported) {
			locale = "us";
		}

		boolean useNegativeBrackets = NumberFormatBuilder.useNegativeBrackets(numericFormat.getStyle());
		char decimalSeperator = getDecimalPointChar(locale);
		char groupingSeperator = (char) (decimalSeperator == '.' ? 44 : 46);
		boolean isPercent = false;
		String symbol;
		switch (numericFormat.getStyle()) {
		case NUMBER:
			String format = NumberFormatBuilder.getFormat(numericFormat.getScale(), decimalSeperator, groupingSeperator,
					isPercent);
			return new JavascriptFormatInfo(format, locale, useNegativeBrackets);
		case PERCENT:
			symbol = "%";
			isPercent = true;
			break;
		case DOLLARS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.US);
			break;
		case FRENCHCANADIANDOLLARS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.CANADA_FRENCH);
			break;
		case POUNDS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.UK);
			break;
		case EURO:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.FRANCE);
			break;
		case YEN:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.JAPAN);
			break;
		case YUAN:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.CHINA);
			break;
		case RAND:
			symbol = NumberFormatBuilder.getCurrencySymbol(new Locale("en", "ZA"));
			break;
		default:
			Assert.state(false);
			symbol = null;
		}

		String var12 = NumberFormatBuilder.getFormat(numericFormat.getScale(), decimalSeperator, groupingSeperator,
				isPercent);
		String mask = "";
		NumberFormatBuilder.CurrencyPattern pattern = NumberFormatBuilder.getCurrencyPattern(numericFormat, symbol);
		switch (pattern) {
		case SYMBOL_BEFORE:
			mask = symbol + var12;
			break;
		case SYMBOL_AFTER:
			mask = var12 + symbol;
			break;
		case SYMBOL_BEFORE_SPACE:
			mask = symbol + " " + var12;
			break;
		case SYMBOL_AFTER_SPACE:
			mask = var12 + " " + symbol;
		}

		if (numericFormat.getStyle() == NumericFormat.Style.RAND) {
			mask = mask + ";" + symbol + "-" + var12;
		}

		return new JavascriptFormatInfo(mask, locale, useNegativeBrackets);
	}
}
