package com.varicent.core.system;

class WindowsIdentifier implements OSIdentifier {
	@Override
	public boolean isOS(String osName) {
		return osName.toLowerCase().indexOf("win") >= 0;
	}
}
