package com.varicent.BPM.web;

import com.varicent.security.domain.CSRFCommand;

public class BPMPagedItemsCommand<T> extends CSRFCommand {
	private int itemsPerPage;
	private int start;
	private int totalItems;
	private String urlFormat;
	private T[] currentItemSubset;
	public final String NOT_AVAILABLE = "";

	public BPMPagedItemsCommand(int start, int itemsPerPage, int totalItems, T[] items, String urlFormat) {
		this.start = start;
		this.itemsPerPage = itemsPerPage;
		this.totalItems = totalItems;
		this.currentItemSubset = items;
		this.urlFormat = urlFormat;
	}

	public String getURL(int start) {
		return String.format(this.urlFormat, start);
	}

	public String getNextURL() {
		return this.start >= this.totalItems - this.itemsPerPage ? "" : this.getURL(this.start + this.itemsPerPage);
	}

	public String getPrevURL() {
		if (this.currentItemSubset.length == 0 && this.start >= this.totalItems) {
			return this.totalItems == 0 ? "" : this.getURL(this.totalItems / this.itemsPerPage * this.itemsPerPage);
		} else {
			return this.start < this.itemsPerPage ? "" : this.getURL(this.start - this.itemsPerPage);
		}
	}

	public T[] getItems() {
		return this.currentItemSubset.length == 0 ? null : this.currentItemSubset;
	}

	public T getFirstItem() {
		return this.currentItemSubset.length == 0 ? null : this.getItems()[0];
	}

	public T getLastItem() {
		return this.currentItemSubset.length == 0 ? null : this.getItems()[this.getItems().length - 1];
	}

	public int getTotalItems() {
		return this.totalItems;
	}

	public int getItemsPerPage() {
		return this.itemsPerPage;
	}
}
