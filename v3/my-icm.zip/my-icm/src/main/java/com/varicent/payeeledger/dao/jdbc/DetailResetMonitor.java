package com.varicent.payeeledger.dao.jdbc;

import java.util.List;

import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.ResetMonitor;
import com.varicent.payeeledger.domain.TraceReport;

class DetailResetMonitor {
	private final ResetMonitor timeResetter;
	private final int firstResettingPartition;
	private final int lastResettingPartition;
	private final int timePartition;

	public DetailResetMonitor(TraceReport report, int firstResettingPartition, int lastResettingPartition,
			TimeDao timeDao) {
		this.firstResettingPartition = firstResettingPartition;
		if (report.hasTimePartition()) {
			this.timeResetter = timeDao.getResetMonitor(report.getCalendar(), report.getTimeLevel(),
					report.getResetLevel());
			this.lastResettingPartition = lastResettingPartition - 1;
			this.timePartition = lastResettingPartition;
		} else {
			this.timeResetter = null;
			this.lastResettingPartition = lastResettingPartition;
			this.timePartition = -1;
		}

	}

	public boolean resetRunningTotals(List<Object> currentRow, List<Object> nextRow) {
		for (int i = this.firstResettingPartition; i <= this.lastResettingPartition; ++i) {
			String currentValue = (String) currentRow.get(i);
			String nextValue = (String) nextRow.get(i);
			if (!currentValue.equals(nextValue)) {
				return true;
			}
		}

		if (this.timeResetter == null) {
			return false;
		} else {
			String currentPeriod = (String) currentRow.get(this.timePartition);
			String nextPeriod = (String) nextRow.get(this.timePartition);
			return this.timeResetter.doesReset(currentPeriod, nextPeriod);
		}
	}
}
