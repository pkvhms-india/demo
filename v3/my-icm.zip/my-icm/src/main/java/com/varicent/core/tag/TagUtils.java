package com.varicent.core.tag;

public class TagUtils {
	public static boolean instanceOf(Object o, String className) {
		try {
			return Class.forName(className).isInstance(o);
		} catch (ClassNotFoundException var3) {
			return false;
		}
	}
}
