package com.varicent.payeeledger.dao.jdbc;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.util.Assert;
import org.springframework.util.NumberUtils;

import com.varicent.common.calculation.dao.CalculationDao;
import com.varicent.common.calculation.domain.Calculation;
import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.port.dao.PortDao;
import com.varicent.common.port.domain.Port;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.RevisionLockPeriod;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.Constants;
import com.varicent.core.database.support.RowUtils;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.util.Link;
import com.varicent.core.util.Range;
import com.varicent.payeeledger.domain.CategoryReport;
import com.varicent.payeeledger.domain.DetailRow;
import com.varicent.payeeledger.domain.DisplayColumn;
import com.varicent.payeeledger.domain.Report;
import com.varicent.payeeledger.domain.ResultReport;
import com.varicent.payeeledger.domain.SortReport;
import com.varicent.payeeledger.domain.TraceReport;

class DetailRowQuery {
	private final String planId;
	private final String payeeId;
	private final TimePeriod period;
	private final boolean repeatHeader;
	private final int headerInterval;
	private final ReportQuery reportQuery;
	private final CalculationDao calculationDao;
	private final TimeDao timeDao;
	private final SchemaDao schemaDao;
	private final HistoryDao historyDao;
	private final PortDao portDao;
	private int currentRowCount;
	private Report previousReport;
	private SqlRowSet previousData;
	private DetailReportTotals currentReportTotals;
	private Map<Integer, Map<String, Port>> revisionPortSourceTableMap;
	private Map<String, Port> portMap;

	public DetailRowQuery(DataSource ds, String planId, String payeeId, TimePeriod period, boolean repeatHeader,
			ReportQuery reportQuery, CalculationDao calculationDao, ConfigDao configDao, TimeDao timeDao,
			SchemaDao schemaDao, HistoryDao historyDao, PortDao portDao) {
		this.planId = planId;
		this.payeeId = payeeId;
		this.period = period;
		this.repeatHeader = repeatHeader;
		this.headerInterval = configDao.getIntValue(ConfigDao.Key.WEB_LEDGER_HEADER_INTERVAL);
		this.reportQuery = reportQuery;
		this.calculationDao = calculationDao;
		this.timeDao = timeDao;
		this.schemaDao = schemaDao;
		this.historyDao = historyDao;
		this.portDao = portDao;
		this.revisionPortSourceTableMap = new HashMap();
		this.portMap = portDao.getPortMap();
	}

	public List<DetailRow> getDetail() {
		List<DetailRow> rows = new ArrayList();
		int reportNumber = 1;
		int reportGroup = 0;
		List<Report> reports = this.reportQuery.getReports(this.planId);
		Iterator<Report> i = reports.iterator();

		while (i.hasNext()) {
			Report report = i.next();
			Calculation calc = this.calculationDao.getCalculation(report.getCalculationId());
			String calendar = calc.getTimeLockCalendar();
			String level = calc.getLevel();
			Range<Date> visibleDates = this.reportQuery.getVisibleDates(this.planId);
			Range<Date> dateRange = this.getDateRange(calendar, visibleDates, report.showPriorPeriods());
			DetailRow reportHeader = DetailRow.newReportRow();
			reportHeader.add(reportNumber + ". " + report.getName());
			if (report.showHeader()) {
				reportHeader.setComment(calc.getComment());
			}

			reportHeader.setTheme(report.getTheme());
			reportHeader.setResultFormat(report.getFormat());
			List<DetailRow> reportRows;
			if (report instanceof SortReport) {
				reportRows = this.getSortReportRows(reportHeader, (SortReport) report, dateRange, visibleDates);
			} else if (report instanceof TraceReport) {
				reportRows = this.getTraceReportRows(reportHeader, (TraceReport) report, (ResultReport) i.next(),
						calendar, level, dateRange, visibleDates, reportGroup);
			} else if (report instanceof ResultReport) {
				reportRows = this.getResultReportRows(reportHeader, (ResultReport) report, calendar, level, dateRange,
						visibleDates, reportGroup);
			} else {
				Assert.isTrue(report instanceof CategoryReport);
				reportRows = this.getCategoryReportRows(reportHeader, (CategoryReport) report, dateRange, visibleDates);
			}

			rows.addAll(reportRows);
			++reportNumber;
			if (report instanceof TraceReport || !report.suppressSummary()) {
				++reportGroup;
			}
		}

		int max = 0;

		for (DetailRow row : rows) {
			max = Math.max(max, row.getSize());
		}

		for (DetailRow row : rows) {
			int padding = max - row.getSize();
			if (row.getType() == DetailRow.Type.REPORT) {
				for (int j = row.getSize(); j < max; ++j) {
					row.insert(j, "");
				}
			} else {
				for (int j = 0; j < padding; ++j) {
					row.insert(0, "");
				}
			}
		}

		return rows;
	}

	private int getLastResettingPartition(int calculationId) {
		return this.calculationDao.getResettingPartitionCount(calculationId);
	}

	private List<DetailRow> getResultReportRows(DetailRow reportHeader, ResultReport report, String calendar,
			String level, Range<Date> dateRange, Range<Date> visibleRange, int reportGroup) {
		List<DetailRow> rows = new ArrayList();
		if (report.suppressSummary()) {
			return rows;
		} else {
			rows.add(reportHeader);
			int timePartition = this.getLastResettingPartition(report.getCalculationId());
			this.currentRowCount = 1;
			this.previousReport = null;
			this.previousData = null;
			this.currentReportTotals = null;
			Range<Date> newDateRange = dateRange;
			if (calendar != null) {
				List<RevisionLockPeriod> lockPeriods = this.timeDao.getRevisionLockPeriods(calendar, level);
				if (!lockPeriods.isEmpty()) {
					rows.addAll(this.getHistoryRows(lockPeriods, reportGroup, dateRange, visibleRange, timePartition));
					TimePeriod period = this.timeDao.getFirstUnlockedPeriod(calendar);
					Date startingDate;
					if (period == null) {
						startingDate = Constants.MAX_DATE;
					} else {
						startingDate = period.getStarting();
					}

					newDateRange = new Range<>(max(dateRange.Start, startingDate), dateRange.End);
				}
			}

			SqlRowSet data = this.reportQuery.getReportData(report, (TraceReport) null, this.payeeId, newDateRange,
					visibleRange, timePartition);
			rows.addAll(this.getResultReportRows(report, data));
			if (report.suppressEmptyReports() && rows.size() == 1) {
				rows.clear();
			}

			return rows;
		}
	}

	private Report[] getReportGroup(int reportGroup, List<Report> reports) {
		int group = 0;

		for (int i = 0; i < reports.size(); ++i) {
			Report report = reports.get(i);
			if (report instanceof SortReport) {
				if (group == reportGroup) {
					return new Report[] { report };
				}
			} else if (report instanceof TraceReport) {
				++i;
				Report resultReport = reports.get(i);
				if (group == reportGroup) {
					return new Report[] { report, resultReport };
				}
			} else if (report instanceof ResultReport && group == reportGroup) {
				return new Report[] { report };
			}

			++group;
		}

		Assert.isTrue(false);
		return null;
	}

	private List<DetailRow> getResultReportRows(ResultReport report, SqlRowSet data) {
		List<DetailRow> rows = new ArrayList();
		if (report.suppressEmptyReports() && !data.isBeforeFirst()) {
			return rows;
		} else {
			String[] columns = data.getMetaData().getColumnNames();
			DetailRow header = DetailRow.newHeaderRow();
			int i = 1;

			for (int n = columns.length - 1; i < n; ++i) {
				header.add(columns[i].replace('_', ' '));
			}

			header.add(report.getResultName());
			if (this.previousReport == null
					|| !this.hasSameHeader(report, data, this.previousReport, this.previousData)) {
				rows.add(header);
				this.currentRowCount = 1;
			}

			for (; data.next(); ++this.currentRowCount) {
				DetailRow row = DetailRow.newResultRow();
				int bi = 1;

				for (int n = columns.length; bi < n; ++bi) {
					row.add(data.getObject(bi + 1), report.getFormat());
				}

				rows.add(row);
				if (this.repeatHeader && this.currentRowCount % this.headerInterval == 0) {
					rows.add(header);
				}
			}

			if (!rows.isEmpty() && (rows.size() != 1 || rows.get(0) != header)) {
				this.previousReport = report;
				this.previousData = data;
			}

			return rows;
		}
	}

	private List<DetailRow> getCategoryReportRows(DetailRow reportHeader, CategoryReport report, Range<Date> dateRange,
			Range<Date> visibleRange) {
		List<DetailRow> rows = new ArrayList();
		if (report.suppressSummary()) {
			return rows;
		} else {
			int timePartition = this.getLastResettingPartition(report.getCalculationId());
			SqlRowSet data = this.reportQuery.getReportData(report, this.payeeId, dateRange, visibleRange,
					timePartition);
			if (report.suppressEmptyReports() && !data.isBeforeFirst()) {
				return rows;
			} else {
				rows.add(reportHeader);
				DetailRow header = DetailRow.newHeaderRow();
				String[] columns = data.getMetaData().getColumnNames();

				for (String column : columns) {
					header.add(column.replace('_', ' '));
				}

				rows.add(header);

				for (int rowCount = 1; data.next(); ++rowCount) {
					DetailRow row = DetailRow.newTraceRow();
					int i = 0;

					for (int n = columns.length; i < n; ++i) {
						row.add(data.getObject(i + 1), report.getFormat());
					}

					rows.add(row);
					if (this.repeatHeader && rowCount % this.headerInterval == 0) {
						rows.add(header);
					}
				}

				if (report.suppressEmptyReports() && rows.size() == 2) {
					rows.clear();
				}

				return rows;
			}
		}
	}

	private Range<Date> getDateRange(String calendar, Range<Date> visible, boolean showPriorPeriods) {
		Date start = Constants.MIN_DATE;
		Date end = Constants.MAX_DATE;
		if (this.period != null && calendar != null && this.period != null) {
			if (!showPriorPeriods) {
				start = max(start, this.period.getStarting());
			}

			end = min(end, this.period.getEnding());
		}

		return new Range<>(max(start, visible.Start), min(end, visible.End));
	}

	private static Date min(Date a, Date b) {
		return a.before(b) ? a : b;
	}

	private static Date max(Date a, Date b) {
		return a.after(b) ? a : b;
	}

	private List<DetailRow> getSortReportRows(DetailRow reportHeader, SortReport report, Range<Date> dateRange,
			Range<Date> visibleRange) {
		List<DetailRow> rows = new ArrayList();
		if (report.suppressSummary()) {
			return rows;
		} else {
			int timePartition = this.getLastResettingPartition(report.getCalculationId());
			SqlRowSet data = this.reportQuery.getReportData(report, this.payeeId, this.portMap, dateRange, visibleRange,
					timePartition);
			if (report.suppressEmptyReports() && !data.isBeforeFirst()) {
				return rows;
			} else {
				rows.add(reportHeader);
				DetailRow header = DetailRow.newHeaderRow();

				for (String column : data.getMetaData().getColumnNames()) {
					header.add(column.replace('_', ' '));
				}

				rows.add(header);

				for (int rowCount = 1; data.next(); ++rowCount) {
					DetailRow row = DetailRow.newSortRow();
					int i = 0;

					for (int n = data.getMetaData().getColumnCount(); i < n; ++i) {
						row.add(data.getObject(i + 1), report.getFormat());
					}

					rows.add(row);
					if (this.repeatHeader && rowCount % this.headerInterval == 0) {
						rows.add(header);
					}
				}

				if (report.suppressEmptyReports() && rows.size() == 2) {
					rows.clear();
				}

				return rows;
			}
		}
	}

	private List<DetailRow> getTraceReportRows(DetailRow reportHeader, TraceReport traceReport,
			ResultReport resultReport, String calendar, String level, Range<Date> dateRange, Range<Date> visibleRange,
			int reportGroup) {
		List<DetailRow> rows = new ArrayList();
		List<NumericFormat> columnNumericFormats = new ArrayList();

		for (DisplayColumn column : traceReport.getDisplayColumns()) {
			columnNumericFormats.add(column.getFormat());
		}

		columnNumericFormats.add(traceReport.getFormat());
		reportHeader.setColumnNumericFormats(
				(NumericFormat[]) columnNumericFormats.toArray(new NumericFormat[columnNumericFormats.size()]));
		rows.add(reportHeader);
		int timePartition = this.getLastResettingPartition(traceReport.getCalculationId());
		this.currentRowCount = 1;
		this.previousReport = null;
		this.previousData = null;
		this.currentReportTotals = null;
		Range<Date> newDateRange = dateRange;
		if (calendar != null) {
			List<RevisionLockPeriod> lockPeriods = this.timeDao.getRevisionLockPeriods(calendar, level);
			if (!lockPeriods.isEmpty()) {
				rows.addAll(this.getHistoryRows(lockPeriods, reportGroup, dateRange, visibleRange, timePartition));
				String calendarName = traceReport.getCalendar();
				if (calendarName != null) {
					TimePeriod period = this.timeDao.getFirstUnlockedPeriod(calendarName);
					Date startingDate;
					if (period == null) {
						startingDate = Constants.MAX_DATE;
					} else {
						startingDate = period.getStarting();
					}

					newDateRange = new Range<>(max(dateRange.Start, startingDate), dateRange.End);
				}
			}
		}

		SqlRowSet traceData = this.reportQuery.getTraceData(traceReport, resultReport, this.payeeId, this.portMap,
				newDateRange, visibleRange, timePartition);
		SqlRowSet resultData = this.reportQuery.getReportData(resultReport, traceReport, this.payeeId, newDateRange,
				visibleRange, timePartition);
		rows.addAll(this.getTraceReportRows(resultReport, traceReport, resultData, traceData, newDateRange));
		if (traceReport.suppressEmptyReports() && rows.size() == 1) {
			rows.clear();
		}

		return rows;
	}

	private List<DetailRow> getTraceReportRows(ResultReport resultReport, TraceReport traceReport, SqlRowSet resultData,
			SqlRowSet traceData, Range<Date> dateRange) {
		this.currentReportTotals = null;
		List<DetailRow> rows = new ArrayList();
		if (traceReport.suppressEmptyReports() && !resultData.isBeforeFirst()) {
			return rows;
		} else {
			HashMap<String, Integer> columnNameMap = new HashMap();
			int columnIndex = 0;
			int resultColumns = 0;

			for (String columnName : resultData.getMetaData().getColumnNames()) {
				columnNameMap.put(columnName, columnIndex);
				++columnIndex;
				if (!columnName.startsWith("_")) {
					++resultColumns;
				}
			}

			int totalTraceColumns = traceReport.getDisplayColumns().size() + 1;
			int totalColumns = totalTraceColumns > resultColumns ? totalTraceColumns : resultColumns;
			int totalResultColumns = resultColumns - 1 + traceReport.getOperatorColumnCount() + 1;
			int tracePadding = totalColumns - totalTraceColumns;
			int resultPadding = totalColumns - totalResultColumns;
			DetailRow header = DetailRow.newHeaderRow();
			int headerCount = 0;
			header.pad(tracePadding);

			for (DisplayColumn column : traceReport.getDisplayColumns()) {
				header.add(column.getName());
			}

			for (int i = 0; i < traceReport.getResultColumns().size(); ++i) {
				header.add(traceReport.getResultName() + (i + 1));
			}

			if (this.previousReport == null
					|| !this.hasSameHeader(traceReport, resultData, this.previousReport, this.previousData)) {
				rows.add(header);
				++headerCount;
				this.currentRowCount = 1;
			}

			int timePartition = this.getLastResettingPartition(traceReport.getCalculationId());
			if (this.currentReportTotals == null) {
				this.currentReportTotals = new DetailReportTotals(traceReport, 1, timePartition, this.timeDao);
			}

			List<Object> currResultRow = resultData.next() ? RowUtils.getRow(resultData) : null;
			List<Object> nextResultRow = !resultData.isLast() && resultData.next() ? RowUtils.getRow(resultData) : null;

			for (boolean moreTraceData = traceData.next(); currResultRow != null; nextResultRow = !resultData.isLast()
					&& resultData.next() ? RowUtils.getRow(resultData) : null) {
				int resultId = (Integer) NumberUtils.convertNumberToTargetClass((Number) currResultRow.get(0),
						Integer.class);
				List<Object> traceValues = new ArrayList();

				for (int i = 1; i <= traceReport.getResultColumns().size(); ++i) {
					int traceValueIndex = columnNameMap.get("_Trace_Value" + i);
					traceValues.add(currResultRow.get(traceValueIndex));
				}

				if (traceValues.size() != 0) {
					DetailRow row = DetailRow.newTraceRow();
					row.pad(tracePadding);
					int displayColumnCount = 0;
					NumericFormat[] formats = new NumericFormat[traceReport.getDisplayColumns().size() + 1];

					for (DisplayColumn column : traceReport.getDisplayColumns()) {
						int displayColumnIndex = columnNameMap.get("_Display" + displayColumnCount);
						Object item = currResultRow.get(displayColumnIndex);
						this.currentReportTotals.update(column, item);
						if (item == null) {
							row.add("");
						} else if (column.isEmail()) {
							row.add(Link.email(item.toString()));
						} else if (column.isUrl()) {
							row.add(Link.url(item.toString()));
						} else if (column.hasFormat()) {
							row.add(item, column.getFormat());
						} else {
							row.add(item, traceReport.getFormat());
						}

						formats[displayColumnCount] = column.getFormat();
						++displayColumnCount;
					}

					formats[displayColumnCount] = traceReport.getFormat();
					row.setColumnNumericFormats(formats);

					for (Object traceValue : traceValues) {
						row.add(traceValue, traceReport.getFormat());
					}

					if (!traceData.isAfterLast() && moreTraceData) {
						int traceResultId = traceData.getInt("_Trace__ResultID");
						if (traceResultId == resultId) {
							Map<String, Object> sourceData = this.reportQuery.getSourceData(traceData);

							for (String key : sourceData.keySet()) {
								row.addSource(key, sourceData.get(key));
							}

							traceData.next();
						}
					}

					rows.add(row);
					if (this.repeatHeader && nextResultRow != null && this.currentRowCount % this.headerInterval == 0) {
						rows.add(header);
						++headerCount;
					}

					++this.currentRowCount;
				}

				boolean resultChange;
				if (nextResultRow == null) {
					resultChange = true;
				} else {
					int nextResultId = (Integer) NumberUtils.convertNumberToTargetClass((Number) nextResultRow.get(0),
							Integer.class);
					resultChange = resultId != nextResultId;
				}

				if (resultChange && !traceReport.suppressSummary()) {
					DetailRow row = DetailRow.newResultRow();
					row.pad(resultPadding);

					for (int i = 1; i < resultColumns; ++i) {
						row.add(currResultRow.get(i));
					}

					boolean operationColumns = false;

					for (DisplayColumn column : traceReport.getDisplayColumns()) {
						if (column.hasOperation()) {
							operationColumns = true;
							if (this.currentReportTotals.hasValue(column)) {
								row.add(this.currentReportTotals.getValue(column), column.getFormat());
							} else {
								row.add("");
							}
						} else if (operationColumns) {
							row.add("");
						}
					}

					row.add(currResultRow.get(resultColumns), traceReport.getFormat());
					rows.add(row);
					if (nextResultRow != null) {
						this.currentReportTotals.reset(currResultRow, nextResultRow);
					}

					if (this.repeatHeader && nextResultRow != null && this.currentRowCount % this.headerInterval == 0) {
						rows.add(header);
						++headerCount;
					}

					++this.currentRowCount;
				}

				currResultRow = nextResultRow;
			}

			if (rows.size() == headerCount && traceReport.suppressEmptyReports()) {
				rows.clear();
			} else {
				this.previousReport = traceReport;
				this.previousData = resultData;
			}

			return rows;
		}
	}

	private boolean hasSameHeader(Report x, SqlRowSet xData, Report y, SqlRowSet yData) {
		if (x instanceof TraceReport && y instanceof TraceReport) {
			return this.hasSameHeader((TraceReport) x, (TraceReport) y);
		} else {
			return x instanceof ResultReport && y instanceof ResultReport
					? this.hasSameHeader((ResultReport) x, xData, (ResultReport) y, yData)
					: false;
		}
	}

	private boolean hasSameHeader(TraceReport x, TraceReport y) {
		List<DisplayColumn> xColumns = x.getDisplayColumns();
		List<DisplayColumn> yColumns = y.getDisplayColumns();
		if (xColumns.size() != yColumns.size()) {
			return false;
		} else {
			for (int i = 0; i < xColumns.size(); ++i) {
				if (!xColumns.get(i).getName().equals(yColumns.get(i).getName())) {
					return false;
				}
			}

			return x.getResultName().equals(y.getResultName());
		}
	}

	private boolean hasSameHeader(ResultReport x, SqlRowSet xData, ResultReport y, SqlRowSet yData) {
		String[] xColumns = xData.getMetaData().getColumnNames();
		String[] yColumns = yData.getMetaData().getColumnNames();
		if (xColumns.length != yColumns.length) {
			return false;
		} else {
			int i = 1;

			for (int n = xColumns.length - 1; i < n; ++i) {
				String xColumn = xColumns[i].replace('_', ' ');
				String yColumn = yColumns[i].replace('_', ' ');
				if (!xColumn.equals(yColumn)) {
					return false;
				}
			}

			return x.getResultName().equals(y.getResultName());
		}
	}

	private List<DetailRow> getHistoryRows(List<RevisionLockPeriod> lockPeriods, int reportGroup, Range<Date> dateRange,
			Range<Date> visibleRange, int timePartition) {
		List<DetailRow> rows = new ArrayList();

		for (RevisionLockPeriod period : lockPeriods) {
			Range<Date> periodRange = new Range<>(period.getPeriod().getStarting(), period.getPeriod().getEnding());
			if (!periodRange.Start.before(visibleRange.Start)
					&& (visibleRange.End.equals(new Date(Long.MAX_VALUE)) || !periodRange.End.after(visibleRange.End))
					&& !periodRange.Start.after(dateRange.End) && !periodRange.End.before(dateRange.Start)) {
				List<Report> reports = this.reportQuery.getReportsAt(this.planId, period.getRevision());
				if (reports.size() != 0) {
					Report[] history = this.getReportGroup(reportGroup, reports);
					List<DetailRow> reportRows;
					if (history.length == 2) {
						TraceReport traceReport = (TraceReport) history[0];
						ResultReport resultReport = (ResultReport) history[1];
						Map<String, Port> historyPortMap = this.getPortMapAt(period.getRevision());
						SqlRowSet traceData = this.reportQuery.getTraceData(traceReport, resultReport, this.payeeId,
								historyPortMap, periodRange, visibleRange, timePartition);
						SqlRowSet resultData = this.reportQuery.getReportDataAt(resultReport, traceReport, this.payeeId,
								periodRange, visibleRange, timePartition, period.getRevision());
						reportRows = this.getTraceReportRows(resultReport, traceReport, resultData, traceData,
								dateRange);
					} else {
						if (!(history[0] instanceof ResultReport)) {
							continue;
						}

						ResultReport resultReport = (ResultReport) history[0];
						SqlRowSet resultData = this.reportQuery.getReportDataAt(resultReport, (TraceReport) null,
								this.payeeId, periodRange, visibleRange, timePartition, period.getRevision());
						reportRows = this.getResultReportRows(resultReport, resultData);
						this.currentReportTotals = null;
					}

					rows.addAll(reportRows);
				}
			}
		}

		return rows;
	}

	private Map<String, Port> getPortMapAt(int revision) {
		if (this.revisionPortSourceTableMap.containsKey(revision)) {
			return this.revisionPortSourceTableMap.get(revision);
		} else {
			Map<String, Port> portMap = this.portDao.getPortMapAt(revision, this.historyDao, this.schemaDao);
			this.revisionPortSourceTableMap.put(revision, portMap);
			return portMap;
		}
	}
}
