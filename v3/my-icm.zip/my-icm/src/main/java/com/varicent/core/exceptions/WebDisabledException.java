package com.varicent.core.exceptions;

public class WebDisabledException extends Exception {
	private static final long serialVersionUID = 1L;

	public WebDisabledException() {
	}

	public WebDisabledException(String message) {
		super(message);
	}

	public WebDisabledException(String message, Throwable cause) {
		super(message, cause);
	}

	public WebDisabledException(Throwable cause) {
		super(cause);
	}
}
