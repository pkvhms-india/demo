package com.varicent.messages.web;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.varicent.core.text.Format;
import com.varicent.messages.domain.Message;

public class MessagesCommand {
	private Calendar start;
	private Calendar end;
	private List<Message> messages;

	public MessagesCommand(Calendar start, Calendar end, List<Message> messages) {
		this.start = start;
		this.end = end;
		this.messages = messages;
	}

	public Date getStartDate() {
		return this.start.getTime();
	}

	public Date getEndDate() {
		return this.end.getTime();
	}

	public String getPrevUrl() {
		return "index.html?start=" + this.getDate(this.start, -8) + "&" + "end" + "=" + this.getDate(this.end, -8);
	}

	public String getNextUrl() {
		return "index.html?start=" + this.getDate(this.start, 8) + "&" + "end" + "=" + this.getDate(this.end, 8);
	}

	private String getDate(Calendar calendar, int amount) {
		Calendar cal = (Calendar) calendar.clone();
		cal.add(5, amount);
		return Format.asISODate(cal.getTime());
	}

	public List<Message> getMessages() {
		return this.messages;
	}

	public boolean getIsNextButtonVisible() {
		return this.end.before(Calendar.getInstance());
	}
}
