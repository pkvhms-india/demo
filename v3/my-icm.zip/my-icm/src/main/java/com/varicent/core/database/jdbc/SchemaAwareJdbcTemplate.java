package com.varicent.core.database.jdbc;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class SchemaAwareJdbcTemplate extends JdbcTemplate {
	public SchemaAwareJdbcTemplate() {
	}

	public SchemaAwareJdbcTemplate(DataSource dataSource) {
		super(dataSource);
	}

	public SchemaAwareJdbcTemplate(DataSource dataSource, boolean lazyInit) {
		super(dataSource, lazyInit);
	}

	@Override
	public <T> List<T> query(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper)
			throws DataAccessException {
		return (List) this.<T>query(sql, args, argTypes, new SchemaAwareRowMapperResultSetExtractor(rowMapper));
	}

	@Override
	public <T> List<T> query(String sql, Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
		return (List) this.query(sql, args, new SchemaAwareRowMapperResultSetExtractor(rowMapper));
	}

	@Override
	public <T> List<T> query(String sql, PreparedStatementSetter pss, RowMapper<T> rowMapper)
			throws DataAccessException {
		return (List<T>) this.<T>query(sql, new SchemaAwareRowMapperResultSetExtractor(rowMapper));
	}

	@Override
	public <T> List<T> query(String sql, RowMapper<T> rowMapper) throws DataAccessException {
		return (List) this.<T>query(sql, new SchemaAwareRowMapperResultSetExtractor(rowMapper));
	}

	@Override
	public <T> T queryForObject(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper)
			throws DataAccessException {
		List<T> results = (List<T>) this.<T>query(sql, args, argTypes,
				new SchemaAwareRowMapperResultSetExtractor(rowMapper, 1));
		return (T) DataAccessUtils.requiredSingleResult(results);
	}

	@Override
	public <T> T queryForObject(String sql, Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
		List<T> results = (List) this.query(sql, args, new SchemaAwareRowMapperResultSetExtractor(rowMapper, 1));
		return (T) DataAccessUtils.requiredSingleResult(results);
	}

	@Override
	public <T> T queryForObject(String sql, RowMapper<T> rowMapper) throws DataAccessException {
		List<T> results = (List<T>) this.<T>query(sql, new SchemaAwareRowMapperResultSetExtractor(rowMapper));
		return (T) DataAccessUtils.requiredSingleResult(results);
	}

	@Override
	public SqlRowSet queryForRowSet(String sql) throws DataAccessException {
		return (SqlRowSet) this.query(sql, new SchemaAwareSqlRowSetResultSetExtractor());
	}

	@Override
	public SqlRowSet queryForRowSet(String sql, Object... args) throws DataAccessException {
		return (SqlRowSet) this.query(sql, args, new SchemaAwareSqlRowSetResultSetExtractor());
	}

	@Override
	public SqlRowSet queryForRowSet(String sql, Object[] args, int[] argTypes) throws DataAccessException {
		return (SqlRowSet) this.query(sql, args, argTypes, new SchemaAwareSqlRowSetResultSetExtractor());
	}

	@Override
	protected RowMapper<Map<String, Object>> getColumnMapRowMapper() {
		return new SchemaAwareColumnMapRowMapper();
	}
}
