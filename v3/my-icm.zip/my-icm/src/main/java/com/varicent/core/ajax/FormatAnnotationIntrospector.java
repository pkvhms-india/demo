package com.varicent.core.ajax;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

import org.codehaus.jackson.map.introspect.Annotated;
import org.codehaus.jackson.map.introspect.AnnotatedMethod;
import org.codehaus.jackson.map.introspect.NopAnnotationIntrospector;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

class FormatAnnotationIntrospector extends NopAnnotationIntrospector {
	private final ConversionService conversionService;

	public FormatAnnotationIntrospector(ConversionService conversionService) {
		this.conversionService = conversionService;
	}

	@Override
	public boolean isHandled(Annotation ann) {
		return ann.toString().startsWith("@org.springframework.format.annotation");
	}

	@Override
	public Object findDeserializer(Annotated a) {
		if (a instanceof AnnotatedMethod) {
			AnnotatedMethod method = (AnnotatedMethod) a;
			TypeDescriptor typeDescriptor = this.getTypeDescriptorForDeserializer(method);

			for (Annotation ann : typeDescriptor.getAnnotations()) {
				if (this.isHandled(ann)) {
					return new ConvertingDeserializer(this.conversionService, typeDescriptor);
				}
			}
		}

		return null;
	}

	@Override
	public Object findSerializer(Annotated a) {
		if (a instanceof AnnotatedMethod) {
			AnnotatedMethod method = (AnnotatedMethod) a;
			TypeDescriptor typeDescriptor = this.getTypeDescriptorForSerializer(method);

			for (Annotation ann : typeDescriptor.getAnnotations()) {
				if (this.isHandled(ann)) {
					return new ConvertingSerializer(this.conversionService, typeDescriptor);
				}
			}
		}

		return null;
	}

	private TypeDescriptor getTypeDescriptorForDeserializer(AnnotatedMethod method) {
		Assert.isTrue(method.getName().startsWith("set"), "Expected a setter method, but was " + method.getName());
		String fieldName = StringUtils.uncapitalize(method.getName().substring(3));
		Field field = ReflectionUtils.findField(method.getDeclaringClass(), fieldName);
		return field != null ? new TypeDescriptor(field) : null;
	}

	private TypeDescriptor getTypeDescriptorForSerializer(AnnotatedMethod method) {
		String fieldName;
		if (method.getName().startsWith("get")) {
			fieldName = StringUtils.uncapitalize(method.getName().substring(3));
		} else {
			if (!method.getName().startsWith("is")) {
				throw new IllegalArgumentException("Expected a getter method, but was " + method.getName());
			}

			fieldName = StringUtils.uncapitalize(method.getName().substring(2));
		}

		Field field = ReflectionUtils.findField(method.getDeclaringClass(), fieldName);
		return field != null ? new TypeDescriptor(field) : null;
	}
}
