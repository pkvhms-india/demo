package com.varicent.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.util.WebUtils;

import com.varicent.common.tab.domain.Tab;
import com.varicent.common.tab.domain.TabGroup;

public class HttpRequestUtils {
	private static final String TABS_ATTRIBUTE = "tabs";

	public static Map<String, String> getParams(HttpServletRequest request) {
		Map<String, String> params = new HashMap();
		Enumeration<?> e = request.getParameterNames();

		while (e.hasMoreElements()) {
			String prefixedName = (String) e.nextElement();
			String value = request.getParameter(prefixedName).trim();
			params.put(prefixedName, value);
		}

		String rawQuery = request.getQueryString();
		if (rawQuery != null) {
			String[] pairs = rawQuery.split("&");

			for (String pair : pairs) {
				String[] components = pair.split("=");
				if (components.length == 2) {
					try {
						String prefixedName = URLDecoder.decode(components[0], "UTF-8");
						String value = URLDecoder.decode(components[1].trim(), "UTF-8");
						params.put(prefixedName, value);
					} catch (UnsupportedEncodingException var11) {
					}
				}
			}
		}

		return params;
	}

	public static Map<Integer, Integer> getVisibleTabIdWorkflowObjectIdMap(HttpServletRequest request) {
		List<Tab> tabs = (List) WebUtils.getSessionAttribute(request, "tabs");
		HashMap<Integer, Integer> visibleTabIdWorkflowObjectIdMap = new HashMap();
		populateVisibleTabIdWorkflowObjectIdMap(tabs, visibleTabIdWorkflowObjectIdMap);
		return visibleTabIdWorkflowObjectIdMap;
	}

	private static void populateVisibleTabIdWorkflowObjectIdMap(List<Tab> tabs,
			HashMap<Integer, Integer> visibleTabIdWorkflowObjectIdMap) {
		if (tabs != null && !tabs.isEmpty()) {
			for (Tab tab : tabs) {
				if (!tab.isPresenterReport() && !tab.isWebForm()) {
					if (tab.isTabGroup()) {
						TabGroup tabGroup = (TabGroup) tab;
						List<Tab> subTabs = tabGroup.getSubTabs();
						populateVisibleTabIdWorkflowObjectIdMap(subTabs, visibleTabIdWorkflowObjectIdMap);
					}
				} else {
					visibleTabIdWorkflowObjectIdMap.put(tab.getId(), tab.getWorkflowObjectId());
				}
			}

		}
	}
}
