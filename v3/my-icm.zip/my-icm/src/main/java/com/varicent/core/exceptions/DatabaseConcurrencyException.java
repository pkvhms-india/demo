package com.varicent.core.exceptions;

import com.varicent.core.i18n.Message;

public class DatabaseConcurrencyException extends Exception {
	private static final long serialVersionUID = 1L;
	private final Message message;

	public DatabaseConcurrencyException(Message message) {
		super(message.getKey().toString());
		this.message = message;
	}

	public Message getMessageObject() {
		return this.message;
	}
}
