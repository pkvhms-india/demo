package com.varicent.customize.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.PeriodLockedException;
import com.varicent.core.text.Parse;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.customize.domain.CustomColumn;
import com.varicent.customize.domain.CustomRow;
import com.varicent.customize.domain.EditRow;

@Service("customizeManager")
@Transactional(readOnly = true)
public class CustomizeManagerImpl implements CustomizeManager {
	private final CustomizeDao customizeDao;
	private final TimeDao timeDao;
	private final SchemaDao schemaDao;

	@Autowired
	public CustomizeManagerImpl(CustomizeDao customizeDao, TimeDao timeDao, SchemaDao schemaDao) {
		this.customizeDao = customizeDao;
		this.timeDao = timeDao;
		this.schemaDao = schemaDao;
	}

	@Override
	public List<CustomColumn> getColumns(String table) {
		return !this.authorized(table) ? Collections.emptyList() : this.customizeDao.getColumns(table);
	}

	@Override
	public List<DataRow> getData(String table, List<String> filterValues) {
		if (!this.authorized(table)) {
			return Collections.emptyList();
		} else {
			List<CustomRow> dataRows = this.customizeDao.getData(table, filterValues);
			ColumnDefinition dateColumn = this.timeDao.getLockableDateColumn(table, this.schemaDao);
			if (dateColumn != null) {
				Date lastLockedDate = this.timeDao.getLockedDate(table);
				if (lastLockedDate != null) {
					for (CustomRow dataRow : dataRows) {
						Date date = (Date) dataRow.getObject(dateColumn.getIndex());
						if (date != null && lastLockedDate.compareTo(date) >= 0) {
							dataRow.setLocked(true);
						}
					}
				}
			}

			List<EditRow> editRows = this.customizeDao.getPendingUpdates(table, filterValues);
			if (editRows.isEmpty()) {
				return new ArrayList(dataRows);
			} else {
				List<CustomColumn> columns = this.customizeDao.getColumns(table);
				List<DataRow> rows = new ArrayList();

				for (CustomRow dataRow : dataRows) {
					rows.add(dataRow);

					for (EditRow editRow : editRows) {
						if (this.keyMatch(dataRow, editRow, columns)) {
							rows.add(editRow);
						}
					}
				}

				return rows;
			}
		}
	}

	@Override
	public List<EditRow> getPendingRows(String table, List<String> filterValues) {
		return !this.authorized(table) ? Collections.emptyList()
				: this.customizeDao.getPendingRows(table, filterValues);
	}

	@Override
	public Set<String> getViewableTables() {
		return this.customizeDao.getViewableTables();
	}

	@Override
	@Transactional(readOnly = false)
	public void submitInsert(String table, List<String> values) throws DataSubmitException, PeriodLockedException {
		if (this.authorized(table)) {
			ColumnDefinition dateColumn = this.timeDao.getLockableDateColumn(table, this.schemaDao);
			if (dateColumn != null) {
				Date lastLockedDate = this.timeDao.getLockedDate(table);
				if (lastLockedDate != null) {
					String value = values.get(dateColumn.getIndex());
					Date date = Parse.date(value);
					if (date != null && lastLockedDate.compareTo(date) >= 0) {
						throw new PeriodLockedException();
					}
				}
			}

			this.customizeDao.submitInsert(table, values);
		}
	}

	@Override
	@Transactional(readOnly = false)
	public void submitUpdate(String table, List<String> originalValues, List<String> editedValues)
			throws DataSubmitException {
		if (this.authorized(table)) {
			this.customizeDao.submitUpdate(table, originalValues, editedValues);
		}

	}

	private boolean authorized(String table) {
		return this.getViewableTables().contains(table);
	}

	private boolean keyMatch(CustomRow row1, EditRow row2, List<CustomColumn> columns) {
		int i = 0;

		for (int n = columns.size(); i < n; ++i) {
			CustomColumn column = columns.get(i);
			String value1 = row1.getValues().get(i);
			String value2 = row2.getValues().get(i);
			if (column.isKey() && !value1.equals(value2)) {
				return false;
			}
		}

		return true;
	}

	@Override
	public boolean isDateValidForTable(String columnName, Date date, String table) {
		ColumnDefinition lockableDateColumn = this.timeDao.getLockableDateColumn(table, this.schemaDao);
		return lockableDateColumn != null && lockableDateColumn.getName().equals(columnName)
				? this.timeDao.isDateValidForTable(date, table)
				: true;
	}
}
