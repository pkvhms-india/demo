package com.varicent.draws.web;

import java.util.ArrayList;
import java.util.List;

import com.varicent.security.domain.CSRFCommand;

public class DrawReportCommand extends CSRFCommand {
	private Integer id;
	private String tabId;
	private int workflowObjectId;
	private String selectedPayeeId;
	private String selectedGroupId;
	private String selectedTemplate;
	private String selectedPeriod;
	private String selectedPeriodLevel;
	private String reportColour;
	private boolean isXLSXExport;
	private List<Boolean> columnVisibilities = new ArrayList(10);
	private int pageNumber;
	private int totalPages;
	private int rowsPerPage;
	private String sortColumn;
	private boolean descending;

	public String getSelectedPayeeId() {
		return this.selectedPayeeId;
	}

	public void setSelectedPayeeId(String selectedPayeeId) {
		this.selectedPayeeId = selectedPayeeId;
	}

	public String getSelectedGroupId() {
		return this.selectedGroupId;
	}

	public void setSelectedGroupId(String selectedGroupId) {
		this.selectedGroupId = selectedGroupId;
	}

	public String getSelectedPeriod() {
		return this.selectedPeriod;
	}

	public void setSelectedPeriod(String selectedPeriod) {
		this.selectedPeriod = selectedPeriod;
	}

	public List<Boolean> getColumnVisibilities() {
		return this.columnVisibilities;
	}

	public void setColumnVisibilities(List<Boolean> columnVisibilities) {
		this.columnVisibilities = columnVisibilities;
	}

	public String getSelectedTemplate() {
		return this.selectedTemplate;
	}

	public void setSelectedTemplate(String selectedTemplate) {
		this.selectedTemplate = selectedTemplate;
	}

	public String getReportColour() {
		return this.reportColour;
	}

	public void setReportColour(String reportColour) {
		this.reportColour = reportColour;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean getIsXLSXExport() {
		return this.isXLSXExport;
	}

	public void setIsXLSXExport(boolean isXLSXExport) {
		this.isXLSXExport = isXLSXExport;
	}

	public int getWorkflowObjectId() {
		return this.workflowObjectId;
	}

	public void setWorkflowObjectId(int workflowObjectId) {
		this.workflowObjectId = workflowObjectId;
	}

	public int getPageNumber() {
		return this.pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getTotalPages() {
		return this.totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public String getSortColumn() {
		return this.sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public boolean isDescending() {
		return this.descending;
	}

	public void setDescending(boolean descending) {
		this.descending = descending;
	}

	public int getRowsPerPage() {
		return this.rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public String getSelectedPeriodLevel() {
		return this.selectedPeriodLevel;
	}

	public void setSelectedPeriodLevel(String selectedPeriodLevel) {
		this.selectedPeriodLevel = selectedPeriodLevel;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public String getTabId() {
		return this.tabId;
	}
}
