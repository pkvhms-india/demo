package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;
import org.springframework.util.Assert;

public class XmlExpressionReader {
	private NodeNumber previousNode;
	private AssignableNode[] variables;
	private int suffix;

	public ExpressionEvaluator toEvaluator(Element node) {
		this.suffix = 0;
		List<?> nodes = node.getChildren();
		Assert.isTrue(nodes.size() == 2);
		this.previousNode = null;
		this.variables = this.getVariables((Element) nodes.get(0));
		EvaluateNode root = this.getEvaluationTree((Element) nodes.get(1));
		if (this.previousNode != null) {
			root = new NodePrevious(root, this.previousNode);
		}

		return new ExpressionEvaluator(root, this.variables);
	}

	private EvaluateNode createFunction(Element node) {
		Op op = XmlExpressionReader.Op.valueOf(node.getName());
		List<EvaluateNode> args = this.getArguments(node);
		switch (op) {
		case Abs:
			return new NodeAbs(args, ++this.suffix);
		case Add:
			return new NodeAdd(args, ++this.suffix);
		case Divide:
			return new NodeDivide(args, ++this.suffix);
		case Max:
			return new NodeMax(args, ++this.suffix);
		case Min:
			return new NodeMin(args, ++this.suffix);
		case Mult:
			return new NodeMult(args, ++this.suffix);
		case Power:
			return new NodePower(args, ++this.suffix);
		case Round:
			return new NodeRound(args, ++this.suffix);
		case RoundDown:
			return new NodeRoundDown(args, ++this.suffix);
		case Subtract:
			return new NodeSubtract(args, ++this.suffix);
		case UnaryMinus:
			return new NodeUnaryMinus(args, ++this.suffix);
		case Prev:
			if (this.previousNode == null) {
				this.previousNode = new NodeNumber(new BigDecimal(0), (String) null, ++this.suffix);
			}

			return this.previousNode;
		case If:
			return new NodeIf(args, ++this.suffix);
		case And:
			return new NodeAnd(args, ++this.suffix);
		case Or:
			return new NodeOr(args, ++this.suffix);
		case Not:
			return new NodeNot(args, ++this.suffix);
		case Equal:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x == null) {
						return y == null;
					} else if (y == null) {
						return false;
					} else {
						return x.compareTo(y) == 0;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Equal);
		case NotEqual:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x == null) {
						return y != null;
					} else if (y == null) {
						return true;
					} else {
						return x.compareTo(y) != 0;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.NotEqual);
		case Greater:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) > 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Greater);
		case GreaterEq:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) >= 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.GreaterEq);
		case Less:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) < 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Less);
		case LessEq:
			return new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) <= 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.LessEq);
		case GroupAvg:
			return new NodeGroupAvg(args, ++this.suffix);
		case GroupCount:
			return new NodeGroupCount(++this.suffix);
		case GroupMax:
			return new NodeGroupMax(args, ++this.suffix);
		case GroupMin:
			return new NodeGroupMin(args, ++this.suffix);
		case GroupMult:
			return new NodeGroupMult(args, ++this.suffix);
		case GroupSum:
			return new NodeGroupSum(args, ++this.suffix);
		default:
			return null;
		}
	}

	private EvaluateNode createVariableNode(Element node) {
		Element nameNode = (Element) node.getChildren().get(0);
		AssignableNode variable = this.findVariable(nameNode.getText(), this.variables);
		return variable.getNode();
	}

	private AssignableNode findVariable(String name, AssignableNode[] variables) {
		for (AssignableNode variable : variables) {
			if (name.equals(variable.getName())) {
				return variable;
			}
		}

		return null;
	}

	private List<EvaluateNode> getArguments(Element node) {
		List<?> arguments = node.getChildren();
		List<EvaluateNode> output = new ArrayList();

		for (int i = 0; i < arguments.size(); ++i) {
			output.add(this.getEvaluationNode((Element) arguments.get(i)));
		}

		return output;
	}

	private EvaluateNode getEvaluationNode(Element node) {
		String nodeName = node.getName();
		if (nodeName.equals("Number")) {
			return NodeNumber.fromXml(node, ++this.suffix);
		} else if (this.isFunction(nodeName)) {
			return this.createFunction(node);
		} else if (nodeName.equals("Variable")) {
			return this.createVariableNode(node);
		} else {
			Assert.state(false);
			return null;
		}
	}

	private EvaluateNode getEvaluationTree(Element treeNode) {
		String nodeName = treeNode.getName();
		Assert.isTrue(nodeName.equals("Tree"));
		Assert.isTrue(treeNode.getChildren().size() == 1);
		return this.getEvaluationNode((Element) treeNode.getChildren().get(0));
	}

	private AssignableNode getVariable(Element node) {
		List<?> children = node.getChildren();
		Assert.isTrue(children.size() == 2);
		Element nameNode = (Element) children.get(0);
		String name = nameNode.getText();
		return new AssignableNumber(name, name, ++this.suffix);
	}

	private AssignableNode[] getVariables(Element variableRoot) {
		List<?> variableNodes = variableRoot.getChildren();
		AssignableNode[] output = new AssignableNode[variableNodes.size()];

		for (int i = 0; i < variableNodes.size(); ++i) {
			output[i] = this.getVariable((Element) variableNodes.get(i));
		}

		return output;
	}

	private boolean isFunction(String name) {
		for (Op op : XmlExpressionReader.Op.values()) {
			if (op.name().equals(name)) {
				return true;
			}
		}

		return false;
	}

	private static enum Op {
		Abs, Add, Divide, Max, Min, Mult, Power, Prev, Round, RoundDown, Subtract, UnaryMinus, If, And, Or, Not, Equal,
		NotEqual, Greater, GreaterEq, Less, LessEq, GroupAvg, GroupCount, GroupMax, GroupMin, GroupMult, GroupSum;
	}
}
