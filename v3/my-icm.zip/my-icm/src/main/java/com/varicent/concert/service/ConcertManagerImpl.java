package com.varicent.concert.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.tab.dao.TabDao;
import com.varicent.reporting.dao.ReportingDao;

@Service("concertManager")
@Transactional(readOnly = true)
public class ConcertManagerImpl implements ConcertManager {
	private final ReportingDao reportingDao;
	private final PayeeDao payeeDao;
	private final TabDao tabDao;

	@Autowired
	public ConcertManagerImpl(PayeeDao payeeDao, ReportingDao reportingDao, TabDao tabDao) {
		this.reportingDao = reportingDao;
		this.payeeDao = payeeDao;
		this.tabDao = tabDao;
	}

	@Override
	public Payee getPayeeByEmail(String email) {
		return this.payeeDao.getPayeeByEmail(email);
	}

	@Override
	public List<Integer> getTabIds(String email) {
		List<Integer> userTabs = null;
		Payee user = this.payeeDao.getPayeeByEmail(email);
		if (user != null) {
			userTabs = this.tabDao.getViewableTabIds(user);
		}

		return userTabs;
	}

	@Override
	public boolean isViewableReport(int reportID, String payeeID) {
		return this.reportingDao.isViewableReport(reportID, payeeID);
	}
}
