package com.varicent.core;

import java.util.Date;
import java.util.GregorianCalendar;

public class Constants {
	public static final String VERSION = "9.0.2.20151223";
	public static final int MIN_DB_VERSION = 1133;
	public static final int MAX_DATA_EDIT_ROWS = 100;
	public static final int MAX_DATA_SOURCE_ROWS = 1000;
	public static final int LONG_STRING_LENGTH = 1000;
	public static final int ITEMS_PER_PAGE = 10;
	public static final String WEB_USER_ALIAS = "WebUser_";
	public static final Date MIN_DATE = (new GregorianCalendar(1753, 0, 1, 0, 0, 0)).getTime();
	public static final Date MAX_DATE = (new GregorianCalendar(9998, 11, 31, 0, 0, 0)).getTime();
	public static final int STRONG_PASSWORD_MINIMUM_LENGTH = 8;
	public static final String XSRF_TOKEN_PERSIST_ATTRIBUTE = "xsrfToken";
	public static final String REDIRECT_HOME_VIEW = "redirect:home.html";
	public static final String API_GET_LOGIN_TYPE_METHOD = "authentication_type";
	public static final String API_EXCEPTION_JSON_ROOT_KEY = "error";
	public static final String API_VERSION_PATH_COMPONENT = "v1";
	public static final String API_USER_PROFILE_JSON_ROOT_KEY = "user";
	public static final String ACCESS_DENIED_DEFAULT_MESSAGE = "You do not have sufficient permissions to access this object";
	public static final String PULSE_PAYEES_JSON_KEY = "payees";
	public static final String PULSE_PAYEES_ID_ATTRIBUTE = "PayeeID";
	public static final String PULSE_PAYEES_IMAGEURL_ATTRIBUTE = "ImageUrl";
	public static final String PULSE_PAYEES_NAME_ATTRIBUTE = "Name";
	public static final int PULSE_REPORT_MAX_PAYEES = 300;

	private Constants() {
	}
}
