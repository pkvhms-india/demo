package com.varicent.core.system;

interface OSIdentifier {
	boolean isOS(String var1);
}
