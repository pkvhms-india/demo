package com.varicent.payeeledger.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.port.domain.Port;
import com.varicent.common.port.domain.PortColumn;
import com.varicent.common.port.domain.PortSourceResolver;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.DataField;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectItem;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.query.sql.TableSorter;
import com.varicent.common.reference.dao.ReferenceDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.Frequency;
import com.varicent.core.Constants;
import com.varicent.core.database.Database;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.support.PortSourceMapper;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.util.Range;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.customize.domain.CustomType;
import com.varicent.payeeledger.domain.CategoryReport;
import com.varicent.payeeledger.domain.DisplayColumn;
import com.varicent.payeeledger.domain.Report;
import com.varicent.payeeledger.domain.ReportTheme;
import com.varicent.payeeledger.domain.ResultReport;
import com.varicent.payeeledger.domain.SortReport;
import com.varicent.payeeledger.domain.TailoredReport;
import com.varicent.payeeledger.domain.TimeShiftReport;
import com.varicent.payeeledger.domain.TraceReport;

class ReportQuery {
	private static final String PREFIX_RESULT = "_Result";
	private static final String PREFIX_TRACE = "_Trace";
	private final RowMapper<ResultReport> resultMapper = new RowMapper<ResultReport>() {
		@Override
		public ResultReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new ResultReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
					rs.getString("ResultName"), rs.getString("CalendarUsed"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")),
					rs.getString("SourceTable"), rs.getString("PayeeColumn"), rs.getBoolean("ShowHeader"),
					rs.getBoolean("ShowPriorPeriods"), rs.getBoolean("SuppressEmptyReports"),
					rs.getBoolean("SuppressSummary"));
		}
	};
	private final RowMapper<TimeShiftReport> timeShiftResultMapper = new RowMapper<TimeShiftReport>() {
		@Override
		public TimeShiftReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new TimeShiftReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
					rs.getString("ResultName"), rs.getString("TimeID"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")),
					rs.getString("SourceTable"), rs.getString("PayeeColumn"), rs.getBoolean("ShowHeader"),
					rs.getBoolean("ShowPriorPeriods"), rs.getBoolean("SuppressEmptyReports"),
					rs.getBoolean("SuppressSummary"));
		}
	};
	private final RowMapper<SortReport> sortMapper = new RowMapper<SortReport>() {
		@Override
		public SortReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new SortReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
					rs.getString("ResultName"), rs.getString("CalendarUsed"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")),
					rs.getString("ResultTable"), rs.getString("SourceTable"), rs.getString("PayeeColumn"),
					rs.getString("FirstSortColumn"), rs.getBoolean("ShowHeader"), rs.getBoolean("ShowPriorPeriods"),
					rs.getBoolean("SuppressEmptyReports"), rs.getBoolean("SuppressSummary"));
		}
	};
	private final RowMapper<TraceReport> traceMapper = new RowMapper<TraceReport>() {
		@Override
		public TraceReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new TraceReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
					rs.getString("ResultName"), rs.getString("CalendarUsed"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")), rs.getString("Source"),
					rs.getString("PayeeTable"), rs.getString("PayeeColumn"), rs.getString("TimeLevel"),
					rs.getString("ResetLevel"), rs.getInt("ReportTraceDataID"),
					ReportQuery.this.getTraceTable(rs.getInt("CalculationDataID")), rs.getInt("KeyColumns"),
					ReportQuery.this.getDisplayColumns(rs.getInt("ReportID")),
					ReportQuery.this.getResultColumns(rs.getInt("CalculationID")), rs.getBoolean("ShowHeader"),
					rs.getBoolean("ShowPriorPeriods"), rs.getBoolean("SuppressEmptyReports"),
					rs.getBoolean("SuppressSummary"));
		}
	};
	private final RowMapper<CategoryReport> categoryMapper = new RowMapper<CategoryReport>() {
		@Override
		public CategoryReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new CategoryReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
					rs.getString("ResultName"), rs.getString("CalendarUsed"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")),
					rs.getString("ResultTable"), rs.getString("SourceTable"), rs.getString("PayeeColumn"),
					rs.getBoolean("ShowHeader"), rs.getBoolean("ShowPriorPeriods"),
					rs.getBoolean("SuppressEmptyReports"), rs.getBoolean("SuppressSummary"));
		}
	};
	private final RowMapper<DisplayColumn> displayColumnMapper = new RowMapper<DisplayColumn>() {
		@Override
		public DisplayColumn mapRow(ResultSet rs, int rowNumber) throws SQLException {
			DataField source = ReportQuery.this.referenceDao.getSourceField(rs.getString("DataItem"));
			CustomType type = source == null ? CustomType.TEXT
					: ReportQuery.this.customizeDao.getColumnType(source.getTable(), source.getColumn());
			return new DisplayColumn(rs.getString("DisplayName"), rs.getInt("Operation"),
					new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")), rs.getString("DataItem"),
					type);
		}
	};
	private final RowMapper<Range<Date>> dateRangeMapper = new RowMapper<Range<Date>>() {
		@Override
		public Range<Date> mapRow(ResultSet rs, int rowNumber) throws SQLException {
			Object startingValue = rs.getObject("Starting");
			Date starting;
			if (startingValue != null && startingValue instanceof Date) {
				starting = (Date) startingValue;
			} else {
				starting = Constants.MIN_DATE;
			}

			Object endingValue = rs.getObject("Ending");
			Date ending;
			if (endingValue != null && endingValue instanceof Date) {
				ending = (Date) endingValue;
			} else {
				ending = Constants.MAX_DATE;
			}

			return new Range<>(starting, ending);
		}
	};
	private final JdbcOperations operations;
	private final CustomizeDao customizeDao;
	private final HistoryDao historyDao;
	private final ReferenceDao referenceDao;
	private final TimeDao timeDao;
	private final SchemaDao schemaDao;

	public ReportQuery(DataSource ds, CustomizeDao customizeDao, HistoryDao historyDao, ReferenceDao referenceDao,
			TimeDao timeDao, SchemaDao schemaDao) {
		this.operations = Database.getOperations(ds);
		this.customizeDao = customizeDao;
		this.historyDao = historyDao;
		this.referenceDao = referenceDao;
		this.timeDao = timeDao;
		this.schemaDao = schemaDao;
	}

	public SqlRowSet getReportData(ResultReport report, TraceReport trace, String payeeId, Range<Date> dateRange,
			Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = this.getReportDataQuery(report, trace, payeeId, dateRange, visibleRange,
				lastResettingPartition);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForRowSet(qb.toSql(query));
	}

	public SqlRowSet getReportDataAt(ResultReport report, TraceReport trace, String payeeId, Range<Date> dateRange,
			Range<Date> visibleRange, int lastResettingPartition, int revision) {
		QueryDefinition query = this.getReportDataQuery(report, trace, payeeId, dateRange, visibleRange,
				lastResettingPartition);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForRowSet(qb.toSql(query));
	}

	private QueryDefinition getReportDataQuery(ResultReport report, TraceReport trace, String payeeId,
			Range<Date> dateRange, Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = new QueryDefinition(report.getResultTable());
		query.select(report.getResultTable(), "_ResultID");
		List<ColumnDefinition> columns = this.schemaDao.getColumns(report.getResultTable());
		TableSorter sorter = new TableSorter(this.timeDao);

		for (ColumnDefinition column : columns) {
			if (!column.getName().startsWith(Database.getSyntax().getSystemPrefix())) {
				query.select(report.getResultTable(), column.getName());
			}

			if (column.isKey()) {
				sorter.orderBy(query, report.getResultTable(), column.getName());
			}
		}

		if (report.hasPayeeColumn()) {
			query.newConstraint(report.getResultTable(), report.getPayeeColumn(), Constraint.Operator.Equals, payeeId);
		}

		if (report.hasTimePartition()) {
			QueryDefinition periodQuery = new QueryDefinition("Time_");
			periodQuery.selectAll();
			periodQuery.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, report.getCalendar());
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, dateRange.End);
			periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, dateRange.Start);
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.GreaterThanEquals, visibleRange.Start);
			if (!visibleRange.End.equals(new Date(Long.MAX_VALUE))) {
				periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, visibleRange.End);
			}

			SelectItem timePartition = (SelectItem) query.getSelect().get(lastResettingPartition);
			Join join = new Join(periodQuery, "_periodFilter", Join.Type.INNER);
			join.newConstraint("_periodFilter", "Name_", Constraint.Operator.Equals, report.getResultTable(),
					timePartition.getColumn());
			query.joinWith(join);
		}

		if (trace != null) {
			int j = 0;

			for (String resCol : trace.getResultColumns()) {
				if (resCol.equals("Value_")) {
					resCol = "Value";
				}

				String var10001 = trace.getTraceTable();
				StringBuilder var10003 = (new StringBuilder()).append("_Trace_Value");
				++j;
				query.select(var10001, resCol, var10003.append(j).toString());
			}

			List<ColumnDefinition> traceColumns = this.schemaDao.getColumns(trace.getTraceTable());

			for (int i = 0; i < trace.getKeyColumns(); ++i) {
				ColumnDefinition column = traceColumns.get(i);
				query.select(trace.getTraceTable(), "_Key" + i, "_Key" + column.getName());
			}

			Join join = new Join(trace.getTraceTable(), Join.Type.LEFT);
			join.newConstraint(trace.getTraceTable(), "_ResultID", Constraint.Operator.Equals, report.getResultTable(),
					"_ResultID");
			query.orderBy(trace.getTraceTable(), "TraceID");
			query.joinWith(join);
			if (trace.getDisplayColumns().size() > 0) {
				QueryDefinition sourceRows = new QueryDefinition(trace.getTraceSourceTable());
				if (trace.hasPayeeColumn()) {
					sourceRows.newConstraint(trace.getTraceSourceTable(), "_PayeeID", Constraint.Operator.Equals,
							payeeId);
				}

				int i = 0;

				for (int n = trace.getDisplayColumns().size(); i < n; ++i) {
					sourceRows.select(trace.getTraceSourceTable(), "_Display" + i);
					query.select("_TraceSourceData", "_Display" + i);
				}

				sourceRows.select(trace.getTraceSourceTable(), "_TraceSourceID");
				query.crossJoin(sourceRows, "_TraceSourceData");
				query.newConstraint(trace.getTraceTable(), "TraceID", Constraint.Operator.Equals, "_TraceSourceData",
						"_TraceSourceID");
			}
		}

		return query;
	}

	public SqlRowSet getReportData(CategoryReport report, String payeeId, Range<Date> dateRange,
			Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = new QueryDefinition(report.getResultTable());
		List<ColumnDefinition> columns = this.schemaDao.getColumns(report.getResultTable());
		TableSorter sorter = new TableSorter(this.timeDao);
		Frequency freq = null;
		String timeColumn = null;

		for (ColumnDefinition column : columns) {
			if (!column.getName().startsWith(Database.getSyntax().getSystemPrefix())) {
				query.select(report.getResultTable(), column.getName());
				if (freq == null) {
					freq = this.timeDao.getFrequency(report.getResultTable(), column.getName());
					timeColumn = freq == null ? null : column.getName();
				}
			}

			if (column.isKey()) {
				sorter.orderBy(query, report.getResultTable(), column.getName());
			}
		}

		if (freq != null) {
			QueryDefinition periodQuery = new QueryDefinition("Time_");
			periodQuery.selectAll();
			periodQuery.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, freq.getTimeId());
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, dateRange.End);
			periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, dateRange.Start);
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.GreaterThanEquals, visibleRange.Start);
			if (!visibleRange.End.equals(new Date(Long.MAX_VALUE))) {
				periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, visibleRange.End);
			}

			Join join = new Join(periodQuery, "_periodFilter", Join.Type.INNER);
			join.newConstraint("_periodFilter", "Name_", Constraint.Operator.Equals, report.getResultTable(),
					timeColumn);
			query.joinWith(join);
		}

		if (report.hasPayeeColumn()) {
			query.newConstraint(report.getResultTable(), report.getPayeeColumn(), Constraint.Operator.Equals, payeeId);
		}

		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForRowSet(qb.toSql(query));
	}

	public SqlRowSet getReportData(SortReport report, String payeeId, Map<String, Port> portMap, Range<Date> dateRange,
			Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = new QueryDefinition(report.getResultTable());
		String sourceTable = report.getSourceTable();
		Join join = new Join(sourceTable, Join.Type.INNER);
		if (sourceTable.startsWith("_Port")) {
			Port port = portMap.get(sourceTable);

			for (PortColumn portColumn : port.getColumns()) {
				if (portColumn.isKey()) {
					join.newConstraint(report.getResultTable(), portColumn.getName(), Constraint.Operator.Equals,
							sourceTable, portColumn.getName());
				}
			}
		} else {
			for (ColumnDefinition keyColumn : this.schemaDao.getKeyColumns(sourceTable)) {
				join.newConstraint(report.getResultTable(), keyColumn.getName(), Constraint.Operator.Equals,
						sourceTable, keyColumn.getName());
			}
		}

		query.joinWith(join);
		TableSorter sorter = new TableSorter(this.timeDao);

		for (ColumnDefinition column : this.schemaDao.getColumns(report.getResultTable())) {
			query.select(report.getResultTable(), column.getName());
			if (column.isKey()) {
				sorter.orderBy(query, report.getResultTable(), column.getName());
			}
		}

		if (report.hasFirstSortColumn()) {
			query.select(sourceTable, report.getFirstSortColumn());
		}

		if (report.hasPayeeColumn()) {
			query.newConstraint(report.getResultTable(), report.getPayeeColumn(), Constraint.Operator.Equals, payeeId);
		}

		if (report.hasTimePartition()) {
			QueryDefinition periodQuery = new QueryDefinition("Time_");
			periodQuery.selectAll();
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, dateRange.End);
			periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, dateRange.Start);
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.GreaterThanEquals, visibleRange.Start);
			if (!visibleRange.End.equals(new Date(Long.MAX_VALUE))) {
				periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, visibleRange.End);
			}

			SelectItem timePartition = (SelectItem) query.getSelect().get(lastResettingPartition);
			Join periodJoin = new Join(periodQuery, "_periodFilter", Join.Type.INNER);
			periodJoin.newConstraint("_periodFilter", "Name_", Constraint.Operator.Equals, report.getResultTable(),
					timePartition.getColumn());
			query.joinWith(periodJoin);
		}

		if (report.getSourceTable().startsWith("_Port")) {
			PortSourceMapper.mapQuery(query, portMap, new PortSourceResolver(portMap.values()));
		}

		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForRowSet(qb.toSql(query));
	}

	public List<Report> getReports(String planId) {
		List<Report> reports = new ArrayList();
		QueryDefinition query = this.getReportListQuery(planId);
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			int reportId = result.getInt("ReportID");
			int reportType = result.getInt("Type");
			ReportTheme theme = new ReportTheme(result.getString("AlternatingColour"), result.getString("HeaderColour"),
					result.getString("SummaryColour"));
			switch (reportType) {
			case 0:
				Report resultReport = this.getResultReport(reportId);
				resultReport.setTheme(theme);
				reports.add(resultReport);
				break;
			case 1:
				Report traceReport = this.getTraceReport(reportId);
				traceReport.setTheme(theme);
				reports.add(traceReport);
				break;
			case 2:
				Report sortReport = this.getSortReport(reportId);
				sortReport.setTheme(theme);
				reports.add(sortReport);
			case 3:
			default:
				break;
			case 4:
				Report categoryReport = this.getCategoryReport(reportId);
				categoryReport.setTheme(theme);
				reports.add(categoryReport);
				break;
			case 5:
				Report timeShiftReport = this.getTimeShiftReport(reportId);
				timeShiftReport.setTheme(theme);
				reports.add(timeShiftReport);
			}
		}

		return reports;
	}

	public List<Report> getReportsAt(String planId, int revision) {
		List<Report> reports = new ArrayList();
		QueryDefinition query = this.getReportListQuery(planId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));

		while (result.next()) {
			int reportId = result.getInt("ReportID");
			int reportType = result.getInt("Type");
			ReportTheme theme = new ReportTheme(result.getString("AlternatingColour"), result.getString("HeaderColour"),
					result.getString("SummaryColour"));
			switch (reportType) {
			case 0:
				Report resultReport = this.getResultReportAt(reportId, revision);
				resultReport.setTheme(theme);
				reports.add(resultReport);
				break;
			case 1:
				Report traceReport = this.getTraceReportAt(reportId, revision);
				traceReport.setTheme(theme);
				reports.add(traceReport);
				break;
			case 2:
				Report sortReport = this.getSortReportAt(reportId, revision);
				sortReport.setTheme(theme);
				reports.add(sortReport);
			case 3:
			default:
				break;
			case 4:
				Report categoryReport = this.getCategoryReportAt(reportId, revision);
				categoryReport.setTheme(theme);
				reports.add(categoryReport);
				break;
			case 5:
				TimeShiftReport timeShiftReport = this.getTimeShiftReportAt(reportId, revision);
				timeShiftReport.setTheme(theme);
				reports.add(timeShiftReport);
			}
		}

		return reports;
	}

	public Map<String, Object> getSourceData(SqlRowSet traceData) {
		Map<String, Object> sourceData = new LinkedHashMap();
		String sourceColumnPrefix = Database.getSyntax().toValidIdentifier("_Src_");

		for (String columnName : traceData.getMetaData().getColumnNames()) {
			if (columnName.startsWith(sourceColumnPrefix)) {
				sourceData.put(columnName.replaceFirst(sourceColumnPrefix, ""), traceData.getObject(columnName));
			}
		}

		return sourceData;
	}

	public SqlRowSet getTraceData(TraceReport trace, ResultReport report, String payeeId, Map<String, Port> portMap,
			Range<Date> dateRange, Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = this.getTraceDataQuery(trace, report, payeeId, portMap, dateRange, visibleRange,
				lastResettingPartition);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForRowSet(qb.toSql(query));
	}

	private QueryDefinition getTraceDataQuery(TraceReport trace, ResultReport report, String payeeId,
			Map<String, Port> portMap, Range<Date> dateRange, Range<Date> visibleRange, int lastResettingPartition) {
		QueryDefinition query = new QueryDefinition(report.getResultTable());
		if (report.hasPayeeColumn()) {
			query.newConstraint(report.getResultTable(), report.getPayeeColumn(), Constraint.Operator.Equals, payeeId);
		}

		if (report.hasTimePartition()) {
			QueryDefinition periodQuery = new QueryDefinition("Time_");
			periodQuery.selectAll();
			periodQuery.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, report.getCalendar());
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, dateRange.End);
			periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, dateRange.Start);
			periodQuery.newConstraint("Time_", "Starting_", Constraint.Operator.GreaterThanEquals, visibleRange.Start);
			if (!visibleRange.End.equals(new Date(Long.MAX_VALUE))) {
				periodQuery.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, visibleRange.End);
			}

			List<ColumnDefinition> columns = this.schemaDao.getColumns(report.getResultTable());
			List<String> displayedColumns = new ArrayList();

			for (ColumnDefinition column : columns) {
				if (!column.getName().startsWith(Database.getSyntax().getSystemPrefix())) {
					displayedColumns.add(column.getName());
				}
			}

			String timePartition = displayedColumns.get(lastResettingPartition - 1);
			Join join = new Join(periodQuery, "_periodFilter", Join.Type.INNER);
			join.newConstraint("_periodFilter", "Name_", Constraint.Operator.Equals, report.getResultTable(),
					timePartition);
			query.joinWith(join);
		}

		String traceTable = trace.getTraceTable();
		String traceSourceTable = trace.getTraceSourceTable();
		String sourceTable = trace.getSourceTable();
		Join join = new Join(traceTable, Join.Type.INNER);
		join.newConstraint(report.getResultTable(), "_ResultID", Constraint.Operator.Equals, traceTable, "_ResultID");
		query.orderBy(traceTable, "TraceID");
		query.joinWith(join);
		query.select(traceTable, "_ResultID", "_Trace__ResultID");
		Join traceSourceJoin = new Join(traceSourceTable, Join.Type.INNER);
		traceSourceJoin.newConstraint(traceTable, "TraceID", Constraint.Operator.Equals, traceSourceTable,
				"_TraceSourceID");
		query.joinWith(traceSourceJoin);
		int i = 0;

		for (int n = trace.getDisplayColumns().size(); i < n; ++i) {
			query.select(traceSourceTable, "_Display" + i);
		}

		i = 0;

		for (String resCol : trace.getResultColumns()) {
			if (resCol.equals("Value_")) {
				resCol = "Value";
			}

			StringBuilder var10003 = (new StringBuilder()).append("_Trace_Value");
			++i;
			query.select(traceTable, resCol, var10003.append(i).toString());
		}

		if (!this.isCalculatedTable(sourceTable)) {
			List<String> sourceColumns = new ArrayList();
			List<String> sourceKeyColumns = new ArrayList();
			if (sourceTable.startsWith("_Port")) {
				Port port = portMap.get(sourceTable);

				for (PortColumn portColumn : port.getColumns()) {
					sourceColumns.add(portColumn.getName());
					if (portColumn.isKey()) {
						sourceKeyColumns.add(portColumn.getName());
					}
				}
			} else {
				for (ColumnDefinition column : this.schemaDao.getColumns(sourceTable)) {
					sourceColumns.add(column.getName());
					if (column.isKey()) {
						sourceKeyColumns.add(column.getName());
					}
				}
			}

			int y = 0;

			for (int n = sourceColumns.size(); y < n; ++y) {
				String sourceColumnName = sourceColumns.get(y);
				query.select(sourceTable, sourceColumnName, "_Src_" + sourceColumnName);
			}

			Join sourceJoin = new Join(sourceTable, Join.Type.LEFT);
			int s = 0;

			for (int n = trace.getKeyColumns(); s < n; ++s) {
				sourceJoin.newConstraint(traceTable, "_Key" + s, Constraint.Operator.Equals, sourceTable,
						sourceKeyColumns.get(s));
			}

			query.joinWith(sourceJoin);
		}

		if (sourceTable.startsWith("_Port")) {
			PortSourceMapper.mapQuery(query, portMap, new PortSourceResolver(portMap.values()));
		}

		return query;
	}

	public Range<Date> getVisibleDates(String planId) {
		QueryDefinition query = new QueryDefinition("CompPlanWebVisibility");
		query.newConstraint("CompPlanWebVisibility", "CompPlanID", Constraint.Operator.Equals, planId);
		query.select("CompPlanWebVisibility", "Starting");
		query.select("CompPlanWebVisibility", "Ending");
		QueryBuilder qb = Database.getQueryBuilder();
		List<Range<Date>> result = this.operations.query(qb.toSql(query), this.dateRangeMapper);
		return result.isEmpty() ? new Range(Constants.MIN_DATE, Constants.MAX_DATE) : (Range) result.get(0);
	}

	private List<DisplayColumn> getDisplayColumns(int reportId) {
		QueryDefinition query = this.getDisplayColumnsQuery(reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.query(qb.toSql(query), this.displayColumnMapper);
	}

	private List<DisplayColumn> getDisplayColumnsAt(int reportId, int revision) {
		QueryDefinition query = this.getDisplayColumnsQuery(reportId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.query(qb.toSql(query), this.getHistoryDisplayColumnMapper(revision));
	}

	private QueryDefinition getDisplayColumnsQuery(int reportId) {
		QueryDefinition query = new QueryDefinition("ReportTraceColumn");
		query.selectAll();
		query.newConstraint("ReportTraceColumn", "ReportID", Constraint.Operator.Equals, reportId);
		query.orderBy("ReportTraceColumn", "Order");
		return query;
	}

	private List<String> getResultColumns(int calcId) {
		QueryDefinition query = this.getResultColumnsQuery(calcId);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForList(qb.toSql(query), String.class);
	}

	private List<String> getResultColumnsAt(int calcId, int revision) {
		QueryDefinition query = this.getResultColumnsQuery(calcId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.queryForList(qb.toSql(query), String.class);
	}

	private QueryDefinition getResultColumnsQuery(int calcId) {
		QueryDefinition query = new QueryDefinition("CalculationFormula");
		query.select("CalculationFormula", "ResultColumnName");
		query.newConstraint("CalculationFormula", "CalculationID", Constraint.Operator.Equals, calcId);
		query.orderBy("CalculationFormula", "Order");
		return query;
	}

	private String getTraceTable(int calcDataID) {
		return "_Trace" + calcDataID;
	}

	private QueryDefinition getReportListQuery(String planId) {
		QueryDefinition query = new QueryDefinition("Report");
		query.select("Report", "ReportID");
		query.select("Report", "Type");
		query.select("ReportList", "AlternatingColour");
		query.select("ReportList", "HeaderColour");
		query.select("ReportList", "SummaryColour");
		Join listJoin = new Join("ReportList", Join.Type.INNER);
		listJoin.newConstraint("Report", "ReportListID", Constraint.Operator.Equals, "ReportList", "ReportListID");
		query.joinWith(listJoin);
		if (TailoredReport.isReport(planId)) {
			Join planJoin = new Join("TailoredReport", Join.Type.INNER);
			planJoin.newConstraint("Report", "ReportListID", Constraint.Operator.Equals, "TailoredReport",
					"ReportQueueID");
			query.joinWith(planJoin);
			query.newConstraint("TailoredReport", "ID", Constraint.Operator.Equals, planId);
		} else {
			Join planJoin = new Join("CompPlan", Join.Type.INNER);
			planJoin.newConstraint("Report", "ReportListID", Constraint.Operator.Equals, "CompPlan", "ReportQueueID");
			query.joinWith(planJoin);
			query.newConstraint("CompPlan", "CompPlanID", Constraint.Operator.Equals, planId);
		}

		query.orderBy("Report", "ReportID");
		return query;
	}

	private QueryDefinition getReportQuery(String reportTable, int reportId) {
		QueryDefinition query = new QueryDefinition("Report");
		query.selectAll();
		Join reportJoin = new Join(reportTable, Join.Type.INNER);
		reportJoin.newConstraint("Report", "ReportID", Constraint.Operator.Equals, reportTable, "ReportID");
		query.joinWith(reportJoin);
		Join calcJoin = new Join("Calculation", Join.Type.INNER);
		calcJoin.newConstraint("Report", "CalculationID", Constraint.Operator.Equals, "Calculation", "CalculationID");
		query.joinWith(calcJoin);
		query.newConstraint("Report", "ReportID", Constraint.Operator.Equals, reportId);
		return query;
	}

	private QueryDefinition getTimeShiftReportQuery(String reportTable, int reportId) {
		QueryDefinition query = this.getReportQuery(reportTable, reportId);
		query.select("TimeShift", "TimeID");
		Join tsJoin = new Join("TimeShift", Join.Type.LEFT);
		tsJoin.newConstraint("TimeShift", "CalculationID", Constraint.Operator.Equals, "Calculation", "CalculationID");
		query.joinWith(tsJoin);
		return query;
	}

	private ResultReport getResultReport(int reportId) {
		QueryDefinition query = this.getReportQuery("ReportResult", reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		return (ResultReport) this.operations.queryForObject(qb.toSql(query), this.resultMapper);
	}

	private ResultReport getResultReportAt(int reportId, int revision) {
		QueryDefinition query = this.getReportQuery("ReportResult", reportId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return (ResultReport) this.operations.queryForObject(qb.toSql(query), this.resultMapper);
	}

	private TimeShiftReport getTimeShiftReport(int reportId) {
		QueryDefinition query = this.getTimeShiftReportQuery("ReportResult", reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		return (TimeShiftReport) this.operations.queryForObject(qb.toSql(query), this.timeShiftResultMapper);
	}

	private TimeShiftReport getTimeShiftReportAt(int reportId, int revision) {
		QueryDefinition query = this.getTimeShiftReportQuery("ReportResult", reportId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return (TimeShiftReport) this.operations.queryForObject(qb.toSql(query), this.timeShiftResultMapper);
	}

	private SortReport getSortReport(int reportId) {
		QueryDefinition query = this.getReportQuery("ReportSort", reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		return (SortReport) this.operations.queryForObject(qb.toSql(query), this.sortMapper);
	}

	private SortReport getSortReportAt(int reportId, int revision) {
		QueryDefinition query = this.getReportQuery("ReportSort", reportId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return (SortReport) this.operations.queryForObject(qb.toSql(query), this.sortMapper);
	}

	private Report getTraceReport(int reportId) {
		QueryDefinition query = this.getReportQuery("ReportTrace", reportId);
		Join traceDataJoin = new Join("ReportTraceData", Join.Type.INNER);
		traceDataJoin.newConstraint("Report", "ReportID", Constraint.Operator.Equals, "ReportTraceData", "ReportID");
		query.joinWith(traceDataJoin);
		Join calcDataJoin = new Join("CalculationData", Join.Type.INNER);
		calcDataJoin.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "CalculationData",
				"CalculationID");
		query.joinWith(calcDataJoin);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Report) this.operations.queryForObject(qb.toSql(query), this.traceMapper);
	}

	private Report getTraceReportAt(int reportId, int revision) {
		QueryDefinition query = this.getReportQuery("ReportTrace", reportId);
		Join traceDataJoin = new Join("ReportTraceData", Join.Type.INNER);
		traceDataJoin.newConstraint("Report", "ReportID", Constraint.Operator.Equals, "ReportTraceData", "ReportID");
		query.joinWith(traceDataJoin);
		Join calcDataJoin = new Join("CalculationData", Join.Type.INNER);
		calcDataJoin.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "CalculationData",
				"CalculationID");
		query.joinWith(calcDataJoin);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Report) this.operations.queryForObject(qb.toSql(query), this.getHistoryTraceMapper(revision));
	}

	private RowMapper<TraceReport> getHistoryTraceMapper(final int revision) {
		return new RowMapper<TraceReport>() {
			@Override
			public TraceReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
				return new TraceReport(rs.getInt("ReportID"), rs.getInt("CalculationID"), rs.getString("Name"),
						rs.getString("ResultName"), rs.getString("CalendarUsed"),
						new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")), rs.getString("Source"),
						rs.getString("PayeeTable"), rs.getString("PayeeColumn"), rs.getString("TimeLevel"),
						rs.getString("ResetLevel"), rs.getInt("ReportTraceDataID"),
						ReportQuery.this.getTraceTable(rs.getInt("CalculationDataID")), rs.getInt("KeyColumns"),
						ReportQuery.this.getDisplayColumnsAt(rs.getInt("ReportID"), revision),
						ReportQuery.this.getResultColumnsAt(rs.getInt("CalculationID"), revision),
						rs.getBoolean("ShowHeader"), rs.getBoolean("ShowPriorPeriods"),
						rs.getBoolean("SuppressEmptyReports"), rs.getBoolean("SuppressSummary"));
			}
		};
	}

	private final RowMapper<DisplayColumn> getHistoryDisplayColumnMapper(final int revision) {
		return new RowMapper<DisplayColumn>() {
			@Override
			public DisplayColumn mapRow(ResultSet rs, int rowNumber) throws SQLException {
				DataField source = ReportQuery.this.referenceDao.getSourceFieldAt(rs.getString("DataItem"), revision,
						ReportQuery.this.schemaDao);
				CustomType type = source == null ? CustomType.TEXT
						: ReportQuery.this.customizeDao.getColumnType(source.getTable(), source.getColumn());
				return new DisplayColumn(rs.getString("DisplayName"), rs.getInt("Operation"),
						new NumericFormat(rs.getInt("NumericStyle"), rs.getInt("NumericScale")),
						rs.getString("DataItem"), type);
			}
		};
	}

	private Report getCategoryReport(int reportId) {
		QueryDefinition query = this.getReportQuery("ReportCategory", reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Report) this.operations.queryForObject(qb.toSql(query), this.categoryMapper);
	}

	private Report getCategoryReportAt(int reportId, int revision) {
		QueryDefinition query = this.getReportQuery("ReportCategory", reportId);
		query = this.historyDao.historifyQuery(query, revision, this.schemaDao);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Report) this.operations.queryForObject(qb.toSql(query), this.categoryMapper);
	}

	private boolean isCalculatedTable(String table) {
		return table.startsWith(Database.getSyntax().toValidIdentifier("_Result"));
	}
}
