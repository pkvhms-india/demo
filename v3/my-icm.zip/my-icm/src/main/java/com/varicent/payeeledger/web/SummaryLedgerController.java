package com.varicent.payeeledger.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.varicent.common.config.service.ConfigManager;
import com.varicent.payeeledger.service.PayeeLedger;
import com.varicent.workflow.service.WorkflowManager;

@Controller
@RequestMapping({ "/ledger/summary.html" })
public class SummaryLedgerController extends AbstractPayeeLedgerController {
	private static final String TYPE = "summary";
	private static final String VIEW = "payeeledger/summary";

	@Autowired
	public SummaryLedgerController(@Qualifier("summaryLedger") PayeeLedger payeeLedger, ConfigManager configManager,
			WorkflowManager workflowManager) {
		super(payeeLedger, configManager, workflowManager);
	}

	@Override
	public String getType() {
		return "summary";
	}

	@Override
	protected String getView() {
		return "payeeledger/summary";
	}
}
