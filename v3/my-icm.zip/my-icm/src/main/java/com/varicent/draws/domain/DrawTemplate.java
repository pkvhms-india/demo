package com.varicent.draws.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

public class DrawTemplate implements Serializable {
	public static final BigDecimal MAX_DRAW_AMOUNT = new BigDecimal("999999.99");
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private int drawId;
	private String description;
	private TemplateType templateType;
	private int duration;
	private int maxDuration;
	private boolean ongoing;
	private boolean canChangeDuration;
	private BigDecimal drawAmount;
	private BigDecimal maxDrawAmount;
	private boolean fixedAmount;
	private boolean canChangeDrawAmount;
	private List<DrawSchedule> schedules;
	private String level;

	public DrawTemplate(int id, String name, int drawId, String description, TemplateType templateType, int duration,
			int maxDuration, boolean ongoing, BigDecimal drawAmount, BigDecimal maxDrawAmount, boolean fixedAmount,
			boolean canChangeDuration, boolean canChangeDrawAmount, String level) {
		this.id = id;
		this.name = name;
		this.drawId = drawId;
		this.description = description;
		this.templateType = templateType;
		this.duration = duration;
		this.maxDuration = maxDuration;
		this.ongoing = ongoing;
		this.canChangeDuration = canChangeDuration;
		this.drawAmount = drawAmount;
		this.maxDrawAmount = maxDrawAmount;
		this.fixedAmount = fixedAmount;
		this.canChangeDrawAmount = canChangeDrawAmount;
		this.level = level;
		this.schedules = new LinkedList();
	}

	public boolean isCanChangeDuration() {
		return this.canChangeDuration;
	}

	public boolean isCanChangeDrawAmount() {
		return this.canChangeDrawAmount;
	}

	public void setCanChangeDuration(boolean canChangeDuration) {
		this.canChangeDuration = canChangeDuration;
	}

	public void setCanChangeDrawAmount(boolean canChangeDrawAmount) {
		this.canChangeDrawAmount = canChangeDrawAmount;
	}

	public int getDrawId() {
		return this.drawId;
	}

	public String getDescription() {
		return this.description;
	}

	public TemplateType getTemplateType() {
		return this.templateType;
	}

	public int getDuration() {
		return this.duration;
	}

	public int getMaxDuration() {
		return this.maxDuration;
	}

	public boolean isOngoing() {
		return this.ongoing;
	}

	public BigDecimal getDrawAmount() {
		return this.drawAmount;
	}

	public BigDecimal getMaxDrawAmount() {
		return this.maxDrawAmount;
	}

	public boolean isFixedAmount() {
		return this.fixedAmount;
	}

	public List<DrawSchedule> getSchedules() {
		return this.schedules;
	}

	public String getLevel() {
		return this.level;
	}

	public void setDrawId(int drawId) {
		this.drawId = drawId;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTemplateType(TemplateType templateType) {
		this.templateType = templateType;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setMaxDuration(int maxDuration) {
		this.maxDuration = maxDuration;
	}

	public void setOngoing(boolean ongoing) {
		this.ongoing = ongoing;
	}

	public void setDrawAmount(BigDecimal drawAmount) {
		this.drawAmount = drawAmount;
	}

	public void setMaxDrawAmount(BigDecimal maxDrawAmount) {
		this.maxDrawAmount = maxDrawAmount;
	}

	public void setFixedAmount(boolean fixedAmount) {
		this.fixedAmount = fixedAmount;
	}

	public void setSchedules(List<DrawSchedule> schedules) {
		this.schedules = schedules;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static enum TemplateType {
		Recoverable, NonRecoverable;
	}
}
