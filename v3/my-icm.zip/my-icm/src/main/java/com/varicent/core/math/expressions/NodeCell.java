package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeCell extends UnaryNode implements EvaluateNode {
	public NodeCell(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		return this.arg.evaluate();
	}

	@Override
	public void reset() {
		this.arg.reset();
	}

	@Override
	public String getJSMathFunctionName() {
		return "cell";
	}
}
