package com.varicent.draws.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.draws.domain.DrawAssignmentFixedTerm;
import com.varicent.draws.domain.DrawAssignmentOngoing;
import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;
import com.varicent.draws.domain.DrawAssignmentWebSettings;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawTemplate;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.PeriodAmount;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.workflow.domain.WorkflowObject;

public interface DrawAssignmentDao {
	String DRAW_RESULT_PREFIX = "_DrawTemplateResult";

	List<Payee> getFilterPayees(int var1);

	List<Payee> getFilterPayees(QueryDefinition var1);

	List<WorkflowGroupName> getWorkflowGroups(int var1);

	List<DrawAssignmentUnassignedPayee> getUnAssignedPayeesAllGroups(int var1, int var2, String var3, int var4,
			int var5, String var6, boolean var7);

	List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(int var1, int var2, String var3, int var4, int var5,
			String var6, boolean var7);

	List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(QueryDefinition var1, int var2, String var3, int var4,
			int var5, String var6, boolean var7);

	int getUnAssignedPayeesAllGroupsCount(int var1, int var2, String var3);

	int getUnAssignedPayeesCount(int var1, int var2, String var3);

	int getUnAssignedPayeesCount(QueryDefinition var1, int var2, String var3);

	List<DrawAssignmentUnassignedPayee> getUnAssignedListForPayee(String var1, int var2, String var3);

	void assignToOngoing(String var1, int var2, BigDecimal var3, Date var4);

	void updateOngoing(DrawAssignmentOngoing var1, Date var2, BigDecimal var3) throws DatabaseConcurrencyException;

	void clearOngoing(DrawAssignmentOngoing var1) throws DatabaseConcurrencyException;

	Date getOngoingAssignmentEndDate(int var1);

	void setOngoingEndDate(DrawAssignmentOngoing var1, Date var2) throws DatabaseConcurrencyException;

	List<DrawAssignmentOngoing> getOngoingPayeesAllGroups(int var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	List<DrawAssignmentOngoing> getOngoingPayees(int var1, int var2, boolean var3, int var4, int var5, String var6,
			boolean var7);

	List<DrawAssignmentOngoing> getOngoingPayees(QueryDefinition var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	List<DrawAssignmentOngoing> getOngoingAssignmentsForPayee(String var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	int getOngoingPayeesAllGroupsCount(int var1, int var2, boolean var3);

	int getOngoingPayeesCount(int var1, int var2, boolean var3);

	int getOngoingPayeesCount(QueryDefinition var1, int var2, boolean var3);

	int assignToFixedterm(String var1, int var2, Date var3, Date var4);

	void addFixedTermPeriods(int var1, Date var2, BigDecimal var3);

	void deleteFixedTermPeriodAmount(int var1, Date var2, long var3) throws DatabaseConcurrencyException;

	void clearFixedTerm(int var1, long var2) throws DatabaseConcurrencyException;

	void setFixedTermEndDate(DrawAssignmentFixedTerm var1, Date var2) throws DatabaseConcurrencyException;

	void terminateFixedTerm(DrawAssignmentFixedTerm var1, Date var2) throws DatabaseConcurrencyException;

	void updateFixedTermPeriodAmount(int var1, PeriodAmount var2, BigDecimal var3) throws DatabaseConcurrencyException;

	void updateFixedTermStartDate(DrawAssignmentFixedTerm var1, Date var2) throws DatabaseConcurrencyException;

	List<DrawAssignmentFixedTerm> getFixedTermPayeesAllGroups(int var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	List<DrawAssignmentFixedTerm> getFixedTermPayees(int var1, int var2, boolean var3, int var4, int var5, String var6,
			boolean var7);

	List<DrawAssignmentFixedTerm> getFixedTermPayees(QueryDefinition var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	int getFixedTermPayeesAllGroupsCount(int var1, int var2, boolean var3);

	int getFixedTermPayeesCount(int var1, int var2, boolean var3);

	int getFixedTermPayeesCount(QueryDefinition var1, int var2, boolean var3);

	List<DrawAssignmentFixedTerm> getFixedTermListForPayee(String var1, int var2, boolean var3, int var4, int var5,
			String var6, boolean var7);

	boolean exists(int var1);

	String getEffectiveDateColumn(int var1);

	Date getCalendarStartDate(int var1);

	Date getCalendarEndDate(int var1);

	String getPeriodName(Date var1, String var2, String var3);

	Date[] getPeriodStartStartingAt(Date var1, int var2, String var3, String var4);

	Date getPeriodEndDate(String var1, String var2, Date var3);

	String getDrawTimeId(int var1);

	String getDrawName(int var1);

	DrawTemplate getDrawTemplate(int var1) throws DatabaseConcurrencyException;

	List<DrawTemplateName> getDrawTemplates(int var1);

	DrawAssignmentWebSettings getSettings(int var1);

	int getNumberOfAvailablePeriods(String var1, String var2, Date var3);

	boolean isViewableDrawAssignment(int var1);

	List<DrawName> getViewableDraws();

	boolean isViewablePayee(int var1, String var2);

	boolean isViewablePayee(QueryDefinition var1, String var2);

	boolean hasOpenOngoing(int var1, String var2);

	boolean OverlappingAssignmentExistsForPayee(int var1, String var2, Date var3, Date var4, Integer var5,
			boolean var6);

	void UpdateFixedTermAmountRowVersion(int var1, PeriodAmount var2, Date var3);

	int getWorkflowObjectId(String var1, WorkflowObject.Type var2);
}
