package com.varicent.core.exceptions;

import java.util.Map;

import com.varicent.reporting.domain.Scope;

public class ReportOverLimitException extends Exception {
	private static final long serialVersionUID = 1L;
	private Scope scope;

	public ReportOverLimitException(Scope scope) {
		this();
		this.scope = scope;
	}

	public ReportOverLimitException() {
	}

	public ReportOverLimitException(String message) {
		super(message);
	}

	public ReportOverLimitException(String message, Throwable cause) {
		super(message, cause);
	}

	public ReportOverLimitException(Throwable cause) {
		super(cause);
	}

	public int getReportID() {
		return this.scope.getReportID();
	}

	public boolean hasSourceRowCounts() {
		return this.getSourceRowCounts() != null || !this.getSourceRowCounts().isEmpty();
	}

	public Map<String, Integer> getSourceRowCounts() {
		return this.scope.getSourceRowCounts();
	}
}
