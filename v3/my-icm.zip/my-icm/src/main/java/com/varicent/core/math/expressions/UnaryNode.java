package com.varicent.core.math.expressions;

import java.util.List;

import org.springframework.util.Assert;

public abstract class UnaryNode extends JavascriptNode {
	protected EvaluateNode arg;

	protected UnaryNode(List<EvaluateNode> arguments, int suffix) {
		super(suffix);
		Assert.isTrue(arguments.size() == 1);
		this.arg = arguments.get(0);
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}
}
