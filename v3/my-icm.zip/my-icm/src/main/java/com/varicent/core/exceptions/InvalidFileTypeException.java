package com.varicent.core.exceptions;

public class InvalidFileTypeException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidFileTypeException() {
	}

	public InvalidFileTypeException(String message) {
		super(message);
	}

	public InvalidFileTypeException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidFileTypeException(Throwable cause) {
		super(cause);
	}
}
