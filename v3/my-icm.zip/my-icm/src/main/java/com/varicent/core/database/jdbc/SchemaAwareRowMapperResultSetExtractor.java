package com.varicent.core.database.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;

public class SchemaAwareRowMapperResultSetExtractor<T> extends RowMapperResultSetExtractor<T> {
	public SchemaAwareRowMapperResultSetExtractor(RowMapper<T> rowMapper) {
		super(rowMapper);
	}

	public SchemaAwareRowMapperResultSetExtractor(RowMapper<T> rowMapper, int rowsExpected) {
		super(rowMapper, rowsExpected);
	}

	@Override
	public List<T> extractData(ResultSet rs) throws SQLException {
		return super.extractData(new SchemaAwareResultSet(rs));
	}
}
