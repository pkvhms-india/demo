package com.varicent.core.tag;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.core.util.JavascriptUtils;

public class DatepickerLocalizer extends SimpleTagSupport {
	private Messages tMessages;
	private Locale tLocale;
	private static final String DatePickerMessagePrefix = "datepicker";
	private static final String[] SingularProperties = new String[] { "closeText", "prevText", "nextText",
			"currentText", "weekHeader" };
	private static final String[] MonthNames = new String[] { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug",
			"sep", "oct", "nov", "dec" };
	private static final String[] WeekDays = new String[] { "sun", "mon", "tue", "wed", "thu", "fri", "sat" };
	private static final localeDateFormat Locale_de = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_es = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_fr = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_it = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_ja = new localeDateFormat(0, false, true, "年");
	private static final localeDateFormat Locale_ko = new localeDateFormat(0, false, true, "년");
	private static final localeDateFormat Locale_nl = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_pt_BR = new localeDateFormat(0, false, false, "");
	private static final localeDateFormat Locale_sv = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_tr = new localeDateFormat(1, false, false, "");
	private static final localeDateFormat Locale_zh_CN = new localeDateFormat(1, false, true, "年");
	private static final localeDateFormat Locale_zh_TW = new localeDateFormat(1, false, true, "年");

	@Override
	public void doTag() throws JspException, IOException {
		PageContext lPageContext = (PageContext) this.getJspContext();
		this.tLocale = LocaleContextHolder.getLocale();
		WebApplicationContext springContext = WebApplicationContextUtils
				.getWebApplicationContext(lPageContext.getServletContext());
		this.tMessages = (Messages) springContext.getBean("messages");
		StringBuilder sb = new StringBuilder("<script type=\"text/javascript\"> jQuery.datepicker.setDefaults({");

		for (String prop : SingularProperties) {
			this.addSingularProperty(sb, prop);
		}

		this.addPluralProperty(sb, "monthNames", MonthNames);
		this.addPluralProperty(sb, "monthNamesShort", MonthNames);
		this.addPluralProperty(sb, "dayNames", WeekDays);
		this.addPluralProperty(sb, "dayNamesShort", WeekDays);
		this.addPluralProperty(sb, "dayNamesMin", WeekDays);
		this.addDateFormatProperties(sb);
		sb.append("}); </script>");
		sb.append("<style type=\"text/css\"> .ui-datepicker-calendar td { min-width: 28px; }");
		sb.append("div.ui-datepicker { width: inherit; } </style>");
		JspWriter out = this.getJspContext().getOut();
		out.print(sb.toString());
	}

	private void addDateFormatProperties(StringBuilder sb) {
		localeDateFormat locale = null;
		if (this.tLocale.getLanguage() == Locale.GERMAN.getLanguage()) {
			locale = Locale_de;
		} else if (this.tLocale.getLanguage() == "es") {
			locale = Locale_es;
		} else if (this.tLocale.getLanguage() == Locale.FRENCH.getLanguage()) {
			locale = Locale_fr;
		} else if (this.tLocale.getLanguage() == Locale.ITALIAN.getLanguage()) {
			locale = Locale_it;
		} else if (this.tLocale.getLanguage() == Locale.JAPANESE.getLanguage()) {
			locale = Locale_ja;
		} else if (this.tLocale.getLanguage() == Locale.KOREAN.getLanguage()) {
			locale = Locale_ko;
		} else if (this.tLocale.getLanguage() == "nl") {
			locale = Locale_nl;
		} else if (this.tLocale.getLanguage() == "pt" && this.tLocale.getCountry() == "BR") {
			locale = Locale_pt_BR;
		} else if (this.tLocale.getLanguage() == "sv") {
			locale = Locale_sv;
		} else if (this.tLocale.getLanguage() == "tr") {
			locale = Locale_tr;
		} else if (this.tLocale.getLanguage() == Locale.CHINA.getLanguage()
				&& this.tLocale.getCountry() == Locale.CHINA.getCountry()) {
			locale = Locale_zh_CN;
		} else if (this.tLocale.getLanguage() == Locale.TAIWAN.getLanguage()
				&& this.tLocale.getCountry() == Locale.TAIWAN.getCountry()) {
			locale = Locale_zh_TW;
		}

		if (locale != null) {
			locale.addDateFormatProperties(sb);
		}

		sb.append("dateFormat:'" + Format.getShortDateFormatString().toLowerCase().replace("yyyy", "yy") + "'");
	}

	private void addSingularProperty(StringBuilder sb, String propertyName) {
		Messages.Key key = this.tMessages.hasKey("datepicker." + propertyName);

		try {
			sb.append(propertyName + ":'"
					+ JavascriptUtils.escapeJavascriptString(this.tMessages.getMessage(key, this.tLocale)) + "',");
		} catch (Exception var5) {
		}

	}

	private void addPluralProperty(StringBuilder sb, String propertyName, String[] itemNames) {
		StringBuilder localSb = new StringBuilder(propertyName + ":[");
		boolean localized = true;
		boolean firstItem = true;

		for (String item : itemNames) {
			Messages.Key key = this.tMessages.hasKey("datepicker." + propertyName + "." + item);

			try {
				String message = JavascriptUtils.escapeJavascriptString(this.tMessages.getMessage(key, this.tLocale));
				if (firstItem) {
					firstItem = false;
				} else {
					localSb.append(",");
				}

				localSb.append("'" + message + "'");
			} catch (Exception var13) {
				localized = false;
				break;
			}
		}

		if (localized) {
			localSb.append("],");
			sb.append(localSb);
		}

	}
}
