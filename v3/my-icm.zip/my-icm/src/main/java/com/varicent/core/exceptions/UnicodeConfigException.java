package com.varicent.core.exceptions;

public class UnicodeConfigException extends Exception {
	private static final long serialVersionUID = 1L;

	public UnicodeConfigException() {
	}

	public UnicodeConfigException(String message) {
		super(message);
	}

	public UnicodeConfigException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnicodeConfigException(Throwable cause) {
		super(cause);
	}
}
