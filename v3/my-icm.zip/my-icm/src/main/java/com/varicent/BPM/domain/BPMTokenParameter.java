package com.varicent.BPM.domain;

public class BPMTokenParameter {
	private int tokenID;
	private String paramName;
	private String value;
	private String paramType;

	public BPMTokenParameter(int tokenID, String paramName, String paramType, String value) {
		this.tokenID = tokenID;
		this.paramName = paramName;
		this.value = value;
		this.paramType = paramType;
	}

	public int getTokenID() {
		return this.tokenID;
	}

	public String getName() {
		return this.paramName;
	}

	public String getValue() {
		return this.value;
	}

	public String getParamType() {
		return this.paramType;
	}
}
