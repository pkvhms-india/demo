package com.varicent.reporting.dao.jdbc.ActionParser;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.varicent.core.math.expressions.AggregateNode;
import com.varicent.core.math.expressions.AssignableNode;
import com.varicent.core.math.expressions.AssignableNumber;
import com.varicent.core.math.expressions.AssignableString;
import com.varicent.core.math.expressions.EvaluateNode;
import com.varicent.core.math.expressions.ExpressionEvaluator;
import com.varicent.core.math.expressions.JavascriptNode;
import com.varicent.core.math.expressions.JavascriptUtil;
import com.varicent.core.math.expressions.NodeAbs;
import com.varicent.core.math.expressions.NodeAdd;
import com.varicent.core.math.expressions.NodeAnd;
import com.varicent.core.math.expressions.NodeCell;
import com.varicent.core.math.expressions.NodeComparison;
import com.varicent.core.math.expressions.NodeDate;
import com.varicent.core.math.expressions.NodeDivide;
import com.varicent.core.math.expressions.NodeGroupAvg;
import com.varicent.core.math.expressions.NodeGroupCount;
import com.varicent.core.math.expressions.NodeGroupMax;
import com.varicent.core.math.expressions.NodeGroupMin;
import com.varicent.core.math.expressions.NodeGroupMult;
import com.varicent.core.math.expressions.NodeGroupSum;
import com.varicent.core.math.expressions.NodeIf;
import com.varicent.core.math.expressions.NodeIsEmpty;
import com.varicent.core.math.expressions.NodeMax;
import com.varicent.core.math.expressions.NodeMin;
import com.varicent.core.math.expressions.NodeMult;
import com.varicent.core.math.expressions.NodeNot;
import com.varicent.core.math.expressions.NodeNumber;
import com.varicent.core.math.expressions.NodeOr;
import com.varicent.core.math.expressions.NodePower;
import com.varicent.core.math.expressions.NodePrevious;
import com.varicent.core.math.expressions.NodeRound;
import com.varicent.core.math.expressions.NodeRoundDown;
import com.varicent.core.math.expressions.NodeString;
import com.varicent.core.math.expressions.NodeSubtract;
import com.varicent.core.math.expressions.NodeUnaryMinus;
import com.varicent.core.math.expressions.Predicate;

public class ExpressionParser {
	int startSuffix;
	int suffix;
	private NodeNumber previousNode;
	private AssignableNode[] variables = null;
	private List<AggregateNode> aggregateNodes = new ArrayList();
	EvaluateNode root;

	public ExpressionEvaluator getExpression(XMLStreamReader streamReader) throws XMLStreamException {
		return this.getExpression(streamReader, (Map) null, 0);
	}

	public ExpressionEvaluator getExpression(XMLStreamReader streamReader, Map<String, String> variableNameAliasMap,
			int startSuffix) throws XMLStreamException {
		streamReader.nextTag();
		this.startSuffix = startSuffix + 1;
		this.suffix = startSuffix;
		this.previousNode = null;
		this.variables = this.getVariables(streamReader, variableNameAliasMap);
		streamReader.nextTag();
		streamReader.nextTag();
		String opNode = streamReader.getLocalName();
		EvaluateNode root;
		if (!opNode.equals("Variable") && !opNode.equals("Number")) {
			root = this.getEvaluateNode(streamReader);
			if (root instanceof AggregateNode) {
				this.aggregateNodes.add((AggregateNode) root);
			}
		} else {
			root = this.getNumberOrVariableNode(streamReader, opNode);
		}

		if (this.previousNode != null) {
			root = new NodePrevious(root, this.previousNode);
		}

		streamReader.nextTag();
		streamReader.nextTag();
		this.root = root;
		return new ExpressionEvaluator(root, this.variables, this.aggregateNodes);
	}

	private AssignableNode[] getVariables(XMLStreamReader streamReader, Map<String, String> variableNameAliasMap)
			throws XMLStreamException {
		List<AssignableNode> variables = new ArrayList();
		streamReader.nextTag();

		for (String pfx = "Source."; streamReader.getEventType() == 1; streamReader.nextTag()) {
			streamReader.nextTag();
			String name = this.getNodeValue(streamReader);
			String alias = name;
			String column = name;
			if (name.startsWith(pfx)) {
				column = name.replace(pfx, "");
			}

			if (variableNameAliasMap != null && variableNameAliasMap.containsKey(column)) {
				alias = variableNameAliasMap.get(column);
			}

			String type = this.getNodeValue(streamReader);
			if (!type.equals("System.Decimal") && !type.equals("System.DateTime")) {
				if (type.equals("System.String")) {
					variables.add(new AssignableString(name, alias, ++this.suffix));
				} else {
					assert false : String.format("Unknown variable type: %s", type);
				}
			} else {
				variables.add(new AssignableNumber(name, alias, ++this.suffix));
				if (type.equals("System.DateTime") && name.contains(".")) {
					variables.get(0).setValue((Object) null);
				}
			}
		}

		return (AssignableNode[]) variables.toArray(new AssignableNode[variables.size()]);
	}

	private EvaluateNode getNumberOrVariableNode(XMLStreamReader streamReader, String opNode)
			throws XMLStreamException {
		if (opNode.equals("Number")) {
			streamReader.nextTag();
			String value = this.getNodeValue(streamReader);
			streamReader.nextTag();
			return new NodeNumber(new BigDecimal(value), (String) null, ++this.suffix);
		} else {
			streamReader.nextTag();
			String variableName = this.getNodeValue(streamReader);
			streamReader.next();

			while (streamReader.getEventType() == 4) {
				streamReader.next();
			}

			streamReader.nextTag();
			streamReader.nextTag();
			return this.createVariableNode(variableName);
		}
	}

	private EvaluateNode getEvaluateNode(XMLStreamReader streamReader) throws XMLStreamException {
		EvaluateNode nodeToReturn = null;
		String nodeName = streamReader.getLocalName();
		Op op = ExpressionParser.Op.valueOf(nodeName);
		List<EvaluateNode> args = this.getArguments(streamReader);
		switch (op) {
		case Abs:
			nodeToReturn = new NodeAbs(args, ++this.suffix);
			break;
		case Add:
			nodeToReturn = new NodeAdd(args, ++this.suffix);
			break;
		case Divide:
			nodeToReturn = new NodeDivide(args, ++this.suffix);
			break;
		case Max:
			nodeToReturn = new NodeMax(args, ++this.suffix);
			break;
		case Min:
			nodeToReturn = new NodeMin(args, ++this.suffix);
			break;
		case Mult:
			nodeToReturn = new NodeMult(args, ++this.suffix);
			break;
		case Power:
			nodeToReturn = new NodePower(args, ++this.suffix);
			break;
		case Round:
			nodeToReturn = new NodeRound(args, ++this.suffix);
			break;
		case RoundDown:
			nodeToReturn = new NodeRoundDown(args, ++this.suffix);
			break;
		case Subtract:
			nodeToReturn = new NodeSubtract(args, ++this.suffix);
			break;
		case UnaryMinus:
			nodeToReturn = new NodeUnaryMinus(args, ++this.suffix);
			break;
		case Prev:
			if (this.previousNode == null) {
				this.previousNode = new NodeNumber(new BigDecimal(0), (String) null, ++this.suffix);
			}

			nodeToReturn = this.previousNode;
			break;
		case If:
			nodeToReturn = new NodeIf(args, ++this.suffix);
			break;
		case IsEmpty:
			nodeToReturn = new NodeIsEmpty(args, ++this.suffix);
			break;
		case And:
			nodeToReturn = new NodeAnd(args, ++this.suffix);
			break;
		case Or:
			nodeToReturn = new NodeOr(args, ++this.suffix);
			break;
		case Not:
			nodeToReturn = new NodeNot(args, ++this.suffix);
			break;
		case Equal:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x == null) {
						return y == null;
					} else if (y == null) {
						return false;
					} else {
						return x.compareTo(y) == 0;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Equal);
			break;
		case NotEqual:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x == null) {
						return y != null;
					} else if (y == null) {
						return true;
					} else {
						return x.compareTo(y) != 0;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.NotEqual);
			break;
		case Greater:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) > 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Greater);
			break;
		case GreaterEq:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) >= 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.GreaterEq);
			break;
		case Less:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) < 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.Less);
			break;
		case LessEq:
			nodeToReturn = new NodeComparison(args, new Predicate<BigDecimal>() {
				@Override
				public boolean test(BigDecimal x, BigDecimal y) {
					if (x != null && y != null) {
						return x.compareTo(y) <= 0;
					} else {
						return false;
					}
				}
			}, ++this.suffix, JavascriptNode.ComparisonType.LessEq);
			break;
		case Cell:
			nodeToReturn = new NodeCell(args, ++this.suffix);
			break;
		case GroupAvg:
			nodeToReturn = new NodeGroupAvg(args, ++this.suffix);
			break;
		case GroupCount:
			nodeToReturn = new NodeGroupCount(++this.suffix);
			break;
		case GroupMax:
			nodeToReturn = new NodeGroupMax(args, ++this.suffix);
			break;
		case GroupMin:
			nodeToReturn = new NodeGroupMin(args, ++this.suffix);
			break;
		case GroupMult:
			nodeToReturn = new NodeGroupMult(args, ++this.suffix);
			break;
		case GroupSum:
			nodeToReturn = new NodeGroupSum(args, ++this.suffix);
		}

		return nodeToReturn;
	}

	private List<EvaluateNode> getArguments(XMLStreamReader streamReader) throws XMLStreamException {
		List<EvaluateNode> arguments = new ArrayList();
		String nodeName = streamReader.getLocalName();
		streamReader.nextTag();

		while (streamReader.getEventType() != 2 || !streamReader.getLocalName().equals(nodeName)) {
			String argumentName = streamReader.getLocalName();
			if (argumentName.equals("Number")) {
				streamReader.nextTag();
				String value = this.getNodeValue(streamReader);
				streamReader.nextTag();
				arguments.add(new NodeNumber(new BigDecimal(value), (String) null, ++this.suffix));
			} else if (argumentName.equals("date")) {
				streamReader.nextTag();
				String value = this.getNodeValue(streamReader);
				streamReader.nextTag();
				DateFormat ISODate = new SimpleDateFormat("yyyy-MM-dd");

				try {
					arguments.add(new NodeDate(ISODate.parse(value), ++this.suffix));
				} catch (ParseException var8) {
				}
			} else if (argumentName.equals("StringText")) {
				streamReader.nextTag();
				String value = this.getNodeValue(streamReader);
				streamReader.nextTag();
				arguments.add(new NodeString(value, (String) null, ++this.suffix));
			} else if (!argumentName.equals("Variable")) {
				if (this.isFunction(argumentName)) {
					EvaluateNode node = this.getEvaluateNode(streamReader);
					arguments.add(node);
					if (node instanceof AggregateNode) {
						this.aggregateNodes.add((AggregateNode) node);
					}
				} else {
					assert false : String.format("Error occurred while parsing: %s", argumentName);
				}
			} else {
				streamReader.nextTag();
				String variableName = this.getNodeValue(streamReader);
				streamReader.next();

				while (streamReader.getEventType() == 4) {
					streamReader.next();
				}

				streamReader.nextTag();
				streamReader.nextTag();
				arguments.add(this.createVariableNode(variableName));
			}
		}

		streamReader.nextTag();
		return arguments;
	}

	public boolean hasAggregate() {
		return this.aggregateNodes.size() > 0;
	}

	private boolean isFunction(String name) {
		for (Op op : ExpressionParser.Op.values()) {
			if (op.name().equals(name)) {
				return true;
			}
		}

		return false;
	}

	private EvaluateNode createVariableNode(String variableName) {
		AssignableNode variable = this.findVariable(variableName, this.variables);
		return variable.getNode();
	}

	private AssignableNode findVariable(String name, AssignableNode[] variables) {
		for (AssignableNode variable : variables) {
			if (name.equals(variable.getName())) {
				return variable;
			}
		}

		return null;
	}

	private String getNodeValue(XMLStreamReader stream) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		stream.next();

		while (stream.getEventType() == 4) {
			sb.append(stream.getText());
			stream.next();
		}

		stream.nextTag();
		return sb.toString();
	}

	public String getJavascriptVariableDeclaration(JavascriptUtil jsUtil) {
		ArrayList<Integer> groupAvgSuffix = new ArrayList();

		for (AggregateNode node : this.aggregateNodes) {
			if (node instanceof NodeGroupAvg) {
				groupAvgSuffix.add(((NodeGroupAvg) node).getSuffix());
			}
		}

		return jsUtil.getVariableDeclarations(this.startSuffix, this.suffix, groupAvgSuffix);
	}

	public String getJavascriptFunctions(JavascriptUtil jsUtil, boolean canUseSameRowValue) {
		ArrayList<Integer> groupAvgSuffix = new ArrayList();

		for (AggregateNode node : this.aggregateNodes) {
			if (node instanceof NodeGroupAvg) {
				groupAvgSuffix.add(((NodeGroupAvg) node).getSuffix());
			}
		}

		StringBuilder sb = new StringBuilder();
		sb.append(((JavascriptNode) this.root).toJavascript(jsUtil));

		for (AssignableNode variable : this.variables) {
			if (variable.getNode() instanceof JavascriptNode) {
				JavascriptNode variableNode = (JavascriptNode) variable.getNode();
				if (!variableNode.isJSFunctionCreated()) {
					sb.append(variableNode.toJavascript(jsUtil));
				}
			}
		}

		sb.append(jsUtil.getAggregateJSFunction(this.startSuffix, this.suffix));
		if (canUseSameRowValue) {
			sb.append(jsUtil.getEvaluationJSFunction(this.aggregateNodes, this.startSuffix, this.suffix));
		}

		sb.append(jsUtil.getResetFunction(this.startSuffix, this.suffix, groupAvgSuffix));
		return sb.toString();
	}

	public int getSuffix() {
		return this.suffix;
	}

	public int getStartSuffix() {
		return this.startSuffix;
	}

	private static enum Op {
		Abs, Add, Divide, Max, Min, Mult, Power, Prev, Round, RoundDown, Subtract, UnaryMinus, If, IsEmpty, And, Or,
		Not, Equal, NotEqual, Greater, GreaterEq, Less, LessEq, Cell, GroupAvg, GroupCount, GroupMax, GroupMin,
		GroupMult, GroupSum;
	}
}
