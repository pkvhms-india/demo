package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class DYComboSet implements Comparable<DYComboSet> {
	private BigDecimal value;
	public DYComboCategory category;

	public DYComboSet(BigDecimal value, DYComboCategory category) {
		this.value = value;
		this.category = category;
	}

	public void writeXMLElement(XMLStreamWriter writer, int currentset, DataTable data, Scope scope, String seriesName,
			ColumnLink link, boolean isPercentage) throws XMLStreamException, ReportOverLimitException {
		if (isPercentage) {
			this.value = this.value.multiply(new BigDecimal(100));
		}

		if (link != null) {
			writer.writeCharacters("<set ");
			writer.writeCharacters("value ='" + this.value.toPlainString() + "' ");

			try {
				String linkurl = link.getLinkAttribute(currentset, data, scope, false);
				writer.writeCharacters("link='" + linkurl + "' /> ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		} else {
			this.writeXMLElement(writer);
		}

	}

	public void writeXMLElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<set value='" + this.value.toPlainString() + "' />");
	}

	public static void writeEmptyXMLElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<set value='0' />");
	}

	@Override
	public int compareTo(DYComboSet other) {
		if (this.category.order < other.category.order) {
			return -1;
		} else {
			return this.category.order > other.category.order ? 1 : 0;
		}
	}
}
