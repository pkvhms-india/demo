package com.varicent.draws.domain;

import java.io.Serializable;

public class WorkflowGroupName implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;

	public WorkflowGroupName(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}
}
