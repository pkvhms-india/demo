package com.varicent.core.util;

public class Entry<Key, Value> {
	public final Key Key;
	public final Value Value;

	public Entry(Key key, Value value) {
		this.Key = key;
		this.Value = value;
	}
}
