package com.varicent.core.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.LinkParam;

public abstract class LinkUrlExpander {
	private List<LinkParam> linkParams;
	private static final String[] validUrlPrefixes = new String[] { "http://", "https://", "ftp://", "mailto:" };

	public LinkUrlExpander(List<LinkParam> params) {
		this.linkParams = params;
	}

	protected abstract String getParamExpandedValue(LinkParam var1) throws ReportOverLimitException;

	protected abstract boolean isParamExpandable(LinkParam var1);

	protected abstract String getParamVariable(LinkParam var1);

	public String getExpandedUrl(String url) throws ReportOverLimitException {
		StringBuilder sb = new StringBuilder();
		int rightBracketIndex = -1;
		Map<String, String> paramMap = new HashMap();

		for (LinkParam param : this.linkParams) {
			if (this.isParamExpandable(param)) {
				paramMap.put(this.getParamVariable(param), this.getParamExpandedValue(param));
			}
		}

		while (true) {
			int leftBracketIndex = url.indexOf(91, rightBracketIndex);
			if (leftBracketIndex < 0) {
				sb.append(url.substring(rightBracketIndex + 1));
				url = sb.toString();
				break;
			}

			sb.append(url.substring(rightBracketIndex + 1, leftBracketIndex));
			rightBracketIndex = url.indexOf(93, leftBracketIndex);
			if (rightBracketIndex <= 0) {
				sb.append(url.substring(leftBracketIndex + 1));
				url = sb.toString();
				break;
			}

			String paramVariable = url.substring(leftBracketIndex + 1, rightBracketIndex);
			if (paramMap.containsKey(paramVariable)) {
				sb.append(paramMap.get(paramVariable));
			} else {
				sb.append(url.substring(leftBracketIndex, rightBracketIndex + 1));
			}
		}

		return this.isValidUrl(url) ? url : this.getInvalidUrlJavascript(url);
	}

	String getInvalidUrlJavascript(String url) {
		return "javascript:showInvalidUrlWarning('" + JavascriptUtils.escapeJavascriptString(url) + "');";
	}

	boolean isValidUrl(String url) {
		url = url.toLowerCase();

		for (String prefix : validUrlPrefixes) {
			if (url.startsWith(prefix)) {
				return true;
			}
		}

		return false;
	}
}
