package com.varicent.core.text;

import java.util.HashSet;

public class UniqueSuffixNamer {
	HashSet<String> columnNames = new HashSet();

	public String newUniqueName(String name) {
		int suffix = 1;
		if (!this.columnNames.contains(name)) {
			this.columnNames.add(name);
		} else {
			while (this.columnNames.contains(name)) {
				name = name + suffix;
				++suffix;
			}

			this.columnNames.add(name);
		}

		return name;
	}
}
