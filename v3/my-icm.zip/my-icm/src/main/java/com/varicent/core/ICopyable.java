package com.varicent.core;

public interface ICopyable<E> {
	E Copy();
}
