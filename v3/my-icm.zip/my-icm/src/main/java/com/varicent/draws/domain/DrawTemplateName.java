package com.varicent.draws.domain;

import java.io.Serializable;

public class DrawTemplateName implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private DrawTemplate.TemplateType type;

	public DrawTemplateName(int id, String name, DrawTemplate.TemplateType type) {
		this.id = id;
		this.name = name;
		this.type = type;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public DrawTemplate.TemplateType getType() {
		return this.type;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(DrawTemplate.TemplateType type) {
		this.type = type;
	}
}
