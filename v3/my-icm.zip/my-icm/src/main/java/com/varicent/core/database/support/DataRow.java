package com.varicent.core.database.support;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;

public class DataRow {
	protected final List<String> values = new ArrayList();
	protected final List<Object> objects = new ArrayList();

	public DataRow() {
	}

	public DataRow(Object[] vals) {
		for (Object val : vals) {
			this.add(val);
		}

	}

	public void add(Object o) {
		this.add(o, (NumericFormat) null);
	}

	public void addCurrencyNumber(Object o, NumberFormat format) {
		this.objects.add(o);
		this.values.add(format.format(o));
	}

	public void add(Object o, NumericFormat format) {
		this.objects.add(o);
		this.values.add(this.format(o, format));
	}

	public void insert(int index, Object o) {
		this.insert(index, o, (NumericFormat) null);
	}

	public void insert(int index, Object o, NumericFormat format) {
		this.objects.add(index, o);
		this.values.add(index, this.format(o, format));
	}

	public Object getObject(int index) {
		return this.objects.get(index);
	}

	public List<Object> getObjects() {
		return Collections.unmodifiableList(this.objects);
	}

	public String getValue(int index) {
		return this.values.get(index);
	}

	public List<String> getValues() {
		return Collections.unmodifiableList(this.values);
	}

	public void pad(int numColumns) {
		for (int i = 0; i < numColumns; ++i) {
			this.add("");
		}

	}

	public int getSize() {
		return this.values.size();
	}

	protected String format(Object o, NumericFormat format) {
		return format == null ? Format.asValueString(o) : Format.asValueString(o, format);
	}
}
