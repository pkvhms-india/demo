package com.varicent.core.util;

import java.nio.ByteBuffer;
import java.util.UUID;

import org.springframework.security.crypto.codec.Base64;

public class Base64Token {
	public static String encode(UUID uuid) {
		ByteBuffer bb = ByteBuffer.wrap(new byte[16]);
		bb.putLong(uuid.getMostSignificantBits());
		bb.putLong(uuid.getLeastSignificantBits());
		byte[] bytes = bb.array();
		return encode(bytes);
	}

	public static String encode(String str) {
		byte[] bytes = str.getBytes();
		return encode(bytes);
	}

	public static String encode(byte[] bytes) {
		return new String(Base64.encode(bytes));
	}
}
