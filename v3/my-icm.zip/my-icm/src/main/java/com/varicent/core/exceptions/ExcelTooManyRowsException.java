package com.varicent.core.exceptions;

public class ExcelTooManyRowsException extends Exception {
	private static final long serialVersionUID = 1L;

	public ExcelTooManyRowsException() {
	}

	public ExcelTooManyRowsException(String message) {
		super(message);
	}

	public ExcelTooManyRowsException(String message, Throwable cause) {
		super(message, cause);
	}

	public ExcelTooManyRowsException(Throwable cause) {
		super(cause);
	}
}
