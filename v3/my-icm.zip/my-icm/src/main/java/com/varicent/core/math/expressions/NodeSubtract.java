package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeSubtract extends BinaryNode implements EvaluateNode {
	public NodeSubtract(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal left = this.lhs.evaluate();
		BigDecimal right = this.rhs.evaluate();
		return left != null && right != null ? left.subtract(right) : null;
	}

	@Override
	public String getJSMathFunctionName() {
		return "subtract";
	}
}
