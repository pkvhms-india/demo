package com.varicent.BPM.domain;

public class BPMExternalEmail {
	private String email;
	private boolean isCC;

	public BPMExternalEmail(String email, boolean isCC) {
		this.email = email;
		this.isCC = isCC;
	}

	public String getEmail() {
		return this.email;
	}

	public boolean isCC() {
		return this.isCC;
	}
}
