package com.varicent.core.database.portability;

import java.math.BigDecimal;

import com.varicent.common.query.domain.Literal;

public abstract class SqlSyntax {
	public String cast(BigDecimal bd) {
		if (bd == null) {
			return String.format("CAST(NULL AS DECIMAL(28,14))");
		} else {
			if (bd.scale() == 0) {
				bd = bd.setScale(1);
			}

			return bd.compareTo(BigDecimal.ZERO) == 0 ? String.format("CAST(%s AS DECIMAL(28,14))", bd.toString())
					: bd.toString();
		}
	}

	public abstract String getDefaultNameSpace();

	public abstract String cast(String var1);

	public abstract String getDate();

	public abstract String getDateTime();

	public abstract String getDateUtc();

	public abstract String getDateTimeUtc();

	public abstract String getEmptyString();

	public abstract String getSystemPrefix();

	public abstract String getTempTablePrefix();

	public abstract String getUnicodeSQL();

	public abstract boolean isEmptyString(String var1);

	public boolean isSqlServer() {
		DatabaseType database = this.getDatabaseType();
		return database.equals(SqlSyntax.DatabaseType.SQL_SERVER)
				|| database.equals(SqlSyntax.DatabaseType.SQL_SERVER_UNICODE);
	}

	public boolean isUnicode() {
		return this.getDatabaseType().equals(SqlSyntax.DatabaseType.SQL_SERVER_UNICODE);
	}

	public abstract String quote(String var1);

	public abstract String toDatabaseType(Literal.Type var1);

	public abstract String toDate(Object var1);

	public abstract String toDateTime(Object var1);

	public abstract String toBlob(byte[] var1);

	public abstract String toValidIdentifier(String var1);

	protected abstract DatabaseType getDatabaseType();

	protected static enum DatabaseType {
		SQL_SERVER, SQL_SERVER_UNICODE;
	}
}
