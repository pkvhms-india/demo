package com.varicent.core.tag;

class localeDateFormat {
	public int firstDay;
	public Boolean isRTL;
	public Boolean showMonthAfterYear;
	public String yearSuffix;

	public localeDateFormat(int firstDay, Boolean isRTL, Boolean showMonthAfterYear, String yearSuffix) {
		this.firstDay = firstDay;
		this.isRTL = isRTL;
		this.showMonthAfterYear = showMonthAfterYear;
		this.yearSuffix = yearSuffix;
	}

	public void addDateFormatProperties(StringBuilder sb) {
		sb.append("firstDay: " + this.firstDay + ",");
		sb.append("isRTL: " + this.isRTL.toString().toLowerCase() + ",");
		sb.append("showMonthAfterYear: " + this.showMonthAfterYear.toString().toLowerCase() + ",");
		sb.append("yearSuffix: '" + this.yearSuffix + "',");
	}
}
