package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.Format;
import com.varicent.core.util.LinkUrlExpander;
import com.varicent.core.util.Validation;
import com.varicent.reporting.domain.LinkParam;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class LinkExpander extends BaseExpander {
	public LinkExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("Link")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("Link")) {
			String document = this.streamReader.getAttributeValue((String) null, "Document");
			boolean openInNewWindow = Boolean
					.parseBoolean(this.streamReader.getAttributeValue((String) null, "OpenInNewWindow"));
			String target = openInNewWindow ? "_blank" : "_self";
			writer.writeStartElement("Link");
			this.streamReader.nextTag();
			String webTabID = null;
			if (this.streamReader.getLocalName().equals("WebTabID")) {
				webTabID = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			this.streamReader.nextTag();
			List<LinkParam> params = new ArrayList();
			boolean isFactorableLink = false;
			boolean isTargetReport = false;

			Integer targetObjectId;
			String name;
			String type;
			String value;
			for (targetObjectId = null; this.streamReader.getEventType() == 1; params
					.add(new LinkParam(name, type, value))) {
				name = this.streamReader.getAttributeValue((String) null, "Name");
				type = this.streamReader.getAttributeValue((String) null, "Type");
				String nodeValue = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
				if (name.equals("ReportID")) {
					isTargetReport = true;
				}

				if (name.equals("ReportID") || name.equals("FormID")) {
					isFactorableLink = true;
					targetObjectId = Integer.parseInt(nodeValue);
				}

				if (type.equals("Scalar")) {
					value = "";
					if (!scope.isNull(nodeValue)) {
						if (scope.getType(nodeValue) == Scope.Type.DATE
								&& !Validation.isNullDate(scope.getDateTime(nodeValue))) {
							value = Format.asShortDate(scope.getDateTime(nodeValue));
						} else if (scope.getType(nodeValue) == Scope.Type.DECIMAL) {
							value = Format.asValueString(scope.getDecimal(nodeValue));
							value = value.trim();
							value = value.replace(new String(new char[] { ' ' }), "");
						} else if (scope.getType(nodeValue) != Scope.Type.DATE) {
							value = scope.getObject(nodeValue).toString();
						}
					}
				} else {
					value = nodeValue;
				}

				if (isFactorableLink) {
					try {
						value = URLEncoder.encode(value, "UTF-8");
					} catch (UnsupportedEncodingException var19) {
					}
				}
			}

			this.streamReader.nextTag();
			if (isFactorableLink) {
				writer.writeAttribute("Document", document);
				writer.writeAttribute("Target", target);
				writer.writeStartElement("Params");

				for (LinkParam param : params) {
					writer.writeStartElement("Param");
					writer.writeAttribute("Name", "L_" + param.getName());
					writer.writeAttribute("Type", param.getType());
					writer.writeCharacters(param.getValue());
					writer.writeEndElement();
				}

				writer.writeEndElement();
				if (webTabID != null && targetObjectId != null) {
					boolean webTabApplies = false;
					if (isTargetReport) {
						webTabApplies = scope.isWebReportInTheTab(targetObjectId, Integer.parseInt(webTabID));
					} else {
						webTabApplies = scope.isWebFormInTheTab(targetObjectId, Integer.parseInt(webTabID));
					}

					if (webTabApplies) {
						writer.writeStartElement("WebTabID");
						writer.writeCharacters(webTabID);
						writer.writeEndElement();
					}
				}
			} else {
				LinkUrlExpander urlExpander = new LinkUrlExpander(params) {
					@Override
					protected boolean isParamExpandable(LinkParam param) {
						return param.getType().equals("Scalar");
					}

					@Override
					protected String getParamExpandedValue(LinkParam param) {
						return param.getValue();
					}

					@Override
					protected String getParamVariable(LinkParam param) {
						return param.getName();
					}
				};

				try {
					type = urlExpander.getExpandedUrl(document);
				} catch (ReportOverLimitException var18) {
					type = "";
				}

				writer.writeAttribute("Document", type);
				writer.writeAttribute("Target", target);
				writer.writeStartElement("Params");
				writer.writeEndElement();
			}

			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
