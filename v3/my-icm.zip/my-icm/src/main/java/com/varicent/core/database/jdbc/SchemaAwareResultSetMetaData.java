package com.varicent.core.database.jdbc;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.varicent.core.database.schema.Schema;

public class SchemaAwareResultSetMetaData implements ResultSetMetaData {
	private final ResultSetMetaData metadata;

	public SchemaAwareResultSetMetaData(ResultSetMetaData metadata) {
		this.metadata = metadata;
	}

	@Override
	public String getCatalogName(int column) throws SQLException {
		return this.metadata.getCatalogName(column);
	}

	@Override
	public String getColumnClassName(int column) throws SQLException {
		return this.metadata.getColumnClassName(column);
	}

	@Override
	public int getColumnCount() throws SQLException {
		return this.metadata.getColumnCount();
	}

	@Override
	public int getColumnDisplaySize(int column) throws SQLException {
		return this.metadata.getColumnDisplaySize(column);
	}

	@Override
	public String getColumnLabel(int column) throws SQLException {
		return this.metadata.getColumnLabel(column);
	}

	@Override
	public String getColumnName(int column) throws SQLException {
		return this.metadata.getColumnName(column);
	}

	@Override
	public int getColumnType(int column) throws SQLException {
		return Schema.isSqlServerDateColumn(this.metadata, column) ? 91 : this.metadata.getColumnType(column);
	}

	@Override
	public String getColumnTypeName(int column) throws SQLException {
		return this.metadata.getColumnTypeName(column);
	}

	@Override
	public int getPrecision(int column) throws SQLException {
		return this.metadata.getPrecision(column);
	}

	@Override
	public int getScale(int column) throws SQLException {
		return this.metadata.getScale(column);
	}

	@Override
	public String getSchemaName(int column) throws SQLException {
		return this.metadata.getSchemaName(column);
	}

	@Override
	public String getTableName(int column) throws SQLException {
		return this.metadata.getTableName(column);
	}

	@Override
	public boolean isAutoIncrement(int column) throws SQLException {
		return this.metadata.isAutoIncrement(column);
	}

	@Override
	public boolean isCaseSensitive(int column) throws SQLException {
		return this.metadata.isCaseSensitive(column);
	}

	@Override
	public boolean isCurrency(int column) throws SQLException {
		return this.metadata.isCurrency(column);
	}

	@Override
	public boolean isDefinitelyWritable(int column) throws SQLException {
		return this.metadata.isDefinitelyWritable(column);
	}

	@Override
	public int isNullable(int column) throws SQLException {
		return this.metadata.isNullable(column);
	}

	@Override
	public boolean isReadOnly(int column) throws SQLException {
		return this.metadata.isReadOnly(column);
	}

	@Override
	public boolean isSearchable(int column) throws SQLException {
		return this.metadata.isSearchable(column);
	}

	@Override
	public boolean isSigned(int column) throws SQLException {
		return this.metadata.isSigned(column);
	}

	@Override
	public boolean isWritable(int column) throws SQLException {
		return this.metadata.isWritable(column);
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return this.metadata.isWrapperFor(iface);
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		return (T) this.metadata.unwrap(iface);
	}
}
