package com.varicent.messages.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.varicent.common.admin.service.AdminManager;
import com.varicent.common.messages.service.NavigationManager;
import com.varicent.core.util.MessageNavigation;
import com.varicent.messages.domain.Message;

@Controller
public class MessageViewController {
	private static final String VIEW = "messages/view";
	private final AdminManager adminManager;
	private final NavigationManager navigationManager;

	@Autowired
	public MessageViewController(AdminManager adminManager, NavigationManager navigationManager) {
		this.adminManager = adminManager;
		this.navigationManager = navigationManager;
	}

	@RequestMapping(method = { RequestMethod.GET }, value = { "/messages/view.html" })
	public String prepareView(@RequestParam("id") int messageId, ModelMap model, HttpServletRequest request) {
		model.addAttribute("message", this.adminManager.getAdminNote(messageId));
		String listType = request.getParameter("type");
		String referrer = request.getHeader("referer");
		if (referrer != null && referrer.contains("/messages/messages")) {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_MESSAGE, MessageNavigation.ListType.ADMIN_MESSAGE));
		} else if (listType != null && listType.equals(MessageNavigation.ListType.ADMIN_MESSAGE.toString())) {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_MESSAGE, MessageNavigation.ListType.ADMIN_MESSAGE));
		} else {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_MESSAGE, MessageNavigation.ListType.ALL));
		}

		return "messages/view";
	}

	@RequestMapping({ "messages/viewPayeeNote" })
	public String prepareView2(@RequestParam("id") int messageId, ModelMap model, HttpServletRequest request) {
		model.addAttribute("message", this.adminManager.getAdminPayeeNote(messageId));
		String referrer = request.getHeader("referer");
		String listType = request.getParameter("type");
		if (referrer != null && referrer.contains("/messages/messages")) {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_PAYEE_MESSAGE, MessageNavigation.ListType.ADMIN_MESSAGE));
		} else if (listType != null && listType.equals(MessageNavigation.ListType.ADMIN_MESSAGE.toString())) {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_PAYEE_MESSAGE, MessageNavigation.ListType.ADMIN_MESSAGE));
		} else {
			model.addAttribute("navMsg", this.navigationManager.getNavigationMessages(messageId,
					Message.Category.ADMIN_PAYEE_MESSAGE, MessageNavigation.ListType.ALL));
		}

		return "messages/view";
	}
}
