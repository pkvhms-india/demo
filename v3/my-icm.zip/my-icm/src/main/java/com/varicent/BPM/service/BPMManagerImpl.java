package com.varicent.BPM.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.regex.Matcher;

import javax.xml.stream.XMLStreamException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.util.HtmlUtils;

import com.varicent.BPM.dao.BPMDao;
import com.varicent.BPM.domain.BPMAlertNode;
import com.varicent.BPM.domain.BPMConditionalPath;
import com.varicent.BPM.domain.BPMExternalEmail;
import com.varicent.BPM.domain.BPMNode;
import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMToken;
import com.varicent.BPM.domain.BPMTokenParameter;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflow;
import com.varicent.BPM.domain.BPMWorkflowParameter;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.common.admin.dao.AdminDao;
import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.core.Constants;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.exceptions.IllegalValueException;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.mail.Mailer;
import com.varicent.core.text.Format;
import com.varicent.core.text.Parse;
import com.varicent.reporting.dao.ReportingDao;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.WebReportTableEdit;
import com.varicent.reporting.web.ReportingCommand;
import com.varicent.security.domain.UserAccount;

@Service("bpmManager")
@Transactional(readOnly = true)
public class BPMManagerImpl implements BPMManager {
	private BPMDao bpmDao;
	private ReportingDao reportingDao;
	private PayeeDao payeeDao;
	private AdminDao adminDao;
	private TimeDao timeDao;
	private ConfigDao configDao;
	private Mailer mailer;
	private final Messages messages;
	private SchemaDao schemaDao;
	private final int BPM_PATH_REVIEW_RESULT_APPROVED = 1;

	@Autowired
	public BPMManagerImpl(BPMDao bpmDao, ReportingDao reportingDao, AdminDao adminDao, PayeeDao payeeDao,
			TimeDao timeDao, ConfigDao configDao, SchemaDao schemaDao, Mailer mailer, Messages messages) {
		this.bpmDao = bpmDao;
		this.reportingDao = reportingDao;
		this.adminDao = adminDao;
		this.payeeDao = payeeDao;
		this.timeDao = timeDao;
		this.configDao = configDao;
		this.schemaDao = schemaDao;
		this.mailer = mailer;
		this.messages = messages;
	}

	@Override
	public boolean canViewToken(int tokenID) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.canViewToken(tokenID, user.getPayeeId());
	}

	@Override
	@Transactional(readOnly = false)
	public void moveToken(int tokenID, long tokenVersion, int pathID, Map<String, Object> paramMap)
			throws DatabaseConcurrencyException {
		UserAccount user = UserAccount.getCurrent();
		BPMToken token = this.bpmDao.getToken(tokenID, user.getPayeeId());
		if (token != null && token.getRowVersion() == tokenVersion) {
			BPMPath path = this.bpmDao.getPath(pathID, token.getNodeID());
			if (path == null) {
				throw new DatabaseConcurrencyException(
						new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
			} else {
				Map<String, Object> param = this.getWorkflowParams(tokenID);

				for (String key : paramMap.keySet()) {
					param.put(key, paramMap.get(key));
				}

				for (BPMTokenParameter parameter : this.reportingDao.getTokenParameters(token.getTokenID())) {
					Scope.Type paramType = Scope.Type.valueOf(parameter.getParamType().toUpperCase());
					if (paramType.equals(Scope.Type.DATE)) {
						Date dateObject = Parse.date(parameter.getValue());
						param.put(parameter.getName(), dateObject);
					} else if (paramType.equals(Scope.Type.DECIMAL)) {
						BigDecimal decimal = Parse.parseDecimal(parameter.getValue(), true);
						param.put(parameter.getName(), decimal);
					} else if (paramType.equals(Scope.Type.STRING)) {
						param.put(parameter.getName(), parameter.getValue());
					} else {
						Assert.state(false);
					}
				}

				this.moveTokenOnPath(token, path, param);
			}
		} else {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	private void moveTokenWithoutUserCheck(int tokenID, long tokenVersion, int pathID, Map<String, Object> params)
			throws DatabaseConcurrencyException {
		BPMToken token = this.bpmDao.getToken(tokenID);
		if (token != null && token.getRowVersion() == tokenVersion) {
			BPMPath path = this.bpmDao.getPath(pathID, token.getNodeID());
			if (path == null) {
				throw new DatabaseConcurrencyException(
						new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
			} else {
				this.moveTokenOnPath(token, path, params);
			}
		} else {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void updateBPMPreviousParameters(HashMap<String, Object> parameters, int tokenId)
			throws DatabaseConcurrencyException {
		this.bpmDao.UpdateBPMPreviousParameters(parameters, tokenId);
	}

	private void moveTokenOnPath(BPMToken token, BPMPath path, Map<String, Object> param)
			throws DatabaseConcurrencyException {
		UserAccount user = UserAccount.getCurrent();
		int tokenID = token.getTokenID();
		int pathID = path.getPathID();
		boolean allSubmit = path.isAllSubmit();
		if (allSubmit) {
			this.bpmDao.deleteTokenAssignee(tokenID, user.getPayeeId());
		} else {
			this.bpmDao.deleteTokenAssignee(tokenID);
		}

		BPMNode targetNode = this.bpmDao.getNode(path.getDestinationNodeID());
		String[] members = this.bpmDao.getSwimLaneMembers(targetNode.getSwimLaneID(), tokenID);
		BPMToken updated = null;
		if (path.isAllMember()) {
			this.updateTokenValues(token, members, path, user, false, true);
			if (this.bpmDao.isActionNode(token.getNodeID())) {
				this.logNodeActioned(tokenID, user.getPayeeId(), path);
			} else if (this.bpmDao.isConditionalNode(token.getNodeID())) {
				this.logConditionalNodeAction(tokenID, user.getPayeeId(), path);
			}

			boolean allTokensWaiting = this.bpmDao.checkAllTokensAreWaiting(path.getOriginNodeID());
			if (allTokensWaiting) {
				this.bpmDao.batchUpdateToken(path.getOriginNodeID(), path.getDestinationNodeID(), pathID, false);
				BPMToken[] tokens = this.bpmDao.getTokens(path.getDestinationNodeID());
				this.runNode(tokens, path, param);
			}
		} else if (allSubmit) {
			if (this.bpmDao.isActionNode(token.getNodeID())) {
				this.logNodeActioned(tokenID, user.getPayeeId(), path);
			} else if (this.bpmDao.isConditionalNode(token.getNodeID())) {
				this.logConditionalNodeAction(tokenID, user.getPayeeId(), path);
			}

			boolean allAssigneesSubmitted = this.bpmDao.checkAllAssignessSubmitted(token.getTokenID());
			if (allAssigneesSubmitted) {
				updated = this.updateTokenValues(token, members, path, user, true, false);
				this.runNode(new BPMToken[] { updated }, path, param);
			}
		} else {
			updated = this.updateTokenValues(token, members, path, user, true, false);
			if (this.bpmDao.isActionNode(path.getOriginNodeID())) {
				this.logNodeActioned(tokenID, user.getPayeeId(), path);
			} else if (this.bpmDao.isConditionalNode(path.getOriginNodeID())) {
				this.logConditionalNodeAction(tokenID, user.getPayeeId(), path);
			}

			this.runNode(new BPMToken[] { updated }, path, param);
		}

	}

	private BPMToken updateTokenValues(BPMToken token, String[] members, BPMPath path, UserAccount user,
			boolean setDestNode, boolean isWaiting) throws DatabaseConcurrencyException {
		for (String member : members) {
			this.bpmDao.insertTokenAssignee(token.getTokenID(), member);
		}

		if (setDestNode) {
			token.setNodeID(path.getDestinationNodeID());
		}

		token.setLastActorID(user.getPayeeId());
		token.setPathID(path.getPathID());
		token.setIsWaiting(isWaiting);
		BPMToken updated = this.bpmDao.updateToken(token);
		return updated;
	}

	private void runNode(BPMToken[] tokens, BPMPath path, Map<String, Object> params)
			throws DatabaseConcurrencyException {
		if (tokens.length != 0) {
			int nodeID = path.getDestinationNodeID();
			if (this.bpmDao.isAlertNode(nodeID)) {
				for (BPMToken token : tokens) {
					assert token.getNodeID() == nodeID;

					this.runAlertNode(token, params);
				}
			} else if (this.bpmDao.isProcessNode(nodeID)) {
				for (BPMToken token : tokens) {
					this.runProcessNode(nodeID, token.getTokenID());
				}
			} else if (this.bpmDao.isEndNode(nodeID)) {
				boolean enablePendingWorkflow = this.configDao.getBooleanValue(ConfigDao.Key.ENABLE_PENDING_WORKFLOW);
				if (enablePendingWorkflow) {
					boolean isApproved = path.getReviewResult() == 1;
					this.flushBPMPendingTable(tokens, isApproved);

					for (BPMToken token : tokens) {
						this.logEndNodeAction(token.getTokenID(), nodeID);
					}
				} else {
					for (BPMToken token : tokens) {
						this.logEndNodeAction(token.getTokenID(), nodeID);
					}
				}
			} else if (this.bpmDao.isConditionalNode(nodeID)) {
				this.runConditionalNode(tokens, nodeID, params);
			}

		}
	}

	private void flushBPMPendingTable(BPMToken[] tokens, boolean isApproved) {
		HashMap<BPMToken, BPMWorkflow> tokenMap = new HashMap();

		for (BPMToken token : tokens) {
			BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(token.getTokenID());
			tokenMap.put(token, workflow);
		}

		for (String bpmTable : this.bpmDao.getBPMPendingTables()) {
			if (isApproved) {
				try {
					this.bpmDao.updateBPMPendingTableSource(bpmTable, tokenMap);
				} catch (IllegalValueException var11) {
					Assert.state(false);
				} catch (DataSubmitException var12) {
					Assert.state(false);
				}
			} else {
				for (BPMToken token : tokens) {
					this.bpmDao.deleteFromBPMPendingTable(bpmTable, token.getFormID());
				}
			}
		}

	}

	private void runConditionalNode(BPMToken[] tokens, int nodeID, Map<String, Object> param)
			throws DatabaseConcurrencyException {
		List<BPMConditionalPath> outgoingPaths = this.bpmDao.getConditionalPaths(nodeID);
		int reportID = this.getReportID(tokens[0].getTokenID());
		HashMap<Integer, WebReportTableEdit> editMap = this.reportingDao.getTableEditMap(reportID);

		for (BPMToken token : tokens) {
			for (BPMConditionalPath outgoingPath : outgoingPaths) {
				BPMConditionalPath path = outgoingPath;
				boolean proceed = false;
				if (path.isDefault()) {
					this.moveTokenOnPath(token, path, param);
					break;
				}

				try {
					path.buildEvaluator();
				} catch (XMLStreamException var15) {
					Assert.state(false);
				}

				proceed = path.decide(param, editMap, this.schemaDao, this.bpmDao, token.getFormID());
				if (proceed) {
					this.moveTokenOnPath(token, path, param);
					break;
				}
			}
		}

	}

	@Override
	public BPMNodeHistoryStatus[] getBPMPendingTokenHistory(int tokenID) {
		return this.bpmDao.getBPMPendingTokenHistory(tokenID);
	}

	@Override
	public BPMNodeHistoryStatus[] getBPMDeletedTokenHistory(int tokenID) {
		return this.bpmDao.getBPMDeletedTokenHistory(tokenID);
	}

	@Override
	public BPMTokenView getBPMDeletedTokenView(int tokenID) {
		return this.bpmDao.getBPMTokenView(tokenID);
	}

	@Override
	public int getWorkFlowID(int tokenID) {
		int formID = this.getFormID(tokenID);
		int wfID = this.bpmDao.getWorkflowIDFromForm(formID);
		return wfID;
	}

	@Override
	public void sendErrorToInitiator(int tokenID, String subject, String body) {
		String member = this.bpmDao.getTokenOwner(tokenID);
		if (member != null) {
			Payee recipientPayee = this.payeeDao.getPayee(member);
			this.adminDao.Insert("admin", subject, body, member);

			try {
				SimpleMailMessage message = new SimpleMailMessage();
				message.setSubject(subject);
				message.setText(body);
				List<Payee> payeeList = new ArrayList();
				payeeList.add(recipientPayee);
				this.mailer.send(message, payeeList);
			} catch (Exception var8) {
			}

		}
	}

	@Override
	public BPMTokenView getBPMToken(int tokenID) {
		return this.bpmDao.getBPMTokenView(tokenID);
	}

	private void runAlertNode(BPMToken token, Map<String, Object> params) throws DatabaseConcurrencyException {
		BPMAlertNode alertNode = this.bpmDao.getAlertNode(token.getNodeID());
		if (alertNode.getAlertType() != BPMAlertNode.AlertTypeEnum.Internal
				&& alertNode.getAlertType() != BPMAlertNode.AlertTypeEnum.InternalAndEmail) {
			Queue<BPMExternalEmail> emails = new LinkedList();
			Collections.addAll(emails, alertNode.getExternalEmails());

			for (; !emails.isEmpty(); emails.remove()) {
				BPMExternalEmail email = emails.peek();
				String subjectConverted = this.fillMessageParameters(alertNode.getSubject(), token, email.getEmail());
				String bodyConverted = this.fillMessageParametersHtml(alertNode.getBody(), token, email.getEmail());

				try {
					this.mailer.sendHtml(subjectConverted, bodyConverted, email.getEmail(), email.isCC());
				} catch (Exception var13) {
					this.bpmDao.insertNodeError(alertNode.getNodeID(),
							this.messages.getMessage(Messages.Key.BPM_EMAIL_FAILED));
					this.bpmDao.insertAlertError(alertNode.getNodeID(), token.getTokenID(), alertNode.getName(),
							token.getOwnerID(), this.messages.getMessage(Messages.Key.BPM_EMAIL_FAILED));
					int id = this.bpmDao.getScopeIdentity();
					Set<String> payeeIds = this.bpmDao.getPayeeIDsFromEmails(emails);
					this.bpmDao.insertAlertNodeErrorAssignees(id, payeeIds);
					break;
				}
			}
		} else {
			this.sendInternalMessage(token);
			if (alertNode.getAlertType() == BPMAlertNode.AlertTypeEnum.InternalAndEmail) {
				Set<String> undeliveredPayees = new HashSet();
				String[] members = this.bpmDao.getTokenAssignees(token.getTokenID());
				Collections.addAll(undeliveredPayees, members);

				for (String member : members) {
					Payee recipientPayee = this.payeeDao.getPayee(member);

					try {
						String subjectConverted = this.fillMessageParameters(alertNode.getSubject(), token,
								recipientPayee.getName());
						String bodyConverted = this.fillMessageParametersHtml(alertNode.getBody(), token,
								recipientPayee.getName());
						this.mailer.sendHtml(subjectConverted, bodyConverted, recipientPayee.getEmail(), false);
						undeliveredPayees.remove(member);
					} catch (Exception var14) {
						this.bpmDao.insertNodeError(alertNode.getNodeID(),
								this.messages.getMessage(Messages.Key.BPM_EMAIL_FAILED));
						this.bpmDao.insertAlertError(alertNode.getNodeID(), token.getTokenID(), alertNode.getName(),
								token.getOwnerID(), this.messages.getMessage(Messages.Key.BPM_EMAIL_FAILED));
						int id = this.bpmDao.getScopeIdentity();
						this.bpmDao.insertAlertNodeErrorAssignees(id, undeliveredPayees);
						break;
					}
				}
			}
		}

		assert alertNode.getPaths().length == 1;

		BPMPath nextPath = alertNode.getPaths()[0];
		this.moveTokenWithoutUserCheck(token.getTokenID(), token.getRowVersion(), nextPath.getPathID(), params);
	}

	private void sendInternalMessage(BPMToken token) {
		BPMAlertNode alertNode = this.bpmDao.getAlertNode(token.getNodeID());
		String[] members = this.bpmDao.getTokenAssignees(token.getTokenID());

		for (String member : members) {
			String payeeName = this.payeeDao.getPayee(member).getName();
			String subject = alertNode.getSubject();
			String body = alertNode.getBody();
			this.adminDao.Insert("admin", subject, body, member);
			BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(token.getTokenID());
			String reportName = this.reportingDao.getReportName(workflow.getReportID());
			String varicentURL = this.configDao.getValue(ConfigDao.Key.WEB_BASE_URL);
			if (!varicentURL.endsWith("/")) {
				varicentURL = varicentURL + "/";
			}

			String linkSeparator = " ";
			String reportLink = String.format("%sbpm/view.html?bpmTokenID=%s%s", varicentURL, token.getTokenID(),
					linkSeparator);
			String reportNameWithLink = String.format("%s~BURL%s~BRNAME%s~BRNEND%s", linkSeparator,
					reportLink.substring(1, reportLink.length() - 1), reportName, linkSeparator);
			int noteID = this.adminDao.getMaxAdminNoteId();
			this.adminDao.InsertVariable(noteID, "%formInitiatorName%",
					this.payeeDao.getPayee(token.getOwnerID()).getName());
			this.adminDao.InsertVariable(noteID, "%recipientName%", payeeName);
			this.adminDao.InsertVariable(noteID, "%reportName%", reportName);
			this.adminDao.InsertVariable(noteID, "%reportNameWithLink%", reportNameWithLink);
		}

	}

	private void logStartNodeAction(int tokenID, BPMPath path) {
		int workflowID = this.bpmDao.getWorkflowUsingTokenID(tokenID).getID();
		BPMNode startNode = this.bpmDao.getNode(path.getOriginNodeID());
		BPMToken token = this.bpmDao.getToken(tokenID);
		String initiator = token.getOwnerID();
		int nodeHistoryID = this.bpmDao.insertNodeHistory(workflowID, startNode.getName(), initiator,
				UserAccount.getCurrent().getPayeeId(), this.messages.getMessage(Messages.Key.BPM_START_NODE_ACTION));
		this.bpmDao.insertTokenHistory(nodeHistoryID, tokenID);
	}

	private void logEndNodeAction(int tokenID, int endNodeID) {
		int workflowID = this.bpmDao.getWorkflowUsingTokenID(tokenID).getID();
		BPMNode endNode = this.bpmDao.getNode(endNodeID);
		BPMToken token = this.bpmDao.getToken(tokenID);
		String initiator = token.getOwnerID();
		int nodeHistoryID = this.bpmDao.insertNodeHistory(workflowID, endNode.getName(), initiator,
				UserAccount.getCurrent().getPayeeId(), this.messages.getMessage(Messages.Key.BPM_END_NODE_ACTION));
		this.bpmDao.insertTokenHistory(nodeHistoryID, tokenID);
	}

	private void logNodeActioned(int tokenID, String payeeID, BPMPath path) {
		int workflowID = this.bpmDao.getWorkflowUsingTokenID(tokenID).getID();
		BPMNode actionedNode = this.bpmDao.getNode(path.getOriginNodeID());
		BPMToken token = this.bpmDao.getToken(tokenID);
		String initiator = token.getOwnerID();
		int nodeHistoryID = this.bpmDao.insertNodeHistory(workflowID, actionedNode.getName(), initiator, payeeID,
				path.getName());
		this.bpmDao.insertTokenHistory(nodeHistoryID, tokenID);
	}

	private void logConditionalNodeAction(int tokenID, String payeeID, BPMPath path) {
		this.logNodeActioned(tokenID, payeeID, path);
	}

	private String fillMessageParameters(String message, BPMToken token, String recipient) {
		Payee initiator = this.payeeDao.getPayee(token.getOwnerID());
		BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(token.getTokenID());
		String reportName = this.reportingDao.getReportName(workflow.getReportID());
		String varicentURL = this.configDao.getValue(ConfigDao.Key.WEB_BASE_URL);
		if (!varicentURL.endsWith("/")) {
			varicentURL = varicentURL + "/";
		}

		String linkSeparator = " ";
		String reportLink = String.format("%sbpm/view.html?bpmTokenID=%s%s", varicentURL, token.getTokenID(),
				linkSeparator);
		String reportNameWithLink = String.format("%s (%s)", reportName,
				reportLink.substring(0, reportLink.length() - 1));
		message = message.replaceAll("%formInitiatorName%", Matcher.quoteReplacement(initiator.getName()));
		message = message.replaceAll("%recipientName%", Matcher.quoteReplacement(recipient));
		message = message.replaceAll("%reportName%", Matcher.quoteReplacement(reportName));
		message = message.replaceAll("%reportNameWithLink%", Matcher.quoteReplacement(reportNameWithLink));
		return message;
	}

	private String fillMessageParametersHtml(String message, BPMToken token, String recipient) {
		String messageHtml = "<html><body>";
		messageHtml = messageHtml + HtmlUtils.htmlEscape(message);
		Payee initiator = this.payeeDao.getPayee(token.getOwnerID());
		BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(token.getTokenID());
		String reportName = this.reportingDao.getReportName(workflow.getReportID());
		String varicentURL = this.configDao.getValue(ConfigDao.Key.WEB_BASE_URL);
		if (!varicentURL.endsWith("/")) {
			varicentURL = varicentURL + "/";
		}

		String reportLinkURL = String.format("%sbpm/view.html?bpmTokenID=%s", varicentURL, token.getTokenID());
		String reportLink = String.format("<a href=\"%s\">%s</a>", reportLinkURL, reportLinkURL);
		String reportNameWithLink = String.format("<a href=\"%s\">%s</a>", reportLinkURL, reportName);
		messageHtml = messageHtml.replaceAll("%formInitiatorName%", Matcher.quoteReplacement(initiator.getName()));
		messageHtml = messageHtml.replaceAll("%recipientName%", Matcher.quoteReplacement(recipient));
		messageHtml = messageHtml.replaceAll("%reportName%", Matcher.quoteReplacement(reportName));
		messageHtml = messageHtml.replaceAll("%reportNameWithLink%", Matcher.quoteReplacement(reportNameWithLink));
		messageHtml = messageHtml.replaceAll("\r\n", "<br>");
		messageHtml = messageHtml + "</body></html>";
		return messageHtml;
	}

	private void runProcessNode(int nodeID, int tokenID) {
		this.bpmDao.scheduleProcessNode(nodeID, tokenID);
	}

	@Override
	public int getReportID(int tokenID) {
		BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(tokenID);
		return workflow.getReportID();
	}

	@Override
	public long getBPMTokenVersion(int tokenID) throws DatabaseConcurrencyException {
		BPMToken token = this.bpmDao.getToken(tokenID);
		if (token == null) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			return token.getRowVersion();
		}
	}

	@Override
	public BPMPath[] getPaths(int tokenID) {
		BPMToken token = this.bpmDao.getToken(tokenID);
		BPMNode node = this.bpmDao.getNode(token.getNodeID());
		return node.getPaths();
	}

	@Override
	public BPMTokenView[] getBPMTokenViews(int startIndex, int rowsPerPage) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getBPMTokenViews(user.getPayeeId(), 1 + startIndex / rowsPerPage, rowsPerPage);
	}

	@Override
	public int getBPMTokenViewsCount() {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getBPMTokenViewsCount(user.getPayeeId());
	}

	@Override
	public BPMTokenView[] getCompletedTokenViews() {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getCompletedTokenViews(user.getPayeeId());
	}

	@Override
	public BPMTokenView[] getCompletedTokenViews(int page, int rowPerPage) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getCompletedTokenViews(user.getPayeeId(), page, rowPerPage);
	}

	@Override
	public BPMTokenView getBPMTokenView(int tokenID) throws DatabaseConcurrencyException {
		UserAccount user = UserAccount.getCurrent();
		BPMTokenView result = this.bpmDao.getBPMTokenView(user.getPayeeId(), tokenID);
		if (result == null) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.BPM_TOKEN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			return result;
		}
	}

	@Override
	public BPMWorkflowView[] getInitiatableWorkflows() {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getInitiatableWorkflows(user.getPayeeId());
	}

	@Override
	public BPMWorkflowView[] getInitiatableWorkflows(int startIndex, int rowsPerPage, boolean sortDescending) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getInitiatableWorkflows(user.getPayeeId(), 1 + startIndex / rowsPerPage, rowsPerPage,
				sortDescending);
	}

	@Override
	public int getInitiatableWorkflowsCount() {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getInitiatableWorkflowsCount(user.getPayeeId());
	}

	@Override
	public boolean canInitiateWorkflow(int workflowID) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.canInitiateWorkflow(user.getPayeeId(), workflowID);
	}

	@Override
	@Transactional(readOnly = false)
	public int initiateWorkflow(int workflowID, HashMap<String, Object> reportParams,
			Map<Integer, Integer> visibleTabIdWorkflowObjectIdMap)
			throws DatabaseConcurrencyException, ReportOverLimitException, IllegalValueException {
		UserAccount user = UserAccount.getCurrent();
		String payeeID = user.getPayeeId();
		int reportID = this.getWorkflowReportID(workflowID);
		BPMNode startNode = this.bpmDao.getStartNode(workflowID);
		BPMPath nextPath = startNode.getPaths()[0];
		int nextNodeID = nextPath.getDestinationNodeID();
		int formID = this.getUninitiatedFormID(workflowID, false);
		BPMToken token = this.bpmDao.insertToken(formID, nextNodeID, payeeID, payeeID, nextPath.getPathID(), false);
		this.bpmDao.markFormAsInitiated(formID);
		BPMNode nextNode = this.bpmDao.getNode(nextNodeID);
		if (!this.bpmDao.getSwimLane(nextNode.getSwimLaneID()).getName().equals("Form Initiator")) {
			ReportingCommand cmd = new ReportingCommand();
			cmd.setId(reportID);
			Map<String, Object> params = this.getWorkflowParamsForInitialize(workflowID);

			for (String key : reportParams.keySet()) {
				if (params.containsKey(key)) {
					params.put(key, reportParams.get(key));
				}

				params.put(key, reportParams.get(key));
			}

			Scope scope = this.reportingDao.getScopeForParameter(reportID, params, visibleTabIdWorkflowObjectIdMap, cmd,
					new HashMap(), formID);
			Set<String> initParams = scope.getObjectNames();
			HashMap<String, Object> tokenParams = new HashMap();

			for (String paramName : initParams) {
				if (scope.getType(paramName).equals(Scope.Type.DATE)) {
					Date date = scope.getDateTime(paramName);
					if (!Constants.MAX_DATE.after(date) && !Constants.MIN_DATE.before(date)) {
						tokenParams.put(paramName, Format.asISODate(date));
					} else {
						tokenParams.put(paramName, "");
					}
				} else {
					tokenParams.put(paramName, scope.getObject(paramName));
				}
			}

			this.updateBPMPreviousParameters(tokenParams, token.getTokenID());
		}

		String[] swimLaneMembers = this.bpmDao.getSwimLaneMembers(nextNode.getSwimLaneID(), token.getTokenID());

		for (String swimLaneMember : swimLaneMembers) {
			this.bpmDao.insertTokenAssignee(token.getTokenID(), swimLaneMember);
		}

		this.logStartNodeAction(token.getTokenID(), nextPath);
		this.runNode(new BPMToken[] { token }, nextPath, reportParams);
		return token.getTokenID();
	}

	@Override
	public Map<String, Object> getWorkflowParams(int tokenID) {
		BPMToken token = this.bpmDao.getToken(tokenID);
		BPMWorkflow workflow = this.bpmDao.getWorkflowUsingTokenID(tokenID);
		Map<String, Object> params = this.getWorkflowParams(workflow, token.getOwnerID());
		return params;
	}

	@Override
	public Map<String, Object> getWorkflowParamsForInitialize(int workflowID) {
		UserAccount user = UserAccount.getCurrent();
		String ownerID = user.getPayeeId();
		BPMWorkflow workflow = this.bpmDao.getWorkflow(workflowID);
		Map<String, Object> params = this.getWorkflowParams(workflow, ownerID);
		return params;
	}

	private Map<String, Object> getWorkflowParams(BPMWorkflow workflow, String ownerID) {
		Map<String, Object> params = new HashMap();
		UserAccount user = UserAccount.getCurrent();

		for (BPMWorkflowParameter param : workflow.getParameters()) {
			if (!param.getUseDefaultValue()) {
				String paramName = param.getName();
				Object paramValue = null;
				String var12;
				if (param.getValueType() == BPMWorkflowParameter.ValueType.Constant) {
					var12 = param.getValue();
				} else if (param.getValue().equals("_BPM_TOKENOWNER")) {
					var12 = ownerID;
				} else if (param.getValue().equals("WebUser_")) {
					var12 = user.getPayeeId();
				} else if (param.getValue().equals("FormInitiator")) {
					var12 = ownerID;
				} else if (param.getValue().equals("CurrentDate")) {
					Date systemDate = this.timeDao.getSystemDate();
					var12 = Format.asISODate(systemDate);
				} else {
					var12 = "";
				}

				params.put(paramName, var12);
			}
		}

		return params;
	}

	@Override
	public int getWorkflowReportID(int workflowID) {
		BPMWorkflow workflow = this.bpmDao.getWorkflow(workflowID);
		return workflow.getReportID();
	}

	@Override
	public BPMWorkflowView getWorkflowView(int workflowID) {
		return this.bpmDao.getWorkflowView(workflowID);
	}

	@Override
	public boolean isViewableReport(int reportID) {
		return this.bpmDao.isViewableReport(reportID);
	}

	@Override
	public HashMap<String, Boolean> getWorkflowLayoutVisibilityMap(int workflowID) {
		return this.bpmDao.getWorkflowLayoutVisibilityMap(workflowID);
	}

	@Override
	public HashMap<String, Boolean> getWorkflowLayoutEditabilityMap(int workflowID) {
		return this.bpmDao.getWorkflowLayoutEditabilityMap(workflowID);
	}

	@Override
	public HashMap<String, Boolean> getTokenLayoutVisibilityMap(int tokenID) {
		BPMToken token = this.bpmDao.getToken(tokenID);
		int nodeID = token.getNodeID();
		return this.bpmDao.getActionNodeLayoutVisibilityMap(nodeID);
	}

	@Override
	public HashMap<String, Boolean> getTokenLayoutEditabilityMap(int tokenID) {
		BPMToken token = this.bpmDao.getToken(tokenID);
		int nodeID = token.getNodeID();
		return this.bpmDao.getActionNodeLayoutEditabilityMap(nodeID);
	}

	@Override
	@Transactional(readOnly = false)
	public int getUninitiatedFormID(int workflowID, boolean createNewIfNotExists) throws DatabaseConcurrencyException {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.getUninitiatedFormID(workflowID, user.getPayeeId(), createNewIfNotExists);
	}

	@Override
	public int getFormID(int tokenID) {
		BPMToken token = this.bpmDao.getToken(tokenID);
		return token.getFormID();
	}

	@Override
	public boolean isStartNodeSaveAndSubmit(int workflowID) {
		BPMNode startNode = this.bpmDao.getStartNode(workflowID);
		return startNode.getPaths()[0].isSaveAndSubmit();
	}

	@Override
	public int BPMCompletedTokenCount(boolean countActiveToken, boolean countDeletedToken) {
		UserAccount user = UserAccount.getCurrent();
		return this.bpmDao.BPMCompletedTokenCount(countActiveToken, countDeletedToken, user.getPayeeId());
	}

	@Override
	public boolean getPendingWorkflowStatus() {
		return this.configDao.getBooleanValue(ConfigDao.Key.ENABLE_PENDING_WORKFLOW);
	}
}
