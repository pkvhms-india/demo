package com.varicent.core.exceptions;

public class GlobalLockException extends Exception {
	private static final long serialVersionUID = 1L;

	public GlobalLockException() {
	}

	public GlobalLockException(String message) {
		super(message);
	}

	public GlobalLockException(String message, Throwable cause) {
		super(message, cause);
	}

	public GlobalLockException(Throwable cause) {
		super(cause);
	}
}
