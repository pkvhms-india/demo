package com.varicent.draws.service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.varicent.common.audit.dao.AuditDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.core.Constants;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.text.Parse;
import com.varicent.draws.dao.DrawAssignmentDao;
import com.varicent.draws.domain.DrawAssignmentFixedTerm;
import com.varicent.draws.domain.DrawAssignmentOngoing;
import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;
import com.varicent.draws.domain.DrawAssignmentWebSettings;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawSchedule;
import com.varicent.draws.domain.DrawTemplate;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.PeriodAmount;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.domain.WorkflowObject;

@Service("drawAssignmentManager")
@Transactional(readOnly = true)
public class DrawAssignmentManagerImpl implements DrawAssignmentManager {
	private final DrawAssignmentDao drawAssignmentDao;
	private final HistoryDao historyDao;
	private final AuditDao auditDao;
	private final TimeDao timeDao;
	Map<Integer, DrawTemplate> drawTemplateMap = new HashMap();

	@Autowired
	public DrawAssignmentManagerImpl(DrawAssignmentDao drawAssignmentDao, AuditDao auditDao, TimeDao timeDao,
			HistoryDao historyDao) {
		this.drawAssignmentDao = drawAssignmentDao;
		this.auditDao = auditDao;
		this.timeDao = timeDao;
		this.historyDao = historyDao;
	}

	@Override
	public List<Payee> getFilterPayees(int drawId, int workflowObjectId) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null ? this.drawAssignmentDao.getFilterPayees(restrictionQuery)
				: this.drawAssignmentDao.getFilterPayees(workflowObjectId);
	}

	private boolean isViewableGroup(int drawId, int workflowObjectId, int groupId) {
		for (WorkflowGroupName groupName : this.getfilterWorkflowGroups(drawId, workflowObjectId)) {
			if (groupName.getId() == groupId) {
				return true;
			}
		}

		return false;
	}

	private boolean isViewablePayee(int drawId, int workflowObjectId, String payeeId) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null ? this.drawAssignmentDao.isViewablePayee(restrictionQuery, payeeId)
				: this.drawAssignmentDao.isViewablePayee(workflowObjectId, payeeId);
	}

	@Override
	public List<WorkflowGroupName> getfilterWorkflowGroups(int drawId, int workflowObjectId) {
		DrawAssignmentWebSettings settings = this.drawAssignmentDao.getSettings(drawId);
		return settings.isAllowGroupSelection() ? this.drawAssignmentDao.getWorkflowGroups(workflowObjectId)
				: new LinkedList();
	}

	@Override
	public boolean drawExists(int drawId) {
		return this.drawAssignmentDao.exists(drawId);
	}

	@Override
	public boolean isViwableDrawAssignment(int drawId) {
		return this.drawAssignmentDao.isViewableDrawAssignment(drawId);
	}

	static QueryDefinition getWebUserQuery() {
		QueryDefinition query = new QueryDefinition();
		String webuser = UserAccount.getCurrent().getPayeeId();
		query.select(new Literal(Literal.Type.STRING, webuser), "WebUser_");
		return query;
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(int drawId, int workflowObjectId,
			String selectedPayeeId, int selectedGroupId, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) {
		List<DrawAssignmentUnassignedPayee> unassignedPayees;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			unassignedPayees = this.getAllUnAssignedPayees(drawId, workflowObjectId, pageNumber, rowsPerPage,
					sortColumn, descending);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			unassignedPayees = this.getUnAssignedListForPayee(selectedPayeeId, drawId, workflowObjectId);
		} else {
			unassignedPayees = this.getUnAssignedPayees(selectedGroupId, drawId, workflowObjectId, pageNumber,
					rowsPerPage, sortColumn, descending);
		}

		return unassignedPayees;
	}

	@Override
	public int getUnAssignedPayeesPageCount(int drawId, int rowsPerPage, int workflowObjectId, String selectedPayeeId,
			int selectedGroupId) {
		int rowCount;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			rowCount = this.getAllUnAssignedPayeesCount(drawId, workflowObjectId);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			rowCount = 1;
		} else {
			rowCount = this.getUnAssignedPayeesCount(selectedGroupId, drawId, workflowObjectId);
		}

		return this.getPageCount(rowCount, rowsPerPage);
	}

	private List<DrawAssignmentUnassignedPayee> getUnAssignedListForPayee(String payeeId, int drawId,
			int workflowObjectId) {
		return !this.isViewablePayee(drawId, workflowObjectId, payeeId) ? new LinkedList()
				: this.drawAssignmentDao.getUnAssignedListForPayee(payeeId, drawId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId));
	}

	private List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(int workflowGroupId, int drawId,
			int workflowObjectId, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? new LinkedList()
				: this.drawAssignmentDao.getUnAssignedPayees(workflowGroupId, drawId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId), pageNumber, rowsPerPage, sortColumn,
						descending);
	}

	private int getUnAssignedPayeesCount(int workflowGroupId, int drawId, int workflowObjectId) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? 0
				: this.drawAssignmentDao.getUnAssignedPayeesCount(workflowGroupId, drawId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId));
	}

	private List<DrawAssignmentUnassignedPayee> getAllUnAssignedPayees(int drawId, int workflowObjectId, int pageNumber,
			int rowsPerPage, String sortColumn, boolean descending) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null ? this.drawAssignmentDao.getUnAssignedPayees(restrictionQuery, drawId,
				this.drawAssignmentDao.getEffectiveDateColumn(drawId), pageNumber, rowsPerPage, sortColumn, descending)
				: this.drawAssignmentDao.getUnAssignedPayeesAllGroups(drawId, workflowObjectId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId), pageNumber, rowsPerPage, sortColumn,
						descending);
	}

	private int getAllUnAssignedPayeesCount(int drawId, int workflowObjectId) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null
				? this.drawAssignmentDao.getUnAssignedPayeesCount(restrictionQuery, drawId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId))
				: this.drawAssignmentDao.getUnAssignedPayeesAllGroupsCount(drawId, workflowObjectId,
						this.drawAssignmentDao.getEffectiveDateColumn(drawId));
	}

	@Override
	public List<DrawTemplateName> getDrawTemplates(int drawId) {
		return this.drawAssignmentDao.getDrawTemplates(drawId);
	}

	private DrawAssignmentUnassignedPayee findUnassignedPayee(List<DrawAssignmentUnassignedPayee> originalPayees,
			DrawAssignmentUnassignedPayee unassigned) {
		for (DrawAssignmentUnassignedPayee original : originalPayees) {
			if (original.compareTo(unassigned) == 0) {
				return original;
			}
		}

		return null;
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> assignAndGetUnassigned(List<DrawAssignmentUnassignedPayee> payeeInfo,
			int drawId, int workflowObjectId, List<Message> errors) {
		if (!this.drawExists(drawId)) {
			errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
			return new LinkedList();
		} else {
			String timeId = this.drawAssignmentDao.getDrawTimeId(drawId);
			String drawName = this.drawAssignmentDao.getDrawName(drawId);
			String assignerID = UserAccount.getCurrent().getPayeeId();
			List<DrawAssignmentUnassignedPayee> unassignedList = new LinkedList();
			Map<String, Date> levelLockedDateMap = new HashMap();

			for (DrawAssignmentUnassignedPayee payee : payeeInfo) {
				List<DrawAssignmentUnassignedPayee> originalPayeeList = this.getUnAssignedListForPayee(payee.getId(),
						drawId, workflowObjectId);
				DrawAssignmentUnassignedPayee original = this.findUnassignedPayee(originalPayeeList, payee);
				if (original == null) {
					errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
					unassignedList.add(payee);
				} else {
					int templateId = payee.getTemplateId();
					if (templateId == 0) {
						unassignedList.add(original);
					} else {
						Date startDate = this.parseDate(payee.getDateOfHireFormatted());
						DrawTemplate template = null;

						try {
							template = this.getDrawTemplate(templateId);
						} catch (DatabaseConcurrencyException e) {
							errors.add(e.getMessageObject());
							unassignedList.add(original);
							continue;
						}

						String level = template.getLevel();
						if (!levelLockedDateMap.containsKey(level)) {
							levelLockedDateMap.put(level, this.timeDao.getLockedDate(timeId, level));
						}

						Date endDate = null;
						Date[] periodStartDates = null;
						boolean isPeriodCountValid = true;
						if (template.isOngoing()) {
							endDate = Constants.MAX_DATE;
						} else if (startDate != null) {
							int availablePeriodCount = this.drawAssignmentDao.getNumberOfAvailablePeriods(timeId,
									template.getLevel(), startDate);
							int periodCount = Math.min(template.getDuration(), availablePeriodCount);
							if (availablePeriodCount >= template.getDuration()) {
								periodStartDates = this.drawAssignmentDao.getPeriodStartStartingAt(startDate,
										periodCount, template.getLevel(), timeId);
								endDate = this.drawAssignmentDao.getPeriodEndDate(timeId, template.getLevel(),
										periodStartDates[periodCount - 1]);
							} else {
								isPeriodCountValid = false;
							}
						}

						Message error = this.getNewStartDateValidationMessage(template, payee.getId(), (Integer) null,
								startDate, endDate, levelLockedDateMap.get(level), payee.getName());
						if (error != null) {
							errors.add(error);
							unassignedList.add(original);
						} else if (!isPeriodCountValid) {
							errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_INVALID_PERIOD,
									new Object[] { payee.getName() }));
							unassignedList.add(original);
						} else {
							String payeeId = payee.getId();
							if (template.getDrawId() != drawId) {
								errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
								unassignedList.add(original);
							} else {
								this.historyDao.beginRevision();
								if (template.isOngoing()) {
									this.drawAssignmentDao.assignToOngoing(payeeId, template.getId(),
											template.getDrawAmount(), startDate);
								} else {
									int assignmentID = this.drawAssignmentDao.assignToFixedterm(payeeId,
											template.getId(), startDate, endDate);
									if (template.isFixedAmount()) {
										BigDecimal amount = template.getDrawAmount();

										for (Date period : periodStartDates) {
											this.drawAssignmentDao.addFixedTermPeriods(assignmentID, period, amount);
										}
									} else {
										for (DrawSchedule schedule : template.getSchedules()) {
											Date period = periodStartDates[schedule.getPeriod() - 1];
											this.drawAssignmentDao.addFixedTermPeriods(assignmentID, period,
													schedule.getAmount());
										}
									}
								}

								this.historyDao.assignRevision();
								this.auditDao.logRevision(new Message(Messages.Key.MODULE_WEB, new Object[0]),
										new Message(Messages.Key.EVENT_DRAW_ASSIGNED, new Object[0]),
										new Message(Messages.Key.EVENT_DRAW_ASSIGNED_MESSAGE,
												new Object[] {
														this.getPayeeIDNameString(payee.getId(), payee.getName()),
														drawName, template.getName() }));
								this.historyDao.endRevision();
							}
						}
					}
				}
			}

			return unassignedList;
		}
	}

	@Override
	public String getPeriodName(String startDateParam, String timeId, String level) {
		Date startDate = this.parseDate(startDateParam);
		return startDate != null && startDate.after(Constants.MIN_DATE) && startDate.before(Constants.MAX_DATE)
				? this.drawAssignmentDao.getPeriodName(startDate, timeId, level)
				: null;
	}

	static DrawAssignmentOngoing findOriginalOngoing(List<DrawAssignmentOngoing> ongoingAssignments,
			DrawAssignmentOngoing ongoing) {
		for (DrawAssignmentOngoing original : ongoingAssignments) {
			if (original.getAssignmentId() == ongoing.getAssignmentId()
					&& original.getPayeeId().compareTo(ongoing.getPayeeId()) == 0
					&& original.getOldStartDateFormatted().compareTo(ongoing.getOldStartDateFormatted()) == 0
					&& original.getTemplateId() == ongoing.getTemplateId()) {
				return original;
			}
		}

		return null;
	}

	@Override
	public List<DrawAssignmentOngoing> updateOngoingAssignmentsAndGetRemaining(int drawId, int workflowObjectId,
			List<DrawAssignmentOngoing> ongoingAssignments, List<Message> errors, int pageNumber, int rowsPerPage,
			String sortColumn, boolean descending) {
		if (!this.drawExists(drawId)) {
			errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
			return new LinkedList();
		} else {
			String timeId = this.drawAssignmentDao.getDrawTimeId(drawId);
			String drawName = this.drawAssignmentDao.getDrawName(drawId);
			Map<String, Date> levelLockedDateMap = new HashMap();
			List<DrawAssignmentOngoing> remainingList = new LinkedList();
			NumericFormat.Style currencyStyle = this.drawAssignmentDao.getSettings(drawId).getNumericStyle();

			for (DrawAssignmentOngoing ongoing : ongoingAssignments) {
				List<DrawAssignmentOngoing> payeeOngoingList = this.getOngoingAssignmentsForPayee(ongoing.getPayeeId(),
						drawId, workflowObjectId, false, pageNumber, rowsPerPage, sortColumn, descending);
				DrawAssignmentOngoing originalOngoing = findOriginalOngoing(payeeOngoingList, ongoing);
				if (originalOngoing == null) {
					errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
					remainingList.add(ongoing);
				} else if (!originalOngoing.isActive()) {
					remainingList.add(originalOngoing);
				} else {
					try {
						this.historyDao.beginRevision();
						Date oldStartDate = this.parseDate(ongoing.getOldStartDateFormatted());
						DrawTemplate template = this.getDrawTemplate(ongoing.getTemplateId());
						String level = template.getLevel();
						if (!levelLockedDateMap.containsKey(level)) {
							levelLockedDateMap.put(level, this.timeDao.getLockedDate(timeId, level));
						}

						Date lockedDate = levelLockedDateMap.get(level);
						if (!ongoing.isUnassigned()) {
							if (ongoing.isDirty()) {
								Date newStartDate = this.parseDate(ongoing.getNewStartDateFormatted());
								BigDecimal newAmount = null;
								if (ongoing.getNewAmount() != null && !ongoing.getNewAmount().isEmpty()) {
									newAmount = this.parseAmount(ongoing.getNewAmount(), currencyStyle);
								}

								BigDecimal oldAmount = this.parseAmount(ongoing.getOldAmount(), currencyStyle);
								int assignmentID = ongoing.getAssignmentId();
								Date endDate = this.drawAssignmentDao.getOngoingAssignmentEndDate(assignmentID);
								if (endDate == null) {
									endDate = Constants.MAX_DATE;
								}

								Message error = this.validateOngoingChanges(template, ongoing, oldAmount, newAmount,
										oldStartDate, newStartDate, endDate, lockedDate, ongoing.getPayeeName());
								if (error != null) {
									errors.add(error);
									remainingList.add(originalOngoing);
								} else {
									if (!ongoing.getNewAmount().equals(ongoing.getOldAmount())) {
										ongoing.setNewAmount(NumericFormat.getNumericCurrencyFormatter(currencyStyle)
												.format(newAmount));
									}

									this.drawAssignmentDao.updateOngoing(ongoing, newStartDate, newAmount);
									ongoing.updateOriginalValues();
									remainingList.add(ongoing);
									this.historyDao.assignRevision();
									this.auditDao.logRevision(new Message(Messages.Key.MODULE_WEB, new Object[0]),
											new Message(Messages.Key.EVENT_DRAW_ASSIGNMENT_MODIFIDED, new Object[0]),
											new Message(Messages.Key.EVENT_DRAW_ASSIGNMENT_MODIFIDED_MESSAGE,
													new Object[] {
															this.getPayeeIDNameString(ongoing.getPayeeId(),
																	ongoing.getPayeeName()),
															drawName, template.getName() }));
								}
							} else {
								remainingList.add(originalOngoing);
							}
						} else {
							if (lockedDate != null && !lockedDate.before(oldStartDate)) {
								this.drawAssignmentDao.setOngoingEndDate(ongoing, lockedDate);
							} else {
								this.drawAssignmentDao.clearOngoing(ongoing);
							}

							this.historyDao.assignRevision();
							this.auditDao.logRevision(new Message(Messages.Key.MODULE_WEB, new Object[0]),
									new Message(Messages.Key.EVENT_DRAW_UNASSIGNED, new Object[0]),
									new Message(Messages.Key.EVENT_DRAW_UNASSIGNED_MESSAGE, new Object[] {
											this.getPayeeIDNameString(ongoing.getPayeeId(), ongoing.getPayeeName()),
											drawName, template.getName() }));
						}
					} catch (DatabaseConcurrencyException e) {
						errors.add(e.getMessageObject());
						remainingList.add(originalOngoing);
					} finally {
						this.historyDao.endRevision();
					}
				}
			}

			return remainingList;
		}
	}

	private BigDecimal parseAmount(String amount, NumericFormat.Style currencyStyle) {
		if (amount != null && !amount.isEmpty()) {
			BigDecimal newAmount = Parse.parseCurrency(amount,
					NumericFormat.getNumericCurrencyFormatter(currencyStyle));
			if (newAmount == null) {
				newAmount = Parse.parseDecimal(amount, false);
			}

			return newAmount;
		} else {
			return null;
		}
	}

	private Message validateOngoingChanges(DrawTemplate template, DrawAssignmentOngoing ongoingTerm,
			BigDecimal oldAmount, BigDecimal newAmount, Date oldStartDate, Date newStardDate, Date newEndDate,
			Date lockedDate, String payeeName) {
		if (newAmount == null) {
			return new Message(Messages.Key.DRAW_ASSIGN_ERROR_INVALID_AMOUNT, new Object[] { payeeName });
		} else if (!template.isCanChangeDrawAmount() && oldAmount.compareTo(newAmount) != 0) {
			return new Message(Messages.Key.DRAW_ASSIGN_ERROR_FIXED_AMOUNT, new Object[] { payeeName });
		} else if (template.isCanChangeDrawAmount() && oldAmount.compareTo(newAmount) != 0
				&& newAmount.compareTo(template.getMaxDrawAmount()) > 0) {
			return new Message(Messages.Key.DRAW_ASSIGN_ERROR_MAX_AMOUNT, new Object[] { payeeName });
		} else if (template.isCanChangeDrawAmount() && oldAmount.compareTo(newAmount) != 0
				&& newAmount.compareTo(BigDecimal.ZERO) < 0) {
			return new Message(Messages.Key.DRAW_ASSIGN_ERROR_NEGATIVE_AMOUNT, new Object[] { payeeName });
		} else {
			if (newStardDate == null || oldStartDate.compareTo(newStardDate) != 0) {
				Message error = this.getStartDateValidationMessage(template, ongoingTerm.getPayeeId(),
						ongoingTerm.getAssignmentId(), newStardDate, oldStartDate, newEndDate, lockedDate, payeeName);
				if (error != null) {
					return error;
				}
			}

			return template.isCanChangeDrawAmount() && lockedDate != null && !oldStartDate.after(lockedDate)
					? new Message(Messages.Key.DRAW_ASSIGN_ERROR_LOCKED_ONGOING, new Object[] { payeeName })
					: null;
		}
	}

	private Message getNewStartDateValidationMessage(DrawTemplate template, String payeeID, Integer assignmentID,
			Date newStartDate, Date newEndDate, Date lockedDate, String payeeName) {
		return this.getStartDateValidationMessage(template, payeeID, assignmentID, newStartDate, (Date) null,
				newEndDate, lockedDate, payeeName);
	}

	private Message getStartDateValidationMessage(DrawTemplate template, String payeeID, Integer assignmentID,
			Date newStartDate, Date oldStartDate, Date newEndDate, Date lockedDate, String payeeName) {
		if (newStartDate == null) {
			return new Message(Messages.Key.DRAW_ASSIGN_ERROR_INVALID_DATE, new Object[] { payeeName });
		} else {
			boolean hasStartDateChange = oldStartDate != null && oldStartDate.compareTo(newStartDate) != 0;
			Date calendarStart = this.drawAssignmentDao.getCalendarStartDate(template.getDrawId());
			Date calendarEnd = this.drawAssignmentDao.getCalendarEndDate(template.getDrawId());
			if (lockedDate != null && hasStartDateChange && !oldStartDate.after(lockedDate)) {
				return new Message(Messages.Key.DRAW_ASSIGN_ERROR_LOCKED_OLD_START_DATE, new Object[] { payeeName });
			} else {
				if (oldStartDate == null || hasStartDateChange) {
					if (newStartDate.before(calendarStart) || newStartDate.after(calendarEnd)) {
						return new Message(Messages.Key.DRAW_ASSIGN_ERROR_MISSING_CALENDAR_DATE,
								new Object[] { payeeName });
					}

					if (lockedDate != null && !newStartDate.after(lockedDate)) {
						return new Message(Messages.Key.DRAW_ASSIGN_ERROR_LOCKED_START_DATE,
								new Object[] { payeeName });
					}
				}

				if (newEndDate != null && hasStartDateChange && newStartDate.after(newEndDate)) {
					return new Message(Messages.Key.DRAW_ASSIGN_ERROR_START_AFTER_END_DATE, new Object[] { payeeName });
				} else if (newEndDate != null && this.drawAssignmentDao.OverlappingAssignmentExistsForPayee(
						template.getDrawId(), payeeID, newStartDate, newEndDate, assignmentID, !template.isOngoing())) {
					return new Message(Messages.Key.DRAW_ASSIGN_ERROR_ASSIGNMENT_EXISTS, new Object[] { payeeName });
				} else {
					return null;
				}
			}
		}
	}

	public DrawAssignmentFixedTerm findOriginalFixedterm(List<DrawAssignmentFixedTerm> originalList,
			DrawAssignmentFixedTerm fixedterm) {
		for (DrawAssignmentFixedTerm original : originalList) {
			if (original.getAssignmentId() == fixedterm.getAssignmentId()
					&& original.getPayeeId().compareTo(fixedterm.getPayeeId()) == 0
					&& original.getTemplateId() == fixedterm.getTemplateId()
					&& original.getOldStartDateFormatted().compareTo(fixedterm.getOldStartDateFormatted()) == 0) {
				return original;
			}
		}

		return null;
	}

	@Override
	public List<DrawAssignmentFixedTerm> updateFixedTermAssignmentsAndGetRemaining(int drawId, int workflowObjectId,
			List<DrawAssignmentFixedTerm> fixedTermAssignment, List<Message> errors, int pageNumber, int rowsPerPage,
			String sortColumn, boolean descending) {
		if (!this.drawExists(drawId)) {
			errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
			return new LinkedList();
		} else {
			String timeId = this.drawAssignmentDao.getDrawTimeId(drawId);
			String drawName = this.drawAssignmentDao.getDrawName(drawId);
			Map<String, Date> levelLockedDateMap = new HashMap();
			List<DrawAssignmentFixedTerm> remainingList = new LinkedList();
			NumericFormat.Style currencyStyle = this.drawAssignmentDao.getSettings(drawId).getNumericStyle();

			for (DrawAssignmentFixedTerm fixedTerm : fixedTermAssignment) {
				List<DrawAssignmentFixedTerm> originalFixedTermList = this.getFixedTermListForPayee(
						fixedTerm.getPayeeId(), drawId, workflowObjectId, false, pageNumber, rowsPerPage, sortColumn,
						descending);
				DrawAssignmentFixedTerm original = this.findOriginalFixedterm(originalFixedTermList, fixedTerm);
				if (original == null) {
					errors.add(new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
					remainingList.add(fixedTerm);
				} else if (!original.isActive()) {
					remainingList.add(original);
				} else {
					try {
						this.historyDao.beginRevision();
						Date oldStartDate = this.parseDate(fixedTerm.getOldStartDateFormatted());
						DrawTemplate template = this.getDrawTemplate(fixedTerm.getTemplateId());
						String level = template.getLevel();
						if (!levelLockedDateMap.containsKey(level)) {
							levelLockedDateMap.put(level, this.timeDao.getLockedDate(timeId, level));
						}

						Date lockedDate = levelLockedDateMap.get(level);
						if (fixedTerm.isUnassigned()) {
							if (lockedDate != null && !lockedDate.before(oldStartDate)) {
								this.drawAssignmentDao.terminateFixedTerm(fixedTerm, lockedDate);
							} else {
								this.drawAssignmentDao.clearFixedTerm(fixedTerm.getAssignmentId(),
										fixedTerm.getRowVersion());
							}

							this.historyDao.assignRevision();
							this.auditDao.logRevision(new Message(Messages.Key.MODULE_WEB, new Object[0]),
									new Message(Messages.Key.EVENT_DRAW_UNASSIGNED, new Object[0]),
									new Message(Messages.Key.EVENT_DRAW_UNASSIGNED_MESSAGE,
											new Object[] {
													this.getPayeeIDNameString(fixedTerm.getPayeeId(),
															fixedTerm.getPayeeName()),
													drawName, fixedTerm.getTemplateName() }));
						} else if (!fixedTerm.isDirty()) {
							remainingList.add(original);
						} else {
							Date newStartDate = this.parseDate(fixedTerm.getNewStartDateFormatted());
							Date newEndDate = null;
							int availablePeriodsCount = 0;
							int newPeriodCount = 0;
							Date[] periodStartDates = null;
							if (newStartDate != null) {
								newPeriodCount = fixedTerm.calculateNewPeriodCount();
								availablePeriodsCount = this.drawAssignmentDao.getNumberOfAvailablePeriods(timeId,
										template.getLevel(), newStartDate);
								int periodCount = Math.min(newPeriodCount, availablePeriodsCount);
								periodStartDates = this.drawAssignmentDao.getPeriodStartStartingAt(newStartDate,
										periodCount, template.getLevel(), timeId);
								if (periodCount != 0) {
									newEndDate = this.drawAssignmentDao.getPeriodEndDate(timeId, template.getLevel(),
											periodStartDates[periodCount - 1]);
								}
							}

							int totalPeriodAmounts = fixedTerm.getPeriodAmounts().size();
							BigDecimal[] oldAmounts = new BigDecimal[totalPeriodAmounts];
							BigDecimal[] newAmounts = new BigDecimal[totalPeriodAmounts];
							int i = 0;

							for (PeriodAmount amount : fixedTerm.getPeriodAmounts()) {
								oldAmounts[i] = this.parseAmount(amount.getOldAmount(), currencyStyle);
								newAmounts[i] = this.parseAmount(amount.getNewAmount(), currencyStyle);
								++i;
							}

							Message error = this.validateAndSetFixedTermChanges(template, fixedTerm, newStartDate,
									oldStartDate, newEndDate, lockedDate, timeId, oldAmounts, newAmounts, original,
									availablePeriodsCount);
							if (error != null) {
								errors.add(error);
								remainingList.add(original);
							} else {
								for (int var44 = 0; var44 < fixedTerm.getPeriodAmountCount(); ++var44) {
									PeriodAmount amount = fixedTerm.getPeriodAmounts().get(var44);
									if (newAmounts[var44] != null
											&& !amount.getOldAmount().equals(amount.getNewAmount())) {
										amount.setNewAmount(NumericFormat.getNumericCurrencyFormatter(currencyStyle)
												.format(newAmounts[var44]));
									}
								}

								if (fixedTerm.hasStartDateChange()) {
									this.drawAssignmentDao.updateFixedTermStartDate(fixedTerm, newStartDate);

									for (PeriodAmount periodAmount : fixedTerm.getPeriodAmounts()) {
										if (periodAmount.isOldActivated()) {
											this.drawAssignmentDao.deleteFixedTermPeriodAmount(
													fixedTerm.getAssignmentId(),
													this.parseDate(periodAmount.getPeriodStart()),
													periodAmount.getRowVersion());
										}
									}

									Date endDate = this.drawAssignmentDao.getPeriodEndDate(timeId, template.getLevel(),
											periodStartDates[newPeriodCount - 1]);

									for (int var45 = 0; var45 < newPeriodCount; ++var45) {
										Date periodStart = periodStartDates[var45];
										this.drawAssignmentDao.addFixedTermPeriods(fixedTerm.getAssignmentId(),
												periodStart, newAmounts[var45]);
									}

									this.drawAssignmentDao.setFixedTermEndDate(fixedTerm, endDate);
								} else {
									int oldPeriodCount = fixedTerm.calculateOldPeriodCount();
									if (newPeriodCount == 0) {
										this.drawAssignmentDao.clearFixedTerm(fixedTerm.getAssignmentId(),
												fixedTerm.getRowVersion());
										continue;
									}

									Date[] periodSartDates = null;
									if (newPeriodCount > oldPeriodCount) {
										Date start = this
												.parseDate(fixedTerm.getPeriodAmounts().get(0).getPeriodStart());
										periodSartDates = this.drawAssignmentDao.getPeriodStartStartingAt(start,
												newPeriodCount, template.getLevel(), timeId);
									}

									Date lastPeriodStartDate = null;
									i = 0;

									for (PeriodAmount periodAmount : fixedTerm.getPeriodAmounts()) {
										if (!periodAmount.isDirty()) {
											++i;
										} else {
											if (!periodAmount.hasActivationChanges()) {
												this.drawAssignmentDao.updateFixedTermPeriodAmount(
														fixedTerm.getAssignmentId(), periodAmount, newAmounts[i]);
											} else if (periodAmount.isNewActivated()) {
												Date periodStart = periodSartDates[i];
												this.drawAssignmentDao.addFixedTermPeriods(fixedTerm.getAssignmentId(),
														periodStart, newAmounts[i]);
												periodAmount.setPeriodStart(Format.asShortDate(periodStart));
												this.drawAssignmentDao.UpdateFixedTermAmountRowVersion(
														fixedTerm.getAssignmentId(), periodAmount, periodStart);
												lastPeriodStartDate = periodSartDates[i];
											} else {
												this.drawAssignmentDao.deleteFixedTermPeriodAmount(
														fixedTerm.getAssignmentId(),
														this.parseDate(periodAmount.getPeriodStart()),
														periodAmount.getRowVersion());
												if (lastPeriodStartDate == null) {
													lastPeriodStartDate = this.parseDate(
															fixedTerm.getPeriodAmounts().get(i - 1).getPeriodStart());
												}
											}

											periodAmount.setOldAmount(periodAmount.getNewAmount());
											periodAmount.setOldActivated(periodAmount.isNewActivated());
											++i;
										}
									}

									if (lastPeriodStartDate != null) {
										Date endDate = this.drawAssignmentDao.getPeriodEndDate(timeId,
												template.getLevel(), lastPeriodStartDate);
										this.drawAssignmentDao.setFixedTermEndDate(fixedTerm, endDate);
									}
								}

								fixedTerm.updateOriginalValues();
								remainingList.add(fixedTerm);
								this.historyDao.assignRevision();
								this.auditDao.logRevision(new Message(Messages.Key.MODULE_WEB, new Object[0]),
										new Message(Messages.Key.EVENT_DRAW_ASSIGNMENT_MODIFIDED, new Object[0]),
										new Message(Messages.Key.EVENT_DRAW_ASSIGNMENT_MODIFIDED_MESSAGE,
												new Object[] {
														this.getPayeeIDNameString(fixedTerm.getPayeeId(),
																fixedTerm.getPayeeName()),
														drawName, fixedTerm.getTemplateName() }));
							}
						}
					} catch (DatabaseConcurrencyException e) {
						errors.add(e.getMessageObject());
						remainingList.add(original);
					} finally {
						this.historyDao.endRevision();
					}
				}
			}

			return remainingList;
		}
	}

	private Message validateAndSetFixedTermChanges(DrawTemplate template, DrawAssignmentFixedTerm fixedTerm,
			Date newStartDate, Date oldStartDate, Date newEndDate, Date lockedDate, String timeId,
			BigDecimal[] oldAmounts, BigDecimal[] newAmounts, DrawAssignmentFixedTerm original,
			int availablePeriodsCount) {
		Message error = this.getStartDateValidationMessage(template, fixedTerm.getPayeeId(),
				fixedTerm.getAssignmentId(), newStartDate, oldStartDate, newEndDate, lockedDate,
				fixedTerm.getPayeeName());
		if (error != null) {
			return error;
		} else {
			int newPeriodCount = fixedTerm.calculateNewPeriodCount();
			if (newPeriodCount != 0 && availablePeriodsCount < newPeriodCount) {
				return new Message(Messages.Key.DRAW_ASSIGN_ERROR_INVALID_PERIOD,
						new Object[] { fixedTerm.getPayeeName() });
			} else {
				int i = 0;

				for (PeriodAmount periodAmount : fixedTerm.getPeriodAmounts()) {
					if (periodAmount.isDirty()) {
						if (!template.isCanChangeDuration() && periodAmount.hasActivationChanges()) {
							return new Message(Messages.Key.DRAW_ASSIGN_ERROR_PERIOD_FIXED,
									new Object[] { fixedTerm.getPayeeName() });
						}

						if (periodAmount.isNewActivated() || !periodAmount.hasActivationChanges()) {
							if (newAmounts[i] == null) {
								return new Message(Messages.Key.DRAW_ASSIGN_ERROR_INVALID_AMOUNT,
										new Object[] { fixedTerm.getPayeeName() });
							}

							if (original.getPeriodAmounts().get(i).isLocked()) {
								return new Message(Messages.Key.DRAW_ASSIGN_ERROR_LOCKED_PERIOD,
										new Object[] { i + 1, fixedTerm.getPayeeName() });
							}

							if (newAmounts[i].compareTo(BigDecimal.ZERO) < 0) {
								return new Message(Messages.Key.DRAW_ASSIGN_ERROR_NEGATIVE_AMOUNT,
										new Object[] { fixedTerm.getPayeeName() });
							}

							if (newAmounts[i].compareTo(DrawTemplate.MAX_DRAW_AMOUNT) > 0) {
								return new Message(Messages.Key.DRAW_ASSIGN_ERROR_GLOBAL_DRAW_LIMIT,
										new Object[] { fixedTerm.getPayeeName() });
							}

							if (template.getMaxDrawAmount() != null
									&& newAmounts[i].compareTo(template.getMaxDrawAmount()) > 0) {
								return new Message(Messages.Key.DRAW_ASSIGN_ERROR_MAX_AMOUNT,
										new Object[] { fixedTerm.getPayeeName() });
							}

							if (!template.isCanChangeDrawAmount()) {
								boolean addDrawValid = true;
								if (template.isFixedAmount()) {
									addDrawValid = oldAmounts[i] == null
											&& newAmounts[i].compareTo(template.getDrawAmount()) == 0;
								} else if (template.getSchedules().size() > i) {
									addDrawValid = oldAmounts[i] == null
											&& newAmounts[i].compareTo(template.getSchedules().get(i).getAmount()) == 0;
								}

								boolean editDrawValid = oldAmounts[i] != null
										&& oldAmounts[i].compareTo(newAmounts[i]) == 0;
								if (!addDrawValid && !editDrawValid) {
									return new Message(Messages.Key.DRAW_ASSIGN_ERROR_FIXED_AMOUNT,
											new Object[] { fixedTerm.getPayeeName() });
								}
							}

							++i;
						} else if (original.getPeriodAmounts().get(i).isLocked()) {
							return new Message(Messages.Key.DRAW_ASSIGN_ERROR_LOCKED_PERIOD,
									new Object[] { i + 1, fixedTerm.getPayeeName() });
						}
					} else {
						++i;
					}
				}

				return null;
			}
		}
	}

	@Override
	public List<DrawAssignmentOngoing> getOngoingPayees(int drawId, int workflowObjectId, String selectedPayeeId,
			int selectedGroupId, boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) {
		List<DrawAssignmentOngoing> ongoingPayees;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			ongoingPayees = this.getAllOngoingPayees(drawId, workflowObjectId, activeOnly, pageNumber, rowsPerPage,
					sortColumn, descending);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			ongoingPayees = this.getOngoingAssignmentsForPayee(selectedPayeeId, drawId, workflowObjectId, activeOnly,
					pageNumber, rowsPerPage, sortColumn, descending);
		} else {
			ongoingPayees = this.getOngoingPayees(selectedGroupId, drawId, workflowObjectId, activeOnly, pageNumber,
					rowsPerPage, sortColumn, descending);
		}

		return ongoingPayees;
	}

	@Override
	public int getOngoingPayeesPageCount(int drawId, int rowsPerPage, int workflowObjectId, String selectedPayeeId,
			int selectedGroupId, boolean activeOnly) {
		int rowCount;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			rowCount = this.getAllOngoingPayeesCount(drawId, workflowObjectId, activeOnly);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			rowCount = 1;
		} else {
			rowCount = this.getOngoingPayeesCount(selectedGroupId, drawId, workflowObjectId, activeOnly);
		}

		return this.getPageCount(rowCount, rowsPerPage);
	}

	private List<DrawAssignmentOngoing> getOngoingAssignmentsForPayee(String payeeId, int drawId, int workflowObjectId,
			boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		return !this.isViewablePayee(drawId, workflowObjectId, payeeId) ? new LinkedList()
				: this.drawAssignmentDao.getOngoingAssignmentsForPayee(payeeId, drawId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending);
	}

	private List<DrawAssignmentOngoing> getOngoingPayees(int workflowGroupId, int drawId, int workflowObjectId,
			boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? new LinkedList()
				: this.drawAssignmentDao.getOngoingPayees(workflowGroupId, drawId, activeOnly, pageNumber, rowsPerPage,
						sortColumn, descending);
	}

	private List<DrawAssignmentOngoing> getAllOngoingPayees(int drawId, int workflowObjectId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		QueryDefinition resctrictionQuery = this.getRestrictionQuery(drawId);
		return resctrictionQuery != null
				? this.drawAssignmentDao.getOngoingPayees(resctrictionQuery, drawId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending)
				: this.drawAssignmentDao.getOngoingPayeesAllGroups(drawId, workflowObjectId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending);
	}

	private int getOngoingPayeesCount(int workflowGroupId, int drawId, int workflowObjectId, boolean activeOnly) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? 0
				: this.drawAssignmentDao.getOngoingPayeesCount(workflowGroupId, drawId, activeOnly);
	}

	private int getAllOngoingPayeesCount(int drawId, int workflowObjectId, boolean activeOnly) {
		QueryDefinition resctrictionQuery = this.getRestrictionQuery(drawId);
		return resctrictionQuery != null
				? this.drawAssignmentDao.getOngoingPayeesCount(resctrictionQuery, drawId, activeOnly)
				: this.drawAssignmentDao.getOngoingPayeesAllGroupsCount(drawId, workflowObjectId, activeOnly);
	}

	@Override
	public List<DrawAssignmentFixedTerm> getFixedTermPayees(int drawId, int workflowObjectId, String selectedPayeeId,
			int selectedGroupId, boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn,
			boolean descending) {
		List<DrawAssignmentFixedTerm> fixedTermPayees;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			fixedTermPayees = this.getAllFixedTermPayees(drawId, workflowObjectId, activeOnly, pageNumber, rowsPerPage,
					sortColumn, descending);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			fixedTermPayees = this.getFixedTermListForPayee(selectedPayeeId, drawId, workflowObjectId, activeOnly,
					pageNumber, rowsPerPage, sortColumn, descending);
		} else {
			fixedTermPayees = this.getFixedTermPayees(selectedGroupId, drawId, workflowObjectId, activeOnly, pageNumber,
					rowsPerPage, sortColumn, descending);
		}

		return fixedTermPayees;
	}

	@Override
	public int getFixedTermPayeesPageCount(int drawId, int rowsPerPage, int workflowObjectId, String selectedPayeeId,
			int selectedGroupId, boolean activeOnly) {
		int rowCount;
		if ((selectedPayeeId == null || selectedPayeeId.length() == 0) && selectedGroupId == 0) {
			rowCount = this.getAllFixedTermPayeesCount(drawId, workflowObjectId, activeOnly);
		} else if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			rowCount = 1;
		} else {
			rowCount = this.getFixedTermPayeesCount(selectedGroupId, drawId, workflowObjectId, activeOnly);
		}

		return this.getPageCount(rowCount, rowsPerPage);
	}

	private List<DrawAssignmentFixedTerm> getFixedTermListForPayee(String payeeId, int drawId, int workflowObjectId,
			boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		return !this.isViewablePayee(drawId, workflowObjectId, payeeId) ? new LinkedList()
				: this.drawAssignmentDao.getFixedTermListForPayee(payeeId, drawId, activeOnly, pageNumber, rowsPerPage,
						sortColumn, descending);
	}

	private List<DrawAssignmentFixedTerm> getFixedTermPayees(int workflowGroupId, int drawId, int workflowObjectId,
			boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? new LinkedList()
				: this.drawAssignmentDao.getFixedTermPayees(workflowGroupId, drawId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending);
	}

	private int getFixedTermPayeesCount(int workflowGroupId, int drawId, int workflowObjectId, boolean activeOnly) {
		return !this.isViewableGroup(drawId, workflowObjectId, workflowGroupId) ? 0
				: this.drawAssignmentDao.getFixedTermPayeesCount(workflowGroupId, drawId, activeOnly);
	}

	private List<DrawAssignmentFixedTerm> getAllFixedTermPayees(int drawId, int workflowObjectId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null
				? this.drawAssignmentDao.getFixedTermPayees(restrictionQuery, drawId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending)
				: this.drawAssignmentDao.getFixedTermPayeesAllGroups(drawId, workflowObjectId, activeOnly, pageNumber,
						rowsPerPage, sortColumn, descending);
	}

	private int getAllFixedTermPayeesCount(int drawId, int workflowObjectId, boolean activeOnly) {
		QueryDefinition restrictionQuery = this.getRestrictionQuery(drawId);
		return restrictionQuery != null
				? this.drawAssignmentDao.getFixedTermPayeesCount(restrictionQuery, drawId, activeOnly)
				: this.drawAssignmentDao.getFixedTermPayeesAllGroupsCount(drawId, workflowObjectId, activeOnly);
	}

	private QueryDefinition getRestrictionQuery(int drawId) {
		DrawAssignmentWebSettings settings = this.drawAssignmentDao.getSettings(drawId);
		if (!settings.isUseRestriction()) {
			return null;
		} else {
			QueryDefinition query = settings.getRestriction().getQuery();
			String alias = "WebUser_";

			for (Join join : query.getJoins()) {
				if (query.getTableName(join.getSource().getName()).equals("_Local_WebUser")) {
					alias = join.getSource().getName();
					query.getJoins().remove(join);
					break;
				}
			}

			QueryDefinition webUserQuery = getWebUserQuery();
			query.crossJoin(webUserQuery, alias);
			return query;
		}
	}

	@Override
	public int getRowsPerPage(int drawId) {
		DrawAssignmentWebSettings settings = this.drawAssignmentDao.getSettings(drawId);
		return settings.getRowsPerPage();
	}

	@Override
	public boolean isGroupSelectionAllowed(int drawId) {
		DrawAssignmentWebSettings settings = this.drawAssignmentDao.getSettings(drawId);
		return settings.isAllowGroupSelection();
	}

	private DrawTemplate getDrawTemplate(int templateId) throws DatabaseConcurrencyException {
		DrawTemplate template = null;
		if (!this.drawTemplateMap.containsKey(templateId)) {
			template = this.drawAssignmentDao.getDrawTemplate(templateId);
			this.drawTemplateMap.put(templateId, template);
		} else {
			template = this.drawTemplateMap.get(templateId);
		}

		return template;
	}

	private int getPageCount(int rowCount, int rowsPerPage) {
		return (new Double(Math.ceil((double) rowCount / (double) rowsPerPage))).intValue();
	}

	private String getPayeeIDNameString(String payeeId, String payeeName) {
		return "(" + payeeId + ") " + payeeName;
	}

	@Override
	public List<DrawName> getViewableDraws() {
		return this.drawAssignmentDao.getViewableDraws();
	}

	@Override
	public String getPeriodAmount(int drawId, int templateId, int periodIndex) {
		NumericFormat.Style numericStyle = this.drawAssignmentDao.getSettings(drawId).getNumericStyle();
		NumberFormat currencyFormat = NumericFormat.getNumericCurrencyFormatter(numericStyle);
		BigDecimal amount = null;

		try {
			DrawTemplate template = this.getDrawTemplate(templateId);
			if (template.isFixedAmount()) {
				amount = template.getDrawAmount();
			} else if (template.getSchedules().size() > periodIndex) {
				amount = template.getSchedules().get(periodIndex).getAmount();
			}

			return amount != null ? currencyFormat.format(amount) : "";
		} catch (DatabaseConcurrencyException var8) {
			return "";
		}
	}

	private Date parseDate(String dateString) {
		Date date = null;
		if (dateString != null && !dateString.isEmpty()) {
			date = Parse.date(dateString);
		}

		if (date != null && (date.after(Constants.MAX_DATE) || date.before(Constants.MIN_DATE))) {
			date = null;
		}

		return date;
	}

	@Override
	public int getWorkflowObjectId(String id, WorkflowObject.Type type) {
		return this.drawAssignmentDao.getWorkflowObjectId(id, type);
	}
}
