package com.varicent.draws.web;

import java.util.ArrayList;
import java.util.List;

import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;

public class UnassignedDrawCommand extends DrawAssignmentCommand {
	private List<DrawAssignmentUnassignedPayee> unassignedPayees = new ArrayList();

	public List<DrawAssignmentUnassignedPayee> getUnassignedPayees() {
		return this.unassignedPayees;
	}

	public void setUnassignedPayees(List<DrawAssignmentUnassignedPayee> unassignedPayees) {
		this.unassignedPayees = unassignedPayees;
	}
}
