package com.varicent.BPM.domain;

public class BPMProcessNode extends BPMNode {
	private int schedulerFolderID;

	public BPMProcessNode(int nodeID, int swimLaneID, String name, BPMPath[] paths, int schedulerFolderID) {
		super(nodeID, swimLaneID, name, paths);
		this.schedulerFolderID = schedulerFolderID;
	}

	public int getSchedulerFolderID() {
		return this.schedulerFolderID;
	}
}
