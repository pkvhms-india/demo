package com.varicent.core.database.support;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;
import java.util.Date;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;

public class RowMapperUtil {
	private static final RowMapper<Date> DATE_MAPPER = new RowMapper<Date>() {
		@Override
		public Date mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getTimestamp(1);
		}
	};
	private static final RowMapper<Integer> INTEGER_MAPPER = new RowMapper<Integer>() {
		@Override
		public Integer mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getInt(1);
		}
	};
	private static final RowMapper<Object> OBJECT_MAPPER = new RowMapper<Object>() {
		@Override
		public Object mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getObject(1);
		}
	};
	private static final RowMapper<SelectOption> OPTION_MAPPER = new RowMapper<SelectOption>() {
		@Override
		public SelectOption mapRow(ResultSet rs, int rowNumber) throws SQLException {
			Object value = rs.getObject(1);
			Object name = null;
			if (rs.getMetaData().getColumnCount() > 1) {
				name = rs.getObject(2);
			}

			if (value instanceof Clob) {
				value = RowMapperUtil.clobToString((Clob) value);
			}

			return new SelectOption(name == null ? null : Format.asValueString(name), Format.asValueString(value));
		}
	};
	private static final RowMapper<Payee> PAYEE_MAPPER = new RowMapper<Payee>() {
		@Override
		public Payee mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new Payee(rs.getString("PayeeID_"), rs.getString("Name_"), rs.getString("Email_"));
		}
	};
	private static final RowMapper<String> STRING_MAPPER = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getString(1);
		}
	};
	private static final RowMapper<String> MULTI_VALUE_STRING_MAPPER = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getObject(1) instanceof BigDecimal
					? Format.asValueString(rs.getObject(1), NumericFormat.DECIMAL_SIGNIFICANT)
					: Format.asValueString(rs.getObject(1));
		}
	};
	private static final RowMapper<Map.Entry<Integer, String>> INT_STRING_ENTRTY_MAPPER = new RowMapper<Map.Entry<Integer, String>>() {
		@Override
		public Map.Entry<Integer, String> mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new AbstractMap.SimpleEntry(rs.getInt(1), rs.getString(2));
		}
	};
	private static final RowMapper<Long> LONG_MAPPER = new RowMapper<Long>() {
		@Override
		public Long mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getLong(1);
		}
	};

	public static RowMapper<Date> getDateMapper() {
		return DATE_MAPPER;
	}

	public static RowMapper<Integer> getIntegerMapper() {
		return INTEGER_MAPPER;
	}

	public static RowMapper<Object> getObjectMapper() {
		return OBJECT_MAPPER;
	}

	public static RowMapper<SelectOption> getOptionMapper() {
		return OPTION_MAPPER;
	}

	public static RowMapper<Payee> getPayeeMapper() {
		return PAYEE_MAPPER;
	}

	public static RowMapper<String> getStringMapper() {
		return STRING_MAPPER;
	}

	public static RowMapper<String> getMultiValueStringMapper() {
		return MULTI_VALUE_STRING_MAPPER;
	}

	public static RowMapper<Map.Entry<Integer, String>> getEntryMapper() {
		return INT_STRING_ENTRTY_MAPPER;
	}

	public static RowMapper<Long> getLongMapper() {
		return LONG_MAPPER;
	}

	private RowMapperUtil() {
	}

	private static String clobToString(Clob data) {
		StringBuilder sb = new StringBuilder();
		String newline = System.getProperty("line.separator");

		try {
			Reader reader = data.getCharacterStream();
			BufferedReader br = new BufferedReader(reader);

			for (String line = br.readLine(); line != null; line = br.readLine()) {
				sb.append(line);
				sb.append(newline);
			}

			br.close();
		} catch (SQLException var6) {
		} catch (IOException var7) {
		}

		return sb.toString();
	}
}
