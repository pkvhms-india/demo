package com.varicent.core.text;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.reporting.domain.XMLStreamUtility;

public class NumericFormat {
	public static final NumericFormat DECIMAL_FIXED;
	public static final NumericFormat DECIMAL_SIGNIFICANT;
	private final Style style;
	private final int scaleMin;
	private final int scaleMax;

	public NumericFormat(int style, int scale) {
		this(NumericFormat.Style.values()[style], scale);
	}

	public NumericFormat(Style style, int scale) {
		this(style, scale, scale);
	}

	public NumericFormat(Style style, int scaleMin, int scaleMax) {
		this.style = style;
		this.scaleMin = scaleMin;
		this.scaleMax = scaleMax;
	}

	public static NumericFormat ReadNumericFormatFromXml(XMLStreamReader streamReader) throws XMLStreamException {
		streamReader.nextTag();
		String style = XMLStreamUtility.getCurrentNodeValue(streamReader);
		String precision = XMLStreamUtility.getCurrentNodeValue(streamReader);
		streamReader.nextTag();
		NumericFormat format = new NumericFormat(Integer.parseInt(style), Integer.parseInt(precision));
		return format;
	}

	public String asString(BigDecimal value) {
		return this.asString(value, true);
	}

	public String asString(BigDecimal value, boolean useGrouping) {
		BigDecimal expectedValue;
		if (this.style == NumericFormat.Style.PERCENT) {
			expectedValue = value.multiply(new BigDecimal(100));
			expectedValue = expectedValue.setScale(this.scaleMax, 4);
		} else {
			expectedValue = value.setScale(this.scaleMax, 4);
		}

		if (expectedValue.compareTo(BigDecimal.ZERO) == 0) {
			value = BigDecimal.ZERO;
		}

		NumberFormat formatter = getNumericCurrencyFormatter(this.style);
		formatter.setRoundingMode(RoundingMode.HALF_UP);
		formatter.setGroupingUsed(useGrouping);
		formatter.setMinimumFractionDigits(this.scaleMin);
		formatter.setMaximumFractionDigits(this.scaleMax);
		return formatter.format(value);
	}

	public int getScale() {
		return this.scaleMin;
	}

	public int getScaleMin() {
		return this.scaleMin;
	}

	public int getScaleMax() {
		return this.scaleMax;
	}

	public Style getStyle() {
		return this.style;
	}

	public static NumberFormat getNumericCurrencyFormatter(Style style) {
		switch (style) {
		case NUMBER:
			return NumberFormat.getInstance(LocaleContextHolder.getLocale());
		case PERCENT:
			return NumberFormat.getPercentInstance(LocaleContextHolder.getLocale());
		case DOLLARS:
			return NumberFormat.getCurrencyInstance(Locale.US);
		case FRENCHCANADIANDOLLARS:
			NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.CANADA_FRENCH);
			DecimalFormat df = (DecimalFormat) nf;
			df.applyPattern("#,##0.00 $;(#,##0.00 $)");
			return df;
		case POUNDS:
			return NumberFormat.getCurrencyInstance(Locale.UK);
		case EURO:
			return NumberFormat.getCurrencyInstance(Locale.FRANCE);
		case YEN:
			return NumberFormat.getCurrencyInstance(Locale.JAPAN);
		case YUAN:
			return NumberFormat.getCurrencyInstance(Locale.CHINA);
		case RAND:
			return NumberFormat.getCurrencyInstance(new Locale("en", "ZA"));
		default:
			return null;
		}
	}

	static {
		DECIMAL_FIXED = new NumericFormat(NumericFormat.Style.NUMBER, 2);
		DECIMAL_SIGNIFICANT = new NumericFormat(NumericFormat.Style.NUMBER, 2, 14);
	}

	public static enum Style {
		NUMBER, PERCENT, DOLLARS, FRENCHCANADIANDOLLARS, POUNDS, EURO, YEN, YUAN, RAND;
	}
}
