package com.varicent.reporting.dao.Expander;

import java.util.List;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.jdbc.core.JdbcOperations;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.PortSourceMapper;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.reporting.web.ReportingCommand;
import com.varicent.security.domain.UserAccount;

public class SignatureControlExpander extends BaseExpander {
	private static final String WEB_REPORT_SIGNATURE = "WebReportSignature";
	private static final String LOG_WEB_REPORT_SIGNATURE = "LogWebReportSignature";
	private static final String WEB_REPORT_ID = "WebReportID";
	private static final String SIGNATURE_ID = "SignatureID";
	private static final String AGREEMENT_TEXT = "AgreementText";
	private static final String STATUS = "Status";
	private static final String PAYEE_ID_ = "PayeeID_";
	private static final String ID = "ID";
	private JdbcOperations operations;
	Messages messages;
	private final boolean resetSigStatus;

	public SignatureControlExpander(XMLStreamReader streamReader, DataSource ds, Messages messages,
			ReportingCommand cmd) {
		super(streamReader);
		this.operations = Database.getOperations(ds);
		this.messages = messages;
		this.resetSigStatus = cmd.getResetSigStatus();
		if (!streamReader.getLocalName().equals("SignatureControl")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("SignatureControl")) {
			this.streamReader.nextTag();
			writer.writeStartElement("SignatureControl");
			String signatureId = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("SignatureID");
			writer.writeCharacters("SIG_ID_" + signatureId);
			writer.writeEndElement();
			writer.writeStartElement("SignatureIDValue");
			writer.writeCharacters(signatureId);
			writer.writeEndElement();
			writer.writeStartElement("StatusID");
			writer.writeCharacters("SIG_STATUS_" + signatureId);
			writer.writeEndElement();
			writer.writeStartElement("AgreementText");
			writer.writeCharacters(this.getAgreementText(scope, signatureId));
			writer.writeEndElement();
			writer.writeStartElement("AcceptText");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.ACCEPT, LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("RejectText");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.REJECT, LocaleContextHolder.getLocale()));
			writer.writeEndElement();
			writer.writeStartElement("RejectedStatus");
			writer.writeCharacters(this.isMostRecentStatusRejected(scope, signatureId));
			writer.writeEndElement();
			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}

	private String getAgreementText(Scope scope, String signatureId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("WebReportSignature");
		query.select("WebReportSignature", "AgreementText");
		query.newConstraint("WebReportSignature", "WebReportID", Constraint.Operator.Equals, scope.getReportID());
		query.newConstraint("WebReportSignature", "SignatureID", Constraint.Operator.Equals, signatureId);
		query = PortSourceMapper.mapQuery(query, scope.getPorts(), scope.getPortResolver());
		List<SelectOption> options = this.operations.query(qb.toSql(query), RowMapperUtil.getOptionMapper());
		return options.size() < 1 ? "" : options.get(0).toString();
	}

	private String isMostRecentStatusRejected(Scope scope, String signatureId) {
		if (this.resetSigStatus) {
			return "true";
		} else {
			QueryBuilder qb = Database.getQueryBuilder();
			QueryDefinition query = new QueryDefinition("LogWebReportSignature");
			query.select("LogWebReportSignature", "Status");
			query.newConstraint("LogWebReportSignature", "WebReportID", Constraint.Operator.Equals,
					scope.getReportID());
			query.newConstraint("LogWebReportSignature", "SignatureID", Constraint.Operator.Equals, signatureId);
			query.newConstraint("LogWebReportSignature", "PayeeID_", Constraint.Operator.Equals,
					UserAccount.getCurrent().getPayeeId());
			query.orderBy("ID", true);
			query = PortSourceMapper.mapQuery(query, scope.getPorts(), scope.getPortResolver());
			List<SelectOption> options = this.operations.query(qb.toSql(query), RowMapperUtil.getOptionMapper());
			return options.size() >= 1 && !options.get(0).toString().equals("0") ? "false" : "true";
		}
	}
}
