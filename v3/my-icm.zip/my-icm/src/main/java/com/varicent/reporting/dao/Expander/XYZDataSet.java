package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class XYZDataSet {
	private String zCol;
	private String xCol;
	private String yCol;
	private String series;
	List<XYZSet> sets;
	private ColumnLink link;
	private boolean isPercentage;
	private boolean isSYPercentage;

	public XYZDataSet(String series, String xColumn, String yColumn, String zColumn, ColumnLink link) {
		this.series = series;
		this.sets = new ArrayList();
		this.xCol = xColumn;
		this.yCol = yColumn;
		this.zCol = zColumn;
		this.link = link;
	}

	public String getXColumn() {
		return this.xCol;
	}

	public String getYColumn() {
		return this.yCol;
	}

	public String getZColumn() {
		return this.zCol;
	}

	public void add(String x, String y, String z) {
		this.sets.add(new XYZSet(x, y, z));
	}

	public void setLink(ColumnLink link) {
		this.link = link;
	}

	public String getName() {
		return this.series;
	}

	public void setPercentage(boolean isPerc) {
		this.isPercentage = isPerc;
	}

	public void setSYPercentage(boolean isPerc) {
		this.isSYPercentage = isPerc;
	}

	public void writeStartElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<dataset seriesName='" + this.series + "' >");
	}

	public void writeSet(XMLStreamWriter writer, int index, DataTable data, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.sets.get(index).writeSet(writer, index, data, scope, this.link, this.series, this.isPercentage,
				this.isSYPercentage);
	}

	public void writeEndElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</dataset>");
	}
}
