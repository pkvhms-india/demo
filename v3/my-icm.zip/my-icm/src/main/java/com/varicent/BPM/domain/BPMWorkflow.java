package com.varicent.BPM.domain;

public class BPMWorkflow {
	private int id;
	private String name;
	private int reportID;
	private boolean isSingleInstance;
	private BPMWorkflowParameter[] parameters;

	public BPMWorkflow(int id, String name, int reportID, boolean isSingleInstance, BPMWorkflowParameter[] parameters) {
		this.id = id;
		this.name = name;
		this.reportID = reportID;
		this.isSingleInstance = isSingleInstance;
		this.parameters = parameters;
	}

	public int getID() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public int getReportID() {
		return this.reportID;
	}

	public boolean isSingleInstance() {
		return this.isSingleInstance;
	}

	public BPMWorkflowParameter[] getParameters() {
		return this.parameters;
	}

	public void setParameters(BPMWorkflowParameter[] parameters) {
		this.parameters = parameters;
	}
}
