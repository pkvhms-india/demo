package com.varicent.api;

import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth.common.OAuthException;
import org.springframework.security.oauth.common.signature.UnsupportedSignatureMethodException;
import org.springframework.security.oauth.provider.token.ExpiredOAuthTokenException;
import org.springframework.security.oauth.provider.token.InvalidOAuthTokenException;
import org.springframework.stereotype.Component;

import com.varicent.core.i18n.Messages;
import com.varicent.reporting.domain.exceptions.APIResourceNotFoundException;
import com.varicent.reporting.domain.exceptions.InvalidAPIRequestException;

@Component
public class APIExceptionResponseTranslator {
	private Logger logger = LoggerFactory.getLogger(APIExceptionResponseTranslator.class);
	private Messages messages;

	@Autowired
	public void setMessages(Messages messages) {
		this.messages = messages;
	}

	public APIExceptionResponseInfo getExceptionResponseInfo(Exception exception) {
		String exceptionResponseMessage = "An unknown exception has occured.";
		int statusCode = 500;
		if (exception instanceof AuthenticationException) {
			if (exception instanceof OAuthException) {
				exceptionResponseMessage = exception.getMessage();
				if (!(exception instanceof InvalidOAuthTokenException)
						&& !(exception instanceof ExpiredOAuthTokenException)) {
					statusCode = 400;
				} else {
					statusCode = 401;
				}
			} else if (exception.getCause() instanceof UnsupportedSignatureMethodException) {
				exceptionResponseMessage = exception.getCause().getMessage();
				statusCode = 400;
			} else {
				if (this.logger.isDebugEnabled()) {
					this.logger.debug("Translating AuthenticationException: {}", exception.getMessage());
				}

				exceptionResponseMessage = this.messages.getMessage(Messages.Key.UNAUTHORIZED);
				statusCode = 401;
			}
		} else if (exception instanceof AccessDeniedException) {
			exceptionResponseMessage = this.messages.getMessage(Messages.Key.FORBIDDEN);
			statusCode = 403;
		} else if (exception instanceof InvalidAPIRequestException) {
			exceptionResponseMessage = exception.getMessage();
			statusCode = 400;
		} else if (exception instanceof DataAccessException) {
			exceptionResponseMessage = this.messages.getMessage(Messages.Key.ERROR_API_DATABASE);
			statusCode = 500;
		} else if (exception instanceof APIResourceNotFoundException) {
			exceptionResponseMessage = exception.getMessage();
			statusCode = 404;
		} else {
			exceptionResponseMessage = exception.getMessage();
			statusCode = 500;
		}

		return new APIExceptionResponseInfo(new APIExceptionResponse(exceptionResponseMessage), statusCode);
	}

	public Object getSerializableExceptionResponse(APIExceptionResponse exception) {
		return Collections.singletonMap("error", exception);
	}
}
