package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.Scope;

public abstract class BaseExpander {
	protected XMLStreamReader streamReader;

	public BaseExpander(XMLStreamReader stream) {
		this.streamReader = stream;
	}

	public void read(XMLStreamWriter stream, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		this.copyCurrentNode(stream);
	}

	public void consumeCurrentNode() {
		try {
			if (this.streamReader.getEventType() == 1) {
				this.streamReader.next();
				if (this.streamReader.isWhiteSpace() && this.streamReader.getEventType() == 6) {
					this.streamReader.nextTag();
				}

				while (this.streamReader.getEventType() == 1) {
					this.consumeCurrentNode();
					if (this.streamReader.isWhiteSpace() && this.streamReader.getEventType() == 6) {
						this.streamReader.nextTag();
					}
				}

				while (this.streamReader.getEventType() == 4) {
					this.streamReader.getText();
					this.streamReader.getText();
					this.streamReader.next();
				}

				this.streamReader.next();
			}
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	protected int copyCurrentNode(XMLStreamWriter writer) {
		try {
			if (this.streamReader.getEventType() != 1) {
				return 0;
			} else {
				int length = 0;
				String nodeName = this.streamReader.getLocalName();
				writer.writeStartElement(nodeName);
				length += nodeName.length();
				int i = 0;

				for (int n = this.streamReader.getAttributeCount(); i < n; ++i) {
					String attribName = this.streamReader.getAttributeLocalName(i);
					String attribValue = this.streamReader.getAttributeValue(i);
					writer.writeAttribute(attribName, attribValue);
					length += 1 + attribName.length() + 1 + attribValue.length();
				}

				this.streamReader.next();
				if (this.streamReader.isWhiteSpace() && this.streamReader.getEventType() == 6) {
					this.streamReader.nextTag();
				}

				while (this.streamReader.getEventType() == 1) {
					length += this.copyCurrentNode(writer);
					if (this.streamReader.isWhiteSpace() && this.streamReader.getEventType() == 6) {
						this.streamReader.nextTag();
					}
				}

				while (this.streamReader.getEventType() == 4) {
					writer.writeCharacters(this.streamReader.getText());
					length += this.streamReader.getText().length();
					this.streamReader.next();
				}

				if (this.streamReader.getEventType() == 2) {
					writer.writeEndElement();
					length += 3 + nodeName.length();
				}

				this.streamReader.next();
				return length;
			}
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	protected void expandColorsNode(XMLStreamWriter writer) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		this.expandColorsNode(sb);
		writer.writeCharacters(sb.toString());
	}

	protected void expandColorsNode(StringBuilder sb) throws XMLStreamException {
		if (!this.streamReader.getLocalName().equals("customColors")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			sb.append("<customColors>");
			this.streamReader.nextTag();

			while (this.streamReader.getLocalName().equals("customColor")) {
				sb.append("<customColor ");
				String color = this.streamReader.getAttributeValue((String) null, "color");
				if (color != null) {
					sb.append("color='" + color + "' ");
				}

				sb.append("/>");
				this.streamReader.nextTag();
				this.streamReader.nextTag();
			}

			this.streamReader.nextTag();
			sb.append("</customColors>");
		}
	}
}
