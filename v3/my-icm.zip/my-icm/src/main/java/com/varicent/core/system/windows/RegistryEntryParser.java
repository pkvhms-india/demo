package com.varicent.core.system.windows;

public interface RegistryEntryParser {
	Object parse(String var1);
}
