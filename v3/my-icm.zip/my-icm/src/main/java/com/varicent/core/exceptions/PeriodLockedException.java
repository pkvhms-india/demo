package com.varicent.core.exceptions;

public class PeriodLockedException extends Exception {
	private static final long serialVersionUID = 1L;

	public PeriodLockedException() {
	}

	public PeriodLockedException(String message) {
		super(message);
	}

	public PeriodLockedException(String message, Throwable cause) {
		super(message, cause);
	}

	public PeriodLockedException(Throwable cause) {
		super(cause);
	}
}
