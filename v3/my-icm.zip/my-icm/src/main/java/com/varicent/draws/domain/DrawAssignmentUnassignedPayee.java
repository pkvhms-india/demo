package com.varicent.draws.domain;

import java.util.Date;

import com.varicent.core.text.Format;

public class DrawAssignmentUnassignedPayee implements Comparable<DrawAssignmentUnassignedPayee> {
	private String id;
	private String name;
	private String title;
	private String parent;
	private String reportsTo;
	private String dateOfHireFormatted;
	private int templateId;

	public DrawAssignmentUnassignedPayee() {
	}

	public DrawAssignmentUnassignedPayee(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public DrawAssignmentUnassignedPayee(String id, String name, String title, String parent, String reportsTo,
			Date dateOfHire) {
		this(id, name);
		this.title = title;
		this.parent = parent;
		this.reportsTo = reportsTo;
		if (dateOfHire != null) {
			this.dateOfHireFormatted = Format.asShortDate(dateOfHire);
		}

	}

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getTitle() {
		return this.title;
	}

	public String getParent() {
		return this.parent;
	}

	public String getReportsTo() {
		return this.reportsTo;
	}

	public int getTemplateId() {
		return this.templateId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public void setReportsTo(String reportsTo) {
		this.reportsTo = reportsTo;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public String getDateOfHireFormatted() {
		return this.dateOfHireFormatted;
	}

	public void setDateOfHireFormatted(String dateOfHireFormatted) {
		this.dateOfHireFormatted = dateOfHireFormatted;
	}

	@Override
	public String toString() {
		return Format.asObjectString(this.id, this.name);
	}

	@Override
	public int compareTo(DrawAssignmentUnassignedPayee o) {
		int diff = o.getId().compareTo(o.getId());
		if (diff != 0) {
			return diff;
		} else {
			if ((this.getDateOfHireFormatted() == null || this.getDateOfHireFormatted().isEmpty())
					&& o.getDateOfHireFormatted() != null && !o.getDateOfHireFormatted().isEmpty()) {
				diff = 1;
			} else if ((o.getDateOfHireFormatted() == null || o.getDateOfHireFormatted().isEmpty())
					&& this.getDateOfHireFormatted() != null && !this.getDateOfHireFormatted().isEmpty()) {
				diff = -1;
			} else if (o.getDateOfHireFormatted() != null && !o.getDateOfHireFormatted().isEmpty()
					|| this.getDateOfHireFormatted() != null && !this.getDateOfHireFormatted().isEmpty()) {
				diff = this.getDateOfHireFormatted().compareTo(o.getDateOfHireFormatted());
			} else {
				diff = 0;
			}

			return diff;
		}
	}
}
