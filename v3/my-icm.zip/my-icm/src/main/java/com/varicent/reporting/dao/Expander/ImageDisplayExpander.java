package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.Image;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class ImageDisplayExpander extends BaseExpander {
	public ImageDisplayExpander(XMLStreamReader stream) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("ImageDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("ImageDisplay")) {
			writer.writeStartElement("ImageDisplay");
			this.streamReader.nextTag();
			XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String imageIdString = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("ImageID");
			writer.writeCharacters(imageIdString);
			writer.writeEndElement();
			int imageId = Integer.parseInt(imageIdString);
			int reportId = scope.getReportID();
			String path = Image.GetImageUrl(reportId, imageId);
			writer.writeStartElement("ImagePath");
			writer.writeCharacters(path);
			writer.writeEndElement();
			super.copyCurrentNode(writer);
			if (this.streamReader.getLocalName().equals("Link")) {
				LinkExpander expander = new LinkExpander(this.streamReader);
				expander.read(writer, scope, permitted, editable);
			}

			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
