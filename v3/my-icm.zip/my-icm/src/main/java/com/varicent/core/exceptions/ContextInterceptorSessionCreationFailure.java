package com.varicent.core.exceptions;

public class ContextInterceptorSessionCreationFailure extends IllegalStateException {
	private static final long serialVersionUID = 1L;

	public ContextInterceptorSessionCreationFailure(IllegalStateException innerException) {
		super(innerException);
	}
}
