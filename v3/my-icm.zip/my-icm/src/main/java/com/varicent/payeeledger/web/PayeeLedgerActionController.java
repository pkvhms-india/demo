package com.varicent.payeeledger.web;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.varicent.common.tab.domain.Tab;
import com.varicent.common.tab.domain.TabObject;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.text.Format;
import com.varicent.payeeledger.service.PayeeLedger;

@Controller
public class PayeeLedgerActionController {
	private static final String DETAIL_VIEW = "redirect:/ledger/detail.html";
	private static final String SUMMARY_VIEW = "redirect:/ledger/summary.html";
	private static final String DETAIL_EXCEL_VIEW = "detailExcelView";
	private static final String SUMMARY_EXCEL_VIEW = "summaryExcelView";
	private static final String EXPORT_FILENAME_XLS = "ledger-{0}.xls";
	private static final String EXPORT_FILENAME_XLSX = "ledger-{0}.xlsx";
	private static final String ACTIVE_TAB_ATTRIBUTE = "activeTab";
	private final PayeeLedger detailLedger;
	private final PayeeLedger summaryLedger;

	@Autowired
	public PayeeLedgerActionController(@Qualifier("detailLedger") PayeeLedger detailLedger,
			@Qualifier("summaryLedger") PayeeLedger summaryLedger) {
		this.detailLedger = detailLedger;
		this.summaryLedger = summaryLedger;
	}

	@RequestMapping({ "/ledger/detail/export.do" })
	public ModelAndView exportDetail(@ModelAttribute("command") PayeeLedgerCommand cmd, HttpServletRequest request,
			HttpServletResponse response) {
		return this.export(this.detailLedger, cmd, request, response);
	}

	@RequestMapping({ "/ledger/summary/export.do" })
	public ModelAndView exportSummary(@ModelAttribute("command") PayeeLedgerCommand cmd, HttpServletRequest request,
			HttpServletResponse response) {
		return this.export(this.summaryLedger, cmd, request, response);
	}

	private ModelAndView export(PayeeLedger ledger, PayeeLedgerCommand cmd, HttpServletRequest request,
			HttpServletResponse response) {
		if (!cmd.hasPlanId() && this.hasObjectId(request)) {
			cmd.setPlanId(this.getObjectId(request));
		}

		if (!cmd.checkAndUpdateToken()) {
			return new ModelAndView(this.getView(ledger));
		} else {
			String planId = cmd.getPlanId();
			String payeeId = cmd.getPayeeId();
			int periodIndex = cmd.getPeriodIndex();
			List<TimePeriod> periods = ledger.getPeriods(planId);
			TimePeriod selectedPeriod = null;
			if (periodIndex >= 0 && !ledger.isSummary() && periods.size() > periodIndex) {
				selectedPeriod = periods.get(periodIndex);
			}

			List<DataRow> rows = ledger.getLedger(planId, payeeId, selectedPeriod, false);
			if (rows.isEmpty()) {
				return new ModelAndView(this.getView(ledger));
			} else {
				ModelAndView mav = new ModelAndView(this.getExcelView(ledger));
				mav.addObject("rows", rows);
				if (planId != null) {
					mav.addObject("plan", ledger.getPlan(planId));
				}

				if (payeeId != null) {
					mav.addObject("payee", ledger.getPayee(payeeId));
				}

				boolean isXLSXExport = cmd.getIsXLSXExport();
				String fileName = MessageFormat.format(isXLSXExport ? "ledger-{0}.xlsx" : "ledger-{0}.xls",
						Format.asTimestamp(new Date()));
				mav.addObject("isXLSXExport", isXLSXExport);
				mav.addObject("fileName", fileName);
				return mav;
			}
		}
	}

	private boolean hasObjectId(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		if (activeTab == null) {
			return false;
		} else {
			return activeTab.isCompensationPlan() || activeTab.isTailoredReport();
		}
	}

	private String getObjectId(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		if (!activeTab.isCompensationPlan() && !activeTab.isTailoredReport()) {
			Assert.state(false, "Invalid tab.");
			return null;
		} else {
			TabObject tabObject = (TabObject) activeTab;
			return tabObject.getObjectId();
		}
	}

	private String getExcelView(PayeeLedger ledger) {
		return ledger.isDetail() ? "detailExcelView" : "summaryExcelView";
	}

	private String getView(PayeeLedger ledger) {
		return ledger.isDetail() ? "redirect:/ledger/detail.html" : "redirect:/ledger/summary.html";
	}
}
