package com.varicent.payeeledger.web.view;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.domain.Plan;
import com.varicent.core.exceptions.ExcelTooManyRowsException;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.util.Excel;
import com.varicent.core.view.AbstractExcelView;
import com.varicent.core.view.ExcelUtility;
import com.varicent.payeeledger.domain.DetailRow;
import com.varicent.payeeledger.domain.ReportTheme;

@Component
public class DetailExcelView extends AbstractExcelView {
	final String NORMAL_FONT = "normal";
	final String HEADER_FONT = "header";
	final String DEFAULT_FONT = "default";

	@Override
	protected void buildExcelDocument(Map model, Workbook wb, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		int HEADER = 0;
		int RESULT = 1;
		int NORMAL = 2;
		int ALT = 3;
		List<DetailRow> rows = (List) model.get("rows");
		if (rows != null && !rows.isEmpty()) {
			Plan plan = (Plan) model.get("plan");
			Payee payee = (Payee) model.get("payee");
			String sheetName = plan.getId() + " - " + payee.getName();
			Sheet sheet = wb.createSheet(ExcelUtility.createSafeSheetName(sheetName));
			sheet.setDefaultColumnWidth(15);
			PrintSetup printSetup = sheet.getPrintSetup();
			printSetup.setLandscape(true);
			printSetup.setPaperSize((short) 1);
			Header header = sheet.getHeader();
			header.setCenter(plan.toString() + " - " + payee.toString());
			ExcelUtility excelUtility = ExcelUtility.getExcelSSUtility(wb);
			if (rows.size() > excelUtility.getRowLimit()) {
				response.sendRedirect("../../ledger/detail.html?error=true");
				throw new ExcelTooManyRowsException();
			} else {
				Font normalFont = excelUtility.getFont("Tahoma", (short) 10);
				Font headerFont = excelUtility.getFont("Tahoma", (short) 10);
				headerFont.setBoldweight((short) 700);
				excelUtility.ApplyFontColour(headerFont, Color.decode("#FFFFFF"));
				CellStyle[] cellStyles = new CellStyle[5];
				ReportTheme theme = null;
				Map<String, CellStyle> columnNumericCellStyles = new HashMap();
				Map<String, CellStyle> columnCellStyles = new HashMap();
				int traceRowCount = 0;
				int sortRowCount = 0;
				int i = 0;

				for (int n = rows.size(); i < n; ++i) {
					DetailRow detailRow = rows.get(i);
					Row row = sheet.createRow(i);
					CellStyle format = null;
					switch (detailRow.getType()) {
					case REPORT:
						theme = detailRow.getTheme();
						cellStyles[0] = this.getAndCacheTextStyle(theme.getHeaderColor(), "header", headerFont,
								columnCellStyles, excelUtility);
						cellStyles[1] = this.getAndCacheTextStyle(theme.getSummaryColor(), "normal", normalFont,
								columnCellStyles, excelUtility);
						cellStyles[2] = this.getAndCacheTextStyle((String) null, "default", (Font) null,
								columnCellStyles, excelUtility);
						cellStyles[3] = this.getAndCacheTextStyle(theme.getAlternatingColor(), "default", (Font) null,
								columnCellStyles, excelUtility);
						break;
					case HEADER:
						format = cellStyles[0];
						break;
					case RESULT:
						format = cellStyles[1];
						break;
					case SORT:
						format = cellStyles[this.isAltRow(sortRowCount) ? 3 : 2];
						break;
					case TRACE:
						format = cellStyles[this.isAltRow(traceRowCount) ? 3 : 2];
					}

					DetailRow.CellData[] cellData = detailRow.getCellData();
					int j = 0;

					for (int numCols = cellData.length; j < numCols; ++j) {
						Object value = cellData[j].getObj();
						if (value instanceof BigDecimal) {
							CellStyle numericCellStyle = null;
							if (detailRow.getType() != DetailRow.Type.TRACE
									&& detailRow.getType() != DetailRow.Type.RESULT) {
								if (detailRow.getType() == DetailRow.Type.SORT) {
									String colour = this.isAltRow(sortRowCount) ? theme.getAlternatingColor() : null;
									numericCellStyle = this.getAndCacheCellStyle(colour, detailRow.getResultFormat(),
											columnNumericCellStyles, excelUtility);
								} else {
									String colour = this.isAltRow(i) ? theme.getAlternatingColor() : null;
									numericCellStyle = this.getAndCacheCellStyle(colour, detailRow.getResultFormat(),
											columnNumericCellStyles, excelUtility);
								}
							} else {
								NumericFormat columnNumericFormat = cellData[j].getFormat();
								if (columnNumericFormat != null) {
									String colour = null;
									if (detailRow.getType() == DetailRow.Type.TRACE) {
										colour = this.isAltRow(traceRowCount) ? theme.getAlternatingColor() : null;
									} else {
										colour = theme.getSummaryColor();
									}

									numericCellStyle = this.getAndCacheCellStyle(colour, columnNumericFormat,
											columnNumericCellStyles, excelUtility);
								}
							}

							Cell cell = row.createCell(j);
							cell.setCellValue(((BigDecimal) value).doubleValue());
							if (numericCellStyle != null) {
								cell.setCellStyle(numericCellStyle);
							}
						} else {
							Cell cell = row.createCell(j);
							cell.setCellValue(detailRow.getValue(j));
							if (format != null) {
								cell.setCellStyle(format);
							}
						}
					}

					if (detailRow.getType() == DetailRow.Type.TRACE) {
						++traceRowCount;
					} else if (detailRow.getType() == DetailRow.Type.SORT) {
						++sortRowCount;
					}
				}

			}
		}
	}

	private CellStyle getAndCacheCellStyle(String colour, NumericFormat numericFormat,
			Map<String, CellStyle> columnNumericCellStyles, ExcelUtility excelUtility) {
		String numberFormat = this.getNumberFormat(numericFormat);
		String key = this.getNumericCacheKey(colour, numberFormat);
		if (!columnNumericCellStyles.containsKey(key)) {
			columnNumericCellStyles.put(key, this.getCellStyle(excelUtility, colour, (Font) null, numberFormat));
		}

		return columnNumericCellStyles.get(key);
	}

	private CellStyle getAndCacheTextStyle(String colour, String fontType, Font font,
			Map<String, CellStyle> columnTextCellStyles, ExcelUtility excelUtility) {
		String key = this.getTextStyleCacheKey(colour, fontType);
		if (!columnTextCellStyles.containsKey(key)) {
			CellStyle cellStyle = font == null ? excelUtility.createTextCellStyle()
					: excelUtility.createTextCellStyle(font);
			if (colour != null) {
				excelUtility.ApplyFillColour(cellStyle, Color.decode(colour), (short) 1);
			}

			columnTextCellStyles.put(key, cellStyle);
		}

		return columnTextCellStyles.get(key);
	}

	private boolean isAltRow(int row) {
		return row % 2 == 0;
	}

	private String getNumericCacheKey(String color, String numberFormatString) {
		return color + "_" + numberFormatString;
	}

	private String getTextStyleCacheKey(String colour, String fontType) {
		return colour != null ? colour + "_" + fontType : fontType;
	}

	private String getNumberFormat(NumericFormat format) {
		return Excel.getNumberFormat(format);
	}

	private CellStyle getCellStyle(ExcelUtility excelUtility, String backGroundColour, Font font, String numberFormat) {
		CellStyle wcf = excelUtility.createDataCellStyle(font, numberFormat);
		if (backGroundColour != null) {
			excelUtility.ApplyFillColour(wcf, Color.decode(backGroundColour), (short) 1);
		}

		return wcf;
	}
}
