package com.varicent.messages.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.varicent.common.attachment.domain.Attachment;
import com.varicent.common.attachment.service.AttachmentManager;

@Controller
public class DocumentsController {
	private static final String VIEW = "documents/index";
	private final AttachmentManager attachmentManager;

	@Autowired
	public DocumentsController(AttachmentManager attachmentManager) {
		this.attachmentManager = attachmentManager;
	}

	@ModelAttribute("attachments")
	public List<Attachment> getAttachments() {
		return this.attachmentManager.getAttachments();
	}

	@RequestMapping(method = { RequestMethod.GET }, value = { "/documents/index.html" })
	public String prepareView(ModelMap model, HttpServletRequest request) {
		Object error = request.getSession().getAttribute("msgKey");
		if (error != null) {
			model.addAttribute("msgKey", error);
			request.getSession().removeAttribute("msgKey");
		}

		return "documents/index";
	}
}
