package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;
import com.varicent.customize.domain.CustomType;

public class DisplayColumn {
	private final String name;
	private final Operator operator;
	private final NumericFormat format;
	private final String dataItem;
	private final CustomType type;

	public DisplayColumn(String name, int operator, NumericFormat format, String dataItem, CustomType type) {
		this.name = name;
		this.operator = DisplayColumn.Operator.values()[operator];
		this.format = format;
		this.dataItem = dataItem;
		this.type = type;
	}

	public NumericFormat getFormat() {
		return this.format;
	}

	public String getName() {
		return this.name;
	}

	public Operator getOperator() {
		return this.operator;
	}

	public String getDataItem() {
		return this.dataItem;
	}

	public boolean hasFormat() {
		return this.format != null;
	}

	public boolean hasOperation() {
		return this.operator != DisplayColumn.Operator.NONE;
	}

	public boolean isEmail() {
		return this.type == CustomType.EMAIL;
	}

	public boolean isUrl() {
		return this.type == CustomType.URL;
	}

	public static enum Operator {
		NONE, SUM, AVG, MIN, MAX, LAST;
	}
}
