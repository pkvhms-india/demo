package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class XYZSet {
	private String xValue;
	private String yValue;
	private String zValue;

	public XYZSet(String x, String y, String z) {
		this.xValue = x;
		this.yValue = y;
		this.zValue = z;
	}

	public void writeSet(XMLStreamWriter writer, int index, DataTable data, Scope scope, ColumnLink link, String series,
			boolean isPercentage, boolean isSYPercentage) throws XMLStreamException, ReportOverLimitException {
		if (isPercentage) {
			this.xValue = (new BigDecimal(this.xValue)).multiply(new BigDecimal(100)).toPlainString();
			this.yValue = (new BigDecimal(this.yValue)).multiply(new BigDecimal(100)).toPlainString();
		}

		if (isSYPercentage) {
			this.zValue = (new BigDecimal(this.zValue)).multiply(new BigDecimal(100)).toPlainString();
		}

		if (link != null) {
			writer.writeCharacters("<set x='" + this.xValue + "' y='" + this.yValue + "' z='" + this.zValue + "' ");

			try {
				String linkurl = link.getLinkAttribute(index, data, scope, false);
				writer.writeCharacters("link='" + linkurl + "' /> ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		} else {
			writer.writeCharacters("<set x='" + this.xValue + "' y='" + this.yValue + "' z='" + this.zValue + "'  />");
		}

	}
}
