package com.varicent.draws.service;

import java.util.List;

import com.varicent.common.payee.domain.Payee;
import com.varicent.core.i18n.Message;
import com.varicent.draws.domain.DrawAssignmentFixedTerm;
import com.varicent.draws.domain.DrawAssignmentOngoing;
import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.workflow.domain.WorkflowObject;

public interface DrawAssignmentManager {
	List<Payee> getFilterPayees(int var1, int var2);

	List<WorkflowGroupName> getfilterWorkflowGroups(int var1, int var2);

	List<DrawTemplateName> getDrawTemplates(int var1);

	List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(int var1, int var2, String var3, int var4, int var5,
			int var6, String var7, boolean var8);

	int getUnAssignedPayeesPageCount(int var1, int var2, int var3, String var4, int var5);

	List<DrawAssignmentOngoing> getOngoingPayees(int var1, int var2, String var3, int var4, boolean var5, int var6,
			int var7, String var8, boolean var9);

	int getOngoingPayeesPageCount(int var1, int var2, int var3, String var4, int var5, boolean var6);

	List<DrawAssignmentFixedTerm> getFixedTermPayees(int var1, int var2, String var3, int var4, boolean var5, int var6,
			int var7, String var8, boolean var9);

	int getFixedTermPayeesPageCount(int var1, int var2, int var3, String var4, int var5, boolean var6);

	List<DrawAssignmentUnassignedPayee> assignAndGetUnassigned(List<DrawAssignmentUnassignedPayee> var1, int var2,
			int var3, List<Message> var4);

	List<DrawAssignmentOngoing> updateOngoingAssignmentsAndGetRemaining(int var1, int var2,
			List<DrawAssignmentOngoing> var3, List<Message> var4, int var5, int var6, String var7, boolean var8);

	List<DrawAssignmentFixedTerm> updateFixedTermAssignmentsAndGetRemaining(int var1, int var2,
			List<DrawAssignmentFixedTerm> var3, List<Message> var4, int var5, int var6, String var7, boolean var8);

	String getPeriodName(String var1, String var2, String var3);

	String getPeriodAmount(int var1, int var2, int var3);

	boolean drawExists(int var1);

	boolean isViwableDrawAssignment(int var1);

	int getRowsPerPage(int var1);

	boolean isGroupSelectionAllowed(int var1);

	List<DrawName> getViewableDraws();

	int getWorkflowObjectId(String var1, WorkflowObject.Type var2);
}
