package com.varicent.errors.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.servlet.view.RedirectView;

public class CustomExceptionResolver extends SimpleMappingExceptionResolver {
	private static final String INQUIRY_VIEW = "/inquiries/view.do";
	private static final String REPORT_INQUIRY_VIEW = "/reporting/index.html";

	@Override
	protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		String referer = request.getHeader("referer");
		if (ex instanceof MaxUploadSizeExceededException) {
			if (referer.contains("/inquiries/view.do")) {
				ModelAndView mv = new ModelAndView(new RedirectView("/inquiries/view.do", true));
				String id = request.getParameter("id");
				mv.addObject("id", id);
				request.getSession().setAttribute("msgKey", "error.maxUploadSizeExceeded");
				return mv;
			}

			if (referer.contains("/reporting/index.html")) {
				RedirectView rv = new RedirectView("/reporting/index.html", true);
				rv.addStaticAttribute("msgKey", "error.maxUploadSizeExceeded");
				return new ModelAndView(rv);
			}
		}

		return super.doResolveException(request, response, handler, ex);
	}
}
