package com.varicent.core.math.expressions;

import java.math.BigDecimal;

import org.jdom.Element;

public class NodeString extends JavascriptNode implements EvaluateNode {
	public static final String XmlNodeName = "StringText";
	String variableName;
	boolean javascriptFunctionCreated;
	private String value;

	public static NodeString fromXml(Element node, int suffix) {
		Element valueNode = (Element) node.getChildren().get(0);
		String value = valueNode.getText();
		return new NodeString(value, (String) null, suffix);
	}

	public NodeString(String value, String variableName, int suffix) {
		super(suffix);
		this.value = value;
		this.variableName = variableName;
	}

	@Override
	public BigDecimal evaluate() {
		return null;
	}

	public String EqualEvaluate() {
		return this.value;
	}

	@Override
	public void reset() {
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public boolean isJSFunctionCreated() {
		return this.javascriptFunctionCreated;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		this.javascriptFunctionCreated = true;
		StringBuilder sb = new StringBuilder();
		sb.append(JavascriptUtil.getFunctionSigniture(this.getJSFunctionName(jsUtil)));
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		if (this.variableName == null) {
			sb.append(this.value.toString());
		} else {
			sb.append(jsUtil.getVariable(this.variableName));
		}

		sb.append(";}");
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		assert false;

		return null;
	}
}
