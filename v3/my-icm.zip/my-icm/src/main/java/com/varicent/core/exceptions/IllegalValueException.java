package com.varicent.core.exceptions;

public class IllegalValueException extends Exception {
	private static final long serialVersionUID = 1L;
	private final String table;
	private final String columnAlias;
	private final String column;
	private final String value;

	public IllegalValueException(String table, String columnAlias, String column, String value) {
		this.table = table;
		this.columnAlias = columnAlias;
		this.column = column;
		this.value = value;
	}

	public String getColumnAlias() {
		return this.columnAlias;
	}

	public String getColumn() {
		return this.column;
	}

	public String getTable() {
		return this.table;
	}

	public String getValue() {
		return this.value;
	}
}
