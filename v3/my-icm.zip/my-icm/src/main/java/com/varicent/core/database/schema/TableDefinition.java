package com.varicent.core.database.schema;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TableDefinition {
	private final String name;
	private final List<ColumnDefinition> columns;

	public TableDefinition(String name, List<ColumnDefinition> columns) {
		this.name = name;
		this.columns = new ArrayList(columns);
	}

	public ColumnDefinition getColumn(int index) {
		return this.columns.get(index);
	}

	public ColumnDefinition getColumn(String name) {
		for (ColumnDefinition column : this.columns) {
			if (column.getName().equals(name)) {
				return column;
			}
		}

		return null;
	}

	public List<ColumnDefinition> getColumns() {
		return Collections.unmodifiableList(this.columns);
	}

	public List<ColumnDefinition> getKeyColumns() {
		List<ColumnDefinition> keyColumns = new ArrayList();

		for (ColumnDefinition column : this.columns) {
			if (column.isKey()) {
				keyColumns.add(column);
			}
		}

		return keyColumns;
	}

	public String getName() {
		return this.name;
	}
}
