package com.varicent.core.system.windows.fonts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.varicent.core.system.System;
import com.varicent.core.system.windows.RegistryUtil;

public class FontLinking {
	private static final Logger logger = Logger.getLogger(FontLinking.class);
	private static FontLinking instance;
	private Map<String, Collection<String>> linking;

	public static FontLinking getInstance() {
		if (instance == null) {
			Map<String, Object> fontLinks = null;
			if (System.getOS() == System.OS.WINDOWS) {
				try {
					fontLinks = RegistryUtil.GetRegistryEntrys(
							"\"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\FontLink\\SystemLink\"");
				} catch (IOException var7) {
					logger.warn(
							"Error retrieving font linking infomation in the registry, some languages may not show.");
				}
			} else {
				logger.info("Automatic glyph selections is turned off");
			}

			if (fontLinks == null) {
				logger.info("Font linking information is empty, automatic glyph selections is turned off.");
				instance = new FontLinking((Map) null);
			} else {
				Map<String, Collection<String>> linking = new HashMap();

				for (Map.Entry<String, Object> entry : fontLinks.entrySet()) {
					Collection<String> fontNames = new ArrayList();

					for (String fontLocationAndName : (Collection<String>) entry.getValue()) {
						fontNames.add(fontLocationAndName.substring(fontLocationAndName.lastIndexOf(44) + 1));
					}

					linking.put(entry.getKey(), fontNames);
				}

				instance = new FontLinking(linking);
			}
		}

		return instance;
	}

	private FontLinking(Map<String, Collection<String>> linking) {
		this.linking = linking;
	}

	public Collection<String> getFontLink(String fontName) {
		Collection<String> linked = null;
		if (this.linking != null) {
			linked = this.linking.get(fontName);
		}

		if (linked == null || linked.size() == 0) {
			logger.info(String.format("Font: \"%s\" is not linked", fontName));
		}

		return linked;
	}
}
