package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeNot extends UnaryNode implements EvaluateNode {
	public NodeNot(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		return this.arg.evaluate().compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ONE : BigDecimal.ZERO;
	}

	@Override
	public void reset() {
		this.arg.reset();
	}

	@Override
	public String getJSMathFunctionName() {
		return "not";
	}
}
