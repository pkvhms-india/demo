package com.varicent.core.exceptions;

public class PasswordChangeException extends PasswordException {
	private static final long serialVersionUID = 1L;

	public PasswordChangeException() {
	}

	public PasswordChangeException(String message) {
		super(message);
	}

	public PasswordChangeException(String message, Throwable cause) {
		super(message, cause);
	}

	public PasswordChangeException(Throwable cause) {
		super(cause);
	}
}
