package com.varicent.core.system;

public class System {
	private static OS currentOS;

	public static OS getOS() {
		if (currentOS == null) {
			String osName = java.lang.System.getProperty("os.name");

			for (OS os : System.OS.values()) {
				if (os.Identify(osName)) {
					currentOS = os;
					break;
				}
			}
		}

		return currentOS;
	}

	public static enum OS {
		WINDOWS(new WindowsIdentifier()), UNSUPPORTED(new UnsupportedOSIdentifier());

		private final OSIdentifier identifier;

		private OS(OSIdentifier identifier) {
			this.identifier = identifier;
		}

		public boolean Identify(String osName) {
			return this.identifier.isOS(osName);
		}
	}
}
