package com.varicent.core.util;

import java.math.BigDecimal;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import org.springframework.util.Assert;

import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;

public class NumberFormatBuilder {
	public static String getFormat(int scale, char decimalSeparator, char groupingSeparator, boolean isPercent) {
		return getFormat(scale, scale, decimalSeparator, groupingSeparator, isPercent);
	}

	public static String getFormat(int scaleMin, int scaleMax, char decimalSeparator, char groupingSeparator,
			boolean isPercent) {
		StringBuilder format = new StringBuilder("#");
		format.append(groupingSeparator);
		format.append("##0");
		if (scaleMin > 0) {
			format.append(decimalSeparator);
		}

		for (int i = 0; i < scaleMin; ++i) {
			format.append(0);
		}

		for (int i = Math.max(0, scaleMin); i < scaleMax; ++i) {
			format.append("#");
		}

		return format.toString();
	}

	protected static boolean useNegativeBrackets(NumericFormat.Style style) {
		return style == NumericFormat.Style.DOLLARS || style == NumericFormat.Style.FRENCHCANADIANDOLLARS;
	}

	protected static String getCurrencySymbol(Locale locale) {
		boolean isLocaleInstalled = false;
		Locale[] installedLocales = Locale.getAvailableLocales();

		int i;
		for (i = 0; i < installedLocales.length; ++i) {
			if (SameCountryAndLanguage(installedLocales[i], locale)) {
				isLocaleInstalled = true;
				break;
			}
		}

		if (isLocaleInstalled) {
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(installedLocales[i]);
			return symbols.getCurrencySymbol();
		} else if (SameCountryAndLanguage(locale, Locale.US)) {
			return "$";
		} else if (SameCountryAndLanguage(locale, Locale.UK)) {
			return "£";
		} else if (SameCountryAndLanguage(locale, Locale.FRANCE)) {
			return "€";
		} else if (SameCountryAndLanguage(locale, Locale.JAPAN)) {
			return "￥";
		} else if (SameCountryAndLanguage(locale, Locale.CHINA)) {
			return "￥";
		} else if (SameCountryAndLanguage(locale, new Locale("en", "ZA"))) {
			return "R";
		} else {
			Assert.state(false);
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
			return symbols.getCurrencySymbol();
		}
	}

	protected static Boolean SameCountryAndLanguage(Locale first, Locale second) {
		return first.getCountry().equalsIgnoreCase(second.getCountry())
				&& first.getLanguage().equalsIgnoreCase(second.getLanguage()) ? true : false;
	}

	protected static CurrencyPattern getCurrencyPattern(NumericFormat format, String symbol) {
		return GetCurrencyPattern(Format.asValueString(new BigDecimal(1.0F), format), symbol);
	}

	protected static CurrencyPattern GetCurrencyPattern(String formattedValue, String symbol) {
		if (formattedValue.indexOf(symbol) < formattedValue.length() - symbol.length()) {
			return formattedValue.indexOf(symbol) + 1 == formattedValue.indexOf(32)
					? NumberFormatBuilder.CurrencyPattern.SYMBOL_BEFORE_SPACE
					: NumberFormatBuilder.CurrencyPattern.SYMBOL_BEFORE;
		} else {
			return formattedValue.lastIndexOf(32) + 1 == formattedValue.indexOf(symbol)
					? NumberFormatBuilder.CurrencyPattern.SYMBOL_AFTER_SPACE
					: NumberFormatBuilder.CurrencyPattern.SYMBOL_AFTER;
		}
	}

	protected static enum CurrencyPattern {
		SYMBOL_BEFORE, SYMBOL_AFTER, SYMBOL_BEFORE_SPACE, SYMBOL_AFTER_SPACE;
	}
}
