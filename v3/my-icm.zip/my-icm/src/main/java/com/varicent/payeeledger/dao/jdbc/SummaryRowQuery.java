package com.varicent.payeeledger.dao.jdbc;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowCallbackHandler;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.Database;
import com.varicent.core.util.Range;
import com.varicent.payeeledger.domain.SummaryRow;

class SummaryRowQuery {
	private final JdbcOperations operations;
	private final ReportQuery reportQuery;

	public SummaryRowQuery(DataSource ds, ReportQuery reportQuery) {
		this.operations = Database.getOperations(ds);
		this.reportQuery = reportQuery;
	}

	public List<SummaryRow> getSummary(String planId, String payeeId, List<TimePeriod> periods, Date lockedDate) {
		Range<Date> visibleDates = this.reportQuery.getVisibleDates(planId);
		Map<Date, BigDecimal> earnings = this.queryColumn("Earnings_", planId, payeeId, visibleDates);
		Map<Date, BigDecimal> netAdjustments = this.queryColumn("NetAdjustments_", planId, payeeId, visibleDates);
		Map<Date, BigDecimal> netEarnings = this.queryColumn("NetEarnings_", planId, payeeId, visibleDates);
		Map<Date, BigDecimal> pending = this.queryColumn("Pending_", planId, payeeId, visibleDates);
		Map<Date, BigDecimal> payment = this.queryColumn("Payment_", planId, payeeId, visibleDates);
		BigDecimal total = new BigDecimal(0);

		for (Date date : pending.keySet()) {
			BigDecimal value = pending.get(date).add(total);
			pending.put(date, value);
			total = value;
		}

		List<SummaryRow> rows = new ArrayList();

		for (TimePeriod period : periods) {
			Date startDate = period.getStarting();
			Date endDate = period.getEnding();
			if (!startDate.before(visibleDates.Start) && !endDate.after(visibleDates.End)) {
				BigDecimal rowEarnings = earnings.containsKey(endDate) ? (BigDecimal) earnings.get(endDate)
						: BigDecimal.ZERO;
				BigDecimal rowNetAdjustments = netAdjustments.containsKey(endDate)
						? (BigDecimal) netAdjustments.get(endDate)
						: BigDecimal.ZERO;
				BigDecimal rowNetEarnings = netEarnings.containsKey(endDate) ? (BigDecimal) netEarnings.get(endDate)
						: BigDecimal.ZERO;
				BigDecimal rowPending = pending.containsKey(endDate) ? (BigDecimal) pending.get(endDate)
						: BigDecimal.ZERO;
				BigDecimal rowPayment = payment.containsKey(endDate) ? (BigDecimal) payment.get(endDate)
						: BigDecimal.ZERO;
				boolean locked = false;
				if (lockedDate != null) {
					int comparison = endDate.compareTo(lockedDate);
					locked = comparison < 0 || comparison == 0;
				}

				SummaryRow row = new SummaryRow(endDate, planId, payeeId, period, rowEarnings, rowNetAdjustments,
						rowNetEarnings, rowPending, rowPayment, locked);
				rows.add(row);
			}
		}

		return rows;
	}

	private Map<Date, BigDecimal> queryColumn(String table, String planId, String payeeId, Range<Date> visible) {
		final Map<Date, BigDecimal> column = new TreeMap();
		QueryDefinition query = new QueryDefinition(table);
		query.select(table, "PayeeID_");
		query.select(table, "Date_");
		query.select(table, "Value_");
		query.newConstraint(table, "CompPlanID_", Constraint.Operator.Equals, planId);
		query.newConstraint(table, "PayeeID_", Constraint.Operator.Equals, payeeId);
		if (visible.Start.after(new Date(0L))) {
			query.newConstraint(table, "Date_", Constraint.Operator.GreaterThanEquals, visible.Start);
		}

		if (visible.End.before(new Date(Long.MAX_VALUE))) {
			query.newConstraint(table, "Date_", Constraint.Operator.LessThanEquals, visible.End);
		}

		QueryBuilder qb = Database.getQueryBuilder();
		this.operations.query(qb.toSql(query), new RowCallbackHandler() {
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				Date date = rs.getDate("Date_");
				BigDecimal value = rs.getBigDecimal("Value_");
				if (column.containsKey(date)) {
					column.put(date, column.get(date).add(value));
				} else {
					column.put(date, value);
				}

			}
		});
		return column;
	}
}
