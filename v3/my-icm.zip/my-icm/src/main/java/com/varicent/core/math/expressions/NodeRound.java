package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.List;

public class NodeRound extends BinaryNode implements EvaluateNode {
	public static final int MAX_ROUNDING_PRECISION = 28;

	public NodeRound(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal scaleDecimal = this.rhs.evaluate();
		BigDecimal value = this.lhs.evaluate();
		if (scaleDecimal != null && value != null) {
			int scale;
			if (scaleDecimal.compareTo(new BigDecimal(0)) <= 0) {
				scale = 0;
			} else if (scaleDecimal.compareTo(new BigDecimal(28)) > 0) {
				scale = 28;
			} else {
				MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
				scale = scaleDecimal.round(mc).intValue();
			}

			return value.setScale(scale, RoundingMode.HALF_EVEN);
		} else {
			return null;
		}
	}

	@Override
	public String getJSMathFunctionName() {
		return "round";
	}
}
