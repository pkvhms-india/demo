package com.varicent.api;

public class APIExceptionResponse {
	private String message;

	public APIExceptionResponse(String message) {
		this.message = message;
	}

	public String getMessage() {
		return this.message;
	}
}
