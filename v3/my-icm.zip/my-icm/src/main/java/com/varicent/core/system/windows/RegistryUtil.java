package com.varicent.core.system.windows;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class RegistryUtil {
	public static Map<String, Object> GetRegistryEntrys(String path) throws IOException {
		Process process = Runtime.getRuntime().exec("reg query " + path);
		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		Map<String, Object> regValues = null;

		String line;
		while ((line = reader.readLine()) != null) {
			line.trim();
			String regType = RegistryType.GetRegistryTypeName(line);
			if (regType != null) {
				int regTypeIndex = line.indexOf(regType);
				String key = line.substring(0, regTypeIndex).trim();
				int regValueStart = regTypeIndex + regType.length();
				if (line.length() > regValueStart) {
					String regValue = line.substring(regValueStart).trim();
					if (regValues == null) {
						regValues = new HashMap();
					}

					regValues.put(key, RegistryType.parse(regType, regValue));
				}
			}
		}

		reader.close();
		return regValues;
	}
}
