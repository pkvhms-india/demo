package com.varicent.payeeledger.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.varicent.common.adjustment.domain.Adjustment;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;

public class SummaryRow extends DataRow {
	private final List<Adjustment> adjustments;
	private final boolean locked;

	public SummaryRow(Date date, String plan, String payee, TimePeriod period, BigDecimal earnings,
			BigDecimal netAdjustments, BigDecimal netEarnings, BigDecimal pending, BigDecimal payment, boolean locked) {
		this.add(date == null ? null : new Date(date.getTime()));
		this.add(plan);
		this.add(payee);
		this.add(period);
		this.add(earnings);
		this.add(netAdjustments);
		this.add(netEarnings);
		this.add(pending);
		this.add(payment);
		this.adjustments = new ArrayList();
		this.locked = locked;
	}

	public boolean addAdjustments(Collection<? extends Adjustment> adjustments) {
		return this.adjustments.addAll(adjustments);
	}

	public List<Adjustment> getAdjustments() {
		return Collections.unmodifiableList(this.adjustments);
	}

	public Date getDate() {
		Date date = (Date) this.objects.get(SummaryRow.Column.DATE.ordinal());
		return date == null ? null : (Date) date.clone();
	}

	public BigDecimal getEarnings() {
		return (BigDecimal) this.objects.get(SummaryRow.Column.EARNINGS.ordinal());
	}

	public BigDecimal getNetAdjustments() {
		return (BigDecimal) this.objects.get(SummaryRow.Column.NET_ADJUSTMENTS.ordinal());
	}

	public BigDecimal getNetEarnings() {
		return (BigDecimal) this.objects.get(SummaryRow.Column.NET_EARNINGS.ordinal());
	}

	public String getPayee() {
		return (String) this.objects.get(SummaryRow.Column.PAYEE.ordinal());
	}

	public BigDecimal getPayment() {
		return (BigDecimal) this.objects.get(SummaryRow.Column.PAYMENT.ordinal());
	}

	public BigDecimal getPending() {
		return (BigDecimal) this.objects.get(SummaryRow.Column.PENDING.ordinal());
	}

	public TimePeriod getPeriod() {
		return (TimePeriod) this.objects.get(SummaryRow.Column.PERIOD.ordinal());
	}

	public String getPlan() {
		return (String) this.objects.get(SummaryRow.Column.PLAN.ordinal());
	}

	public boolean isLocked() {
		return this.locked;
	}

	private static enum Column {
		DATE, PLAN, PAYEE, PERIOD, EARNINGS, NET_ADJUSTMENTS, NET_EARNINGS, PENDING, PAYMENT;
	}
}
