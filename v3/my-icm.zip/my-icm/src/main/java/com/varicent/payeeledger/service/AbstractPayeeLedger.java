package com.varicent.payeeledger.service;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.springframework.transaction.annotation.Transactional;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.domain.Plan;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.text.NumericFormat;
import com.varicent.payeeledger.dao.PayeeLedgerDao;
import com.varicent.payeeledger.domain.DetailRow;

@Transactional(readOnly = true)
public abstract class AbstractPayeeLedger implements PayeeLedger {
	protected final PayeeLedgerDao payeeLedgerDao;

	protected AbstractPayeeLedger(PayeeLedgerDao payeeLedgerDao) {
		this.payeeLedgerDao = payeeLedgerDao;
	}

	@Override
	public List<DataRow> getLedger(String planId, String payeeId, TimePeriod period, boolean repeatHeader) {
		if (planId != null && payeeId != null) {
			List<DataRow> rows = this.payeeLedgerDao.getLedger(planId, payeeId, period, repeatHeader);
			NumericFormat reportResultFormat = null;
			NumericFormat[] columnNumericFormats = null;
			int i = 0;

			for (int n = rows.size(); i < n; ++i) {
				DataRow row = rows.get(i);
				if (row instanceof DetailRow) {
					DetailRow detailRow = (DetailRow) row;
					switch (detailRow.getType()) {
					case REPORT:
						reportResultFormat = detailRow.getResultFormat();
						columnNumericFormats = detailRow.getColumnNumericFormats();
						break;
					case RESULT:
					case TRACE:
						columnNumericFormats = detailRow.getColumnNumericFormats();
						detailRow.setColumnNumericFormats(columnNumericFormats);
					default:
						detailRow.setResultFormat(reportResultFormat);
					}
				}
			}

			return rows;
		} else {
			return Collections.emptyList();
		}
	}

	@Override
	public Payee getPayee(String payeeId) {
		return this.payeeLedgerDao.getPayee(payeeId);
	}

	@Override
	public List<Payee> getPayees(String planId) {
		return this.payeeLedgerDao.getPayees(planId);
	}

	@Override
	public List<TimePeriod> getPeriods(String planId) {
		return this.payeeLedgerDao.getPeriods(planId);
	}

	@Override
	public Plan getPlan(String planId) {
		return this.payeeLedgerDao.getPlan(planId);
	}

	@Override
	public List<Plan> getPlans(String payeeId) {
		return this.payeeLedgerDao.getPlans(payeeId);
	}

	@Override
	public Set<String> getViewablePlans() {
		return this.payeeLedgerDao.getAuthorizedPlanIds();
	}
}
