package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeOr extends PolyNode implements EvaluateNode {
	public NodeOr(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		for (EvaluateNode arg : this.args) {
			if (arg.evaluate().compareTo(BigDecimal.ONE) == 0) {
				return BigDecimal.ONE;
			}
		}

		return BigDecimal.ZERO;
	}

	@Override
	public void reset() {
		for (EvaluateNode arg : this.args) {
			arg.reset();
		}

	}

	@Override
	public String getJSMathFunctionName() {
		return "or";
	}
}
