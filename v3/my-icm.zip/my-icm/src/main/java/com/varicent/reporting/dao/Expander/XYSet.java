package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class XYSet {
	private String xValue;
	private String yValue;

	public XYSet(String x, String y) {
		this.xValue = x;
		this.yValue = y;
	}

	public void writeSet(XMLStreamWriter writer, int index, DataTable data, Scope scope, ColumnLink link, String series,
			boolean isPercentage) throws XMLStreamException, ReportOverLimitException {
		if (isPercentage) {
			this.xValue = (new BigDecimal(this.xValue)).multiply(new BigDecimal(100)).toPlainString();
			this.yValue = (new BigDecimal(this.yValue)).multiply(new BigDecimal(100)).toPlainString();
		}

		if (link != null) {
			writer.writeCharacters("<set y='" + this.yValue + "' x='" + this.xValue + "' ");

			try {
				String linkurl = link.getLinkAttribute(index, data, scope, false);
				writer.writeCharacters("link='" + linkurl + "' /> ");
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}
		} else {
			writer.writeCharacters("<set y='" + this.yValue + "' x='" + this.xValue + "' />");
		}

	}
}
