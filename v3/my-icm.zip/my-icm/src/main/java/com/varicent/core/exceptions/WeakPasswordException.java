package com.varicent.core.exceptions;

public class WeakPasswordException extends PasswordException {
	private static final long serialVersionUID = 1L;

	public WeakPasswordException() {
	}

	public WeakPasswordException(String message) {
		super(message);
	}

	public WeakPasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public WeakPasswordException(Throwable cause) {
		super(cause);
	}
}
