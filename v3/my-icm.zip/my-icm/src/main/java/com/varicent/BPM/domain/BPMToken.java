package com.varicent.BPM.domain;

public class BPMToken {
	public static final String FormInitiatorAlias = "Form Initiator";
	public static final String FormIDAlias = "Workflow Form ID";
	public static final String FormIDColumnName = "WorkflowFormID_";
	private int tokenID;
	private int formID;
	private int nodeID;
	private String ownerID;
	private String lastActorID;
	private int pathID;
	private boolean isWaiting;
	private long rowVersion;

	public BPMToken(int tokenID, int formID, int nodeID, String ownerID, String lastActorID, int pathID,
			boolean isWaiting, long rowVersion) {
		this.tokenID = tokenID;
		this.formID = formID;
		this.nodeID = nodeID;
		this.ownerID = ownerID;
		this.lastActorID = lastActorID;
		this.pathID = pathID;
		this.isWaiting = isWaiting;
		this.rowVersion = rowVersion;
	}

	public int getFormID() {
		return this.formID;
	}

	public void setFormID(int formID) {
		this.formID = formID;
	}

	public int getNodeID() {
		return this.nodeID;
	}

	public void setNodeID(int nodeID) {
		this.nodeID = nodeID;
	}

	public String getLastActorID() {
		return this.lastActorID;
	}

	public void setLastActorID(String lastActorID) {
		this.lastActorID = lastActorID;
	}

	public int getPathID() {
		return this.pathID;
	}

	public void setPathID(int pathID) {
		this.pathID = pathID;
	}

	public int getTokenID() {
		return this.tokenID;
	}

	public String getOwnerID() {
		return this.ownerID;
	}

	public boolean isWaiting() {
		return this.isWaiting;
	}

	public void setIsWaiting(boolean isWaiting) {
		this.isWaiting = isWaiting;
	}

	public long getRowVersion() {
		return this.rowVersion;
	}
}
