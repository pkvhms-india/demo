package com.varicent.core.exceptions;

public class MissingReportParameterException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final String name;

	public MissingReportParameterException(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
