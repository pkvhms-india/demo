package com.varicent.core.exceptions;

public class ModelVersionException extends Exception {
	private static final long serialVersionUID = 1L;

	public ModelVersionException() {
	}

	public ModelVersionException(String message) {
		super(message);
	}

	public ModelVersionException(String message, Throwable cause) {
		super(message, cause);
	}

	public ModelVersionException(Throwable cause) {
		super(cause);
	}
}
