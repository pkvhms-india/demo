package com.varicent.core.util;

import java.util.Locale;

import org.springframework.util.Assert;

import com.varicent.core.text.NumericFormat;

public class Excel {
	public static String getFormat(int precision, char decimalSeperator, char groupingSeperator, boolean isPercent) {
		return NumberFormatBuilder.getFormat(precision, decimalSeperator, groupingSeperator, isPercent);
	}

	public static String getNumberFormat(NumericFormat numericFormat) {
		char decimalSeperator = '.';
		char groupingSeperator = ',';
		boolean isPercent = false;
		String symbol;
		switch (numericFormat.getStyle()) {
		case NUMBER:
			String format = NumberFormatBuilder.getFormat(numericFormat.getScaleMin(), numericFormat.getScaleMax(),
					decimalSeperator, groupingSeperator, isPercent);
			return format;
		case PERCENT:
			symbol = "%";
			isPercent = true;
			break;
		case DOLLARS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.US);
			break;
		case FRENCHCANADIANDOLLARS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.CANADA_FRENCH);
			break;
		case POUNDS:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.UK);
			break;
		case EURO:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.FRANCE);
			break;
		case YEN:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.JAPAN);
			break;
		case YUAN:
			symbol = NumberFormatBuilder.getCurrencySymbol(Locale.CHINA);
			break;
		case RAND:
			symbol = NumberFormatBuilder.getCurrencySymbol(new Locale("en", "ZA"));
			break;
		default:
			Assert.state(false);
			symbol = null;
		}

		String var8 = NumberFormatBuilder.getFormat(numericFormat.getScaleMin(), numericFormat.getScaleMax(),
				decimalSeperator, groupingSeperator, isPercent);
		String mask = "";
		NumberFormatBuilder.CurrencyPattern pattern = NumberFormatBuilder.getCurrencyPattern(numericFormat, symbol);
		if (numericFormat.getStyle() != NumericFormat.Style.PERCENT) {
			symbol = "\"" + symbol + "\"";
		}

		switch (pattern) {
		case SYMBOL_BEFORE:
			mask = symbol + var8;
			break;
		case SYMBOL_AFTER:
			mask = var8 + symbol;
			break;
		case SYMBOL_BEFORE_SPACE:
			mask = symbol + " " + var8;
			break;
		case SYMBOL_AFTER_SPACE:
			mask = var8 + " " + symbol;
		}

		if (numericFormat.getStyle() == NumericFormat.Style.RAND) {
			mask = mask + ";" + symbol + "-" + var8;
		}

		if (NumberFormatBuilder.useNegativeBrackets(numericFormat.getStyle())) {
			mask = mask + ";(" + mask + ")";
		}

		return mask;
	}
}
