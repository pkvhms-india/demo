package com.varicent.BPM.domain;

public class BPMWorkflowView {
	private int workflowID;
	private String name;
	private String description;
	private int rowNumber;

	public BPMWorkflowView(int workflowID, String name, String description, int rowNumber) {
		this.workflowID = workflowID;
		this.name = name;
		this.description = description;
		this.rowNumber = rowNumber;
	}

	public BPMWorkflowView(int workflowID, String name, String description) {
		this(workflowID, name, description, -1);
	}

	public int getWorkflowID() {
		return this.workflowID;
	}

	public String getName() {
		return this.name;
	}

	public String getDescription() {
		return this.description;
	}

	public int getRowNumber() {
		return this.rowNumber;
	}
}
