package com.varicent.customize.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.schema.ColumnDefinition;

public class CustomColumn {
	private final ColumnDefinition definition;
	private final CustomType type;
	private final boolean isEditable;
	private final List<SelectOption> options;
	private final boolean hasPicklist;

	public CustomColumn(ColumnDefinition definition, CustomType type, boolean isEditable, boolean hasPicklist) {
		this.definition = definition;
		this.type = type;
		this.isEditable = isEditable;
		this.hasPicklist = hasPicklist;
		this.options = new ArrayList();
	}

	public void addOption(SelectOption option) {
		this.options.add(option);
	}

	public void addOptions(Collection<? extends SelectOption> options) {
		this.options.addAll(options);
	}

	public String getDisplayName() {
		return this.definition.getDisplayName();
	}

	public String getName() {
		return this.definition.getName();
	}

	public List<SelectOption> getOptions() {
		return Collections.unmodifiableList(this.options);
	}

	public List<String> getOptionValues() {
		List<String> values = new ArrayList();

		for (SelectOption value : this.options) {
			values.add(value.getValue());
		}

		return Collections.unmodifiableList(values);
	}

	public int getSchemaType() {
		return this.definition.getType();
	}

	public String getTable() {
		return this.definition.getTable();
	}

	public CustomType getType() {
		return this.type;
	}

	public boolean isEditable() {
		return this.isEditable;
	}

	public boolean isKey() {
		return this.definition.isKey();
	}

	public boolean getHasPicklist() {
		return this.hasPicklist;
	}
}
