package com.varicent.draws.dao.jdbc;

import java.util.Date;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectAggregate;
import com.varicent.draws.domain.DrawTemplate;
import com.varicent.draws.domain.DrawTemplateName;

public class PayoutDetailsQuery {
	private static QueryDefinition getDrawTemplateResultSubQuery(String tablename, DrawTemplateName template) {
		QueryDefinition q2 = new QueryDefinition(tablename);
		q2.select(tablename, "PayeeID_", "PayeeID");
		q2.select(tablename, "Period_", "Period");
		q2.select(tablename, "Value_", "Value");
		q2.select(tablename, "Payout");
		q2.select(tablename, "Earning", "Earnings");
		q2.select(tablename, "Draw", "Amount");
		if (template.getType() == DrawTemplate.TemplateType.NonRecoverable) {
			q2.select(Literal.newNullLiteral(), "Balance");
		} else {
			q2.select(tablename, "Balance_", "Balance");
		}

		q2.select("DrawTemplate", "Level");
		q2.select("DrawDefinition", "TimeID");
		QueryDefinition templateQuery = new QueryDefinition("DrawTemplate");
		templateQuery.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, template.getId());
		Join templateJoin = new Join(templateQuery, "DrawTemplate", Join.Type.CROSS);
		q2.joinWith(templateJoin);
		Join definitionJoin = new Join("DrawDefinition", Join.Type.INNER);
		definitionJoin.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, "DrawTemplate",
				"BlockID");
		q2.joinWith(definitionJoin);
		return q2;
	}

	public static QueryDefinition getBaseDrawTemplateResultsQuery(DrawTemplateName template, Date start, Date end) {
		QueryDefinition templateResults = null;
		String tablename = "_DrawTemplateResult" + template.getId();
		templateResults = getDrawTemplateResultSubQuery(tablename, template);
		QueryDefinition query = new QueryDefinition(templateResults, "DrawTemplateResults");
		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, "DrawTemplateResults", "TimeID");
		timeJoin.newConstraint("Time_", "Level_", Constraint.Operator.Equals, "DrawTemplateResults", "Level");
		timeJoin.newConstraint("Time_", "Name_", Constraint.Operator.Equals, "DrawTemplateResults", "Period");
		query.joinWith(timeJoin);
		if (start != null || end != null) {
			if (start != null) {
				query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, start);
			}

			if (end != null) {
				query.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, end);
			}
		}

		return query;
	}

	public static QueryDefinition getYTDDrawTemplateResultsQuery(DrawTemplateName template, Date start, Date end) {
		QueryDefinition query = getBaseDrawTemplateResultsQuery(template, start, end);
		query.select("DrawTemplateResults", "PayeeID");
		query.select("DrawTemplateResults", "Value");
		query.select("DrawTemplateResults", "Payout");
		query.select("DrawTemplateResults", "Earnings");
		query.select("Time_", "Starting_", "Starting");
		query.select("Time_", "Ending_", "Ending");
		return query;
	}

	public static QueryDefinition getYTDDrawTemplateBalanceQuery(DrawTemplateName template, Date start, Date end) {
		QueryDefinition query = getBaseDrawTemplateResultsQuery(template, start, end);
		Join timeJoin = new Join("Time_", "BalanceTime", Join.Type.INNER);
		timeJoin.newConstraint("BalanceTime", "TimeID_", Constraint.Operator.Equals, "DrawTemplateResults", "TimeID");
		timeJoin.newConstraint("BalanceTime", "Level_", Constraint.Operator.Equals, "DrawTemplateResults", "Level");
		timeJoin.newConstraint("BalanceTime", "Name_", Constraint.Operator.Equals, "DrawTemplateResults", "Period");
		query.joinWith(timeJoin);
		QueryDefinition clone = getBaseDrawTemplateResultsQuery(template, start, end);
		clone.joinWith(timeJoin);
		clone.select("DrawTemplateResults", "PayeeID");
		clone.addSelect(new SelectAggregate(SelectAggregate.Type.MAX, "BalanceTime", "Ending_", "MaxEnding"));
		clone.groupBy("PayeeID");
		Join selfJoin = new Join(clone, "SelfJoin", Join.Type.INNER);
		selfJoin.newConstraint("SelfJoin", "PayeeID", Constraint.Operator.Equals, "DrawTemplateResults", "PayeeID");
		query.joinWith(selfJoin);
		query.newConstraint("BalanceTime", "Ending_", Constraint.Operator.Equals, "SelfJoin", "MaxEnding");
		query.select("DrawTemplateResults", "PayeeID");
		query.select("DrawTemplateResults", "Balance");
		return query;
	}

	public static QueryDefinition getDrawQueryBase(int drawId, int templateId, Date start, Date end) {
		QueryDefinition fixedTermQuery = new QueryDefinition("DrawAssignmentFixedTerm");
		fixedTermQuery.select("DrawAssignmentFixedTerm", "PayeeID");
		fixedTermQuery.select("DrawAssignmentFixedTerm", "TemplateID", "TemplateID");
		fixedTermQuery.select("DrawAssignmentFixedTermAmount", "PeriodStart", "Start");
		fixedTermQuery.select("DrawAssignmentFixedTermAmount", "PeriodStart", "Ending");
		fixedTermQuery.select("DrawAssignmentFixedTermAmount", "Amount");
		Join fixedTermQueryJoin = new Join("DrawAssignmentFixedTermAmount", Join.Type.INNER);
		fixedTermQueryJoin.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals,
				"DrawAssignmentFixedTerm", "AssignmentID");
		fixedTermQuery.joinWith(fixedTermQueryJoin);
		QueryDefinition ongoingTermQuery = new QueryDefinition("DrawAssignmentOngoingTerm");
		ongoingTermQuery.select("DrawAssignmentOngoingTerm", "PayeeID");
		ongoingTermQuery.select("DrawAssignmentOngoingTerm", "TemplateID");
		ongoingTermQuery.select("DrawAssignmentOngoingTerm", "StartDate", "Start");
		ongoingTermQuery.select("DrawAssignmentOngoingTerm", "EndDate", "Ending");
		ongoingTermQuery.select("DrawAssignmentOngoingTerm", "Amount");
		fixedTermQuery.union(ongoingTermQuery);
		QueryDefinition query = new QueryDefinition(fixedTermQuery, "DrawAssignment");
		Join templateJoin = new Join("DrawTemplate", Join.Type.INNER);
		templateJoin.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, "DrawAssignment", "TemplateID");
		query.joinWith(templateJoin);
		Join definitionJoin = new Join("DrawDefinition", Join.Type.INNER);
		definitionJoin.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, "DrawTemplate",
				"BlockID");
		query.joinWith(definitionJoin);
		Join periodJoin = new Join("Time_", "TemplateTime", Join.Type.LEFT);
		periodJoin.newConstraint("TemplateTime", "TimeID_", Constraint.Operator.Equals, "DrawDefinition", "TimeID");
		periodJoin.newConstraint("TemplateTime", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		OrClause orClause = new OrClause();
		orClause.newConstraint("TemplateTime", "Starting_", Constraint.Operator.LessThanEquals, "DrawAssignment",
				"Ending");
		orClause.newNullConstraint("DrawAssignment", "Ending", true);
		periodJoin.addConstraint(orClause);
		periodJoin.newConstraint("TemplateTime", "Ending_", Constraint.Operator.GreaterThanEquals, "DrawAssignment",
				"Start");
		query.joinWith(periodJoin);
		if (start != null) {
			query.newConstraint("TemplateTime", "Starting_", Constraint.Operator.GreaterThanEquals, start);
		}

		if (end != null) {
			query.newConstraint("TemplateTime", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		query.newConstraint("DrawAssignment", "TemplateID", Constraint.Operator.Equals, templateId);
		return query;
	}

	public static QueryDefinition getByPeriodDrawTemplateResultsQuery(DrawTemplateName template) {
		QueryDefinition query = getBaseDrawTemplateResultsQuery(template, (Date) null, (Date) null);
		query.select("DrawTemplateResults", "PayeeID");
		query.select("DrawTemplateResults", "Period");
		query.select("DrawTemplateResults", "Value");
		query.select("DrawTemplateResults", "Balance");
		query.select("DrawTemplateResults", "Payout");
		query.select("DrawTemplateResults", "Earnings");
		query.select("DrawTemplateResults", "Amount");
		query.select("Time_", "Ending_", "Ending");
		query.select("Time_", "Starting_", "Starting");
		return query;
	}

	public static QueryDefinition getYTDPayoutQuery(int drawId, DrawTemplateName template, String payeeId,
			String workflowGroupId, String calendar, String level, Date start, Date end) {
		QueryDefinition query = new QueryDefinition("Time_");
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, calendar);
		query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		if (start != null) {
			query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, start);
		}

		if (end != null) {
			query.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		query.select("DrawTemplateResults", "PayeeID");
		query.select("DrawTemplateResults", "Earnings");
		query.select("DrawTemplateResults", "Value");
		query.select("DrawTemplateResults", "Payout");
		Join templateJoin = new Join(getYTDDrawTemplateResultsQuery(template, start, end), "DrawTemplateResults",
				Join.Type.INNER);
		templateJoin.newConstraint("DrawTemplateResults", "Ending", Constraint.Operator.GreaterThanEquals, "Time_",
				"Starting_");
		templateJoin.newConstraint("DrawTemplateResults", "Ending", Constraint.Operator.LessThanEquals, "Time_",
				"Ending_");
		query.joinWith(templateJoin);
		if (payeeId != null) {
			query.newConstraint("DrawTemplateResults", "PayeeID", Constraint.Operator.Equals, payeeId);
		} else if (workflowGroupId != null) {
			QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
			groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, workflowGroupId);
			Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals,
					"DrawTemplateResults", "PayeeID");
			query.joinWith(workflowJoin);
		}

		return query;
	}

	public static QueryDefinition getByPeriodPayoutQuery(int drawId, DrawTemplateName template, String payeeId,
			String workflowGroupId, String calendar, String level, Date start, Date end) {
		QueryDefinition query = new QueryDefinition("Time_");
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, calendar);
		query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		if (start != null) {
			query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, start);
		}

		if (end != null) {
			query.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		query.select("Payee_", "PayeeID_", "PayeeID");
		query.select("Payee_", "Name_", "Name");
		query.select("DrawTemplateResults", "Period");
		query.select("Time_", "Ending_", "PeriodEnd");
		query.select("DrawTemplateResults", "Amount");
		query.select("DrawTemplateResults", "Earnings");
		query.select("DrawTemplateResults", "Value");
		query.select("DrawTemplateResults", "Balance");
		query.select("DrawTemplateResults", "Payout");
		Join templateJoin = new Join(getByPeriodDrawTemplateResultsQuery(template), "DrawTemplateResults",
				Join.Type.INNER);
		templateJoin.newConstraint("DrawTemplateResults", "Starting", Constraint.Operator.LessThanEquals, "Time_",
				"Ending_");
		templateJoin.newConstraint("DrawTemplateResults", "Ending", Constraint.Operator.GreaterThanEquals, "Time_",
				"Ending_");
		query.joinWith(templateJoin);
		Join payeeJoin = new Join("Payee_", Join.Type.INNER);
		payeeJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "DrawTemplateResults", "PayeeID");
		query.joinWith(payeeJoin);
		if (workflowGroupId != null) {
			QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
			groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, workflowGroupId);
			Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_",
					"PayeeID_");
			query.joinWith(workflowJoin);
		}

		if (payeeId != null) {
			query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		}

		return query;
	}
}
