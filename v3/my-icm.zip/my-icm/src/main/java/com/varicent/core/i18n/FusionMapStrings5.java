package com.varicent.core.i18n;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

@Component
public class FusionMapStrings5 {
	private final MessageSource messageSource;

	@Autowired
	public FusionMapStrings5(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public String getMessage(Key key) {
		return this.getMessage(key, Locale.getDefault());
	}

	public String getMessage(Key key, Locale locale) {
		return this.messageSource.getMessage(key.toString(), (Object[]) null, locale);
	}

	public static enum Key {
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_03("webreport.fusion.tooltip.FCMap_KosovoDistricts_03"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_05("webreport.fusion.tooltip.FCMap_KosovoDistricts_05"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_25("webreport.fusion.tooltip.FCMap_KosovoDistricts_25"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_26("webreport.fusion.tooltip.FCMap_KosovoDistricts_26"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_27("webreport.fusion.tooltip.FCMap_KosovoDistricts_27"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_28("webreport.fusion.tooltip.FCMap_KosovoDistricts_28"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_KosovoDistricts_29("webreport.fusion.tooltip.FCMap_KosovoDistricts_29"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotBG(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotBG"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotBO(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotBO"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotBR(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotBR"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotSD(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotSD"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotPD(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotPD"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotJA(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotJA"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotKB(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotKB"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotMA(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotMA"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotMR(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotMR"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotNS(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotNS"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotSC(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotSC"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotSN(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotSN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotPC(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotPC"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotPI(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotPI"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotPM(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotPM"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotRN(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotRN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotRS(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotRS"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotJC(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotJC"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotJN(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotJN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotSM(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotSM"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotSU(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotSU"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotTO(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotTO"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotZC(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotZC"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotZJ(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotZJ"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SerbiaWoKosovo_RS_dotZL(
				"webreport.fusion.tooltip.FCMap_SerbiaWoKosovo_RS_dotZL"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotBG("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotBG"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotEE("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotEE"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotJG("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotJG"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotEB("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotEB"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotNB("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotNB"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotWH("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotWH"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotUN("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotUN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotWR("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotWR"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotWB("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotWB"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SouthSudan_SD_dotWE("webreport.fusion.tooltip.FCMap_SouthSudan_SD_dotWE"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotGZ(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotGZ"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotGD(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotGD"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotBN(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotBN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotKA(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotKA"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotKH(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotKH"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotND(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotND"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotNK(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotNK"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotNO(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotNO"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotRS(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotRS"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotRN(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotRN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotSI(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotSI"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotSD(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotSD"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotSK(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotSK"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotWD(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotWD"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotWK(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotWK"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_SudanWoSouthSudan_SD_dotWN(
				"webreport.fusion.tooltip.FCMap_SudanWoSouthSudan_SD_dotWN"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_01(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_01"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_02(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_02"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_03(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_03"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_04(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_04"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_05(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_05"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_06(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_06"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_07(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_07"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_08(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_08"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_World8WithAntarctica_09(
				"webreport.fusion.tooltip.FCMap_World8WithAntarctica_09"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_NA("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_NA"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_SA("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_SA"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_EU("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_EU"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_AS("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_AS"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_AF("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_AF"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_AU("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_AU"),
		WEBREPORT_FUSION_TOOLTIP_FCMap_WorldWithAntarctica_AT("webreport.fusion.tooltip.FCMap_WorldWithAntarctica_AT");

		private final String key;
		private final int paramCount;

		private Key(String key) {
			this.key = key;
			this.paramCount = 0;
		}

		private Key(String key, int paramCount) {
			this.key = key;
			this.paramCount = paramCount;
		}

		public int getParamCount() {
			return this.paramCount;
		}

		@Override
		public String toString() {
			return this.key;
		}
	}
}
