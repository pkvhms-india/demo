package com.varicent.core.math.expressions;

public interface AssignableNode {
	String getName();

	EvaluateNode getNode();

	void setValue(Object var1);
}
