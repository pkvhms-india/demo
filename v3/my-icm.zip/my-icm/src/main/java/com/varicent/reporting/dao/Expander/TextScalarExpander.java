package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class TextScalarExpander extends BaseExpander {
	public TextScalarExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("TextScalarDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("TextScalarDisplay")) {
			this.streamReader.nextTag();
			writer.writeStartElement("TextScalarDisplay");
			super.copyCurrentNode(writer);
			String source = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("SourceData");
			String value = "";
			if (!scope.isNull(source)) {
				value = scope.getObject(source).toString();
			}

			writer.writeCharacters(value);
			writer.writeEndElement();
			if (this.streamReader.getLocalName().equals("Link")) {
				LinkExpander link = new LinkExpander(this.streamReader);
				link.read(writer, scope, permitted, editable);
			}

			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
