package com.varicent.draws.web;

import java.util.ArrayList;
import java.util.List;

import com.varicent.draws.domain.DrawAssignmentFixedTerm;

public class DrawAssignmentFixedTermCommand extends DrawAssignmentCommand {
	private List<DrawAssignmentFixedTerm> fixedTermAssignments = new ArrayList();
	private boolean hideInactivePayees;

	public List<DrawAssignmentFixedTerm> getFixedTermAssignments() {
		return this.fixedTermAssignments;
	}

	public void setFixedTermAssignments(List<DrawAssignmentFixedTerm> fixedTermAssignments) {
		this.fixedTermAssignments = fixedTermAssignments;
	}

	public boolean isHideInactivePayees() {
		return this.hideInactivePayees;
	}

	public void setHideInactivePayees(boolean hideInactivePayees) {
		this.hideInactivePayees = hideInactivePayees;
	}

	public int getMaxPeriodCount() {
		int maxPeriodCount = 0;

		for (DrawAssignmentFixedTerm fixedterm : this.fixedTermAssignments) {
			maxPeriodCount = Math.max(maxPeriodCount, fixedterm.getPeriodAmounts().size());
		}

		return maxPeriodCount;
	}
}
