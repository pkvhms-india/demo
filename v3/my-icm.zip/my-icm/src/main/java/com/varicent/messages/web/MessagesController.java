package com.varicent.messages.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.varicent.common.admin.domain.AdminNote;
import com.varicent.common.admin.service.AdminManager;

@Controller
public class MessagesController {
	private static final String VIEW = "messages/messages";
	private final AdminManager adminManager;

	@Autowired
	public MessagesController(AdminManager adminManager) {
		this.adminManager = adminManager;
	}

	@ModelAttribute("messages")
	public List<AdminNote> getMessages() {
		return this.adminManager.getAdminNotes();
	}

	@RequestMapping(method = { RequestMethod.GET }, value = { "/messages/messages.html" })
	public String prepareView() {
		return "messages/messages";
	}
}
