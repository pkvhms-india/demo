package com.varicent.payeeledger.web.view;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.domain.Plan;
import com.varicent.core.i18n.Messages;
import com.varicent.core.view.AbstractExcelView;
import com.varicent.core.view.ExcelUtility;
import com.varicent.payeeledger.domain.SummaryRow;

@Component
public class SummaryExcelView extends AbstractExcelView {
	private final Messages messages;

	@Autowired
	public SummaryExcelView(Messages messages) {
		this.messages = messages;
	}

	@Override
	protected void buildExcelDocument(Map model, Workbook wb, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		List<SummaryRow> rows = (List) model.get("rows");
		if (rows != null && !rows.isEmpty()) {
			Plan plan = (Plan) model.get("plan");
			Payee payee = (Payee) model.get("payee");
			String sheetName = plan.getId() + " - " + payee.getName();
			Sheet sheet = wb.createSheet(ExcelUtility.createSafeSheetName(sheetName));
			sheet.setDefaultColumnWidth(20);
			PrintSetup printSetup = sheet.getPrintSetup();
			printSetup.setLandscape(true);
			printSetup.setPaperSize((short) 1);
			Header header = sheet.getHeader();
			header.setCenter(plan.toString() + " - " + payee.toString());
			ExcelUtility excelUtility = ExcelUtility.getExcelSSUtility(wb);
			Font boldFont = excelUtility.getFont("Tahoma", (short) 10);
			boldFont.setBoldweight((short) 700);
			String numberFormatString = "#,##0.00";
			CellStyle labelCellStyle = excelUtility.createTextCellStyle(boldFont);
			CellStyle headerCellStyle = excelUtility.createTextCellStyle(boldFont);
			headerCellStyle.setAlignment((short) 3);
			CellStyle numberCellStyle = excelUtility.createDataCellStyle(numberFormatString);
			CellStyle totalNumberCellStyle = excelUtility.createDataCellStyle(boldFont, numberFormatString);
			int sheetRow = 0;
			Row row = sheet.createRow(sheetRow);
			Locale locale = LocaleContextHolder.getLocale();
			setValueAndStyle(row.createCell(0), this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_PERIOD, locale),
					labelCellStyle);
			setValueAndStyle(row.createCell(1), this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_EARNINGS, locale),
					headerCellStyle);
			setValueAndStyle(row.createCell(2),
					this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_NET_ADJUSTMENTS, locale), headerCellStyle);
			setValueAndStyle(row.createCell(3),
					this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_NET_EARNINGS, locale), headerCellStyle);
			setValueAndStyle(row.createCell(4), this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_PENDING, locale),
					headerCellStyle);
			setValueAndStyle(row.createCell(5), this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_PAYMENT, locale),
					headerCellStyle);
			++sheetRow;
			int lastIndex = rows.size() - 1;
			int i = 0;

			for (int n = lastIndex; i < n; ++i) {
				SummaryRow summaryRow = rows.get(i);
				if (summaryRow.getDate() == null) {
					break;
				}

				row = sheet.createRow(sheetRow);
				setValueAndStyle(row.createCell(0), summaryRow.getPeriod().getName(), (CellStyle) null);
				setValueAndStyle(row.createCell(1), summaryRow.getEarnings().doubleValue(), numberCellStyle);
				setValueAndStyle(row.createCell(2), summaryRow.getNetAdjustments().doubleValue(), numberCellStyle);
				setValueAndStyle(row.createCell(3), summaryRow.getNetEarnings().doubleValue(), numberCellStyle);
				setValueAndStyle(row.createCell(4), summaryRow.getPending().doubleValue(), numberCellStyle);
				setValueAndStyle(row.createCell(5), summaryRow.getPayment().doubleValue(), numberCellStyle);
				++sheetRow;
			}

			SummaryRow totalRow = rows.get(lastIndex);
			row = sheet.createRow(sheetRow);
			setValueAndStyle(row.createCell(0),
					this.messages.getMessage(Messages.Key.LEDGER_SUMMARY_GRAND_TOTAL, locale), labelCellStyle);
			setValueAndStyle(row.createCell(1), totalRow.getEarnings().doubleValue(), totalNumberCellStyle);
			setValueAndStyle(row.createCell(2), totalRow.getNetAdjustments().doubleValue(), totalNumberCellStyle);
			setValueAndStyle(row.createCell(3), totalRow.getNetEarnings().doubleValue(), totalNumberCellStyle);
			setValueAndStyle(row.createCell(4), totalRow.getPending().doubleValue(), totalNumberCellStyle);
			setValueAndStyle(row.createCell(5), totalRow.getPayment().doubleValue(), totalNumberCellStyle);
		}
	}

	private static void setValueAndStyle(Cell cell, String value, CellStyle style) {
		cell.setCellValue(value);
		if (style != null) {
			cell.setCellStyle(style);
		}

	}

	private static void setValueAndStyle(Cell cell, Double value, CellStyle style) {
		cell.setCellValue(value);
		if (style != null) {
			cell.setCellStyle(style);
		}

	}
}
