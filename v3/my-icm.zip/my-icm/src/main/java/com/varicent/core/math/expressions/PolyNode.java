package com.varicent.core.math.expressions;

import java.util.List;

public abstract class PolyNode extends JavascriptNode {
	protected List<EvaluateNode> args;

	public PolyNode(List<EvaluateNode> args, int suffix) {
		super(suffix);
		this.args = args;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append("var values = new Array();");
		int i = 0;

		for (EvaluateNode arg : this.args) {
			sb.append("values[");
			sb.append(i);
			sb.append("] = ");
			sb.append(((JavascriptNode) arg).getJSResultVariableName(jsUtil));
			sb.append(";");
			++i;
		}

		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(values);");
		sb.append("}");

		for (EvaluateNode arg : this.args) {
			sb.append(((JavascriptNode) arg).toJavascript(jsUtil));
		}

		return sb.toString();
	}
}
