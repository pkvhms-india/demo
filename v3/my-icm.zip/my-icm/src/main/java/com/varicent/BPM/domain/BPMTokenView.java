package com.varicent.BPM.domain;

import java.util.Date;

public class BPMTokenView {
	private int tokenID;
	private String workflow;
	private int workflowID;
	private String description;
	private String nodeName;
	private String payee;
	private String payeeName;
	private String report;
	private Date createdAt;
	private Date lastModified;
	private int rowNumber;
	private String lastModifier;

	public BPMTokenView(int tokenID, String workflow, int workflowID, String description, String nodeName, String payee,
			String payeeName, String report, Date createdAt, Date lastModified, int rowNumber, String lastModifier) {
		this.tokenID = tokenID;
		this.workflow = workflow;
		this.workflowID = workflowID;
		this.description = description;
		this.nodeName = nodeName;
		this.payee = payee;
		this.payeeName = payeeName;
		this.report = report;
		this.createdAt = createdAt;
		this.lastModified = lastModified;
		this.rowNumber = rowNumber;
		this.lastModifier = lastModifier;
	}

	public BPMTokenView(int tokenID, String workflow, int workflowID, String description, String nodeName, String payee,
			String payeeName, String report, Date createdAt, Date lastModified, int rowNumber) {
		this(tokenID, workflow, workflowID, description, nodeName, payee, payeeName, report, createdAt, lastModified,
				rowNumber, (String) null);
	}

	public BPMTokenView(int tokenID, String workflow, int workflowID, String description, String nodeName, String payee,
			String payeeName, String report, Date createdAt, Date lastModified) {
		this(tokenID, workflow, workflowID, description, nodeName, payee, payeeName, report, createdAt, lastModified,
				-1);
	}

	public BPMTokenView(int tokenID, String initiator, String lastActor, Date dateInitiation, Date dateCompletion,
			String workflowName, String webReportName) {
		this(tokenID, workflowName, -1, (String) null, (String) null, initiator, (String) null, webReportName,
				dateInitiation, dateCompletion, -1, lastActor);
	}

	public BPMTokenView(int tokenID, String ownerID, String ownerName, Date createdAt, Date lastModified, String wfname,
			int rowNumber) {
		this(tokenID, wfname, -1, (String) null, (String) null, ownerID, ownerName, (String) null, createdAt,
				lastModified, rowNumber, (String) null);
	}

	public BPMTokenView(int tokenID, String ownerID, String ownerName, Date createdAt, Date lastModified,
			String wfname) {
		this(tokenID, ownerID, ownerName, createdAt, lastModified, wfname, -1);
	}

	public BPMTokenView(int tokenID, String ownerID, Date lastModified) {
		this(tokenID, ownerID, (String) null, (Date) null, lastModified, (String) null);
	}

	public int getTokenID() {
		return this.tokenID;
	}

	public String getWorkflow() {
		return this.workflow;
	}

	public int getWorkflowID() {
		return this.workflowID;
	}

	public String getDescription() {
		return this.description;
	}

	public String getNodeName() {
		return this.nodeName;
	}

	public String getPayee() {
		return this.payee;
	}

	public String getLastActor() {
		return this.lastModifier;
	}

	public String getPayeeName() {
		return this.payeeName;
	}

	public String getReport() {
		return this.report;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public Date getLastModified() {
		return this.lastModified;
	}

	public int getRowNumber() {
		return this.rowNumber;
	}
}
