package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.i18n.Messages;

public class ChartExpander extends BaseExpander {
	Messages messages;

	public ChartExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		this.messages = messages;
	}

	public void expandChartNode(XMLStreamWriter writer) throws XMLStreamException {
		if (!this.streamReader.getLocalName().equals("chart")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			writer.writeCharacters("<chart ");
			String captureAttribute = "exportDialogMessage='"
					+ this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_CAPTURING, LocaleContextHolder.getLocale())
					+ "' ";
			writer.writeCharacters(captureAttribute);
			writer.writeCharacters("showBorder='0' ");
			writer.writeCharacters("bgColor='#FFFFFF' ");
			writer.writeCharacters("bgAlpha='0' ");
			writer.writeCharacters("exportAction='save' ");
			writer.writeCharacters("exportAtClient='0' ");
			writer.writeCharacters("exportEnabled='1' ");
			writer.writeCharacters("exportFormats='JPG=JPG' ");
			writer.writeCharacters("exportShowMenuItem='0' ");
			writer.writeCharacters("exportHandler='Placeholder' ");
			writer.writeCharacters("streamlinedData='0' ");
			writer.writeCharacters("labelPadding='15' ");
			String noDataLabel = "noDataLabel='"
					+ this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_NO_DATA, LocaleContextHolder.getLocale())
					+ "' ";
			String legendTitleLabel = "legendTitleLabel='" + this.messages
					.getMessage(Messages.Key.WEBREPORT_D3_LEGENDTITLELABEL, LocaleContextHolder.getLocale()) + "' ";
			String totalLabel = "totalLabel='"
					+ this.messages.getMessage(Messages.Key.WEBREPORT_D3_TOTALLABEL, LocaleContextHolder.getLocale())
					+ "' ";
			writer.writeCharacters(noDataLabel);
			writer.writeCharacters(legendTitleLabel);
			writer.writeCharacters(totalLabel);
			String[] attributeNames = new String[] { "alternateHGridAlpha", "alternateHGridColor", "anchorAlpha",
					"anchorBgAlpha", "anchorRadius", "animation", "areaBorderThickness", "baseFontColor",
					"canvasBgColor", "canvasBorderAlpha", "canvasBorderThickness", "canvasPadding", "caption",
					"captionPadding", "chartLeftMargin", "chartRightMargin", "clipBubbles", "connectNullData",
					"connectorDashed", "decimals", "decimalPrecision", "decimalSeparator", "divLineAlpha",
					"divLineColor", "enableSmartLabels", "forceDecimals", "formatNumberScale", "is2D", "is3D",
					"isPercentage", "isSYPercentage", "isSliced", "labelDisplay", "legendBgColor", "legendBorderColor",
					"legendIconScale", "legendPosition", "legendShadow", "lineColor", "lineThickness",
					"manageLabelOverflow", "numberPrefix", "numberSuffix", "numDivLines", "numMinorDivLines",
					"overlapBars", "palette", "pieYScale", "plotBorderAlpha", "plotBorderThickness", "plotFillAlpha",
					"plotFillColor", "plotGradientColor", "PYAxisName", "radarFillColor", "scrollPadding", "sDecimals",
					"sDecimalSeparator", "setAdaptiveSYMin", "sFormatNumberScale", "slicingDistance", "shadowAlpha",
					"showAlternateHGridColor", "showAlternateVGridColor", "showAnchors", "showCanvasBg",
					"showDivLineValues", "showLabels", "showLegend", "showNames", "showMinorDivLineValues",
					"showPlotBorder", "showShadow", "showSum", "showSYValues", "showTitle", "showValues",
					"showYAxisValues", "slantLabels", "sNumberPrefix", "sNumberSuffix", "sThousandSeparator",
					"subCaption", "startingAngle", "streamLinedData", "SYAxisName", "thousandSeparator",
					"toolTipBorderColor", "use3DLighting", "useEllipsesWhenOverflow", "useRoundEdges", "xAxisName",
					"yAxisName", "yAxisMinValue", "YMinMax", "YMin", "YMax", "ZMinMax", "ZMin", "ZMax",
					"zeroPlaneAlpha", "zeroPlaneColor", "zeroPlaneThickness" };
			String[] attributeValues = new String[attributeNames.length];

			for (int i = 0; i < attributeNames.length; ++i) {
				attributeValues[i] = this.streamReader.getAttributeValue((String) null, attributeNames[i]);
				if (attributeValues[i] != null) {
					try {
						String toWrite = URLDecoder.decode(attributeValues[i], "UTF-8");
						toWrite = attributeNames[i] + "='" + toWrite + "' ";
						writer.writeCharacters(toWrite);
					} catch (UnsupportedEncodingException var10) {
						writer.writeCharacters(attributeNames[i] + "='" + attributeValues[i] + "' ");
					}
				}
			}

			writer.writeCharacters(">");
		}
	}
}
