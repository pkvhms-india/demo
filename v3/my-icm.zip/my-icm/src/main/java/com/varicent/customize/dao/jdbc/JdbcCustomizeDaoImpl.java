package com.varicent.customize.dao.jdbc;

import java.math.BigDecimal;
import java.sql.DataTruncation;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.varicent.common.audit.dao.AuditDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.InsertDefinition;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.domain.UpdateDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.query.sql.insert.InsertBuilder;
import com.varicent.common.query.sql.update.UpdateBuilder;
import com.varicent.common.query.xml.SourceDefinitionParser;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.ui.dao.PickListDao;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.Database;
import com.varicent.core.database.portability.SqlSyntax;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.schema.Schema;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.IllegalValueException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Validation;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.customize.domain.CustomColumn;
import com.varicent.customize.domain.CustomRow;
import com.varicent.customize.domain.CustomType;
import com.varicent.customize.domain.EditOperation;
import com.varicent.customize.domain.EditRow;
import com.varicent.security.domain.UserAccount;

@Repository("customizeDao")
public class JdbcCustomizeDaoImpl implements CustomizeDao {
	private static final String EDIT_TABLE_PREFIX = "_WDE_";
	private static final int SOURCE_COLUMN_START_INDEX = 4;
	private static final RowMapper<CustomRow> dataRowMapper = new RowMapper<CustomRow>() {
		@Override
		public CustomRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
			CustomRow row = new CustomRow();
			int i = 0;

			for (int n = rs.getMetaData().getColumnCount(); i < n; ++i) {
				row.add(JdbcCustomizeDaoImpl.processRowObject(rs.getObject(i + 1)));
			}

			return row;
		}
	};
	private static final RowMapper<EditRow> editRowMapper = new RowMapper<EditRow>() {
		@Override
		public EditRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
			SqlSyntax syntax = Database.getSyntax();
			EditRow row = new EditRow(rs.getInt(syntax.toValidIdentifier("_EditID_")),
					rs.getString(syntax.toValidIdentifier("_PayeeID_")),
					rs.getTimestamp(syntax.toValidIdentifier("_Created_")),
					EditOperation.values()[rs.getInt(syntax.toValidIdentifier("_Operation_"))]);
			int i = 4;

			for (int n = rs.getMetaData().getColumnCount(); i < n; ++i) {
				row.add(JdbcCustomizeDaoImpl.processRowObject(rs.getObject(i + 1)));
			}

			return row;
		}
	};
	private final JdbcOperations operations;
	private final AuditDao auditDao;
	private final HistoryDao historyDao;
	private final PickListDao pickListDao;
	private final SchemaDao schemaDao;

	@Autowired
	public JdbcCustomizeDaoImpl(DataSource ds, AuditDao auditDao, HistoryDao historyDao, PickListDao pickListDao,
			SchemaDao schemaDao) {
		this.operations = Database.getOperations(ds);
		this.auditDao = auditDao;
		this.historyDao = historyDao;
		this.pickListDao = pickListDao;
		this.schemaDao = schemaDao;
	}

	@Override
	public List<CustomColumn> getColumns(String table) {
		UserAccount user = UserAccount.getCurrent();
		List<ColumnDefinition> definitions = this.schemaDao.getColumns(table);
		List<String> editableColumnNames = this.getEditableColumnNames(user.getPayeeId(), table);
		List<CustomColumn> columns = new ArrayList();

		for (ColumnDefinition definition : definitions) {
			boolean isEditable = editableColumnNames.contains(definition.getName());
			List<SelectOption> options = this.pickListDao.getOptions(definition.getTable(), definition.getName());
			CustomColumn column = new CustomColumn(definition, this.getColumnType(definition), isEditable,
					options != null);
			if (options != null) {
				column.addOptions(options);
			}

			columns.add(column);
		}

		return columns;
	}

	@Override
	public CustomType getColumnType(ColumnDefinition definition) {
		return getColumnCustomType(definition, this.operations);
	}

	@Override
	public CustomType getColumnType(String table, String column) {
		return getColumnCustomType(table, column, this.operations);
	}

	public static CustomType getColumnCustomType(ColumnDefinition definition, JdbcOperations operations) {
		CustomType type = getColumnCustomType(definition.getTable(), definition.getName(), operations);
		if (type == null) {
			type = getSystemColumnType(definition);
		}

		return type;
	}

	public static CustomType getColumnCustomType(String table, String column, JdbcOperations operations) {
		QueryDefinition query = new QueryDefinition("CustomColumn");
		query.select("CustomColumn", "Type");
		query.newConstraint("CustomColumn", "TableName", Constraint.Operator.Equals, table);
		query.newConstraint("CustomColumn", "ColumnName", Constraint.Operator.Equals, column);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> result = operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		CustomType type = null;
		if (!result.isEmpty()) {
			return CustomType.valueOf(result.get(0).toUpperCase());
		} else if (column.equals("Comment_")) {
			return CustomType.COMMENT;
		} else if (column.equals("Email_")) {
			return CustomType.EMAIL;
		} else {
			if (table.equals("Payee_")) {
				if (column.equals("PayeeID_") || column.equals("Parent_") || column.equals("Salutation_")
						|| column.equals("Phone_") || column.equals("Extension_") || column.equals("Name_")
						|| column.equals("TitleID_") || column.equals("Reports_To_")
						|| column.equals("Payee_Currency_")) {
					return CustomType.TEXT;
				}

				if (column.equals("Date_of_Hire_") || column.equals("Termination_Date_")) {
					return CustomType.DATE;
				}
			} else if (table.equals("Account_")) {
				if (column.equals("AccountID_") || column.equals("Name_") || column.equals("Parent_")
						|| column.equals("DrCr_")) {
					return CustomType.TEXT;
				}
			} else if (column.equals("EffStart_") || column.equals("EffEnd_")) {
				return CustomType.DATE;
			}

			return type;
		}
	}

	@Override
	public List<CustomRow> getData(String table, List<String> filterValues) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition viewQuery = new QueryDefinition("WebDataEditQuery");
		viewQuery.select("WebDataEditQuery", "Definition");
		viewQuery.newConstraint("WebDataEditQuery", "TableName", Constraint.Operator.Equals, table);
		List<String> result = this.operations.query(qb.toSql(viewQuery), RowMapperUtil.getStringMapper());
		List<ColumnDefinition> columns = this.schemaDao.getColumns(table);
		QueryDefinition query;
		if (result.isEmpty()) {
			query = new QueryDefinition(table);

			for (ColumnDefinition cd : columns) {
				query.select(table, cd.getName());
			}
		} else {
			SourceDefinition source;
			try {
				source = SourceDefinitionParser.getSourceDefinition(result.get(0));
			} catch (XMLStreamException e) {
				throw new RuntimeException(e);
			}

			source.constrainToWebUser();
			query = source.getQuery();
			this.RefreshSelectItems(query, table, columns);
		}

		query.limitTo(100);
		if (!filterValues.isEmpty()) {
			this.applyQueryFilter(query, table, columns, filterValues);
		}

		return this.operations.query(qb.toSql(query), dataRowMapper);
	}

	void RefreshSelectItems(QueryDefinition query, String table, List<ColumnDefinition> columns) {
		query.getSelect().clear();

		for (ColumnDefinition column : columns) {
			query.select(table, column.getName());
		}

	}

	@Override
	public List<EditRow> getPendingRows(String table, List<String> filterValues) {
		return this.getEdits(table, filterValues, EditOperation.INSERT);
	}

	@Override
	public List<EditRow> getPendingUpdates(String table, List<String> filterValues) {
		return this.getEdits(table, filterValues, EditOperation.UPDATE);
	}

	@Override
	public Set<String> getViewableTables() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition query = new QueryDefinition("WebDataEditColumn");
		query.selectDistinct();
		query.select("WebDataEditColumn", "TableName");
		query.newConstraint("WebDataEditColumn", "PayeeID", Constraint.Operator.Equals, user.getPayeeId());
		QueryBuilder qb = Database.getQueryBuilder();
		return new HashSet(this.operations.query(qb.toSql(query), RowMapperUtil.getStringMapper()));
	}

	@Override
	public void submitInsert(String table, List<String> values) throws DataSubmitException {
		if (this.isDirectEdit(table)) {
			try {
				this.historyDao.beginRevision();
				this.submitDirectEdit(table, (List) null, values, EditOperation.INSERT);
				this.historyDao.assignRevision();
				this.auditDao.logRevision(new Message(Messages.Key.MODULE_CUSTOMIZE, new Object[0]),
						new Message(Messages.Key.EVENT_EDIT_SUBMIT, new Object[0]),
						new Message(Messages.Key.EVENT_EDIT_SUBMIT_MESSAGE,
								new Object[] { table, StringUtils.collectionToDelimitedString(values, ", ") }));
			} finally {
				this.historyDao.endRevision();
			}
		} else {
			this.submitEdit(table, values, EditOperation.INSERT);
			this.auditDao.log(new Message(Messages.Key.MODULE_CUSTOMIZE, new Object[0]),
					new Message(Messages.Key.EVENT_EDIT_SUBMIT, new Object[0]),
					new Message(Messages.Key.EVENT_EDIT_SUBMIT_MESSAGE,
							new Object[] { table, StringUtils.collectionToDelimitedString(values, ", ") }));
		}

	}

	@Override
	public void submitUpdate(String table, List<String> originalValues, List<String> editedValues)
			throws DataSubmitException {
		if (this.isDirectEdit(table)) {
			try {
				this.historyDao.beginRevision();
				this.submitDirectEdit(table, originalValues, editedValues, EditOperation.UPDATE);
				this.historyDao.assignRevision();
				this.auditDao.logRevision(new Message(Messages.Key.MODULE_CUSTOMIZE, new Object[0]),
						new Message(Messages.Key.EVENT_EDIT_UPDATE_SUBMIT, new Object[0]),
						new Message(Messages.Key.EVENT_EDIT_UPDATE_SUBMIT_MESSAGE,
								new Object[] { table, StringUtils.collectionToDelimitedString(editedValues, ", ") }));
			} finally {
				this.historyDao.endRevision();
			}
		} else {
			this.submitEdit(table, editedValues, EditOperation.UPDATE);
			this.auditDao.log(new Message(Messages.Key.MODULE_CUSTOMIZE, new Object[0]),
					new Message(Messages.Key.EVENT_EDIT_UPDATE_SUBMIT, new Object[0]),
					new Message(Messages.Key.EVENT_EDIT_UPDATE_SUBMIT_MESSAGE,
							new Object[] { table, StringUtils.collectionToDelimitedString(editedValues, ", ") }));
		}

	}

	@Override
	public String getCustomTableType(String tableName) {
		QueryDefinition query = new QueryDefinition("CustomTable");
		query.select("CustomTable", "TableType");
		query.newConstraint("CustomTable", "TableName", Constraint.Operator.Equals, tableName);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> results = this.operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		return results.isEmpty() ? null : (String) results.get(0);
	}

	@Override
	public boolean isEffectiveDated(String tableName) {
		QueryDefinition query = new QueryDefinition("CustomTable");
		query.select("CustomTable", "EffectiveDated");
		query.newConstraint("CustomTable", "TableName", Constraint.Operator.Equals, tableName);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> results = this.operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (results.isEmpty()) {
			return false;
		} else {
			return Integer.parseInt(results.get(0)) == 1;
		}
	}

	private void applyQueryFilter(QueryDefinition query, String table, List<ColumnDefinition> columns,
			List<String> filterValues) {
		Assert.isTrue(columns.size() == filterValues.size());
		int i = 0;

		for (int n = columns.size(); i < n; ++i) {
			ColumnDefinition column = columns.get(i);
			String filterValue = filterValues.get(i);
			if (filterValue != null && filterValue.length() > 0) {
				query.newConstraint(table, column.getName(), Constraint.Operator.Equals,
						Schema.parse(filterValue, column.getType(), false));
				if (column.isKey()) {
					query.orderBy(table, column.getName());
				}
			}
		}

	}

	private void buildInsert(InsertDefinition insert, List<ColumnDefinition> columns, List<String> values)
			throws IllegalValueException {
		int i = 0;

		for (int n = columns.size(); i < n; ++i) {
			ColumnDefinition column = columns.get(i);
			String value = values.get(i);
			if (!this.isValid(column, value)) {
				throw new IllegalValueException(column.getTable(), column.getDisplayName(), column.getName(), value);
			}

			insert.addValue(column, value);
		}

	}

	private void buildUpdate(UpdateDefinition update, List<ColumnDefinition> columns, List<String> originalValues,
			List<String> editedValues) throws IllegalValueException {
		int i = 0;

		for (int n = columns.size(); i < n; ++i) {
			ColumnDefinition column = columns.get(i);
			String originalValue = originalValues.get(i);
			String editedValue = editedValues.get(i);
			if (!this.isValid(column, editedValue)) {
				throw new IllegalValueException(column.getTable(), column.getDisplayName(), column.getName(),
						editedValue);
			}

			update.set(column, editedValue);
			update.newConstraint(column, originalValue);
		}

	}

	private List<String> getEditableColumnNames(String payeeId, String table) {
		QueryDefinition query = new QueryDefinition("WebDataEditColumn");
		query.select("WebDataEditColumn", "ColumnName");
		query.newConstraint("WebDataEditColumn", "PayeeID", Constraint.Operator.Equals, payeeId);
		query.newConstraint("WebDataEditColumn", "TableName", Constraint.Operator.Equals, table);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
	}

	private List<EditRow> getEdits(String table, List<String> filterValues, EditOperation operation) {
		String editTable = this.getEditTable(table);
		QueryDefinition query = new QueryDefinition(editTable);

		for (ColumnDefinition cd : this.schemaDao.getColumns(editTable)) {
			query.select(editTable, cd.getName());
		}

		if (!filterValues.isEmpty()) {
			List<ColumnDefinition> tableColumns = this.schemaDao.getColumns(table);
			this.applyQueryFilter(query, editTable, tableColumns, filterValues);
		}

		query.newConstraint(editTable, "_Operation_", Constraint.Operator.Equals, operation.ordinal());
		query.orderBy(editTable, "_Created_");
		QueryBuilder qb = Database.getQueryBuilder();
		return this.operations.query(qb.toSql(query), editRowMapper);
	}

	private String getEditTable(String table) {
		return "_WDE_" + table;
	}

	private static CustomType getSystemColumnType(ColumnDefinition definition) {
		String table = definition.getTable();
		String column = definition.getName();
		if (table.equals("Payee_") && column.equals("Email_")) {
			return CustomType.EMAIL;
		} else if (column.equals("URL_")) {
			return CustomType.URL;
		} else if (column.equals("Comment_")) {
			return CustomType.COMMENT;
		} else if (definition.isDateTime()) {
			return CustomType.DATE;
		} else if (definition.isNumeric()) {
			return CustomType.NUMERIC;
		} else if (definition.isVarchar()) {
			return CustomType.TEXT;
		} else {
			Assert.state(false);
			return CustomType.TEXT;
		}
	}

	private boolean isDirectEdit(String table) {
		QueryDefinition query = new QueryDefinition("WebDataEditDirect");
		query.selectAll();
		query.newConstraint("WebDataEditDirect", "TableName", Constraint.Operator.Equals, table);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> result = this.operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		return !result.isEmpty();
	}

	private boolean isValid(ColumnDefinition definition, String value) {
		if (value.length() == 0) {
			return true;
		} else {
			CustomType type = this.getColumnType(definition);
			return Validation.isValid(type, value);
		}
	}

	private static Object processRowObject(Object o) {
		return o instanceof String && Database.getSyntax().isEmptyString((String) o) ? "" : o;
	}

	private void submitDirectEdit(String table, List<String> originalValues, List<String> values,
			EditOperation operation) throws DataSubmitException {
		try {
			List<ColumnDefinition> columns = this.schemaDao.getColumns(table);
			if (operation.equals(EditOperation.INSERT)) {
				Assert.isTrue(originalValues == null);
				List<String> columnNames = new ArrayList();

				for (ColumnDefinition column : columns) {
					columnNames.add(column.getName());
				}

				InsertDefinition insert = new InsertDefinition(table, columnNames);
				this.buildInsert(insert, columns, values);
				InsertBuilder ib = Database.getInsertBuilder();
				if (this.operations.update(ib.toSql(insert)) == 0) {
					throw new DataSubmitException(
							new Message(Messages.Key.WEBFORMS_ERROR_SUBMIT_CHANGES, new Object[0]));
				}
			} else {
				if (!operation.equals(EditOperation.UPDATE)) {
					throw new UnsupportedOperationException(operation.toString());
				}

				Assert.isTrue(originalValues != null);
				UpdateDefinition update = new UpdateDefinition(table);
				this.buildUpdate(update, columns, originalValues, values);
				UpdateBuilder ub = Database.getUpdateBuilder();
				if (this.operations.update(ub.toSql(update)) == 0) {
					throw new DataSubmitException(
							new Message(Messages.Key.WEBFORMS_ERROR_SUBMIT_CHANGES, new Object[0]));
				}
			}

		} catch (IllegalValueException e) {
			throw new DataSubmitException(
					new Message(Messages.Key.CUSTOMIZE_ERROR_VALUE, new Object[] { e.getColumnAlias() }));
		} catch (DataIntegrityViolationException e) {
			if (DataTruncation.class.isInstance(e.getCause())) {
				throw new DataSubmitException(
						new Message(Messages.Key.WEBFORMS_ERROR_SUBMIT_TRUNCATION, new Object[0]));
			} else {
				throw new DataSubmitException(new Message(Messages.Key.WEBFORMS_ERROR_SUBMIT_INTEGRITY, new Object[0]));
			}
		}
	}

	private void submitEdit(String table, List<String> values, EditOperation operation) throws DataSubmitException {
		List<String> columnNames = new ArrayList();
		columnNames.add("_PayeeID_");
		columnNames.add("_Created_");
		columnNames.add("_Operation_");
		List<ColumnDefinition> columns = this.schemaDao.getColumns(table);

		for (ColumnDefinition column : columns) {
			columnNames.add(column.getName());
		}

		try {
			values = this.truncateLargeNumbers(table, values, columns);
			InsertDefinition insert = new InsertDefinition(this.getEditTable(table), columnNames);
			insert.addValue(UserAccount.getCurrent().getPayeeId());
			insert.addSystemDateTime();
			insert.addValue(operation.ordinal());
			this.buildInsert(insert, columns, values);
			InsertBuilder ib = Database.getInsertBuilder();
			this.operations.update(ib.toSql(insert));
		} catch (IllegalValueException e) {
			if (e.getValue().length() == 0) {
				throw new DataSubmitException(
						new Message(Messages.Key.CUSTOMIZE_ERROR_REQUIRED_FIELD, new Object[] { e.getColumnAlias() }));
			} else {
				throw new DataSubmitException(
						new Message(Messages.Key.CUSTOMIZE_ERROR_VALUE, new Object[] { e.getColumnAlias() }));
			}
		}
	}

	private List<String> truncateLargeNumbers(String table, List<String> values, List<ColumnDefinition> cols) {
		List<String> tempVals = new ArrayList();

		for (int i = 0; i < values.size(); ++i) {
			String val = values.get(i);
			ColumnDefinition col = cols.get(i);
			if (!col.isNumeric()) {
				tempVals.add(val);
			} else {
				try {
					BigDecimal bd = new BigDecimal(val);
					if (bd.precision() > 37) {
						tempVals.add(val.substring(0, Math.min(val.length(), 37)));
					} else {
						tempVals.add(val);
					}
				} catch (Exception var9) {
					tempVals.add(val);
				}
			}
		}

		return tempVals;
	}
}
