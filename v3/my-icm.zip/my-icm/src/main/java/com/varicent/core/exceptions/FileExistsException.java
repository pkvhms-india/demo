package com.varicent.core.exceptions;

public class FileExistsException extends Exception {
	private static final long serialVersionUID = 1L;

	public FileExistsException() {
	}

	public FileExistsException(String message) {
		super(message);
	}

	public FileExistsException(String message, Throwable cause) {
		super(message, cause);
	}

	public FileExistsException(Throwable cause) {
		super(cause);
	}
}
