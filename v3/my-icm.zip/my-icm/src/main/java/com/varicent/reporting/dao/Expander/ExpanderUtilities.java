package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.util.Date;

import com.varicent.core.text.Format;
import com.varicent.reporting.domain.ColumnInfo;

public class ExpanderUtilities {
	public static String getRawValueAsString(Object val) {
		String rawValue;
		if (val instanceof BigDecimal) {
			BigDecimal bd = (BigDecimal) val;
			rawValue = bd.toPlainString();
		} else if (val instanceof Date) {
			rawValue = Long.toString(((Date) val).getTime());
		} else {
			rawValue = Format.asValueString(val);
		}

		return rawValue;
	}

	public static String getDataType(Object val) {
		String dataType;
		if (val instanceof BigDecimal) {
			dataType = ColumnInfo.Type.NUMERIC.toString();
		} else if (val instanceof Date) {
			dataType = ColumnInfo.Type.DATE.toString();
		} else {
			dataType = ColumnInfo.Type.VARCHAR.toString();
		}

		return dataType;
	}
}
