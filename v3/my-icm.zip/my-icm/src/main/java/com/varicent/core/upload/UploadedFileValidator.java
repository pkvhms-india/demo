package com.varicent.core.upload;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.varicent.core.upload.MalwareScanner.MalwareScanException;

public class UploadedFileValidator {

	private static final Logger LOG = LoggerFactory.getLogger(UploadedFileValidator.class);

	private static final long DEFAULT_MAX_BYTES = 10L * 1024L * 1024L;

	private static final Set<String> DEFAULT_ALLOWED_EXTENSIONS = Collections
			.unmodifiableSet(new LinkedHashSet<>(Arrays.asList("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
					"csv", "txt", "png", "jpg", "jpeg", "gif", "msg", "eml")));

	private static final Map<String, Set<String>> MIME_TYPES = new HashMap<>();

	private static final Map<String, List<byte[]>> MAGIC_NUMBERS = new HashMap<>();

	static {
		mime("pdf", "application/pdf");
		mime("doc", "application/msword", "application/vnd.ms-office");
		mime("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		mime("xls", "application/vnd.ms-excel", "application/vnd.ms-office");
		mime("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		mime("ppt", "application/vnd.ms-powerpoint", "application/vnd.ms-office");
		mime("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
		mime("csv", "text/csv", "text/plain", "application/csv", "application/vnd.ms-excel");
		mime("txt", "text/plain");
		mime("png", "image/png");
		mime("jpg", "image/jpeg");
		mime("jpeg", "image/jpeg");
		mime("gif", "image/gif");
		mime("msg", "application/vnd.ms-outlook", "application/octet-stream");
		mime("eml", "message/rfc822", "text/plain");

		byte[] ole2 = { (byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0, (byte) 0xA1, (byte) 0xB1, 0x1A, (byte) 0xE1 };
		byte[] zip = { 0x50, 0x4B, 0x03, 0x04 };
		byte[] zipEmpty = { 0x50, 0x4B, 0x05, 0x06 };
		byte[] zipSpanned = { 0x50, 0x4B, 0x07, 0x08 };

		magic("pdf", new byte[] { 0x25, 0x50, 0x44, 0x46 }); // %PDF
		magic("doc", ole2);
		magic("xls", ole2);
		magic("ppt", ole2);
		magic("msg", ole2);
		magic("docx", zip, zipEmpty, zipSpanned);
		magic("xlsx", zip, zipEmpty, zipSpanned);
		magic("pptx", zip, zipEmpty, zipSpanned);
		magic("png", new byte[] { (byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A });
		magic("gif", new byte[] { 0x47, 0x49, 0x46, 0x38 }); // GIF8
		magic("jpg", new byte[] { (byte) 0xFF, (byte) 0xD8, (byte) 0xFF });
		magic("jpeg", new byte[] { (byte) 0xFF, (byte) 0xD8, (byte) 0xFF });
	}

	private static void mime(String extension, String... types) {
		MIME_TYPES.put(extension, new LinkedHashSet<>(Arrays.asList(types)));
	}

	private static void magic(String extension, byte[]... prefixes) {
		MAGIC_NUMBERS.put(extension, Arrays.asList(prefixes));
	}

	private Set<String> allowedExtensions = DEFAULT_ALLOWED_EXTENSIONS;
	private long maxBytes = DEFAULT_MAX_BYTES;
	private MalwareScanner malwareScanner = new ContentInspectingMalwareScanner();

	public void setAllowedExtensions(Set<String> allowedExtensions) {
		Set<String> normalised = new LinkedHashSet<>();
		for (String extension : allowedExtensions) {
			normalised.add(extension.trim().toLowerCase(Locale.ENGLISH));
		}
		this.allowedExtensions = Collections.unmodifiableSet(normalised);
	}

	public void setMaxBytes(long maxBytes) {
		this.maxBytes = maxBytes;
	}

	public void setMalwareScanner(MalwareScanner malwareScanner) {
		this.malwareScanner = malwareScanner;
	}

	public boolean isAcceptable(MultipartFile file) {
		if (file == null || file.isEmpty()) {
			return false;
		}
		if (file.getSize() > this.maxBytes) {
			LOG.warn("Rejected upload: size {} exceeds the {} byte limit", file.getSize(), this.maxBytes);
			return false;
		}

		String fileName = safeFileName(file.getOriginalFilename());
		if (fileName == null) {
			LOG.warn("Rejected upload: unusable file name");
			return false;
		}

		String extension = extensionOf(fileName);
		if (extension == null || !this.allowedExtensions.contains(extension)) {
			LOG.warn("Rejected upload '{}': extension is not on the allow list", fileName);
			return false;
		}

		if (!mimeTypeMatches(extension, file.getContentType())) {
			LOG.warn("Rejected upload '{}': declared content type '{}' does not match the extension", fileName,
					file.getContentType());
			return false;
		}

		byte[] head = readHead(file);
		if (head == null) {
			LOG.warn("Rejected upload '{}': content could not be read for inspection", fileName);
			return false;
		}
		if (!contentMatches(extension, head)) {
			LOG.warn("Rejected upload '{}': content does not match the declared '{}' format", fileName, extension);
			return false;
		}

		try {
			if (!this.malwareScanner.isClean(file)) {
				LOG.warn("Rejected upload '{}': flagged by the malware scanner", fileName);
				return false;
			}
		} catch (MalwareScanException e) {
			LOG.error("Rejected upload '" + fileName + "': malware scan could not be completed", e);
			return false;
		}

		return true;
	}

	public static String safeFileName(String originalFileName) {
		if (originalFileName == null) {
			return null;
		}
		String name = originalFileName;
		int separator = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
		if (separator >= 0) {
			name = name.substring(separator + 1);
		}
		name = name.trim();
		if (name.isEmpty() || ".".equals(name) || "..".equals(name)) {
			return null;
		}
		for (int i = 0; i < name.length(); i++) {
			if (name.charAt(i) < 0x20 || name.charAt(i) == 0x7F) {
				return null;
			}
		}
		return name;
	}

	private static String extensionOf(String fileName) {
		int dot = fileName.lastIndexOf('.');
		if (dot <= 0 || dot == fileName.length() - 1) {
			return null;
		}
		return fileName.substring(dot + 1).toLowerCase(Locale.ENGLISH);
	}

	private static boolean mimeTypeMatches(String extension, String contentType) {
		Set<String> expected = MIME_TYPES.get(extension);
		if (expected == null) {
			return true;
		}
		if (contentType == null) {
			return false;
		}
		String declared = contentType.toLowerCase(Locale.ENGLISH);
		int parameterStart = declared.indexOf(';');
		if (parameterStart >= 0) {
			declared = declared.substring(0, parameterStart);
		}
		return expected.contains(declared.trim());
	}

	private byte[] readHead(MultipartFile file) {
		InputStream in = null;
		try {
			in = file.getInputStream();
			byte[] buffer = new byte[512];
			int read = 0;
			while (read < buffer.length) {
				int count = in.read(buffer, read, buffer.length - read);
				if (count < 0) {
					break;
				}
				read += count;
			}
			return Arrays.copyOf(buffer, read);
		} catch (IOException e) {
			LOG.error("Could not read uploaded file for inspection", e);
			return null;
		} finally {
			closeQuietly(in);
		}
	}

	private static boolean contentMatches(String extension, byte[] head) {
		List<byte[]> prefixes = MAGIC_NUMBERS.get(extension);
		if (prefixes == null) {
			return isPlainText(head);
		}
		for (byte[] prefix : prefixes) {
			if (startsWith(head, prefix)) {
				return true;
			}
		}
		return false;
	}

	private static boolean startsWith(byte[] content, byte[] prefix) {
		if (content.length < prefix.length) {
			return false;
		}
		for (int i = 0; i < prefix.length; i++) {
			if (content[i] != prefix[i]) {
				return false;
			}
		}
		return true;
	}

	private static boolean isPlainText(byte[] head) {
		for (byte b : head) {
			int value = b & 0xFF;
			boolean printable = value >= 0x20 || value == '\t' || value == '\n' || value == '\r';
			if (!printable) {
				return false;
			}
		}
		return true;
	}

	private static void closeQuietly(InputStream in) {
		if (in != null) {
			try {
				in.close();
			} catch (IOException ignored) {
			}
		}
	}
}
