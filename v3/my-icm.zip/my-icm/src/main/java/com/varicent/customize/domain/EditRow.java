package com.varicent.customize.domain;

import java.util.Date;

import com.varicent.core.database.support.DataRow;

public class EditRow extends DataRow {
	private final int editId;
	private final String payeeId;
	private final Date created;
	private final EditOperation operation;

	public EditRow(int editId, String payeeId, Date created, EditOperation operation) {
		this.editId = editId;
		this.payeeId = payeeId;
		this.created = new Date(created.getTime());
		this.operation = operation;
	}

	public Date getCreated() {
		return (Date) this.created.clone();
	}

	public int getEditId() {
		return this.editId;
	}

	public String getPayeeId() {
		return this.payeeId;
	}

	public boolean isInsert() {
		return this.operation.equals(EditOperation.INSERT);
	}

	public boolean isUpdate() {
		return this.operation.equals(EditOperation.UPDATE);
	}
}
