package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeGroupMin extends UnaryNode implements EvaluateNode, AggregateNode {
	private BigDecimal min = null;
	private boolean isFinalized;

	public NodeGroupMin(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.min;
		} else {
			BigDecimal value = this.arg.evaluate();
			if (value != null && (this.min == null || value.compareTo(this.min) < 0)) {
				this.min = value;
			}

			return this.min;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.min = null;
			this.arg.reset();
		}
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupMin";
	}
}
