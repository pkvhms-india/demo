package com.varicent.core.system.windows;

public class StringValueRegistryParser implements RegistryEntryParser {
	@Override
	public Object parse(String value) {
		return value;
	}
}
