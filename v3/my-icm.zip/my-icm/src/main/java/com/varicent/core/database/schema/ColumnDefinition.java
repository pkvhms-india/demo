package com.varicent.core.database.schema;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.util.Assert;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.customize.domain.CustomType;

public class ColumnDefinition {
	private final String table;
	private final String name;
	private final int type;
	private final int index;
	private final boolean isKey;
	private final boolean isNullable;
	private static Comparator<ColumnDefinition> ColumnComparator = new Comparator<ColumnDefinition>() {
		@Override
		public int compare(ColumnDefinition c1, ColumnDefinition c2) {
			int c1Index = c1.getIndex();
			int c2Index = c2.getIndex();
			return c1Index > c2Index ? 1 : (c1Index < c2Index ? -1 : 0);
		}
	};

	private static final int toSqlType(String type) {
		if (type.equalsIgnoreCase("System.String")) {
			return 12;
		} else if (type.equalsIgnoreCase("System.Decimal")) {
			return 3;
		} else if (type.equalsIgnoreCase("System.DateTime")) {
			return 91;
		} else {
			Assert.state(false);
			return 0;
		}
	}

	public ColumnDefinition(String table, String name, int type, int index, boolean isKey, boolean isNullable) {
		this.table = table;
		this.name = name;
		this.type = type;
		this.index = index;
		this.isKey = isKey;
		this.isNullable = isNullable;
	}

	public ColumnDefinition(String table, String name, String type, int index, boolean isKey, boolean isNullable) {
		this(table, name, toSqlType(type), index, isKey, isNullable);
	}

	public String getDisplayName() {
		return this.name.replace(Database.getSyntax().getSystemPrefix(), " ").trim();
	}

	public int getIndex() {
		return this.index;
	}

	public String getName() {
		return this.name;
	}

	public String getTable() {
		return this.table;
	}

	public int getType() {
		return this.type;
	}

	public boolean isDateTime() {
		return this.type == 91 || this.type == 93;
	}

	public boolean isKey() {
		return this.isKey;
	}

	public boolean isNullable() {
		return this.isNullable;
	}

	public boolean isNumeric() {
		return this.type == 2 || this.type == 4 || this.type == 3;
	}

	public boolean isVarchar() {
		return this.type == 12;
	}

	public static CustomType getSystemColumnType(ColumnDefinition definition) {
		String table = definition.getTable();
		String column = definition.getName();
		if (table.equals("Payee_") && column.equals("Email_")) {
			return CustomType.EMAIL;
		} else if (column.equals("URL_")) {
			return CustomType.URL;
		} else if (column.equals("Comment_")) {
			return CustomType.COMMENT;
		} else if (definition.isDateTime()) {
			return CustomType.DATE;
		} else if (definition.isNumeric()) {
			return CustomType.NUMERIC;
		} else if (definition.isVarchar()) {
			return CustomType.TEXT;
		} else {
			Assert.state(false);
			return CustomType.TEXT;
		}
	}

	public static CustomType getColumnCustomType(ColumnDefinition definition, JdbcOperations operations) {
		CustomType type = getColumnCustomType(definition.getTable(), definition.getName(), operations);
		if (type == null) {
			type = getSystemColumnType(definition);
		}

		return type;
	}

	public static CustomType getColumnCustomType(String table, String column, JdbcOperations operations) {
		QueryDefinition query = new QueryDefinition("CustomColumn");
		query.select("CustomColumn", "Type");
		query.newConstraint("CustomColumn", "TableName", Constraint.Operator.Equals, table);
		query.newConstraint("CustomColumn", "ColumnName", Constraint.Operator.Equals, column);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> result = operations.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		CustomType type = null;
		if (!result.isEmpty()) {
			return CustomType.valueOf(result.get(0).toUpperCase());
		} else if (column.equals("Comment")) {
			return CustomType.COMMENT;
		} else if (column.equals("Email")) {
			return CustomType.EMAIL;
		} else {
			if (table.equals("Payee_")) {
				if (column.equals("PayeeID_") || column.equals("Parent_") || column.equals("Salutation_")
						|| column.equals("Phone_") || column.equals("Extension_") || column.equals("Name_")
						|| column.equals("TitleID_") || column.equals("Reports_To_")
						|| column.equals("Payee_Currency_")) {
					return CustomType.TEXT;
				}
			} else if (table.equals("Account_") && (column.equals("AccountID_") || column.equals("Name_")
					|| column.equals("Parent_") || column.equals("DrCr_"))) {
				return CustomType.TEXT;
			}

			return type;
		}
	}

	public static List<ColumnDefinition> getReordered(List<ColumnDefinition> columns) {
		List<ColumnDefinition> orderedColumns = new ArrayList();
		Collections.sort(columns, ColumnComparator);

		for (int i = 0; i < columns.size(); ++i) {
			ColumnDefinition column = columns.get(i);
			ColumnDefinition newColumn = new ColumnDefinition(column.getTable(), column.getName(), column.getType(), i,
					column.isKey(), column.isNullable());
			orderedColumns.add(newColumn);
		}

		return orderedColumns;
	}

	@Override
	public String toString() {
		return this.table + "." + this.name;
	}
}
