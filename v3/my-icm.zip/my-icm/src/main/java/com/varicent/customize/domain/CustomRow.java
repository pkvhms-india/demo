package com.varicent.customize.domain;

import com.varicent.core.database.support.DataRow;

public class CustomRow extends DataRow {
	private boolean locked;

	public boolean isLocked() {
		return this.locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}
}
