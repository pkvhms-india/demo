package com.varicent.core.util;

public class JavascriptUtils {
	public static String escapeJavascriptString(String s) {
		return s.replace("'", "\\'").replace("\"", "\\\"");
	}
}
