package com.varicent.core.util;

import java.math.BigDecimal;

import org.springframework.util.Assert;

public class Converter {
	public static BigDecimal ConvertToBigDecimal(Object obj) {
		if (obj instanceof BigDecimal) {
			return (BigDecimal) obj;
		} else if (obj instanceof Integer) {
			return BigDecimal.valueOf(((Integer) obj).longValue());
		} else if (obj instanceof Long) {
			return BigDecimal.valueOf((Long) obj);
		} else if (obj instanceof Double) {
			return BigDecimal.valueOf((Double) obj);
		} else if (obj instanceof Float) {
			return BigDecimal.valueOf(((Float) obj).doubleValue());
		} else {
			Assert.state(false);
			return null;
		}
	}
}
