package com.varicent.customize.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import com.varicent.common.tab.domain.Tab;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.core.exceptions.PeriodLockedException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.customize.service.CustomizeManager;

public abstract class EditController {
	protected static final String VIEW = "redirect:/dataedit/index.html";
	private static final String ACTIVE_TAB_ATTRIBUTE = "activeTab";
	protected final CustomizeManager customizeManager;
	protected final CustomizeValidator validator;

	protected EditController(CustomizeManager customizeManager, CustomizeValidator validator) {
		this.customizeManager = customizeManager;
		this.validator = validator;
	}

	private String getActiveTabParameterUrl(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		return activeTab == null ? "" : activeTab.getParameterUrl();
	}

	@RequestMapping(method = { RequestMethod.POST })
	public String processForm(@ModelAttribute("command") CustomizeCommand cmd, BindingResult result,
			HttpServletRequest request) {
		if (!cmd.checkAndUpdateToken()) {
			return "redirect:/dataedit/index.html";
		} else {
			try {
				this.validator.validate(cmd, result);
				this.submitEdit(cmd, result);
			} catch (DataSubmitException e) {
				Message message = e.getMessageObject();
				result.reject(message.getKey().toString(), message.getParams(), (String) null);
			} catch (PeriodLockedException var7) {
				result.reject(Messages.Key.WEBFORMS_ERROR_SUBMIT_LOCKED_PERIOD.toString());
			}

			WebUtils.setSessionAttribute(request, "command", cmd);
			WebUtils.setSessionAttribute(request, "errors", result);
			String activeTabParameterUrl = this.getActiveTabParameterUrl(request);
			return "redirect:/dataedit/index.html" + activeTabParameterUrl;
		}
	}

	protected abstract void submitEdit(CustomizeCommand var1, BindingResult var2)
			throws DataSubmitException, PeriodLockedException;
}
