package com.varicent.draws.dao.jdbc;

import java.util.Date;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectAggregate;

public class OverviewQuery {
	public static QueryDefinition getAveragePercentPayoutByPeriod(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) {
		String tablename = "_DrawTemplateResult" + templateId;
		QueryDefinition query = new QueryDefinition(tablename);
		query.select(tablename, "Value_");
		query.select("DrawAssignment", "Amount");
		query.select("DrawAssignment", "Period");
		query.select("DrawAssignment", "Ending_");
		QueryDefinition assignmentQuery = PayoutDetailsQuery.getDrawQueryBase(drawId, templateId, start, end);
		assignmentQuery.select("DrawAssignment", "PayeeID");
		assignmentQuery.select("TemplateTime", "Name_", "Period");
		assignmentQuery.select("TemplateTime", "Starting_");
		assignmentQuery.select("TemplateTime", "Ending_");
		assignmentQuery.select("DrawAssignment", "Amount");
		Join assignmentJoin = new Join(assignmentQuery, "DrawAssignment", Join.Type.INNER);
		assignmentJoin.newConstraint("DrawAssignment", "PayeeID", Constraint.Operator.Equals, tablename, "PayeeID_");
		assignmentJoin.newConstraint("DrawAssignment", "Period", Constraint.Operator.Equals, tablename, "Period_");
		query.joinWith(assignmentJoin);
		if (start != null && end != null) {
			query.newConstraint("DrawAssignment", "Starting_", Constraint.Operator.GreaterThanEquals, start);
			query.newConstraint("DrawAssignment", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		if (payeeId != null) {
			query.newConstraint(tablename, "PayeeID_", Constraint.Operator.Equals, payeeId);
		} else if (workflowGroupId != null) {
			QueryDefinition workflowGroupQuery = new QueryDefinition("WorkflowGroupMember");
			workflowGroupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals,
					workflowGroupId);
			Join workflowJoin = new Join(workflowGroupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, tablename,
					"PayeeID_");
			query.joinWith(workflowJoin);
		}

		return query;
	}

	public static QueryDefinition getDrawsAndCommissionsPayoutByPeriod(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end, String calendarLevel) {
		String tablename = "_DrawTemplateResult" + templateId;
		QueryDefinition query = new QueryDefinition(tablename);
		query.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, tablename, "Value_", "Value"));
		query.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, tablename, "Payout", "Payout"));
		query.select("Time", "Name_");
		query.groupBy("Time", "Name_");
		QueryDefinition templateQuery = new QueryDefinition("DrawTemplate");
		templateQuery.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		Join templateJoin = new Join(templateQuery, "DrawTemplate", Join.Type.CROSS);
		query.joinWith(templateJoin);
		Join definitionJoin = new Join("DrawDefinition", Join.Type.INNER);
		definitionJoin.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, "DrawTemplate",
				"BlockID");
		query.joinWith(definitionJoin);
		Join templateTimeJoin = new Join("Time_", "TemplateTime", Join.Type.INNER);
		templateTimeJoin.newConstraint("TemplateTime", "TimeID_", Constraint.Operator.Equals, "DrawDefinition",
				"TimeID");
		templateTimeJoin.newConstraint("TemplateTime", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		templateTimeJoin.newConstraint(tablename, "Period_", Constraint.Operator.Equals, "TemplateTime", "Name_");
		query.joinWith(templateTimeJoin);
		QueryDefinition timeQuery = new QueryDefinition("Time_");
		timeQuery.newConstraint("Time_", "Level_", Constraint.Operator.Equals, calendarLevel);
		Join timeJoin = new Join(timeQuery, "Time", Join.Type.INNER);
		timeJoin.newConstraint("Time", "TimeID_", Constraint.Operator.Equals, "DrawDefinition", "TimeID");
		timeJoin.newConstraint("TemplateTime", "Ending_", Constraint.Operator.LessThanEquals, "Time", "Ending_");
		timeJoin.newConstraint("TemplateTime", "Ending_", Constraint.Operator.GreaterThanEquals, "Time", "Starting_");
		query.joinWith(timeJoin);
		if (start != null && end != null) {
			query.newConstraint("Time", "Starting_", Constraint.Operator.GreaterThanEquals, start);
			query.newConstraint("Time", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		if (payeeId != null) {
			query.newConstraint(tablename, "PayeeID_", Constraint.Operator.Equals, payeeId);
		} else if (workflowGroupId != null) {
			QueryDefinition workflowGroupQuery = new QueryDefinition("WorkflowGroupMember");
			workflowGroupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals,
					workflowGroupId);
			Join workflowJoin = new Join(workflowGroupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, tablename,
					"PayeeID_");
			query.joinWith(workflowJoin);
		}

		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		if (start != null) {
			query.newConstraint("Time", "Starting_", Constraint.Operator.GreaterThanEquals, start);
		}

		if (end != null) {
			query.newConstraint("Time", "Ending_", Constraint.Operator.LessThanEquals, end);
		}

		return query;
	}
}
