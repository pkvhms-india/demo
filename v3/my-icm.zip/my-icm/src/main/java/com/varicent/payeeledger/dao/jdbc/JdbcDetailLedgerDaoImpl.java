package com.varicent.payeeledger.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.varicent.common.adjustment.dao.AdjustmentDao;
import com.varicent.common.calculation.dao.CalculationDao;
import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.plan.dao.PlanDao;
import com.varicent.common.plan.domain.Plan;
import com.varicent.common.port.dao.PortDao;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.reference.dao.ReferenceDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.util.Range;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.payeeledger.domain.TailoredReport;
import com.varicent.workflow.dao.WorkflowDao;

@Repository("detailLedgerDao")
public class JdbcDetailLedgerDaoImpl extends AbstractJdbcLedgerDaoImpl {
	private final RowMapper<TailoredReport> tailoredReportMapper = new RowMapper<TailoredReport>() {
		@Override
		public TailoredReport mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new TailoredReport(rs.getString("ID"), rs.getString("Name"));
		}
	};

	@Autowired
	public JdbcDetailLedgerDaoImpl(DataSource ds, AdjustmentDao adjustmentDao, CalculationDao calculationDao,
			ConfigDao configDao, CustomizeDao customizeDao, HistoryDao historyDao, PayeeDao payeeDao, PlanDao planDao,
			ReferenceDao referenceDao, TimeDao timeDao, WorkflowDao workflowDao, SchemaDao schemaDao, PortDao portDao) {
		super(ds, adjustmentDao, calculationDao, configDao, customizeDao, historyDao, payeeDao, planDao, referenceDao,
				timeDao, workflowDao, schemaDao, portDao);
	}

	@Override
	public String getCalendar(String planId) {
		if (TailoredReport.isReport(planId)) {
			QueryDefinition query = new QueryDefinition("TailoredReport");
			query.selectDistinct();
			query.select("Calculation", "Type");
			query.select("Calculation", "CalendarUsed");
			query.select("CalculationCategoryTime", "CalendarUsed", "CatCalendarUsed");
			query.select("TimeShift", "TimeID", "TimeShiftCalendarUsed");
			Join calcListJoin = new Join("CalculationListElement", Join.Type.INNER);
			calcListJoin.newConstraint("TailoredReport", "CalculationListID", Constraint.Operator.Equals,
					"CalculationListElement", "ListID");
			query.joinWith(calcListJoin);
			Join calcJoin = new Join("Calculation", Join.Type.INNER);
			calcJoin.newConstraint("CalculationListElement", "CalculationID", Constraint.Operator.Equals, "Calculation",
					"CalculationID");
			query.joinWith(calcJoin);
			Join catJoin = new Join("CalculationCategoryTime", Join.Type.LEFT);
			catJoin.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "CalculationCategoryTime",
					"CalculationID");
			query.joinWith(catJoin);
			Join tsJoin = new Join("TimeShift", Join.Type.LEFT);
			tsJoin.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "TimeShift",
					"CalculationID");
			query.joinWith(tsJoin);
			query.newConstraint("TailoredReport", "ID", Constraint.Operator.Equals, planId);
			QueryBuilder qb = Database.getQueryBuilder();
			SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));
			String calendar = null;

			while (result.next()) {
				String cal;
				if (result.getInt("Type") == 4) {
					cal = result.getString("CatCalendarUsed");
				} else if (result.getInt("Type") == 2) {
					cal = result.getString("TimeShiftCalendarUsed");
				} else {
					cal = result.getString("CalendarUsed");
				}

				if (cal != null) {
					if (calendar == null) {
						calendar = cal;
					} else if (!calendar.equals(cal)) {
						return null;
					}
				}
			}

			return calendar;
		} else {
			return super.getCalendar(planId);
		}
	}

	@Override
	public List<DataRow> getLedger(String planId, String payeeId, TimePeriod period, boolean repeatHeader,
			SchemaDao schemaDao) {
		Set<String> viewablePayees = this.workflowDao.getAuthorizedPayeeIds(planId);
		if (!viewablePayees.contains(payeeId)) {
			return Collections.emptyList();
		} else {
			ReportQuery reportQuery = new ReportQuery(this.ds, this.customizeDao, this.historyDao, this.referenceDao,
					this.timeDao, schemaDao);
			DetailRowQuery rowQuery = new DetailRowQuery(this.ds, planId, payeeId, period, repeatHeader, reportQuery,
					this.calculationDao, this.configDao, this.timeDao, schemaDao, this.historyDao, this.portDao);
			return new ArrayList(rowQuery.getDetail());
		}
	}

	@Override
	public List<TimePeriod> getPeriods(String planId, SchemaDao schemaDao) {
		if (planId == null) {
			return Collections.emptyList();
		} else {
			String calendar = this.getCalendar(planId);
			if (calendar == null) {
				return Collections.emptyList();
			} else {
				ReportQuery reportQuery = new ReportQuery(this.ds, this.customizeDao, this.historyDao,
						this.referenceDao, this.timeDao, schemaDao);
				Range<Date> visibleDates = reportQuery.getVisibleDates(planId);
				return visibleDates.End.equals(new Date(Long.MAX_VALUE))
						? this.timeDao.getTimePeriods(calendar, visibleDates.Start, (Date) null)
						: this.timeDao.getTimePeriods(calendar, visibleDates.Start, visibleDates.End);
			}
		}
	}

	@Override
	public Plan getPlan(String planId) {
		return TailoredReport.isReport(planId) ? this.getTailoredReport(planId) : super.getPlan(planId);
	}

	@Override
	public List<Plan> getPlans(String payeeId) {
		List<Plan> plans = super.getPlans(payeeId);
		plans.addAll(this.getTailoredReports(payeeId));
		return plans;
	}

	private Plan getTailoredReport(String reportId) {
		QueryDefinition query = new QueryDefinition("TailoredReport");
		query.select("TailoredReport", "ID");
		query.select("TailoredReport", "Name");
		query.newConstraint("TailoredReport", "ID", Constraint.Operator.Equals, reportId);
		QueryBuilder qb = Database.getQueryBuilder();
		TailoredReport report = (TailoredReport) this.operations.queryForObject(qb.toSql(query),
				this.tailoredReportMapper);
		return new Plan(report.getId(), report.getName());
	}

	private List<Plan> getTailoredReports(String payeeId) {
		QueryDefinition query = new QueryDefinition("TailoredReport");
		query.selectDistinct();
		query.select("TailoredReport", "ID");
		query.select("TailoredReport", "Name");
		if (payeeId != null) {
			Join join = new Join("GroupMember_", Join.Type.INNER);
			join.newConstraint("TailoredReport", "PayeeGroupID", Constraint.Operator.Equals, "GroupMember_",
					"PayeeGroupID_");
			query.joinWith(join);
			query.newConstraint("GroupMember_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		}

		query.orderBy("TailoredReport", "ID");
		QueryBuilder qb = Database.getQueryBuilder();
		List<TailoredReport> result = this.operations.query(qb.toSql(query), this.tailoredReportMapper);
		Set<String> visiblePlans = this.workflowDao.getAuthorizedPlanIds();
		List<Plan> reports = new ArrayList();
		if (!result.isEmpty()) {
			for (TailoredReport report : result) {
				if (visiblePlans.contains(report.getId())) {
					reports.add(new Plan(report.getId(), report.getName()));
				}
			}
		}

		return reports;
	}
}
