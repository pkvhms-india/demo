package com.varicent.core.i18n;

import org.springframework.util.Assert;

import com.varicent.core.text.Format;

public class Message {
	private final Messages.Key key;
	private final Object[] params;
	private final boolean internalMessage;

	public Message(Messages.Key key, Object... params) {
		this(true, key, params);
	}

	public Message(boolean internalMessage, Messages.Key key, Object... params) {
		Assert.isTrue(key.getParamCount() == params.length);
		this.key = key;
		this.params = new Object[params.length];

		for (int i = 0; i < params.length; ++i) {
			if (params[i] instanceof String) {
				this.params[i] = Format.escapeHtml((String) params[i]);
			} else {
				this.params[i] = Format.escapeHtml(params[i].toString());
			}
		}

		this.internalMessage = internalMessage;
	}

	public Messages.Key getKey() {
		return this.key;
	}

	public Object[] getParams() {
		return this.params;
	}

	public boolean isInternalMessage() {
		return this.internalMessage;
	}
}
