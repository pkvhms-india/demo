package com.varicent.draws.dao.jdbc;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.dao.jdbc.WorkflowQuery;

public class DrawQuery {
	public static QueryDefinition getWorkflowGroupsQuery(int workflowObjectID) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectID);
		query.select("DescendantGroup", "ID");
		query.select("DescendantGroup", "Name");
		query.selectDistinct();
		return query;
	}
}
