package com.varicent.BPM.domain;

import java.util.Date;

import com.varicent.common.payee.domain.Payee;

public class BPMNodeHistoryStatus {
	private int id;
	private int workflowID;
	private String nodeName;
	private String initiator;
	private String actor;
	private String isForcedBy;
	private String action;
	private Date dateActioned;
	private String actionWithStyle;
	private String actorWithStyle;
	private String forceByWithStyle;

	public BPMNodeHistoryStatus(int id, int workflowID, String nodeName, String initiator, Payee actor,
			Payee isForcedBy, String action, Date dateActioned) {
		this.id = id;
		this.workflowID = workflowID;
		this.nodeName = nodeName;
		this.initiator = initiator;
		this.actor = actor.getId();
		this.isForcedBy = isForcedBy.getId();
		this.action = action;
		this.dateActioned = dateActioned;
		this.actionWithStyle = "<b class=\"token_action_cell\">" + this.action + "</b>";
		String actorLabel;
		if (actor.getId() == null) {
			actorLabel = actor.getName();
		} else {
			actorLabel = actor.getDisplayName();
		}

		String forcingLabel;
		if (isForcedBy.getId() == null) {
			forcingLabel = isForcedBy.getName();
		} else {
			forcingLabel = isForcedBy.getDisplayName();
		}

		this.actorWithStyle = "<b class=\"token_actor_cell\" title=\"" + actorLabel + "\">" + actorLabel + "</b>";
		if (forcingLabel != null) {
			this.forceByWithStyle = "<b class=\"token_actor_cell\" title=\"" + forcingLabel + "\">" + forcingLabel
					+ "</b>";
		}

	}

	public Date getDateActioned() {
		return this.dateActioned;
	}

	public String getAction() {
		return this.action;
	}

	public String getActor() {
		return this.actor;
	}

	public String getInitiator() {
		return this.initiator;
	}

	public String getIsForcedBy() {
		return this.isForcedBy;
	}

	public String getNodeName() {
		return this.nodeName;
	}

	public int getId() {
		return this.id;
	}

	public int getworkflowID() {
		return this.workflowID;
	}

	public String getActorWithStyle() {
		return this.actorWithStyle;
	}

	public String getActionWithStyle() {
		return this.actionWithStyle;
	}

	public String getForceByWithStyle() {
		return this.forceByWithStyle;
	}
}
