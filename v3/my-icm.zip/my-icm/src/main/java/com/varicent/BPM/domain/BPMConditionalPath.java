package com.varicent.BPM.domain;

import java.io.Reader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.varicent.BPM.dao.BPMDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.math.expressions.ExpressionEvaluator;
import com.varicent.core.math.expressions.NodeDate;
import com.varicent.core.text.Parse;
import com.varicent.reporting.dao.jdbc.ActionParser.ExpressionParser;
import com.varicent.reporting.domain.WebReportTableEdit;
import com.varicent.reporting.domain.XMLStreamUtility;

public class BPMConditionalPath extends BPMPath implements Comparable<BPMConditionalPath> {
	int position;
	String condition;
	boolean isDefault;
	ExpressionEvaluator evaluator;

	public BPMConditionalPath(int pathID, String name, int originNodeID, int destinationNodeID, boolean allMember,
			boolean saveAndSubmit, boolean allSubmit, int reviewResult, int position, String condition,
			boolean isDefault) {
		super(pathID, name, originNodeID, destinationNodeID, allMember, saveAndSubmit, allSubmit, reviewResult);
		this.position = position;
		this.condition = condition;
		this.isDefault = isDefault;
	}

	public int getPosition() {
		return this.position;
	}

	public String getCondition() {
		return this.condition;
	}

	public boolean isDefault() {
		return this.isDefault;
	}

	@Override
	public int compareTo(BPMConditionalPath other) {
		return this.position - other.getPosition();
	}

	public void buildEvaluator() throws XMLStreamException {
		Reader xml = new StringReader(this.condition);
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader streamReader = factory.createXMLStreamReader(xml);
		streamReader.nextTag();
		streamReader.nextTag();
		XMLStreamUtility.getCurrentNodeValue(streamReader);
		ExpressionParser parser = new ExpressionParser();
		this.evaluator = parser.getExpression(streamReader);
		this.evaluator.reset();
	}

	public boolean decide(Map<String, Object> param, HashMap<Integer, WebReportTableEdit> editMap, SchemaDao schemaDao,
			BPMDao bpmDao, int formId) {
		List<String> bufferTables = bpmDao.getBPMPendingTables();
		if (param != null) {
			for (int j = 0; j < this.evaluator.getVariables().size(); ++j) {
				String variable = this.evaluator.getVariables().get(j);
				if (variable.startsWith("_Local_")) {
					String scalarName = variable.substring("_Local_".length());
					this.setEvaluationValue(param.get(scalarName), this.evaluator, j, (ColumnDefinition) null);
				} else {
					Map<String, ColumnDefinition> matchedKeys = this.getMatch(variable, param, editMap, schemaDao);
					if (!matchedKeys.isEmpty()) {
						for (String key : matchedKeys.keySet()) {
							this.setEvaluationValue(param.get(key), this.evaluator, j, matchedKeys.get(key));
						}
					}

					if (param.get("Pending Workflow Status") != null
							&& !param.get("Pending Workflow Status").equals(String.valueOf(false))) {
						for (WebReportTableEdit item : editMap.values()) {
							if (variable.equals(item.getTable() + "." + item.getColumn())
									&& bufferTables.contains("_BPMPending_" + item.getTable())) {
								ColumnDefinition column = this.findDefinition(schemaDao.getColumns(item.getTable()),
										item.getColumn());

								for (Object value : bpmDao.getPendingValues("_BPMPending_" + item.getTable(), column,
										formId)) {
									this.setEvaluationValue(value, this.evaluator, j, column);
								}
								break;
							}
						}
					}
				}
			}
		}

		this.evaluator.finalizeAggregates();
		return this.evaluator.evaluate().compareTo(BigDecimal.ZERO) > 0;
	}

	private void setEvaluationValue(Object input, ExpressionEvaluator evaluator, int index, ColumnDefinition def) {
		if (input != null) {
			if (input instanceof Date) {
				NodeDate date = new NodeDate((Date) input, 0);
				evaluator.setValue(index, date.evaluate());
			} else if (def != null && def.isDateTime()) {
				Date dateValue = Parse.tryLocaleDate((String) input).toDate();
				NodeDate date = new NodeDate(dateValue, 0);
				evaluator.setValue(index, date.evaluate());
			} else if (input instanceof String) {
				evaluator.setValueOfString(index, (String) input);
			} else {
				BigDecimal value = Parse.parseDecimal(input.toString(), true);
				evaluator.setValue(index, value);
			}

			evaluator.evaluate();
		}
	}

	private Map<String, ColumnDefinition> getMatch(String variable, Map<String, Object> params,
			HashMap<Integer, WebReportTableEdit> editMap, SchemaDao schemaDao) {
		Map<String, ColumnDefinition> matches = new HashMap();

		for (String key : params.keySet()) {
			if (key.startsWith("Edited_")) {
				String rawName = key.substring("Edited_IR_".length());
				rawName = rawName.contains("_") ? rawName.substring(0, rawName.indexOf(95)) : rawName;
				int editID = Integer.parseInt(rawName);
				WebReportTableEdit editItem = editMap.get(editID);
				List<ColumnDefinition> columnDefinitions = schemaDao.getColumns(editItem.getTable());
				String tableAndColumn = editItem.getTable() + "." + editItem.getColumn();
				if (tableAndColumn.equals(variable)) {
					matches.put(key, this.findDefinition(columnDefinitions, editItem.getColumn()));
				}
			}
		}

		return matches;
	}

	private ColumnDefinition findDefinition(List<ColumnDefinition> defs, String name) {
		for (ColumnDefinition def : defs) {
			if (def.getName().equals(name)) {
				return def;
			}
		}

		return null;
	}
}
