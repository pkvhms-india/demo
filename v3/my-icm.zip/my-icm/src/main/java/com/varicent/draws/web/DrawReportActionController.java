package com.varicent.draws.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Download;
import com.varicent.core.util.NoncacheHttpResponseSetter;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.service.DrawReportManager;

@Controller
public class DrawReportActionController {
	private final DrawReportManager drawReportManager;
	private final Messages messages;

	@Autowired
	public DrawReportActionController(DrawReportManager manager, Messages messages) {
		this.drawReportManager = manager;
		this.messages = messages;
	}

	@RequestMapping(value = { "/drawreport/assignments/export.do" }, method = { RequestMethod.POST })
	public ModelAndView doExportAssignmentsPayout(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request, HttpServletResponse response) {
		if (!headerCmd.checkAndUpdateToken()) {
			return new ModelAndView("/drawreport/index");
		} else {
			Integer drawID = headerCmd.getId();
			boolean isXLSX = headerCmd.getIsXLSXExport();
			if (drawID == null) {
				ModelAndView blank = new ModelAndView("/drawreport/index");
				blank.addObject("command", (Object) null);
				return blank;
			} else if (!this.drawReportManager.exists(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST.toString());
				error.addObject("command", (Object) null);
				return error;
			} else if (!this.drawReportManager.isViewable(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS.toString());
				error.addObject("command", (Object) null);
				return error;
			} else {
				ModelAndView mav = new ModelAndView("drawReportExcelView");
				DrawReportWebSettings settings = null;

				try {
					settings = this.drawReportManager.getSettings(drawID);
					mav.addObject("datarows", this.drawReportManager.getAssignments(headerCmd));
				} catch (InvalidDrawException e) {
					ModelAndView error = new ModelAndView("/drawreport/index");
					error.addObject("messageKey", e.getMessageObject().getKey().toString());
					return error;
				}

				String[] headers = this.getHTMLDecodedMessages(
						new Messages.Key[] { Messages.Key.DRAW_REPORT_ASSIGNMENTS_HEADERS_PAYEEID,
								Messages.Key.DRAW_REPORT_ASSIGNMENTS_HEADERS_NAME,
								Messages.Key.DRAW_REPORT_ASSIGNMENTS_HEADERS_DRAWTEMPLATE,
								Messages.Key.DRAW_REPORT_ASSIGNMENTS_HEADERS_STARTPERIOD,
								Messages.Key.DRAW_REPORT_ASSIGNMENTS_HEADERS_ENDPERIOD },
						LocaleContextHolder.getLocale());
				mav.addObject("excelHeaders", headers);
				mav.addObject("visibilities", headerCmd.getColumnVisibilities());
				mav.addObject("headerColor", settings.getColor());
				mav.addObject("numberStyle", settings.getNumericStyle());
				if (isXLSX) {
					mav.addObject("fileName", "export.xlsx");
				} else {
					mav.addObject("fileName", "export.xls");
				}

				mav.addObject("isXLSXExport", isXLSX);
				return mav;
			}
		}
	}

	@RequestMapping(value = { "/drawreport/ytdpayout/export.do" }, method = { RequestMethod.POST })
	public ModelAndView doExportYTDPayout(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request, HttpServletResponse response) {
		if (!headerCmd.checkAndUpdateToken()) {
			return new ModelAndView("/drawreport/index");
		} else {
			Integer drawID = headerCmd.getId();
			boolean isXLSX = headerCmd.getIsXLSXExport();
			if (drawID == null) {
				ModelAndView blank = new ModelAndView("/drawreport/index");
				blank.addObject("command", (Object) null);
				return blank;
			} else if (!this.drawReportManager.exists(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST.toString());
				error.addObject("command", (Object) null);
				return error;
			} else if (!this.drawReportManager.isViewable(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS.toString());
				error.addObject("command", (Object) null);
				return error;
			} else {
				ModelAndView mav = new ModelAndView("drawReportExcelView");
				DrawReportWebSettings settings = null;
				DataRow totalsRow = null;

				try {
					settings = this.drawReportManager.getSettings(drawID);
					mav.addObject("datarows", this.drawReportManager.getYTDPayoutDetails(headerCmd));
					totalsRow = this.drawReportManager.getYTDPayoutTotals(headerCmd);
				} catch (InvalidDrawException e) {
					ModelAndView error = new ModelAndView("/drawreport/index");
					error.addObject("messageKey", e.getMessageObject().getKey().toString());
					return error;
				}

				Locale userLocale = LocaleContextHolder.getLocale();
				String selectedPayees = this.getSelectedName(headerCmd, settings.isAllowGroupSelection());
				totalsRow.insert(0, selectedPayees);
				totalsRow.insert(0,
						this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_DATAGRID_TOTAL, userLocale));
				mav.addObject("totalsrow", totalsRow);
				String[] headers = this
						.getHTMLDecodedMessages(new Messages.Key[] { Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_PAYEEID,
								Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_PAYEE,
								Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_EARNINGS,
								Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_DRAW,
								Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_BALANCE,
								Messages.Key.DRAW_REPORT_YTDPAYOUT_HEADERS_PAYOUT }, userLocale);
				mav.addObject("excelHeaders", headers);
				mav.addObject("visibilities", headerCmd.getColumnVisibilities());
				mav.addObject("headerColor", settings.getColor());
				mav.addObject("numberStyle", settings.getNumericStyle());
				if (isXLSX) {
					mav.addObject("fileName", "export.xlsx");
				} else {
					mav.addObject("fileName", "export.xls");
				}

				mav.addObject("isXLSXExport", isXLSX);
				return mav;
			}
		}
	}

	@RequestMapping(value = { "/drawreport/periodpayout/export.do" }, method = { RequestMethod.POST })
	public ModelAndView doExportPeriodPayout(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request, HttpServletResponse response) {
		if (!headerCmd.checkAndUpdateToken()) {
			return new ModelAndView("/drawreport/index");
		} else {
			Integer drawID = headerCmd.getId();
			boolean isXLSX = headerCmd.getIsXLSXExport();
			if (drawID == null) {
				ModelAndView blank = new ModelAndView("/drawreport/index");
				blank.addObject("command", (Object) null);
				return blank;
			} else if (!this.drawReportManager.exists(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST.toString());
				error.addObject("command", (Object) null);
				return error;
			} else if (!this.drawReportManager.isViewable(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS.toString());
				error.addObject("command", (Object) null);
				return error;
			} else {
				ModelAndView mav = new ModelAndView("drawReportExcelView");
				DrawReportWebSettings settings = null;
				DataRow totalsRow = null;

				try {
					settings = this.drawReportManager.getSettings(drawID);
					mav.addObject("datarows", this.drawReportManager.getByPeriodPayoutDetails(headerCmd));
					totalsRow = this.drawReportManager.getYTDPayoutTotals(headerCmd);
				} catch (InvalidDrawException e) {
					ModelAndView error = new ModelAndView("/drawreport/index");
					error.addObject("messageKey", e.getMessageObject().getKey().toString());
					return error;
				}

				String selectedPayees = this.getSelectedName(headerCmd, settings.isAllowGroupSelection());
				if (totalsRow.getSize() >= 1) {
					totalsRow.insert(1, (Object) null);
				}

				Locale userLocale = LocaleContextHolder.getLocale();
				String selectedPeriod = headerCmd.getSelectedPeriod();
				if (selectedPeriod == null || selectedPeriod.isEmpty()) {
					selectedPeriod = this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_FILTER_ALLPERIODS,
							userLocale);
				}

				totalsRow.insert(0, selectedPeriod);
				totalsRow.insert(0, selectedPayees);
				totalsRow.insert(0,
						this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_DATAGRID_TOTAL, userLocale));
				mav.addObject("totalsrow", totalsRow);
				String[] headers = this.getHTMLDecodedMessages(
						new Messages.Key[] { Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYEEID,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYEE,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_PERIOD,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_EARNINGS,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_DRAW,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_PERIODDRAW,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_BALANCE,
								Messages.Key.DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYOUT },
						userLocale);
				mav.addObject("excelHeaders", headers);
				mav.addObject("visibilities", headerCmd.getColumnVisibilities());
				mav.addObject("headerColor", settings.getColor());
				mav.addObject("numberStyle", settings.getNumericStyle());
				if (isXLSX) {
					mav.addObject("fileName", "export.xlsx");
				} else {
					mav.addObject("fileName", "export.xls");
				}

				mav.addObject("isXLSXExport", isXLSX);
				return mav;
			}
		}
	}

	private String[] getHTMLDecodedMessages(Messages.Key[] keys, Locale locale) {
		String[] result = new String[keys.length];

		for (int i = 0; i < keys.length; ++i) {
			result[i] = this.messages.getHTMLDecodedMessage(keys[i], locale);
		}

		return result;
	}

	@RequestMapping({ "/drawreport/overview/showImage.do" })
	public void getLogo(@RequestParam("drawId") int drawId, HttpServletResponse response) throws IOException {
		byte[] image = this.drawReportManager.getLogo(drawId);
		if (image != null) {
			response.setContentType("image/jpeg");
			NoncacheHttpResponseSetter.setResponseNonCache(response);
			FileCopyUtils.copy(image, response.getOutputStream());
		}

	}

	@RequestMapping(value = { "/drawreport/overview/export.do" }, method = { RequestMethod.POST })
	public ModelAndView doExportOverviewPDF(@ModelAttribute("exportCommand") DrawReportExportCommand exportCmd,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("overviewPdfView");
		if (!exportCmd.checkAndUpdateToken()) {
			return new ModelAndView("/drawreport/index");
		} else {
			Integer drawID = exportCmd.getId();
			if (drawID == null) {
				return new ModelAndView("/drawreport/index");
			} else if (!this.drawReportManager.exists(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST.toString());
				error.addObject("command", (Object) null);
				return error;
			} else if (!this.drawReportManager.isViewable(drawID)) {
				ModelAndView error = new ModelAndView("/drawreport/index");
				error.addObject("messageKey", Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS.toString());
				error.addObject("command", (Object) null);
				return error;
			} else {
				Map<String, String> chartsDataMap = new HashMap();

				for (int i = 0; i < exportCmd.getChartFileNames().size(); ++i) {
					chartsDataMap.put(exportCmd.getChartFileNames().get(i), exportCmd.getChartStreams().get(i));
				}

				mav.addObject("chartsData", chartsDataMap);
				mav.addObject("logo", this.drawReportManager.getLogo(drawID));
				Download.asAttachment(response, request, Download.FileType.PDF, "export.pdf");
				return mav;
			}
		}
	}

	private String getSelectedName(DrawReportCommand cmd, boolean allowGroupSelection) {
		Locale userLocale = LocaleContextHolder.getLocale();
		String selectedName = null;
		String selectedPayeeId = cmd.getSelectedPayeeId();
		if (selectedPayeeId != null && !selectedPayeeId.isEmpty()) {
			selectedName = this.drawReportManager.getPayee(selectedPayeeId);
		} else if (allowGroupSelection) {
			String selectedGroupId = cmd.getSelectedGroupId();
			if (selectedGroupId != null && !selectedGroupId.isEmpty()) {
				selectedName = this.drawReportManager.getGroup(selectedGroupId);
			} else {
				selectedName = this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_FILTER_ALLGROUPS,
						userLocale);
			}
		} else {
			selectedName = this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_FILTER_ALLPAYEES, userLocale);
		}

		return selectedName;
	}

	@RequestMapping({ "/drawreport/filter/getPeriods.do" })
	@ResponseBody
	public HashMap<String, Object> getPeriodsJSON(@RequestParam int drawId, @RequestParam int templateId,
			HttpServletResponse response) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		HashMap<String, Object> responseContent = new HashMap();
		responseContent.put("allPeriodsString",
				this.messages.getMessage(Messages.Key.DRAW_REPORT_FILTER_ALLPERIODS, LocaleContextHolder.getLocale()));

		try {
			responseContent.put("periods",
					this.drawReportManager.getPeriods(drawId, templateId).toArray(new TimePeriod[0]));
			return responseContent;
		} catch (InvalidDrawException var6) {
			responseContent.put("periods", new TimePeriod[0]);
			return responseContent;
		}
	}

	@RequestMapping({ "/drawreport/assignments/getData.do" })
	@ResponseBody
	public DataRow[] getAssignmentsJSON(@RequestParam int id, @RequestParam String selectedPayeeId,
			@RequestParam String selectedGroupId, @RequestParam String selectedTemplate,
			@RequestParam String selectedPeriod, @RequestParam String selectedPeriodLevel, @RequestParam int pageNumber,
			@RequestParam int rowsPerPage, @RequestParam String sortColumn, @RequestParam boolean descending,
			HttpServletResponse response) {
		DrawReportCommand command = new DrawReportCommand();
		command.setId(id);
		command.setSelectedPayeeId(selectedPayeeId);
		command.setSelectedGroupId(selectedGroupId);
		command.setSelectedTemplate(selectedTemplate);
		command.setSelectedPeriod(selectedPeriod);
		command.setSelectedPeriodLevel(selectedPeriodLevel);
		NoncacheHttpResponseSetter.setResponseNonCache(response);

		try {
			return (DataRow[]) this.drawReportManager
					.getAssignments(command, pageNumber, rowsPerPage, sortColumn, descending).toArray(new DataRow[0]);
		} catch (InvalidDrawException var14) {
			return new DataRow[0];
		}
	}

	@RequestMapping({ "/drawreport/ytdpayout/getData.do" })
	@ResponseBody
	public DataRow[] getYTDPayoutJSON(@RequestParam int id, @RequestParam String selectedPayeeId,
			@RequestParam String selectedGroupId, @RequestParam String selectedTemplate,
			@RequestParam String selectedPeriod, @RequestParam String selectedPeriodLevel, @RequestParam int pageNumber,
			@RequestParam int rowsPerPage, @RequestParam String sortColumn, @RequestParam boolean descending,
			HttpServletResponse response) {
		DrawReportCommand command = new DrawReportCommand();
		command.setId(id);
		command.setSelectedPayeeId(selectedPayeeId);
		command.setSelectedGroupId(selectedGroupId);
		command.setSelectedTemplate(selectedTemplate);
		command.setSelectedPeriod(selectedPeriod);
		command.setSelectedPeriodLevel(selectedPeriodLevel);
		NoncacheHttpResponseSetter.setResponseNonCache(response);

		try {
			return (DataRow[]) this.drawReportManager
					.getYTDPayoutDetails(command, pageNumber, rowsPerPage, sortColumn, descending)
					.toArray(new DataRow[0]);
		} catch (InvalidDrawException var14) {
			return new DataRow[0];
		}
	}

	@RequestMapping({ "/drawreport/periodpayout/getData.do" })
	@ResponseBody
	public DataRow[] getPeriodPayoutJSON(@RequestParam int id, @RequestParam String selectedPayeeId,
			@RequestParam String selectedGroupId, @RequestParam String selectedTemplate,
			@RequestParam String selectedPeriod, @RequestParam String selectedPeriodLevel, @RequestParam int pageNumber,
			@RequestParam int rowsPerPage, @RequestParam String sortColumn, @RequestParam boolean descending,
			HttpServletResponse response) {
		DrawReportCommand command = new DrawReportCommand();
		command.setId(id);
		command.setSelectedPayeeId(selectedPayeeId);
		command.setSelectedGroupId(selectedGroupId);
		command.setSelectedTemplate(selectedTemplate);
		command.setSelectedPeriod(selectedPeriod);
		command.setSelectedPeriodLevel(selectedPeriodLevel);
		NoncacheHttpResponseSetter.setResponseNonCache(response);

		try {
			return (DataRow[]) this.drawReportManager
					.getByPeriodPayoutDetails(command, pageNumber, rowsPerPage, sortColumn, descending)
					.toArray(new DataRow[0]);
		} catch (InvalidDrawException var14) {
			return new DataRow[0];
		}
	}
}
