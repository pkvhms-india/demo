package com.varicent.payeeledger.dao.jdbc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.varicent.common.time.dao.TimeDao;
import com.varicent.payeeledger.domain.DisplayColumn;
import com.varicent.payeeledger.domain.RunningTotal;
import com.varicent.payeeledger.domain.TraceReport;

class DetailReportTotals {
	private final DetailResetMonitor resetter;
	private final List<RunningTotal> totals;

	public DetailReportTotals(TraceReport report, int firstResettingPartition, int lastResettingPartition,
			TimeDao timeDao) {
		this.resetter = new DetailResetMonitor(report, firstResettingPartition, lastResettingPartition, timeDao);
		this.totals = new ArrayList();
	}

	public BigDecimal getValue(DisplayColumn column) {
		return this.findRunningTotal(column).getValue();
	}

	public boolean hasValue(DisplayColumn column) {
		RunningTotal total = this.findRunningTotal(column);
		return total == null ? false : total.hasValue();
	}

	public boolean reset(List<Object> currentRow, List<Object> nextRow) {
		if (!this.resetter.resetRunningTotals(currentRow, nextRow)) {
			return false;
		} else {
			for (RunningTotal total : this.totals) {
				total.reset();
			}

			return true;
		}
	}

	public void update(DisplayColumn column, Object value) {
		if (column.hasOperation()) {
			RunningTotal total = this.getRunningTotal(column);
			if (value != null) {
				BigDecimal decminalValue = (BigDecimal) value;
				total.evaluate(decminalValue);
			}

		}
	}

	private RunningTotal findRunningTotal(DisplayColumn column) {
		for (RunningTotal t : this.totals) {
			if (t.getOperator() == column.getOperator() && t.getDataItem().equals(column.getDataItem())) {
				return t;
			}
		}

		return null;
	}

	private RunningTotal getRunningTotal(DisplayColumn column) {
		RunningTotal total = this.findRunningTotal(column);
		if (total != null) {
			return total;
		} else {
			total = new RunningTotal(column.getOperator(), column.getDataItem());
			this.totals.add(total);
			return total;
		}
	}
}
