package com.varicent.payeeledger.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.varicent.common.config.service.ConfigManager;
import com.varicent.payeeledger.service.PayeeLedger;
import com.varicent.workflow.service.WorkflowManager;

@Controller
@RequestMapping({ "/ledger/detail.html" })
public class DetailLedgerController extends AbstractPayeeLedgerController {
	private static final String TYPE = "detail";
	private static final String VIEW = "payeeledger/detail";

	@Autowired
	public DetailLedgerController(@Qualifier("detailLedger") PayeeLedger payeeLedger, ConfigManager configManager,
			WorkflowManager workflowManager) {
		super(payeeLedger, configManager, workflowManager);
	}

	@Override
	public String getType() {
		return "detail";
	}

	@Override
	protected String getView() {
		return "payeeledger/detail";
	}
}
