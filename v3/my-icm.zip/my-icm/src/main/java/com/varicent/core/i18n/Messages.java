package com.varicent.core.i18n;

import java.util.Locale;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class Messages {
	private final MessageSource messageSource;

	@Autowired
	public Messages(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public String getMessage(Key key) {
		return this.getMessage(key, Locale.getDefault());
	}

	public String getMessage(Key key, Object... params) {
		Assert.isTrue(key.getParamCount() == params.length);
		return this.messageSource.getMessage(key.toString(), params, Locale.getDefault());
	}

	public String getMessage(Key key, Locale locale) {
		return this.messageSource.getMessage(key.toString(), (Object[]) null, locale);
	}

	public String getMessage(Key key, Locale locale, Object... params) {
		return this.messageSource.getMessage(key.toString(), params, locale);
	}

	public String getMessage(Message message) {
		return this.getMessage(message.getKey(), message.getParams());
	}

	public String getHTMLDecodedMessage(Key key, Locale locale) {
		return StringEscapeUtils.unescapeHtml(this.getMessage(key, locale));
	}

	public String getHTMLDecodedMessage(Key key, Locale locale, Object... params) {
		return StringEscapeUtils.unescapeHtml(this.getMessage(key, locale, params));
	}

	public Key hasKey(String key) {
		for (Key k : Messages.Key.values()) {
			if (key.equals(k.toString())) {
				return k;
			}
		}

		return null;
	}

	public static enum Key {
		ACCEPT("signaturecontrolexpander.useroptions.accept"), REJECT("signaturecontrolexpander.useroptions.reject"),
		ADJUSTMENT_ERROR_COMMENT_TOO_LONG("error.adjustment.commentTooLong"),
		ADJUSTMENT_ERROR_INVALID_NUMERIC("error.adjustment.invalidNumericField"),
		ADJUSTMENT_ERROR_ZERO_NUMERIC("error.adjustment.zeroNumericField"),
		CONCURRENCY_ERROR_DATAINTEGRITY("error.concurrency.dataintegrity"),
		CUSTOMIZE_ERROR_REQUIRED_FIELD("error.customize.requiredField", 1),
		CUSTOMIZE_ERROR_VALUE("error.customize.invalidValue", 1),
		CUSTOMIZE_ERROR_VALUE_COMMENT("error.customize.invalidComment", 1),
		CUSTOMIZE_ERROR_VALUE_DATE("error.customize.invalidDate", 1),
		CUSTOMIZE_ERROR_VALUE_EMAIL("error.customize.invalidEmail", 1),
		CUSTOMIZE_ERROR_VALUE_NUMERIC("error.customize.invalidNumeric", 1),
		CUSTOMIZE_ERROR_VALUE_TEXT("error.customize.invalidText", 1),
		CUSTOMIZE_ERROR_VALUE_URL("error.customize.invalidURL", 1),
		CUSTOMIZE_ERROR_FIELD_VALUE("error.customize.invalidValueField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_COMMENT("error.customize.invalidCommentField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_DATE("error.customize.invalidDateField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_EMAIL("error.customize.invalidEmailField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_NUMERIC("error.customize.invalidNumericField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_TEXT("error.customize.invalidTextField", 2),
		CUSTOMIZE_ERROR_FIELD_VALUE_URL("error.customize.invalidURLField", 2), COLUMN_ACCOUNTID("column.AccountID_"),
		COLUMN_ACTIVE("column.Active_"), COLUMN_AUDITID("column.AuditID_"), COLUMN_CITY("column.City_"),
		COLUMN_COMMENT("column.Comment_"), COLUMN_COMPLANID("column.CompPlanID_"), COLUMN_COUNTRY("column.Country_"),
		COLUMN_CUSTOMERID("column.CustomerID_"), COLUMN_DATE("column.Date_"),
		COLUMN_DATE_OF_HIRE("column.Date_of_Hire_"), COLUMN_DRCR("column.DrCr_"), COLUMN_EMAIL("column.Email_"),
		COLUMN_END("column.End_"), COLUMN_ENDING("column.Ending_"), COLUMN_EVENT("column.Event_"),
		COLUMN_EXTENSION("column.Extension_"), COLUMN_INDUSTRY("column.Industry_"),
		COLUMN_LAUNCH_DATE("column.Launch_Date_"), COLUMN_MESSAGE("column.Message_"), COLUMN_MODULE("column.Module_"),
		COLUMN_NAME("column.Name_"), COLUMN_ORDER_CURRENCY("column.Order_Currency_"), COLUMN_PARENT("column.Parent_"),
		COLUMN_PAYEE_CURRENCY("column.Payee_Currency_"), COLUMN_PAYEEGROUPID("column.PayeeGroupID_"),
		COLUMN_PAYEEID("column.PayeeID_"), COLUMN_PHONE("column.Phone_"), COLUMN_PRODUCTID("column.ProductID_"),
		COLUMN_REPORTS_TO("column.Reports_To_"), COLUMN_SALUTATION("column.Salutation_"), COLUMN_START("column.Start_"),
		COLUMN_STARTING("column.Starting_"), COLUMN_STATE("column.State_"), COLUMN_STREET("column.Street_"),
		COLUMN_TERMINATION_DATA("column.Termination_Date_"), COLUMN_TIME("column.column.Time_"),
		COLUMN_TITLEID("column.TitleID_"), COLUMN_USERID("column.UserID_"), COLUMN_USERTYPE("column.UserType_"),
		COLUMN_VALUE("column.Value_"), COLUMN_ZIP("column.Zip_"), TABLE_ACCOUNT("table.Account_"),
		TABLE_AUDIT("table.Audit_"), TABLE_CURRENCY("table.Currency_"), TABLE_CUSTOMER("table.Customer_"),
		TABLE_DATA("table.Data_"), TABLE_EARNINGS("table.Earnings_"), TABLE_GROUPMEMBER("table.GroupMember_"),
		TABLE_NETADJUSTMENTS("table.NetAdjustments_"), TABLE_NETEARNINGS("table.NetEarnings_"),
		TABLE_NETPENDING("table.NetPending_"), TABLE_PAYEE("table.Payee_"), TABLE_PAYEEGROUP("table.PayeeGroup_"),
		TABLE_PAYMENT("table.Payment_"), TABLE_PENDING("table.Pending_"), TABLE_PRODUCT("table.Product_"),
		TABLE_SALUTATION("table.Salutation_"), TABLE_TIME("table.Time_"), TABLE_TITLE("table.Title_"),
		EMAIL_PASSWORD_RESET_MESSAGE("email.password.reset.message", 1),
		EMAIL_PASSWORD_RESET_SUBJECT("email.password.reset.subject"),
		EMAIL_USER_LOCKED_DEFAULT_MESSAGE("email.user.locked.default.message", 1),
		EMAIL_USER_LOCKED_RESET_MESSAGE("email.user.locked.reset.message", 1),
		EMAIL_USER_LOCKED_SUBJECT("email.user.locked.subject"),
		EMAIL_WORKFLOW_INQUIRY_MESSAGE("email.workflow.inquiry.message"),
		EMAIL_WORKFLOW_INQUIRY_SUBJECT("email.workflow.inquiry.subject", 1),
		EMAIL_WORKFLOW_INQUIRY_CLOSED("messagecenter.messages.summary.inquiriesClosed"),
		EMAIL_WORKFLOW_INQUIRY_COMMENTED("messagecenter.messages.summary.inquiriesCommented"),
		EMAIL_WORKFLOW_INQUIRY_ESCALATED("messagecenter.messages.summary.inquiriesEscalated"),
		EMAIL_WORKFLOW_INQUIRY_OPEN("messagecenter.messages.summary.inquiriesSubmitted"),
		EMAIL_WORKFLOW_INQUIRY_RETURNED("messagecenter.messages.summary.inquiriesReturned"),
		EMAIL_WORKFLOW_INQUIRY_RESUBMITTED("messagecenter.messages.summary.inquiriesResubmitted"),
		EMAIL_WORKFLOW_SIGNOFF_MESSAGE("email.workflow.signoff.message"),
		EMAIL_WORKFLOW_SIGNOFF_SUBJECT("email.workflow.signoff.subject"), EVENT_ADMIN_APPROVE("event.admin.approve"),
		ERROR_API_DATABASE("error.api.database"), EVENT_ADMIN_APPROVE_MESSAGE("event.admin.approve.message", 3),
		EVENT_ADMIN_REJECT("event.admin.reject"), EVENT_ADMIN_REJECT_MESSAGE("event.admin.reject.message", 3),
		EVENT_EDIT_SUBMIT("event.edit.submit"), EVENT_EDIT_SUBMIT_MESSAGE("event.edit.submit.message", 2),
		EVENT_EDIT_UPDATE_SUBMIT("event.edit.update.submit"),
		EVENT_EDIT_UPDATE_SUBMIT_MESSAGE("event.edit.update.submit.message", 2),
		EVENT_INQUIRY_CLOSE("event.inquiry.close"), EVENT_INQUIRY_CLOSE_COMMENT("event.inquiry.close.comment"),
		EVENT_INQUIRY_CLOSE_MESSAGE("event.inquiry.close.message", 1), EVENT_INQUIRY_ESCALATE("event.inquiry.escalate"),
		EVENT_INQUIRY_ESCALATE_COMMENT("event.inquiry.escalate.comment"),
		EVENT_INQUIRY_ESCALATE_MESSAGE("event.inquiry.escalate.message", 1), EVENT_INQUIRY_OPEN("event.inquiry.open"),
		EVENT_INQUIRY_OPEN_MESSAGE("event.inquiry.open.message", 1), EVENT_INQUIRY_REJECT("event.inquiry.reject"),
		EVENT_INQUIRY_REJECT_COMMENT("event.inquiry.reject.comment"),
		EVENT_INQUIRY_REJECT_MESSAGE("event.inquiry.reject.message", 1),
		EVENT_INQUIRY_RESUBMIT("event.inquiry.resubmit"),
		EVENT_INQUIRY_RESUBMIT_COMMENT("event.inquiry.resubmit.comment"),
		EVENT_INQUIRY_RESUBMIT_MESSAGE("event.inquiry.resubmit.message", 1), EVENT_LOGIN("event.login"),
		EVENT_LOGIN_MESSAGE("event.login.message", 1), EVENT_LOGIN_WEBDISABLED("event.login.webdisabled", 1),
		EVENT_LOGOUT("event.logout"), EVENT_LOGOUT_MESSAGE("event.logout.message", 1),
		EVENT_SIGNOFF_COMPLETE("event.signoff.complete"),
		EVENT_SIGNOFF_COMPLETE_MESSAGE("event.signoff.complete.message", 1), EVENT_USER_LOCKED("event.user.locked"),
		EVENT_USER_LOCKED_MESSAGE("event.user.locked.message", 1), EVENT_USER_UNLOCKED("event.user.unlocked"),
		EVENT_USER_UNLOCKED_MESSAGE("event.user.unlocked.message", 1), EVENT_DRAW_ASSIGNED("event.draw.assigned"),
		EVENT_DRAW_UNASSIGNED("event.draw.unassigned"), EVENT_DRAW_ASSIGNED_MESSAGE("event.draw.assigned.message", 3),
		EVENT_DRAW_UNASSIGNED_MESSAGE("event.draw.unassigned.message", 3),
		EVENT_DRAW_ASSIGNMENT_MODIFIDED("event.draw.assign.modified"),
		EVENT_DRAW_ASSIGNMENT_MODIFIDED_MESSAGE("event.draw.assign.modified.message", 3),
		EVENT_WEBFORM_INSERT_SUBMIT("event.webform.insert.submit"),
		EVENT_WEBFORM_INSERT_SUBMIT_MESSAGE("event.webform.insert.submit.message", 3),
		EVENT_WEBFORM_UPDATE_SUBMIT("event.webform.update.submit"),
		EVENT_WEBFORM_UPDATE_SUBMIT_MESSAGE("event.webform.update.submit.message", 3),
		EVENT_WEBFORM_UPDATE_MANUALADJUST_MESSAGE("event.webform.update.manualadjust.message", 3),
		EVENT_WEBREPORT_INSERT_SUBMIT("event.webreport.insert.submit"),
		EVENT_WEBREPORT_INSERT_SUBMIT_MESSAGE("event.webreport.insert.submit.message", 3),
		EVENT_WEBREPORT_UPDATE_SUBMIT("event.webreport.update.submit"),
		EVENT_WEBREPORT_UPDATE_SUBMIT_MESSAGE("event.webreport.update.submit.message", 3),
		INQUIRIES_CATEGORY_NONE("inquiries.category.none"), LEDGER_SUMMARY_EARNINGS("payeeledger.summary.earnings"),
		LEDGER_SUMMARY_GRAND_TOTAL("payeeledger.summary.grandTotal"),
		LEDGER_SUMMARY_NET_ADJUSTMENTS("payeeledger.summary.netAdjustments"),
		LEDGER_SUMMARY_NET_EARNINGS("payeeledger.summary.netEarnings"),
		LEDGER_SUMMARY_PAYMENT("payeeledger.summary.payment"), LEDGER_SUMMARY_PENDING("payeeledger.summary.pending"),
		LEDGER_SUMMARY_PERIOD("payeeledger.summary.period"), LOCALE_PAGE_MISMATCH("error.locale"),
		LOGIN_INVALID_UNICODE_CONFIG("error.login.invalidUnicodeConfig"),
		LOGIN_OLD_DATABASE_VERSION("error.login.oldDatabaseVersion", 2), LOGIN_ERROR("error.login"),
		LOGIN_LOCKED("error.password.locked"), MODULE_CUSTOMIZE("module.customize"), MODULE_WEB("module.web"),
		MODULE_WEBFORMS("module.webforms"), MODULE_WORKFLOW("module.workflow"), MODULE_REPORTING("module.reporting"),
		NOT_FOUND("error.messages.pagenotfound"), PASSWORD_DISABLED("error.password.disabled"),
		PASSWORD_EMPTY_CONFIRM("error.password.emptyConfirm"), PASSWORD_EMPTY_NEW("error.password.emptyNew"),
		PASSWORD_EMPTY_OLD("error.password.emptyOld"), PASSWORD_INVALID_CURRENT("error.password.invalidCurrent"),
		PASSWORD_INVALID_NEW("error.password.invalidNew"), PASSWORD_MISMATCH("error.password.mismatch"),
		PASSWORD_HISTORY("error.password.history", 1), PASSWORD_RESET_REQUEST_SUCCESS("user.passwordHelp.success"),
		PASSWORD_SUCCESS("user.password.success"), PASSWORD_WEAK("error.password.weak"),
		PASSWORD_INVALID_EMAIL("error.password.invalidEmail"),
		REPORTING_ERROR_DATAGRID_TOO_BIG("reporting.error.datagridTooManyRows", 1),
		REPORTING_ERROR_LACK_ACCESS("reporting.error.lackAccess"),
		REPORTING_ERROR_MISSING_PARAMETER("reporting.error.missingReportParameter", 1),
		REPORTING_ERROR_BAD_PARAMETER("reporting.error.badReportParameter", 2),
		REPORTING_ERROR_MISSING_REQUIRED_PARAMS_REPLACED_WITH_DEFAULT(
				"reporting.error.missingRequiredParametersReplacedWithDefault", 1),
		REPORTING_ERROR_PARAMETER_TOO_LARGE("reporting.error.parameterTooLarge", 1),
		REPORTING_ERROR_MISSING_DEPENDENCY("reporting.error.missingDependency"),
		REPORTING_ERROR_TOO_BIG("reporting.error.reportTooBig"),
		REPORTING_ERROR_OVER_LIMIT("reporting.error.reportOverLimit"),
		REPORTING_ERROR_OVER_LIMIT_LOG("reporting.error.reportOverLimit.log", 1),
		REPORTING_ERROR_OVER_LIMIT_LOG_REPORT_NAME("reporting.error.reportOverLimit.log.ReportName", 1),
		REPORTING_ERROR_OVER_LIMIT_LOG_SOURCE("reporting.error.reportOverLimit.log.Source", 1),
		REPORTING_ERROR_OVER_LIMIT_LOG_ROWS("reporting.error.reportOverLimit.log.Rows", 1),
		USERNAME_EMPTY("error.username.empty"), WEBFORMS_ERROR_SUBMIT_CHANGES("error.webforms.submit.changes"),
		WEBFORMS_ERROR_SUBMIT_DUPLICATE("error.webforms.submit.duplicate"),
		WEBFORMS_ERROR_SUBMIT_INVALID("error.webforms.submit.invalid", 3),
		WEBFORMS_ERROR_SUBMIT_INVALID_RULE("error.webforms.submit.invalidRule", 3),
		WEBFORMS_ERROR_SUBMIT_INPUTRULE_ERROR("error.webreports.fix.input.rule.errors"),
		WEBFORMS_ERROR_SUBMIT_LOCKED_PERIOD("error.webforms.submit.lockedPeriod"),
		WEBFORMS_ERROR_SUBMIT_LOCKED_ROW("error.webforms.submit.lockedRow"),
		WEBFORMS_ERROR_SUBMIT_REQUIRED_FIELD("error.webforms.submit.requiredField", 2),
		WEBFORMS_ERROR_SUBMIT_RESTRICTED_FIELD("error.webforms.submit.restrictedField", 2),
		WEBFORMS_ERROR_SUBMIT_RESTRICTED_TABLE("error.webforms.submit.restrictedTable", 1),
		WEBFORMS_ERROR_SUBMIT_TRUNCATION("error.webforms.submit.truncation"),
		WEBFORMS_ERROR_SUBMIT_DATE_LOCKED_NOT_IN_CALENDAR("error.webforms.submit.date.locked.notInCal", 3),
		WEBFORMS_ERROR_SUBMIT_INTEGRITY("error.webforms.submit.integrity"),
		WEBFORMS_ERROR_SUBMIT_CYCLE_CREATED("error.webforms.submit.cycleCreated"),
		WEBFORMS_ERROR_INVALID("error.webforms.invalid"), WEBFORMS_ERROR_UNAVAILABLE("error.webforms.unavailable"),
		WEBFORMS_INSERT("webforms.admin.insert"), WEBFORMS_UPDATE("webforms.admin.update"),
		DRAW_ASSIGN_ERROR_GLOBAL_DRAW_LIMIT("error.draw.assign.global.draw.limit", 1),
		DRAW_ASSIGN_ERROR_FIXED_AMOUNT("error.draw.assign.fixed.amount", 1),
		DRAW_ASSIGN_ERROR_MAX_AMOUNT("error.draw.assign.max.amount", 1),
		DRAW_ASSIGN_ERROR_NEGATIVE_AMOUNT("error.draw.assign.negative.amount", 1),
		DRAW_ASSIGN_ERROR_LOCKED_START_DATE("error.draw.assign.locked.start.date", 1),
		DRAW_ASSIGN_ERROR_LOCKED_OLD_START_DATE("error.draw.assign.locked.old.start.date", 1),
		DRAW_ASSIGN_ERROR_INVALID_AMOUNT("error.draw.assign.invalid.amount", 1),
		DRAW_ASSIGN_ERROR_EMPTY_DATE("error.draw.assign.empty.date", 1),
		DRAW_ASSIGN_ERROR_INVALID_DATE("error.draw.assign.invalid.date", 1),
		DRAW_ASSIGN_ERROR_START_AFTER_END_DATE("error.draw.assign.start.after.end.date", 1),
		DRAW_ASSIGN_ERROR_MISSING_CALENDAR_DATE("error.draw.assign.missing.calendar.date", 1),
		DRAW_ASSIGN_ERROR_ASSIGNMENT_EXISTS("error.draw.assign.assignment.exists", 1),
		DRAW_ASSIGN_ERROR_INVALID_PERIOD("error.draw.assign.invalid.period", 1),
		DRAW_ASSIGN_ERROR_LOCKED_PERIOD("error.draw.assign.locked.period", 2),
		DRAW_ASSIGN_ERROR_PERIOD_FIXED("error.draw.assign.period.fixed", 1),
		DRAW_ASSIGN_ERROR_LOCKED_ONGOING("error.draw.assign.locked.ongoing", 1),
		DRAW_ASSIGN_ERROR_CONCURRENCY("error.draw.assign.concurrency"),
		DRAW_ASSIGN_ERROR_INVALIDDRAW("error.draw.assign.invalid.draw"),
		DRAW_REPORT_ERROR_INVALIDDRAW("error.draw.report.invalid.draw"),
		DRAW_REPORT_ERROR_LACK_OF_ACCESS("error.draw.report.lack.of.access"),
		DRAW_ASSIGN_ERROR_LACK_OF_ACCESS("error.draw.assign.lack.of.access"),
		DRAW_REPORT_ERROR_DOES_NOT_EXIST("error.draw.report.does.not.exist"),
		DRAW_ASSIGN_ERROR_DOES_NOT_EXIST("error.draw.assign.does.not.exist"),
		DRAW_REPORT_DATAGRID_TOTAL("draw.report.datagrid.total"),
		DRAW_REPORT_FILTER_ALLPAYEES("draw.report.filter.allPayees"),
		DRAW_REPORT_FILTER_ALLGROUPS("draw.report.filter.allGroups"),
		DRAW_REPORT_FILTER_ALLPERIODS("draw.report.filter.allPeriods"),
		DRAW_REPORT_ASSIGNMENTS_HEADERS_PAYEEID("draw.report.assignments.headers.payeeID"),
		DRAW_REPORT_ASSIGNMENTS_HEADERS_NAME("draw.report.assignments.headers.name"),
		DRAW_REPORT_ASSIGNMENTS_HEADERS_DRAWTEMPLATE("draw.report.assignments.headers.drawTemplate"),
		DRAW_REPORT_ASSIGNMENTS_HEADERS_STARTPERIOD("draw.report.assignments.headers.start"),
		DRAW_REPORT_ASSIGNMENTS_HEADERS_ENDPERIOD("draw.report.assignments.headers.end"),
		DRAW_REPORT_DROPDOWN_TITLE("draw.report.dropdown.title"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_PAYEEID("draw.report.ytdpayout.headers.payeeID"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_PAYEE("draw.report.ytdpayout.headers.payee"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_EARNINGS("draw.report.ytdpayout.headers.earnings"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_DRAW("draw.report.ytdpayout.headers.draw"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_BALANCE("draw.report.ytdpayout.headers.balance"),
		DRAW_REPORT_YTDPAYOUT_HEADERS_PAYOUT("draw.report.ytdpayout.headers.payout"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYEEID("draw.report.periodpayout.headers.payeeID"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYEE("draw.report.periodpayout.headers.payee"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_PERIOD("draw.report.periodpayout.headers.period"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_EARNINGS("draw.report.periodpayout.headers.earnings"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_DRAW("draw.report.periodpayout.headers.draw"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_PERIODDRAW("draw.report.periodpayout.headers.periodDraw"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_BALANCE("draw.report.periodpayout.headers.balance"),
		DRAW_REPORT_PERIODPAYOUT_HEADERS_PAYOUT("draw.report.periodpayout.headers.payout"),
		BPM_EMAIL_FAILED("bpm.token.error.email"), BPM_TOKEN_ERROR_CONCURRENCY("bpm.token.error.action"),
		BPM_TOKEN_ERROR_VIEW("bpm.token.error.view"), BPM_ERROR_VIEW("bpm.error.view"),
		BPM_START_NODE_ACTION("bpm.start.node.action"), BPM_END_NODE_ACTION("bpm.end.node.action"),
		BPM_ERROR_NODE_ACTION("bpm.error.node.action"), ERROR_SUBMIT_LOCKED_PERIOD("error.submit.lockedPeriod"),
		ERROR_SUBMIT_LOCKED_ROW("error.submit.lockedRow"),
		WEBREPORT_ERROR_DUPLICATEKEY("error.webreports.duplicateKey"),
		WEBREPORT_ERROR_TRUNCATION("error.webreports.tooManyDigits"),
		WEBREPORT_ERROR_BADFORMAT("error.webreports.badFormat", 3),
		WEBREPORT_ERROR_SUBMIT_INVALID_RULE("error.webreports.invalid.rule", 3),
		WEBREPORT_ERROR_SUBMIT_DATE_LOCKED_NOT_IN_CALENDAR("error.webreports.submit.date.locked.notInCal", 3),
		WEBREPORT_ERROR_KEYCOLUMN_MISSING("error.webreports.keycolumnsMissing", 2),
		WEBREPORT_ERROR_CONCURRENCY("error.webreports.concurrency"),
		WEBREPORT_ERROR_REMOVED("error.webreports.Removed"),
		WEBREPORT_ERROR_AUTOGENERATE("error.webreports.autogenerate", 1),
		WEBREPORT_ERROR_MODIFICATIONINPROGRESS("error.webreports.modificationInProgress"),
		WEBREPORT_FUSION_NO_DATA("webreport.fusion.nodata"),
		WEBREPORT_FUSION_INVALID_XML("webreport.fusion.invalidXml"),
		WEBREPORT_FUSION_LOAD_ERROR("webreport.fusion.loadError"),
		WEBREPORT_FUSION_PARSING_ERROR("webreport.fusion.parsing"),
		WEBREPORT_FUSION_LOADING("webreport.fusion.loading"), WEBREPORT_FUSION_RENDERING("webreport.fusion.rendering"),
		WEBREPORT_FUSION_XML_LOADING("webreport.fusion.XML.loading"),
		WEBREPORT_FUSION_CAPTURING("webreport.fusion.capturing"),
		WEBREPORT_D3_LEGENDTITLELABEL("webreport.d3.legendTitleLabel"),
		WEBREPORT_D3_TOTALLABEL("webreport.d3.totalLabel"),
		WEBREPORT_FIXEDGRID_OPTIONS_TITLE("webreport.fixedgrid.options.title"),
		WEBREPORT_PDF_PAGE_NUMBER("webreport.pdf.pagenumber", 1),
		WEBREPORT_EXPORTEXCEL_NAME("webreport.exportexcel.name"),
		WEBREPORT_EXPORTEXCEL_EXTENSION_XLS("webreport.exportexcel.extension.xls"),
		WEBREPORT_EXPORTEXCEL_EXTENSION_XLSX("webreport.exportexcel.extension.xlsx"),
		WEBREPORT_EXPORTEXCEL_TOOLTIP_XLS("webreport.title.exporttoexcel2003"),
		WEBREPORT_EXPORTEXCEL_TOOLTIP_XLSX("webreport.title.exporttoexcel2007"),
		WEBREPORT_COPY_INQUIRY_TOOLTIP("webreport.tooltip.copyToInquiry"),
		WEBREPORT_MESSAGEGENERATEDBYICM("webreport.messagegeneratedbyICM"),
		WORKFLOWLINK_HEADERS_REPORTNAME("bpm.tokenlist.reportname"),
		WORKFLOWLINK_HEADERS_ACTIONNAME("bpm.tokenlist.actionname"),
		WORKFLOWLINK_HEADERS_SUBMITTEDBY("bpm.tokenlist.submittedby"),
		WORKFLOWLINK_HEADERS_SUBMITTEDBYNAME("bpm.tokenlist.submittedbyname"),
		WORKFLOWLINK_HEADERS_DATERECEIVED("bpm.tokenlist.date"),
		WORKFLOWLINK_HEADERS_WORKFLOWNAME("bpm.workflow.workflow"),
		WORKFLOWLINK_HEADERS_WORKFLOWDESCRIPTION("bpm.workflow.description"),
		WORKFLOWLINK_HEADERS_INITIATOR("bpm.history.Initiator"),
		WORKFLOWLINK_HEADERS_INITIATORNAME("bpm.history.InitiatorName"),
		WORKFLOWLINK_HEADERS_DATEOFCREATION("bpm.history.DateofInitiation"),
		WORKFLOWLINK_HEADERS_DATEOFDELETION("bpm.history.DateofCompletion"),
		DATEPICKER_CLOSETEXT("datepicker.closeText"), DATEPICKER_PREVTEXT("datepicker.prevText"),
		DATEPICKER_NEXTTEXT("datepicker.nextText"), DATEPICKER_CURRENTTEXT("datepicker.currentText"),
		DATEPICKER_MONTHNAMES_JAN("datepicker.monthNames.jan"), DATEPICKER_MONTHNAMES_FEB("datepicker.monthNames.feb"),
		DATEPICKER_MONTHNAMES_MAR("datepicker.monthNames.mar"), DATEPICKER_MONTHNAMES_APR("datepicker.monthNames.apr"),
		DATEPICKER_MONTHNAMES_MAY("datepicker.monthNames.may"), DATEPICKER_MONTHNAMES_JUN("datepicker.monthNames.jun"),
		DATEPICKER_MONTHNAMES_JUL("datepicker.monthNames.jul"), DATEPICKER_MONTHNAMES_AUG("datepicker.monthNames.aug"),
		DATEPICKER_MONTHNAMES_SEP("datepicker.monthNames.sep"), DATEPICKER_MONTHNAMES_OCT("datepicker.monthNames.oct"),
		DATEPICKER_MONTHNAMES_NOV("datepicker.monthNames.nov"), DATEPICKER_MONTHNAMES_DEC("datepicker.monthNames.dec"),
		DATEPICKER_MONTHNAMESSHORT_JAN("datepicker.monthNamesShort.jan"),
		DATEPICKER_MONTHNAMESSHORT_FEB("datepicker.monthNamesShort.feb"),
		DATEPICKER_MONTHNAMESSHORT_MAR("datepicker.monthNamesShort.mar"),
		DATEPICKER_MONTHNAMESSHORT_APR("datepicker.monthNamesShort.apr"),
		DATEPICKER_MONTHNAMESSHORT_MAY("datepicker.monthNamesShort.may"),
		DATEPICKER_MONTHNAMESSHORT_JUN("datepicker.monthNamesShort.jun"),
		DATEPICKER_MONTHNAMESSHORT_JUL("datepicker.monthNamesShort.jul"),
		DATEPICKER_MONTHNAMESSHORT_AUG("datepicker.monthNamesShort.aug"),
		DATEPICKER_MONTHNAMESSHORT_SEP("datepicker.monthNamesShort.sep"),
		DATEPICKER_MONTHNAMESSHORT_OCT("datepicker.monthNamesShort.oct"),
		DATEPICKER_MONTHNAMESSHORT_NOV("datepicker.monthNamesShort.nov"),
		DATEPICKER_MONTHNAMESSHORT_DEC("datepicker.monthNamesShort.dec"),
		DATEPICKER_DAYNAMES_SUN("datepicker.dayNames.sun"), DATEPICKER_DAYNAMES_MON("datepicker.dayNames.mon"),
		DATEPICKER_DAYNAMES_TUE("datepicker.dayNames.tue"), DATEPICKER_DAYNAMES_WED("datepicker.dayNames.wed"),
		DATEPICKER_DAYNAMES_THU("datepicker.dayNames.thu"), DATEPICKER_DAYNAMES_FRI("datepicker.dayNames.fri"),
		DATEPICKER_DAYNAMES_SAT("datepicker.dayNames.sat"),
		DATEPICKER_DAYNAMESSHORT_SUN("datepicker.dayNamesShort.sun"),
		DATEPICKER_DAYNAMESSHORT_MON("datepicker.dayNamesShort.mon"),
		DATEPICKER_DAYNAMESSHORT_TUE("datepicker.dayNamesShort.tue"),
		DATEPICKER_DAYNAMESSHORT_WED("datepicker.dayNamesShort.wed"),
		DATEPICKER_DAYNAMESSHORT_THU("datepicker.dayNamesShort.thu"),
		DATEPICKER_DAYNAMESSHORT_FRI("datepicker.dayNamesShort.fri"),
		DATEPICKER_DAYNAMESSHORT_SAT("datepicker.dayNamesShort.sat"),
		DATEPICKER_DAYNAMESMIN_SUN("datepicker.dayNamesMin.sun"),
		DATEPICKER_DAYNAMESMIN_MON("datepicker.dayNamesMin.mon"),
		DATEPICKER_DAYNAMESMIN_TUE("datepicker.dayNamesMin.tue"),
		DATEPICKER_DAYNAMESMIN_WED("datepicker.dayNamesMin.wed"),
		DATEPICKER_DAYNAMESMIN_THU("datepicker.dayNamesMin.thu"),
		DATEPICKER_DAYNAMESMIN_FRI("datepicker.dayNamesMin.fri"),
		DATEPICKER_DAYNAMESMIN_SAT("datepicker.dayNamesMin.sat"), DATEPICKER_WEEKHEADER("datepicker.weekHeader"),
		UNAUTHORIZED("error.messages.unauthorized"), FORBIDDEN("error.messages.forbidden"),
		WEBFORM_SYSTEMSOURCES_WEBUSER("webreport.systemsources.webuser"),
		WEBFORM_SYSTEMSOURCES_CURRENTDATE("webreport.systemsources.currentdate"),
		WEBFORM_SYSTEMSOURCES_WORKFLOWFORMID("webreport.systemsources.workflowformid"),
		WEBFORM_SYSTEMSOURCES_FORMINITIATOR("webreport.systemsources.forminitiator"),
		WORKFLOW_DISPUTE_STATUS_OPEN("workflow.dispute.status.open"),
		WORKFLOW_DISPUTE_STATUS_INVALID("workflow.dispute.status.invalid"),
		WORKFLOW_DISPUTE_STATUS_CLOSED("workflow.dispute.status.closed"),
		WORKFLOW_DISPUTE_STATUS_FIXED("workflow.dispute.status.fixed");

		private final String key;
		private final int paramCount;

		private Key(String key) {
			this.key = key;
			this.paramCount = 0;
		}

		private Key(String key, int paramCount) {
			this.key = key;
			this.paramCount = paramCount;
		}

		public int getParamCount() {
			return this.paramCount;
		}

		@Override
		public String toString() {
			return this.key;
		}
	}
}
