package com.varicent.core.database.support;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.Assert;

import com.varicent.common.query.domain.AndClause;
import com.varicent.common.query.domain.Clause;
import com.varicent.common.query.domain.DataField;
import com.varicent.common.query.domain.IConstraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.domain.SqlDataSource;
import com.varicent.common.query.domain.SubQueryConstraint;

public final class DataStoreSourceMapper {
	private static final String DataStorePrefix = "_DS";
	private static final String DataStoreSysPrefix = "_SysDS";

	private static boolean isMappableDataStore(String source, Map<Integer, SourceDefinition> dataStoreMap) {
		return isDataStore(source) && dataStoreMap.containsKey(getID(source));
	}

	public static int getID(String source) {
		return source.contains("_DS") ? Integer.parseInt(source.replace("_DS", ""))
				: Integer.parseInt(source.replace("_SysDS", ""));
	}

	public static boolean isDataStore(String source) {
		return source != null && (source.startsWith("_DS") || source.startsWith("_SysDS"));
	}

	private static Clause mapClause(Clause clause, Map<Integer, SourceDefinition> dataStoreMap) {
		Clause mappedClause;
		if (clause instanceof AndClause) {
			mappedClause = new AndClause();
		} else {
			Assert.isTrue(clause instanceof OrClause);
			mappedClause = new OrClause();
		}

		for (IConstraint constraint : clause.getConstraints()) {
			IConstraint mappedConstraint = constraint;
			if (constraint instanceof SubQueryConstraint) {
				SubQueryConstraint subQueryConstraint = (SubQueryConstraint) constraint;
				QueryDefinition subQuery = subQueryConstraint.getRight();
				QueryDefinition mappedSubQuery = mapQuery(subQuery, dataStoreMap);
				DataField dataField = subQueryConstraint.getLeft();
				if (dataField == null) {
					mappedConstraint = new SubQueryConstraint(subQueryConstraint.getOperator(), mappedSubQuery);
				} else {
					mappedConstraint = new SubQueryConstraint(dataField.getTable(), dataField.getColumn(),
							subQueryConstraint.getOperator(), mappedSubQuery);
				}
			}

			mappedClause.addConstraint(mappedConstraint);
		}

		return mappedClause;
	}

	private static List<Join> mapJoins(List<Join> joins, Map<Integer, SourceDefinition> dataStoreMap) {
		List<Join> mappedJoins = new ArrayList();

		for (Join join : joins) {
			SqlDataSource mappedSource = mapSource(join.getSource(), dataStoreMap);
			Clause mappedClause = mapClause(join.getRestriction(), dataStoreMap);
			join.setSource(mappedSource);
			join.setRestriction(mappedClause);
			mappedJoins.add(join);
		}

		return mappedJoins;
	}

	public static QueryDefinition mapQuery(QueryDefinition query, Map<Integer, SourceDefinition> dataStoreMap) {
		if (query != null) {
			SqlDataSource mappedSource = mapSource(query.getSource(), dataStoreMap);
			List<Join> mappedJoins = mapJoins(query.getJoins(), dataStoreMap);
			Clause mappedClause = mapClause(query.getRestriction(), dataStoreMap);
			QueryDefinition mappedUnion = mapQuery(query.getUnion(), dataStoreMap);
			QueryDefinition mappedQuery = new QueryDefinition();
			mappedQuery.addSelects(query.getSelect());
			mappedQuery.setSource(mappedSource);
			mappedQuery.joinWith(mappedJoins);
			mappedQuery.setRestriction(mappedClause);
			mappedQuery.addGroupItems(query.getGroup());
			mappedQuery.addOrderItems(query.getOrder());
			mappedQuery.limitTo(query.getLimit());
			if (query.isSelectDistinct()) {
				mappedQuery.selectDistinct();
			}

			if (query.hasUnion()) {
				mappedQuery.setUnionWith(mappedUnion);
			}

			query = mappedQuery;
		}

		return query;
	}

	private static SqlDataSource mapSource(SqlDataSource source, Map<Integer, SourceDefinition> dataStoreMap) {
		if (source != null) {
			if (source.isQuery()) {
				QueryDefinition mappedQuery = mapQuery(source.getQuery(), dataStoreMap);
				source = new SqlDataSource(mappedQuery, source.getAlias());
			} else if (source.isTable()) {
				String table = source.getTable();
				if (isMappableDataStore(table, dataStoreMap)) {
					String alias = source.getAlias();
					if (!source.hasAlias()) {
						alias = table;
					}

					SourceDefinition sourceDefn = dataStoreMap.get(getID(table));
					source = new SqlDataSource(sourceDefn.getQuery(), alias);
				}
			}
		}

		return source;
	}
}
