package com.varicent.core.mail;

import java.util.Collection;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.varicent.common.payee.domain.Payee;
import com.varicent.core.i18n.Messages;

public class Mailer {
	private static final Logger LOG = Logger.getLogger(Mailer.class);
	private final MailSender mailSender;
	private final JavaMailSender javaMailSender;
	private final Messages messages;
	private String from;

	@Autowired
	public Mailer(MailSender mailSender, JavaMailSender javaMailSender, Messages messages) {
		this.mailSender = mailSender;
		this.javaMailSender = javaMailSender;
		this.messages = messages;
	}

	public void send(SimpleMailMessage message, String email) throws MailException {
		this.send(message, email, false);
	}

	public void send(SimpleMailMessage message, Collection<Payee> recipients) {
		message.setFrom(this.from);
		message.setText(message.getText() + "\n\n"
				+ this.messages.getMessage(Messages.Key.WEBREPORT_MESSAGEGENERATEDBYICM) + "\n");

		for (Payee recipient : recipients) {
			if (recipient.hasEmail()) {
				try {
					message.setTo(recipient.getEmail());
					this.mailSender.send(message);
				} catch (MailException e) {
					LOG.error(e.getMessage(), e);
					throw e;
				}
			}
		}

	}

	public void send(Collection<Payee> recipients, String subject, String content, boolean isUnicode)
			throws MessagingException {
		for (Payee recipient : recipients) {
			if (recipient.hasEmail()) {
				this.send(recipient.getEmail(), subject, content, isUnicode);
			}
		}

	}

	public void send(String recipientEmail, String subject, String content, boolean isUnicode)
			throws MessagingException {
		try {
			MimeMessage message = this.javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(this.from);
			helper.setTo(recipientEmail);
			content = content + "\n\n" + this.messages.getMessage(Messages.Key.WEBREPORT_MESSAGEGENERATEDBYICM) + "\n";
			if (isUnicode) {
				message.setSubject(subject, "UTF-8");
				message.setText(content, "UTF-8");
			} else {
				message.setSubject(subject);
				message.setText(content);
			}

			this.javaMailSender.send(message);
		} catch (MessagingException e) {
			LOG.error(e.getMessage(), e);
			throw e;
		}
	}

	public void sendHtml(String subject, String messageHtml, Collection<Payee> recipients) throws MessagingException {
		try {
			MimeMessage message = this.javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(this.from);
			messageHtml = messageHtml.replace("</body></html>",
					"<p></p><p><font face=\"monospace, monospace\">"
							+ this.messages.getMessage(Messages.Key.WEBREPORT_MESSAGEGENERATEDBYICM) + "</font></p>"
							+ "</body></html>");

			for (Payee recipient : recipients) {
				if (recipient.hasEmail()) {
					helper.setTo(recipient.getEmail());
					helper.setSubject(subject);
					helper.setText(messageHtml, true);
					this.javaMailSender.send(message);
				}
			}

		} catch (MessagingException e) {
			LOG.error(e.getMessage(), e);
			throw e;
		}
	}

	public void send(SimpleMailMessage message, String email, boolean isCC) throws MailException {
		message.setFrom(this.from);
		message.setText(message.getText() + "\n\n"
				+ this.messages.getMessage(Messages.Key.WEBREPORT_MESSAGEGENERATEDBYICM) + "\n");

		try {
			if (isCC) {
				message.setCc(email);
			} else {
				message.setTo(email);
			}

			this.mailSender.send(message);
		} catch (MailException e) {
			LOG.error(e.getMessage(), e);
			throw e;
		}
	}

	public void sendHtml(String subject, String messageHtml, String email, boolean isCC) throws MessagingException {
		try {
			MimeMessage message = this.javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(this.from);
			if (isCC) {
				helper.setCc(email);
			} else {
				helper.setTo(email);
			}

			helper.setSubject(subject);
			messageHtml = messageHtml.replace("</body></html>",
					"<p></p><p><font face=\"monospace, monospace\">"
							+ this.messages.getMessage(Messages.Key.WEBREPORT_MESSAGEGENERATEDBYICM) + "</font></p>"
							+ "</body></html>");
			helper.setText(messageHtml, true);
			this.javaMailSender.send(message);
		} catch (MessagingException e) {
			LOG.error(e.getMessage(), e);
			throw e;
		}
	}

	public void setFrom(String from) {
		this.from = from;
	}
}
