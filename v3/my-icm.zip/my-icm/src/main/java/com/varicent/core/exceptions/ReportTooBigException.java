package com.varicent.core.exceptions;

public class ReportTooBigException extends Exception {
	private static final long serialVersionUID = 1L;

	public ReportTooBigException() {
	}

	public ReportTooBigException(String message) {
		super(message);
	}

	public ReportTooBigException(String message, Throwable cause) {
		super(message, cause);
	}

	public ReportTooBigException(Throwable cause) {
		super(cause);
	}
}
