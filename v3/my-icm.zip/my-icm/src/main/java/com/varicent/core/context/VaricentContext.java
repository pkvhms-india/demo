package com.varicent.core.context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.theme.domain.Theme;

@Component
public class VaricentContext {
	private static final VaricentContext INSTANCE = new VaricentContext();
	private static String adminEmail;
	private static Theme theme;
	private static boolean initialized;
	private static ConfigDao CONFIG_DAO;
	private static PayeeDao PAYEE_DAO;
	private static boolean isModelUnicode;

	private VaricentContext() {
	}

	@Autowired
	void setConfigDao(ConfigDao configDao) {
		CONFIG_DAO = configDao;
	}

	@Autowired
	void setPayeeDao(PayeeDao payeeDao) {
		PAYEE_DAO = payeeDao;
	}

	public static synchronized String getAdminEmail() {
		return adminEmail;
	}

	public static synchronized Theme getTheme() {
		return theme;
	}

	public static synchronized boolean hasTheme() {
		return theme != null;
	}

	public static synchronized void initialize(String adminEmail, Theme theme) {
		VaricentContext.adminEmail = adminEmail;
		VaricentContext.theme = theme;
		initialized = true;
		isModelUnicode = CONFIG_DAO.isModelUnicode();
	}

	public static synchronized boolean initialized() {
		return initialized;
	}

	public static boolean isModelUnicode() {
		return isModelUnicode;
	}

	public static Payee getPayee(String payeeID) {
		return PAYEE_DAO.getPayee(payeeID);
	}
}
