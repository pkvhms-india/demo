package com.varicent.api.compression;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

class GZipResponseWrapper extends HttpServletResponseWrapper {
	private GZipResponseStream gzipStream;
	private ServletOutputStream outputStream;
	private PrintWriter printWriter;

	public GZipResponseWrapper(HttpServletResponse response) throws IOException {
		super(response);
		response.addHeader("Content-Encoding", "gzip");
	}

	public void finish() throws IOException {
		if (this.printWriter != null) {
			this.printWriter.close();
		}

		if (this.outputStream != null) {
			this.outputStream.close();
		}

		if (this.gzipStream != null) {
			this.gzipStream.close();
		}

	}

	@Override
	public void flushBuffer() throws IOException {
		if (this.printWriter != null) {
			this.printWriter.flush();
		}

		if (this.outputStream != null) {
			this.outputStream.flush();
		}

		super.flushBuffer();
	}

	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		if (this.printWriter != null) {
			throw new IllegalStateException("printWriter already defined");
		} else {
			if (this.outputStream == null) {
				this.gzipStream = new GZipResponseStream(this.getResponse().getOutputStream());
				this.outputStream = this.gzipStream;
			}

			return this.outputStream;
		}
	}

	@Override
	public PrintWriter getWriter() throws IOException {
		if (this.outputStream != null) {
			throw new IllegalStateException("printWriter already defined");
		} else {
			if (this.printWriter == null) {
				this.gzipStream = new GZipResponseStream(this.getResponse().getOutputStream());
				this.printWriter = new PrintWriter(
						new OutputStreamWriter(this.gzipStream, this.getResponse().getCharacterEncoding()));
			}

			return this.printWriter;
		}
	}
}
