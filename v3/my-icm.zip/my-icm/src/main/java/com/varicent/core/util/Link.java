package com.varicent.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Link {
	private static final Pattern ALIASED_LINK = Pattern.compile("^(.+)\\|(.+)$");
	private final String address;
	private final String name;
	private final Type type;

	public static Link email(String link) {
		return new Link(link, Link.Type.EMAIL);
	}

	public static Link url(String link) {
		return new Link(link, Link.Type.URL);
	}

	private Link(String link, Type type) {
		Matcher matcher = ALIASED_LINK.matcher(link);
		if (matcher.matches()) {
			this.address = matcher.group(1);
			this.name = matcher.group(2);
		} else {
			this.address = link;
			this.name = link;
		}

		this.type = type;
	}

	public String getAddress() {
		return this.address;
	}

	public String getName() {
		return this.name;
	}

	public boolean isEmail() {
		return this.type == Link.Type.EMAIL;
	}

	public boolean isUrl() {
		return this.type == Link.Type.URL;
	}

	@Override
	public String toString() {
		return this.address;
	}

	private static enum Type {
		EMAIL, URL;
	}
}
