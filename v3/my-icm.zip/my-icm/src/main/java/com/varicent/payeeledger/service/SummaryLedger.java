package com.varicent.payeeledger.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.varicent.payeeledger.dao.PayeeLedgerDao;

@Service
public class SummaryLedger extends AbstractPayeeLedger {
	@Autowired
	protected SummaryLedger(@Qualifier("summaryLedgerDao") PayeeLedgerDao payeeLedgerDao) {
		super(payeeLedgerDao);
	}

	@Override
	public boolean isDetail() {
		return false;
	}

	@Override
	public boolean isSummary() {
		return true;
	}
}
