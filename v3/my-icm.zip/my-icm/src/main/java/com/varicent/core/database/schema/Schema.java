package com.varicent.core.database.schema;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.validator.routines.IntegerValidator;
import org.springframework.util.Assert;

import com.varicent.common.query.domain.Literal;
import com.varicent.core.database.Database;
import com.varicent.core.text.Format;
import com.varicent.core.text.Parse;
import com.varicent.core.util.Validation;

public class Schema {
	public static final int DECIMAL_PRECISION = 28;
	public static final int DECIMAL_SCALE = 14;
	public static final int STRING_LENGTH = 100;
	public static final int STRING_LONG_LENGTH = 1000;
	public static final String KEY_COLUMN_PREFIX = "_";

	public static String format(String value, int dataType) {
		switch (dataType) {
		case 91:
		case 93:
			Date date = Parse.date(value);
			return date == null ? null : Format.asISODate(date);
		default:
			return value;
		}
	}

	public static boolean isValid(String value, int dataType, boolean isInInvariantCulture) {
		switch (dataType) {
		case 3:
			BigDecimal bdValue = Parse.parseDecimal(value, isInInvariantCulture);
			return bdValue == null ? false : bdValue.precision() - bdValue.scale() <= 14;
		case 4:
			return IntegerValidator.getInstance().isValid(value);
		case 12:
			return value.length() <= 1000;
		case 91:
		case 93:
			Date date = Parse.date(value);
			return Validation.isValidDate(date);
		default:
			Assert.state(false);
			return false;
		}
	}

	public static Object parse(String value, int dataType, boolean isInInvariantCulture) {
		switch (dataType) {
		case 3:
			return Parse.parseDecimal(value, isInInvariantCulture);
		case 4:
			return IntegerValidator.getInstance().validate(value);
		case 12:
			return Format.lengthSecureString(value, 1000);
		case 91:
		case 93:
			return Parse.date(value);
		default:
			Assert.state(false);
			return null;
		}
	}

	public static Literal.Type toLiteralType(int dataType, Object value) {
		switch (dataType) {
		case 3:
			return Literal.Type.DECIMAL;
		case 4:
			return Literal.Type.INTEGER;
		case 12:
			return value != null && ((String) value).length() > 100 ? Literal.Type.LONG_STRING : Literal.Type.STRING;
		case 91:
			return Literal.Type.DATE;
		case 93:
			return Literal.Type.DATETIME;
		case 2004:
			return Literal.Type.BLOB;
		default:
			Assert.state(false);
			return Literal.Type.NULL;
		}
	}

	public static boolean isSqlServerDateColumn(ResultSetMetaData metadata, int index) throws SQLException {
		return Database.getSyntax().isSqlServer() && metadata.getColumnType(index) == 12
				&& metadata.getColumnDisplaySize(index) == 10;
	}

	private Schema() {
	}
}
