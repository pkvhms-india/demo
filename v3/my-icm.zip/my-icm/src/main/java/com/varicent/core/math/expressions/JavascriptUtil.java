package com.varicent.core.math.expressions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.Format;
import com.varicent.core.text.Parse;
import com.varicent.core.util.JavascriptFormatInfo;
import com.varicent.reporting.dao.jdbc.DataGridInputRule;
import com.varicent.reporting.domain.Scope;

public class JavascriptUtil {
	private int id;
	private Map<String, JavascriptFormatInfo> columnFormatInfoMap;

	public JavascriptUtil(int id, Map<String, JavascriptFormatInfo> columnFormatInfoMap) {
		this.id = id;
		this.columnFormatInfoMap = columnFormatInfoMap;
	}

	public String getFunctionPrefix() {
		return "function_" + this.id + "_";
	}

	public String getResultPrefix() {
		return "result_" + this.id + "_";
	}

	public String getCountPrefix() {
		return "count_" + this.id + "_";
	}

	public String getTotalPrefix() {
		return "total_" + this.id + "_";
	}

	public String getHeaderIndexJSFunction() {
		String[] parameters = new String[] { "columnName" };
		String functionName = "getHeaderIndex" + this.id;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, parameters));
		sb.append("for(i = 0; i < headers");
		sb.append(this.id);
		sb.append(".length; i++){if (headers");
		sb.append(this.id);
		sb.append("[i] == columnName){ return i; }} return -1;");
		sb.append("}");
		return sb.toString();
	}

	public String getRowValueJSFunction() {
		String[] parameters = new String[] { "columnName", "fmt", "lc", "useNegativeBrackets" };
		String functionName = "getRowValue" + this.id;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, parameters));
		sb.append(
				"var name = columnName; if (columnName.indexOf('.') > -1) { var valueVariable = getComputedRowValue(columnName); if (valueVariable !== undefined)");
		sb.append(" {return valueVariable; } else if (columnName.search('Source.') > -1) ");
		sb.append("{ name = columnName.split('.')[1]; } } var index = getHeaderIndex");
		sb.append(this.id);
		sb.append("(name); if (index < 0) {");
		sb.append(" return 0; } var parsedValue = parseValue(row");
		sb.append(this.id);
		sb.append("[index], index, fmt, lc, useNegativeBrackets); return parsedValue;");
		sb.append("}");
		return sb.toString();
	}

	public String getEvaluationJSFunction(List<AggregateNode> aggregateNodes, int startSuffix, int endSuffix) {
		Set<Integer> aggregates = new HashSet();

		for (AggregateNode node : aggregateNodes) {
			aggregates.add(node.getSuffix());
		}

		String functionName = "evaluationPhase" + this.id + "_" + startSuffix;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, (String[]) null));

		for (int i = startSuffix; i <= endSuffix; ++i) {
			if (!aggregates.contains(i)) {
				sb.append(this.getFunctionPrefix() + i);
				sb.append("();");
			}
		}

		sb.append("}");
		return sb.toString();
	}

	public String getAggregateJSFunction(int startSuffix, int endSuffix) {
		String functionName = "aggregatePhase" + this.id + "_" + startSuffix;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, (String[]) null));

		for (int i = startSuffix; i <= endSuffix; ++i) {
			sb.append(this.getFunctionPrefix() + i);
			sb.append("();");
		}

		sb.append("}");
		return sb.toString();
	}

	public String getCommonVariableDeclerations() {
		StringBuilder sb = new StringBuilder();
		sb.append("var headers");
		sb.append(this.id);
		sb.append(";");
		sb.append("var row");
		sb.append(this.id);
		sb.append(";");
		return sb.toString();
	}

	public String getVariableDeclarations(int startSuffix, int endSuffix, ArrayList<Integer> groupAvgSuffix) {
		StringBuilder sb = new StringBuilder();

		for (int i = startSuffix; i <= endSuffix; ++i) {
			sb.append("var ");
			sb.append(this.getResultPrefix() + i);
			sb.append(";");
		}

		for (Integer element : groupAvgSuffix) {
			sb.append("var ");
			sb.append(this.getCountPrefix() + element);
			sb.append(";");
			sb.append("var ");
			sb.append(this.getTotalPrefix() + element);
			sb.append(";");
		}

		return sb.toString();
	}

	public String getVariable(String name) {
		String format = "";
		String locale = "";
		String useNegativeBrackets = "";
		if (this.columnFormatInfoMap.containsKey(name)) {
			format = this.columnFormatInfoMap.get(name).getFormat();
			locale = this.columnFormatInfoMap.get(name).getLocale();
			useNegativeBrackets = Boolean.toString(this.columnFormatInfoMap.get(name).isUseNegativeBrackets());
		}

		StringBuilder sb = new StringBuilder();
		sb.append("getRowValue");
		sb.append(this.id);
		sb.append(" (");
		sb.append("'");
		sb.append(name.replaceAll("'", "\u0092"));
		sb.append("','");
		sb.append(format);
		sb.append("','");
		sb.append(locale);
		sb.append("','");
		sb.append(useNegativeBrackets);
		sb.append("')");
		return sb.toString();
	}

	public String getValidateRowInputRuleFunction(List<DataGridInputRule> inputRules, Scope scope, String source,
			Map<String, String> columnNameDisplayNameMap, Boolean isVertical) throws ReportOverLimitException {
		StringBuilder sb = new StringBuilder();
		String functionName = "validateRow" + this.id;
		String[] parameters = new String[] { "currentRow" };
		sb.append(getFunctionSigniture(functionName, parameters));
		if (inputRules != null && inputRules.size() > 0) {
			if (isVertical) {
				this.appendEditedVerticalInputRowCondition(sb);
				sb.append("if (skipRow) {return;}");
				sb.append("populateHeaders");
				sb.append(this.id);
				sb.append("();");
				sb.append("row");
				sb.append(this.id);
				sb.append("=new Array();");
				sb.append("populateVerticalRow(row");
				sb.append(this.id);
				sb.append(", jQuery('#");
				sb.append(this.id);
				sb.append("'));");
			} else {
				this.appendEditedRowCondition(sb);
				sb.append("if (skipRow) {return;}");
				sb.append("populateHeaders");
				sb.append(this.id);
				sb.append("();");
				sb.append("row");
				sb.append(this.id);
				sb.append("= new Array();");
				sb.append("populateCurrentRow(row");
				sb.append(this.id);
				sb.append(", currentRow);");
			}

			sb.append("var invalidColumns = new Array();var invalidMessages = new Array(); var i = 0;");

			for (DataGridInputRule inputRule : inputRules) {
				sb.append(this.getInputRuleValidationStatement(inputRule, scope, source, columnNameDisplayNameMap));
			}

			if (isVertical) {
				sb.append("setCellStyle(currentGrid, invalidColumns, invalidMessages);");
			} else {
				sb.append("setCellStyle(currentRow, invalidColumns, invalidMessages);");
			}
		}

		sb.append("}");
		return sb.toString();
	}

	String getInputRuleValidationStatement(DataGridInputRule inputRule, Scope scope, String source,
			Map<String, String> columnNameDisplayNameMap) throws ReportOverLimitException {
		StringBuilder sb = new StringBuilder();
		String lhsColumnName = scope.getSourceColumnAlias(source, inputRule.getColumn());
		String lhsDisplayName = columnNameDisplayNameMap.get(lhsColumnName);
		String format = "";
		String locale = "";
		String useNegativeBrackets = "";
		if (this.columnFormatInfoMap.containsKey(lhsDisplayName)) {
			format = this.columnFormatInfoMap.get(lhsDisplayName).getFormat();
			locale = this.columnFormatInfoMap.get(lhsDisplayName).getLocale();
			useNegativeBrackets = Boolean
					.toString(this.columnFormatInfoMap.get(lhsDisplayName).isUseNegativeBrackets());
		}

		String parseFunctionCall = " if(!(getRowValue" + this.id + " ('" + lhsDisplayName + "','" + format + "','"
				+ locale + "','" + useNegativeBrackets + "')";
		sb.append(parseFunctionCall);
		sb.append(DataGridInputRule.Operator.operation(inputRule.getOperator().getSymbol()));
		String rhsValue = null;
		String sourcePfx = source + ".";
		String displayValue = null;
		String rhsDisplayName = null;
		if (inputRule.getOperator().hasRHS()) {
			switch (inputRule.getType()) {
			case FIELD:
				String rhsColumnName = inputRule.getValue().replace(sourcePfx, "");
				rhsDisplayName = columnNameDisplayNameMap.get(rhsColumnName);
				format = "";
				locale = "";
				useNegativeBrackets = "";
				if (this.columnFormatInfoMap.containsKey(rhsDisplayName)) {
					format = this.columnFormatInfoMap.get(rhsDisplayName).getFormat();
					locale = this.columnFormatInfoMap.get(rhsDisplayName).getLocale();
					useNegativeBrackets = Boolean
							.toString(this.columnFormatInfoMap.get(rhsDisplayName).isUseNegativeBrackets());
				}

				sb.append("getRowValue");
				sb.append(this.id);
				sb.append(" (");
				sb.append("'");
				sb.append(rhsDisplayName);
				sb.append("','");
				sb.append(format);
				sb.append("','");
				sb.append(locale);
				sb.append("','");
				sb.append(useNegativeBrackets);
				sb.append("')");
				displayValue = rhsDisplayName;
				break;
			case STRING:
				rhsValue = inputRule.getValue();
				sb.append("'");
				sb.append(rhsValue);
				sb.append("'");
				displayValue = "\"" + rhsValue + "\"";
				break;
			case NUMERIC:
				rhsValue = inputRule.getValue();
				sb.append(rhsValue);
				displayValue = "\"" + rhsValue + "\"";
				break;
			case DATE:
				rhsValue = inputRule.getValue();
				Date date = Parse.date(rhsValue);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				rhsValue = Format.asShortDate(date);
				sb.append("parseDateValue(");
				sb.append("new Date('");
				sb.append(cal.get(1));
				sb.append("', '");
				sb.append(cal.get(2));
				sb.append("', '");
				sb.append(cal.get(5));
				sb.append("').getTime()");
				sb.append(")");
				displayValue = "\"" + rhsValue + "\"";
				break;
			case SCALAR:
				String scalarName = inputRule.getValue().replace("_Local_", "");
				if (scope.getType(scalarName) == Scope.Type.DATE) {
					rhsValue = Format.asShortDate(scope.getDateTime(scalarName));
					Date dateScalar = Parse.date(rhsValue);
					if (dateScalar == null) {
						sb.append("\"\"");
					} else {
						Calendar calScalar = Calendar.getInstance();
						calScalar.setTime(dateScalar);
						sb.append("parseDateValue(");
						sb.append("new Date('");
						sb.append(calScalar.get(1));
						sb.append("', '");
						sb.append(calScalar.get(2));
						sb.append("', '");
						sb.append(calScalar.get(5));
						sb.append("').getTime()");
						sb.append(")");
					}
				} else if (scope.getType(scalarName) == Scope.Type.DECIMAL) {
					rhsValue = scope.isNull(scalarName) ? "null" : scope.getDecimal(scalarName).toString();
					sb.append(rhsValue);
				} else {
					rhsValue = scope.isNull(scalarName) ? "" : scope.getObject(scalarName).toString();
					sb.append("'");
					sb.append(rhsValue);
					sb.append("'");
				}

				displayValue = "\"" + rhsValue + "\"";
			}
		}

		sb.append(")) {invalidColumns[i] = getHeaderIndex");
		sb.append(this.id);
		sb.append("('");
		sb.append(lhsDisplayName);
		sb.append("');invalidMessages[i] = ");
		sb.append("jQuery('#InputRuleValidationFailedMsgID').val() + ");
		sb.append("' ");
		sb.append(lhsDisplayName);
		sb.append(" ");
		sb.append(inputRule.getOperator().toString());
		if (inputRule.getOperator().hasRHS()) {
			sb.append(" ");
			sb.append(displayValue);
		}

		sb.append("';i++;");
		if (rhsDisplayName != null) {
			sb.append("invalidColumns[i] = getHeaderIndex");
			sb.append(this.id);
			sb.append("('");
			sb.append(rhsDisplayName);
			sb.append("');invalidMessages[i] = ");
			sb.append("jQuery('#InputRuleValidationFailedMsgID').val() + ");
			sb.append("' ");
			sb.append(lhsDisplayName);
			sb.append(" ");
			sb.append(inputRule.getOperator().toString());
			if (inputRule.getOperator().hasRHS()) {
				sb.append(" ");
				sb.append(displayValue);
			}

			sb.append("';i++;");
		}

		sb.append("}");
		return sb.toString();
	}

	public static String getParseValueFunction() {
		return "function parseValue(text, index, fmt, lc, useNegativeBrackets) {\tif (!text && text != \"\")\t\treturn text;\tif (columnTypes[index] == \"NUMERIC\") {\t\tvar format = fmt;\t\tif (useNegativeBrackets == 'true') format = \"(\" + fmt + \")\";\t\tvar parsedFloatValue = jQuery.parseNumber(text, { format: fmt, locale: lc });\t\tif (isNaN(text) && parsedFloatValue == 0){\t\t\tif((lc!=\"us\" && lc!=\"en\") && text.indexOf(\",\") > 0){\t\t\t\treturn parsedFloatValue;\t\t\t}\t\t\treturn undefined;\t\t}\t\tif (!isNaN(parsedFloatValue) && parsedFloatValue + 0 == parsedFloatValue) {\t\t\treturn parsedFloatValue + 0;\t\t}\t\treturn undefined;\t} else if (columnTypes[index] == \"DATE\") {\t\treturn parseDateValue(text);\t}\treturn text;}";
	}

	public static String getParseDateValueFunction() {
		return "function parseDateValue(text) {\tvar millisecondsPerDay = 24*60*60*1000;\tif (text.length > 0 && !isNaN(text))\t\treturn Math.round(text / millisecondsPerDay);\treturn text;}";
	}

	public String getResetFunction(int startSuffix, int endSuffix, ArrayList<Integer> groupAvgSuffix) {
		String functionName = "resetVariables" + this.id + "_" + startSuffix;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, (String[]) null));

		for (int i = startSuffix; i <= endSuffix; ++i) {
			sb.append(this.getResultPrefix() + i);
			sb.append(" = undefined;");
		}

		for (Integer element : groupAvgSuffix) {
			sb.append(this.getCountPrefix() + element);
			sb.append(" = undefined;");
			sb.append(this.getTotalPrefix() + element);
			sb.append(" = undefined;");
		}

		sb.append("}");
		return sb.toString();
	}

	public String getPopulateHeadersFunction(boolean isVertical) {
		String functionName = "populateHeaders" + this.id;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, (String[]) null));
		sb.append("headers");
		sb.append(this.id);
		sb.append(" = new Array();columnTypes=new Array();");
		sb.append(String.format("jQuery(\"table[id='%s'][class!='layoutTable']", this.id));
		if (!isVertical) {
			sb.append(" .DGHeaderRow th\").each(function(index){headers");
			sb.append(this.id);
			sb.append("[index] = jQuery(this).find('div:first-child').text();");
			sb.append("columnTypes[index] = jQuery(this).find('span').first().text();});");
			sb.append("}");
		} else {
			sb.append(" th.DGHeaderVertical\").each(function(index){headers");
			sb.append(this.id);
			sb.append("[index] = jQuery(this).find('div:first-child').text();");
			sb.append("columnTypes[index] = jQuery(this).find('span').first().text();});");
			sb.append("}");
		}

		return sb.toString();
	}

	public static String getPopulateCurrentRowFunction() {
		return "function populateCurrentRow(currentRowArr, currentRow) {\tvar ieVersion = getIEVersionNumber();\tvar isIE8 = ieVersion === 8;\tcurrentRow.find('td').each(function(colIdx) {\t\tvar cellChildren = jQuery(this).children(),\t\t\tlastChild = cellChildren.last(),\t\t\tfirstChild = cellChildren.first();\t\tif( lastChild.hasClass('outerTextBoxContainer')) { lastChild  =  lastChild.children().children(); }\t\tif(firstChild.hasClass('outerTextBoxContainer')) { firstChild = firstChild.children().children(); }\t\tif (lastChild.attr('class') !== undefined && lastChild.attr('class').indexOf('datepickerInput') === 0) {\t\t\tif (isIE8) {\t\t\t\tcurrentRowArr[colIdx] = lastChild.datepicker(\"getDate\");\t\t\t} else {\t\t\t\tcurrentRowArr[colIdx] = jQuery.datepicker.parseDate(jQuery(\"#clientLocale\").val().toLowerCase(), lastChild.val());\t\t\t}\t\t\tif (currentRowArr[colIdx] == null) {\t\t\t\tcurrentRowArr[colIdx] = '';\t\t\t} else {\t\t\t\tcurrentRowArr[colIdx] = currentRowArr[colIdx].getTime();\t\t\t}\t\t} else if (jQuery(this).find('input').size() == 1) {\t\t\tcurrentRowArr[colIdx] = jQuery(this).find('input').val()\t\t} else if (firstChild.is('div') && lastChild.is('span')) {\t\t\tcurrentRowArr[colIdx] = lastChild.children().first().val();\t\t} else if (firstChild.is('div')) {\t\t\tcurrentRowArr[colIdx] = firstChild.text();\t\t} else if (firstChild.is('span')) {\t\t\tcurrentRowArr[colIdx] = firstChild.children().first().val();\t\t} else if (cellChildren.length==0) {\t\t\tif(ieVersion > 0)\t\t\t\tif(columnTypes[colIdx] == \"DATE\")\t\t\t\t\tcurrentRowArr[colIdx] = getCellDateValue(firstChild.context.innerText);\t\t\t\telse if(columnTypes[colIdx] == \"NUMERIC\" && $(this).attributes['sortdata'] !== undefined)\t\t\t\t\tcurrentRowArr[colIdx] = $(this).attributes['sortdata'].value;\t\t\t\telse\t\t\t\t\tcurrentRowArr[colIdx] = firstChild.context.innerText;\t\t\telse\t\t\t\tif(columnTypes[colIdx] == \"DATE\")\t\t\t\t\tcurrentRowArr[colIdx] = getCellDateValue($(this).textContent);\t\t\t\telse if(columnTypes[colIdx] == \"NUMERIC\" && firstChild.attr('sortdata') !== undefined)\t\t\t\t\tcurrentRowArr[colIdx] = $(this).attr('sortData');\t\t\t\telse\t\t\t\t\tcurrentRowArr[colIdx] = $(this).textContent;\t\t} else {\t\t\tcurrentRowArr[colIdx] = firstChild.val();\t\t}\t});}";
	}

	public static String getPopulateVerticalRowFunction() {
		return "function populateVerticalRow(currentRowArr, currentTable) {\tvar ieVersion = getIEVersionNumber();\tcurrentTable.find('td').each(function(colIdx) {\t\tvar cellChildren = jQuery(this).children(),\t\t\tlastChild = cellChildren.last(),\t\t\tfirstChild = cellChildren.first();\t\tif( lastChild.hasClass('outerTextBoxContainer')) { lastChild  =  lastChild.children().children(); }\t\tif(firstChild.hasClass('outerTextBoxContainer')) { firstChild = firstChild.children().children(); }\t\tif (lastChild.attr('class') !== undefined && lastChild.attr('class').indexOf('datepickerInput') === 0) {\t\t\tcurrentRowArr[colIdx] = lastChild.datepicker(\"getDate\");\t\t\tif (currentRowArr[colIdx] == null) {\t\t\t\tcurrentRowArr[colIdx] = '';\t\t\t} else {\t\t\t\tcurrentRowArr[colIdx] = currentRowArr[colIdx].getTime();\t\t\t}\t\t} else if (lastChild.is('input')) {\t\t\tcurrentRowArr[colIdx] = lastChild.val();\t\t} else if (firstChild.is('div')) {\t\t\tcurrentRowArr[colIdx] = firstChild.text();\t\t} else if (firstChild.is('span')) {\t\t\tcurrentRowArr[colIdx] = firstChild.children().first().val();\t\t} else if (cellChildren.length==0) {\t\t\tif(ieVersion > 0)\t\t\t\tif(columnTypes[colIdx] == \"DATE\")\t\t\t\t\tcurrentRowArr[colIdx] = getCellDateValue(firstChild.context.innerText);\t\t\t\telse\t\t\t\t\tcurrentRowArr[colIdx] = firstChild.context.innerText;\t\t\telse\t\t\t\tif(columnTypes[colIdx] == \"DATE\")\t\t\t\t\tcurrentRowArr[colIdx] = getCellDateValue($(this).textContent);\t\t\t\telse\t\t\t\t\tcurrentRowArr[colIdx] = $(this).textContent;\t\t} else {\t\t\tcurrentRowArr[colIdx] = firstChild.val();\t\t}\t});}";
	}

	public static String getGetCellDateValueFunction() {
		return "function getCellDateValue(cellValue) {\tcellValue = jQuery.trim(cellValue);\tif(cellValue == '') return '';\tvar dateValue = jQuery.datepicker.parseDate(jQuery(\"#clientLocale\").val().toLowerCase(), cellValue);\tif(dateValue == null)\t\treturn '';\telse\t\treturn dateValue.getTime();}";
	}

	public String getComputedColumnEvaluationFunctionName(int order) {
		return "evaluateComputedColumn" + this.id + "_" + order;
	}

	public String getComputedColumnEvaluationFunction(int startSuffix, int endSuffix, JavascriptFormatInfo formatInfo,
			String columnName, int order) {
		String functionName = this.getComputedColumnEvaluationFunctionName(order);
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName));
		sb.append("resetVariables");
		sb.append(this.id);
		sb.append("_");
		sb.append(startSuffix);
		sb.append("();");
		sb.append("populateHeaders");
		sb.append(this.id);
		sb.append("();");
		sb.append("jQuery('#");
		sb.append(this.id);
		sb.append(" ");
		sb.append("tr').each(function(index){");
		this.appendSkipComputedAndSectionRowCondition(sb);
		this.appendEditedInputRowCondition(sb);
		sb.append("if(index>0 && !skipRow){row");
		sb.append(this.id);
		sb.append("=new Array();populateCurrentRow(row");
		sb.append(this.id);
		sb.append(", jQuery(this));");
		sb.append("aggregatePhase");
		sb.append(this.id);
		sb.append("_");
		sb.append(startSuffix);
		sb.append("();}}});");
		sb.append("jQuery('#");
		sb.append(this.id);
		sb.append(" ");
		sb.append("tr').each(function(index){");
		this.appendSkipComputedAndSectionRowCondition(sb);
		this.appendEditedInputRowCondition(sb);
		sb.append("row");
		sb.append(this.id);
		sb.append("=new Array();populateCurrentRow(row");
		sb.append(this.id);
		sb.append(", jQuery(this));");
		sb.append("evaluationPhase");
		sb.append(this.id);
		sb.append("_");
		sb.append(startSuffix);
		sb.append("();jQuery(this).find('td').eq(" + order + ").html(getCellHtml(");
		sb.append(this.getResultPrefix() + endSuffix);
		sb.append(",'");
		sb.append(formatInfo.getFormat());
		sb.append("','");
		sb.append(formatInfo.getLocale());
		sb.append("',");
		if (formatInfo.isUseNegativeBrackets()) {
			sb.append("'true'");
		} else {
			sb.append("'false'");
		}

		sb.append(", jQuery(this).find('td').eq(" + order + ").find('a')))}});");
		sb.append("}");
		return sb.toString();
	}

	public String getComputedRowEvaluationFunction(int[] startSuffices, int[] endSuffices, String[] columnNames,
			JavascriptFormatInfo[] formattingInfo) {
		String functionName = "evaluateComputedRow" + this.id;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName));

		for (int element : startSuffices) {
			sb.append("resetVariables");
			sb.append(this.id);
			sb.append("_");
			sb.append(element);
			sb.append("();");
		}

		sb.append("populateHeaders");
		sb.append(this.id);
		sb.append("();");
		sb.append("jQuery('#");
		sb.append(this.id);
		sb.append(" ");
		sb.append("tr').each(function(index){");
		this.appendSkipComputedAndSectionRowCondition(sb);
		this.appendEditedInputRowCondition(sb);
		sb.append("if(index>0 && !skipRow){row");
		sb.append(this.id);
		sb.append("=new Array();populateCurrentRow(row");
		sb.append(this.id);
		sb.append(", jQuery(this));");

		for (int element : startSuffices) {
			sb.append("aggregatePhase");
			sb.append(this.id);
			sb.append("_");
			sb.append(element);
			sb.append("();");
		}

		sb.append("}}});");

		for (int i = 0; i < endSuffices.length; ++i) {
			sb.append("jQuery('#");
			sb.append(this.id);
			sb.append(" ");
			sb.append("tr').last().find('td').each(function(index){if (index == getHeaderIndex");
			sb.append(this.id);
			sb.append("('");
			sb.append(columnNames[i].replaceAll("'", "\u0092"));
			sb.append("')){jQuery(this).html(getCellHtml(");
			sb.append(this.getResultPrefix() + endSuffices[i]);
			sb.append(",'");
			sb.append(formattingInfo[i].getFormat());
			sb.append("','");
			sb.append(formattingInfo[i].getLocale());
			sb.append("',");
			if (formattingInfo[i].isUseNegativeBrackets()) {
				sb.append("'true'");
			} else {
				sb.append("'false'");
			}

			sb.append(", jQuery(this).find('td').last().find('a')))}});");
		}

		sb.append("}");
		return sb.toString();
	}

	public static String getSetCellStyleFunction() {
		return "function setCellStyle(currentRow, invalidColumns, invalidMessages) {\tcurrentRow.find('td').each(function (colIdx) {\t\tvar lastChild = jQuery(this).children().last();\t\tif(lastChild.hasClass('outerTextBoxContainer')) { lastChild = lastChild.children().children(); }\t\tif (!(lastChild.is('div'))) {\t\t\tvar hasError = false,\t\t\t\tmessage, j, jLen;\t\t\tfor (j = 0, jLen = invalidColumns.length; j < jLen; j++) {\t\t\t\tif (invalidColumns[j] == colIdx) {\t\t\t\t\thasError = true;\t\t\t\t\tmessage = invalidMessages[j];\t\t\t\t\tbreak;\t\t\t\t}\t\t\t}\t\t\tif (hasError) {\t\t\t\tlastChild.addClass(\"error-input\")\t\t\t\t\t.css({ \"font-weight\": \"bold\", \"color\": \"#C9000F\" })\t\t\t\t\t.attr(\"title\", message);\t\t\t} else {\t\t\t\tlastChild.removeClass(\"error-input\")\t\t\t\t\t.css({ \"font-weight\": \"\", \"color\": \"\" })\t\t\t\t\t.removeAttr(\"title\");\t\t\t}\t\t}\t});}";
	}

	public static String getEvaluateFunction(ArrayList<Integer> datagridIDs) {
		StringBuilder sb = new StringBuilder();
		sb.append("function");
		sb.append(" evaluate(datagridId){");

		for (Integer id : datagridIDs) {
			sb.append("if (datagridId == ");
			sb.append(id);
			sb.append(") {");
			sb.append("evaluate");
			sb.append(id);
			sb.append("();");
			sb.append("return;");
			sb.append("}");
		}

		sb.append("}");
		return sb.toString();
	}

	public static String getValidateFunction(ArrayList<Integer> datagridIDs) {
		StringBuilder js = new StringBuilder();
		js.append("function validateOnSubmit(){ canSubmit = true;");
		js.append("var dataGrid = null;");

		for (Integer id : datagridIDs) {
			js.append(String.format("dataGrid = jQuery(\"table[id='%s'][class!='layoutTable']\");", id.toString()));
			js.append("dataGrid.find('tr').each(function(index){");
			js.append(String.format("\tvalidateRow(%s, jQuery(this));", id.toString()));
			js.append("});");
		}

		js.append("var invalidFields = jQuery('.error-input').size(); if (invalidFields > 0) { ");
		js.append("jQuery('.error').append('<br />' + ");
		js.append("jQuery('#InputRuleValidationErrorSubmitID').val());");
		js.append("canSubmit = false;");
		js.append("return; }");

		for (Integer id : datagridIDs) {
			js.append(String.format("evaluate%s();", id.toString()));
		}

		for (Integer id : datagridIDs) {
			js.append(String.format("validate%s();", id.toString()));
		}

		js.append("}");
		return js.toString();
	}

	public static String getCellHtmlFunction() {
		return "function getCellHtml(rawValue, fmt, lc, useNegativeBrackets, link) {\tvar displayValue;\tif (rawValue < 0 && useNegativeBrackets === 'true') {\t\tvar absoluteValue = Math.abs(rawValue),\t\t\tnegativeformat = \"(\" + fmt + \")\";\t\tdisplayValue = jQuery.formatNumber(absoluteValue, {format: negativeformat, locale: lc});\t} else { \t\tdisplayValue = jQuery.formatNumber(rawValue, {format: fmt, locale: lc});\t\tif (displayValue.indexOf('NaN') >= 0) displayValue = rawValue;\t}\tif (link && link.attr('href')) {\t\tvar href = link.attr('href'),\t\t\ttarget = link.attr('target');\t\treturn '<div style=\"display:none\"><span>' + rawValue+'</span></div><a href=\"' + href + '\" target=\"' + target + '\">' + displayValue + '</a>';\t}\treturn '<div style=\"display:none\"><span>' + rawValue + '</span></div>' + displayValue;}";
	}

	public static String getFunctionSigniture(String functionName) {
		return getFunctionSigniture(functionName, (String[]) null);
	}

	public static String getFunctionSigniture(String functionName, String[] parameters) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(functionName);
		sb.append("(");
		if (parameters != null && parameters.length > 0) {
			for (int i = 0; i < parameters.length; ++i) {
				if (i > 0) {
					sb.append(", ");
				}

				sb.append(parameters[i]);
			}
		}

		sb.append(") {");
		return sb.toString();
	}

	public static String getComputedRowValue(HashMap<String, String> computedRowResultNameMap) {
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture("getComputedRowValue", new String[] { "columnName" }));

		for (String computedRow : computedRowResultNameMap.keySet()) {
			sb.append("if(columnName == '");
			sb.append(computedRow.replaceAll("'", "\u0092"));
			sb.append("') {return ");
			sb.append(computedRowResultNameMap.get(computedRow));
			sb.append(";}");
		}

		sb.append("return undefined;}");
		return sb.toString();
	}

	public static String getValidateRowFunction(ArrayList<Integer> datagridIDs) {
		String[] parameters = new String[] { "datagridId", "currentRow" };
		String functionName = "validateRow";
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName, parameters));

		for (Integer id : datagridIDs) {
			sb.append(String.format("if (datagridId == %s) {", id.toString()));
			sb.append(String.format("validateRow%s(currentRow);", id.toString()));
			sb.append("return;");
			sb.append("}");
		}

		sb.append("}");
		return sb.toString();
	}

	public String getValidationFunction(int[] startSuffices, int[] endSuffices, boolean isVertical,
			String[] errorMessages) {
		String functionName = "validateRules" + this.id;
		StringBuilder sb = new StringBuilder();
		sb.append(getFunctionSigniture(functionName));

		for (int element : startSuffices) {
			sb.append("resetVariables");
			sb.append(this.id);
			sb.append("_");
			sb.append(element);
			sb.append("();");
		}

		sb.append("populateHeaders");
		sb.append(this.id);
		sb.append("();");
		if (isVertical) {
			this.appendEditedVerticalInputRowCondition(sb);
			sb.append("if (!skipRow){");
			sb.append("row");
			sb.append(this.id);
			sb.append("=new Array();");
			sb.append("populateVerticalRow(row");
			sb.append(this.id);
			sb.append(", jQuery('#");
			sb.append(this.id);
			sb.append("'));");

			for (int element : startSuffices) {
				sb.append("aggregatePhase");
				sb.append(this.id);
				sb.append("_");
				sb.append(element);
				sb.append("();");
			}

			sb.append("}");
		} else {
			sb.append(String.format("var dataGrid = jQuery(\"table[id='%s'][class!='layoutTable']\");", this.id));
			sb.append("dataGrid.find('tr').each(function(index){");
			this.appendSkipComputedAndSectionRowCondition(sb);
			this.appendEditedInputRowCondition(sb);
			sb.append("if(index>0 && !skipRow){row");
			sb.append(this.id);
			sb.append("=new Array();populateCurrentRow(row");
			sb.append(this.id);
			sb.append(", jQuery(this));");

			for (int element : startSuffices) {
				sb.append("aggregatePhase");
				sb.append(this.id);
				sb.append("_");
				sb.append(element);
				sb.append("();");
			}

			sb.append("}}});");
		}

		for (int i = 0; i < endSuffices.length; ++i) {
			if (i == 0) {
				sb.append("if(");
			} else {
				sb.append("else if(");
			}

			sb.append(this.getResultPrefix() + endSuffices[i]);
			sb.append(" == 0 ) { jQuery('.error').append('<br />");
			sb.append(errorMessages[i].replaceAll("\\n", "<br />"));
			sb.append("');");
			sb.append("canSubmit = false;");
			sb.append("}");
		}

		sb.append("}");
		return sb.toString();
	}

	private void appendEditedInputRowCondition(StringBuilder sb) {
		sb.append("var skipRow = false; if(jQuery(this).attr('class').search('InputRow') >= 0) { ");
		sb.append("if (jQuery(this).find('select[name^=\"Edited_IR_\"]').first().attr('name') === undefined &&");
		sb.append(" jQuery(this).find('textarea[name^=\"Edited_IR_\"]').first().attr('name') === undefined &&");
		sb.append(
				" jQuery(this).find('input[name^=\"Edited_IR_\"]').first().attr('name') === undefined){ skipRow = true;}}");
	}

	private void appendEditedVerticalInputRowCondition(StringBuilder sb) {
		sb.append("var currentGrid = jQuery('#");
		sb.append(this.id);
		sb.append("');");
		sb.append("var skipRow = false; if(currentGrid.find('tr.VerticalInputHeader').length >= 0) { ");
		sb.append("if (currentGrid.find('select[name^=\"Edited_IR_\"]').first().attr('name') === undefined &&");
		sb.append(" currentGrid.find('textarea[name^=\"Edited_IR_\"]').first().attr('name') === undefined &&");
		sb.append(
				" currentGrid.find('input[name^=\"Edited_IR_\"]').first().attr('name') === undefined){ skipRow = true;}}");
	}

	private void appendEditedRowCondition(StringBuilder sb) {
		sb.append("var skipRow = false;");
		sb.append("if (currentRow.find('select[name^=\"Edited_\"]').first().attr('name') === undefined &&");
		sb.append(" currentRow.find('textarea[name^=\"Edited_\"]').first().attr('name') === undefined &&");
		sb.append(" currentRow.find('input[name^=\"Edited_\"]').first().attr('name') === undefined){ skipRow = true;}");
	}

	private void appendSkipComputedAndSectionRowCondition(StringBuilder sb) {
		sb.append(
				"if((jQuery(this).attr('id') === undefined || jQuery(this).attr('id').search('computed_row_') == -1) &&(jQuery(this).attr('class') === undefined || jQuery(this).attr('class').search('_Section') == -1)) {");
	}
}
