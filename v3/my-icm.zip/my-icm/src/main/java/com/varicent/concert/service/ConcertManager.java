package com.varicent.concert.service;

import java.util.List;

import com.varicent.common.payee.domain.Payee;

public interface ConcertManager {
	Payee getPayeeByEmail(String var1);

	List<Integer> getTabIds(String var1);

	boolean isViewableReport(int var1, String var2);
}
