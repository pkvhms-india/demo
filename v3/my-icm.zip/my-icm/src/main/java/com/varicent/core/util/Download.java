package com.varicent.core.util;

import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.varicent.common.config.dao.ConfigDao;
import com.varicent.domain.BrowserInfo;

@Component
public class Download {
	private static final Download INSTANCE = new Download();
	private static ConfigDao CONFIG_DAO;

	private Download() {
	}

	@Autowired
	void setConfigDao(ConfigDao configDao) {
		CONFIG_DAO = configDao;
	}

	public static void asAttachment(HttpServletResponse response, HttpServletRequest request, FileType type,
			String saveAs) {
		setContentType(response, type);
		setHeader(response, request, true, saveAs);
	}

	public static void openInBrowser(HttpServletResponse response, HttpServletRequest request, FileType type,
			String saveAs) {
		setContentType(response, type);
		setHeader(response, request, false, saveAs);
	}

	static void setContentType(HttpServletResponse response, FileType type) {
		String contentType;
		switch (type) {
		case PDF:
			contentType = "application/pdf";
			break;
		case ZIP:
			contentType = "application/zip";
			break;
		case EXCEL:
			contentType = "application/vnd.ms-excel";
			break;
		case EXCEL2007:
			contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			break;
		default:
			contentType = "application/download";
		}

		response.setContentType(contentType);
	}

	static void setHeader(HttpServletResponse response, HttpServletRequest request, boolean attach, String filename) {
		BrowserInfo info = HeaderUtil.getBrowserInfo(request);
		String contentDisposition = getContentDispositionHeader(filename, info, attach);
		response.setHeader("Content-Disposition", contentDisposition);
	}

	static String getBrowserFriendlyName(String filename) {
		return filename.replace("–", "-");
	}

	static String getContentDispositionHeader(String filename, BrowserInfo browserInfo, boolean attach) {
		String contentDisposition;
		if (attach) {
			contentDisposition = "attachment; ";
		} else {
			contentDisposition = "inline; ";
		}

		try {
			if (browserInfo != null && CONFIG_DAO.isModelUnicode()) {
				BrowserInfo.Type type = browserInfo.getType();
				String version = browserInfo.getVersion();
				if (type != BrowserInfo.Type.FireFox && type != BrowserInfo.Type.Chrome) {
					if (type == BrowserInfo.Type.IE) {
						if ("9.0".equals(version)) {
							contentDisposition = contentDisposition + "filename*=UTF-8''"
									+ URLEncoder.encode(getBrowserFriendlyName(filename), "UTF-8");
						} else {
							contentDisposition = contentDisposition + "filename=\""
									+ URLEncoder.encode(getBrowserFriendlyName(filename), "UTF-8") + "\"";
						}
					} else if (type == BrowserInfo.Type.Safari) {
						contentDisposition = contentDisposition + "filename=\""
								+ URLEncoder.encode(getBrowserFriendlyName(filename), "UTF-8") + "\"";
					} else {
						contentDisposition = contentDisposition + "filename=\""
								+ URLEncoder.encode(getBrowserFriendlyName(filename), "UTF-8") + "\"";
					}
				} else {
					contentDisposition = contentDisposition + "filename*=UTF-8''"
							+ URLEncoder.encode(filename, "UTF-8");
				}
			} else {
				contentDisposition = contentDisposition + "filename=\"" + filename + "\"";
			}
		} catch (Exception var6) {
			contentDisposition = contentDisposition + "filename=\"" + getBrowserFriendlyName(filename) + "\"";
		}

		return contentDisposition;
	}

	public static enum FileType {
		GENERAL, PDF, ZIP, EXCEL, EXCEL2007;
	}
}
