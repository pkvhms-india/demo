package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeAnd extends PolyNode implements EvaluateNode {
	public NodeAnd(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		for (EvaluateNode arg : this.args) {
			if (arg.evaluate().compareTo(BigDecimal.ZERO) == 0) {
				return BigDecimal.ZERO;
			}
		}

		return BigDecimal.ONE;
	}

	@Override
	public void reset() {
		for (EvaluateNode arg : this.args) {
			arg.reset();
		}

	}

	@Override
	public String getJSMathFunctionName() {
		return "and";
	}
}
