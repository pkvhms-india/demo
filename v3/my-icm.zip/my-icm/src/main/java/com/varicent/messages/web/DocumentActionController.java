package com.varicent.messages.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.varicent.common.attachment.domain.Attachment;
import com.varicent.common.attachment.service.AttachmentManager;
import com.varicent.core.util.Download;

@Controller
public class DocumentActionController {
	private static final String VIEW = "redirect:/documents/index.html";
	private final AttachmentManager attachmentManager;

	@Autowired
	public DocumentActionController(AttachmentManager attachmentManager) {
		this.attachmentManager = attachmentManager;
	}

	@RequestMapping({ "/documents/download.do" })
	public String download(@RequestParam("id") String fileId, HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		if (fileId.equals("0")) {
			request.getSession().setAttribute("msgKey", "error.documents.no.document");
		} else {
			for (Attachment attachment : this.attachmentManager.getAttachments()) {
				if (attachment.getFileId().equals(fileId)) {
					Download.asAttachment(response, request, Download.FileType.GENERAL, attachment.getName());
					this.attachmentManager.streamAttachment(attachment.getTable(), attachment.getIDColumn(), fileId,
							attachment.getName(), response.getOutputStream());
					return null;
				}
			}

			request.getSession().setAttribute("msgKey", "error.documents.no.access.or.no.document");
		}

		return "redirect:/documents/index.html";
	}
}
