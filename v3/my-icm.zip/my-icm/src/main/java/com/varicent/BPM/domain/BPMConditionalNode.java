package com.varicent.BPM.domain;

import java.util.ArrayList;

public class BPMConditionalNode extends BPMNode {
	public BPMConditionalNode(int nodeID, int swimLaneID, String name, BPMConditionalPath[] paths) {
		super(nodeID, swimLaneID, name, paths);
	}

	public ArrayList<BPMConditionalPath> getConditions() {
		ArrayList<BPMConditionalPath> conditions = new ArrayList();

		for (BPMPath path : this.getPaths()) {
			conditions.add((BPMConditionalPath) path);
		}

		return conditions;
	}
}
