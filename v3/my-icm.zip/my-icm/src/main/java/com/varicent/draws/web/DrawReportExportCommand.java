package com.varicent.draws.web;

import java.util.ArrayList;
import java.util.List;

import com.varicent.security.domain.CSRFCommand;

public class DrawReportExportCommand extends CSRFCommand {
	Integer id;
	List<String> ChartStreams = new ArrayList(4);
	List<String> ChartFileNames = new ArrayList(4);

	public List<String> getChartStreams() {
		return this.ChartStreams;
	}

	public void setChartStreams(List<String> chartStreams) {
		this.ChartStreams = chartStreams;
	}

	public List<String> getChartFileNames() {
		return this.ChartFileNames;
	}

	public void setChartFileNames(List<String> chartFileNames) {
		this.ChartFileNames = chartFileNames;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}
