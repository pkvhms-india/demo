package com.varicent.draws.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;

public class DrawAssignmentOngoing {
	private int assignmentId;
	private String payeeId;
	private String payeeName;
	private String startPeriod;
	private String newStartDateFormatted;
	private String oldStartDateFormatted;
	private String endDateFormatted;
	private String newAmount;
	private String oldAmount;
	private boolean unassigned;
	private int templateId;
	private String templateName;
	private String timeId;
	private String level;
	private long rowVersion;
	private boolean active;
	private boolean lockedStartDate;
	private boolean fixedAmount;

	public DrawAssignmentOngoing() {
	}

	public DrawAssignmentOngoing(int assignmentId, String payeeId, String payeeName, String startPeriod, Date startDate,
			Date endDate, BigDecimal drawAmount, int templateId, String templateName, String timeId, String level,
			boolean active, boolean lockedStartDate, boolean fixedAmount, long rowVersion, NumericFormat.Style style) {
		this.assignmentId = assignmentId;
		this.payeeId = payeeId;
		this.payeeName = payeeName;
		this.startPeriod = startPeriod;
		this.newStartDateFormatted = this.oldStartDateFormatted = Format.asShortDate(startDate);
		this.endDateFormatted = endDate == null ? "" : Format.asShortDate(endDate);
		this.newAmount = this.oldAmount = NumericFormat.getNumericCurrencyFormatter(style).format(drawAmount);
		this.templateId = templateId;
		this.templateName = templateName;
		this.timeId = timeId;
		this.level = level;
		this.rowVersion = rowVersion;
		this.active = active;
		this.lockedStartDate = lockedStartDate;
		this.fixedAmount = fixedAmount;
	}

	public void updateOriginalValues() {
		this.oldStartDateFormatted = this.newStartDateFormatted;
		this.oldAmount = this.newAmount;
	}

	public boolean isDirty() {
		return this.hasAmountChange() || this.hasStartDateChange();
	}

	boolean hasAmountChange() {
		if (this.newAmount == null) {
			return this.oldAmount != null;
		} else {
			return this.oldAmount.compareTo(this.newAmount) != 0;
		}
	}

	boolean hasStartDateChange() {
		return this.oldStartDateFormatted.compareTo(this.newStartDateFormatted) != 0;
	}

	public long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public String getNewAmount() {
		return this.newAmount;
	}

	public void setNewAmount(String newAmount) {
		this.newAmount = newAmount;
	}

	public String getOldAmount() {
		return this.oldAmount;
	}

	public void setOldAmount(String oldAmount) {
		this.oldAmount = oldAmount;
	}

	public String getPayeeId() {
		return this.payeeId;
	}

	public String getPayeeName() {
		return this.payeeName;
	}

	public String getStartPeriod() {
		return this.startPeriod;
	}

	public void setNewStartDateFormatted(String date) {
		this.newStartDateFormatted = date;
	}

	public void setOldStartDateFormatted(String date) {
		this.oldStartDateFormatted = date;
	}

	public String getNewStartDateFormatted() {
		return this.newStartDateFormatted;
	}

	public String getOldStartDateFormatted() {
		return this.oldStartDateFormatted;
	}

	public boolean isUnassigned() {
		return this.unassigned;
	}

	public int getTemplateId() {
		return this.templateId;
	}

	public String getTimeId() {
		return this.timeId;
	}

	public String getLevel() {
		return this.level;
	}

	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public void setStartPeriod(String startPeriod) {
		this.startPeriod = startPeriod;
	}

	public void setUnassigned(boolean unassigned) {
		this.unassigned = unassigned;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public void setTimeId(String timeId) {
		this.timeId = timeId;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getTemplateName() {
		return this.templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public boolean isLockedStartDate() {
		return this.lockedStartDate;
	}

	public boolean isFixedAmount() {
		return this.fixedAmount;
	}

	public void setLockedStartDate(boolean lockedStartDate) {
		this.lockedStartDate = lockedStartDate;
	}

	public int getAssignmentId() {
		return this.assignmentId;
	}

	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}

	public void setFixedAmount(boolean fixedAmount) {
		this.fixedAmount = fixedAmount;
	}

	public String getEndDateFormatted() {
		return this.endDateFormatted;
	}

	public void setEndDateFormatted(String endDateFormatted) {
		this.endDateFormatted = endDateFormatted;
	}
}
