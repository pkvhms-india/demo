package com.varicent.draws.web;

import java.awt.Color;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.WebUtils;

import com.varicent.common.tab.domain.Tab;
import com.varicent.common.tab.domain.TabObject;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.NoncacheHttpResponseSetter;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.service.DrawReportManager;

@Controller
public class DrawReportController {
	private static final String SHOW_EXPORT_TO_PDF = "showExportToPdf";
	public static final String VIEW = "drawreport/index";
	private final DrawReportManager drawReportManager;
	private final Messages messages;

	@Autowired
	public DrawReportController(DrawReportManager manager, Messages messages) {
		this.drawReportManager = manager;
		this.messages = messages;
	}

	private TabObject getTabObject(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		if (activeTab != null && activeTab.getType() == Tab.Type.DRAW_REPORT) {
			return (TabObject) activeTab;
		} else {
			Assert.state(false, "couldn't get active tab for draw report");
			return null;
		}
	}

	private boolean hasTabObject(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		return activeTab != null && activeTab.getType() == Tab.Type.DRAW_REPORT;
	}

	private boolean isWebModule(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		return activeTab != null && activeTab.isModule();
	}

	private int getDrawID(TabObject obj) {
		Assert.state(obj.getType() == Tab.Type.DRAW_REPORT);
		return Integer.parseInt(obj.getObjectId());
	}

	@RequestMapping(method = { RequestMethod.GET }, value = { "/drawreport/*.html" })
	public ModelAndView prepareView(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("drawreport/index");
		int drawID = -1;
		int workflowObjectID = -1;
		if (this.hasTabObject(request)) {
			TabObject obj = this.getTabObject(request);
			drawID = this.getDrawID(obj);
			workflowObjectID = obj.getWorkflowObjectId();
		} else {
			String drawIdString = request.getParameter("id");
			if (this.isWebModule(request)) {
				mav.addObject("viewableDraws", this.drawReportManager.getViewableDraws());
			}

			if (drawIdString == null) {
				DrawReportCommand cmd = new DrawReportCommand();
				mav.addObject("command", cmd);
				return mav;
			}

			drawID = Integer.parseInt(drawIdString);
		}

		if (!this.drawReportManager.exists(drawID)) {
			return this.errorView(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST.toString());
		} else if (!this.drawReportManager.isViewable(drawID)) {
			return this.errorView(Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS.toString());
		} else {
			DrawReportCommand cmd = new DrawReportCommand();
			cmd.setId(drawID);
			cmd.setWorkflowObjectId(workflowObjectID);

			try {
				DrawReportWebSettings settings = this.drawReportManager.getSettings(cmd.getId());
				return this.populate(mav, cmd, settings);
			} catch (InvalidDrawException e) {
				return this.errorView(e.getMessageObject().getKey().toString());
			}
		}
	}

	private RedirectView createDrawReportRedirect(String dest, HttpServletRequest request,
			DrawReportCommand headerCmd) {
		RedirectView redirect = new RedirectView(dest);
		if (headerCmd.getTabId() != "") {
			redirect.addStaticAttribute("tabId", headerCmd.getTabId());
		}

		if (headerCmd.getId() != null) {
			redirect.addStaticAttribute("id", headerCmd.getId());
		}

		if (headerCmd.getSelectedPayeeId() != "") {
			redirect.addStaticAttribute("selectedPayeeId", headerCmd.getSelectedPayeeId());
		}

		if (headerCmd.getSelectedGroupId() != "") {
			redirect.addStaticAttribute("selectedGroupId", headerCmd.getSelectedGroupId());
		}

		if (headerCmd.getSelectedTemplate() != "") {
			redirect.addStaticAttribute("selectedTemplate", headerCmd.getSelectedTemplate());
		}

		if (headerCmd.getSelectedPeriod() != "") {
			redirect.addStaticAttribute("selectedPeriod", headerCmd.getSelectedPeriod());
		}

		if (headerCmd.getSelectedPeriodLevel() != "") {
			redirect.addStaticAttribute("selectedPeriodLevel", headerCmd.getSelectedPeriodLevel());
		}

		redirect.setExposeModelAttributes(true);
		redirect.setContextRelative(true);
		return redirect;
	}

	@RequestMapping(value = { "/drawreport/index.do" }, method = { RequestMethod.POST })
	public RedirectView doPostIndex(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request) {
		return this.createDrawReportRedirect("index.html", request, headerCmd);
	}

	@RequestMapping(value = { "/drawreport/overview.do" }, method = { RequestMethod.POST })
	public RedirectView doPostOverview(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request) {
		return this.createDrawReportRedirect("overview.html", request, headerCmd);
	}

	@RequestMapping(value = { "/drawreport/assignments.do" }, method = { RequestMethod.POST })
	public RedirectView doPostAssignments(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request) {
		return this.createDrawReportRedirect("assignments.html", request, headerCmd);
	}

	@RequestMapping(value = { "/drawreport/ytdpayout.do" }, method = { RequestMethod.POST })
	public RedirectView doPostYTD(@ModelAttribute("command") DrawReportCommand headerCmd, HttpServletRequest request) {
		return this.createDrawReportRedirect("ytdpayout.html", request, headerCmd);
	}

	@RequestMapping(value = { "/drawreport/periodpayout.do" }, method = { RequestMethod.POST })
	public RedirectView doPostByPeriod(@ModelAttribute("command") DrawReportCommand headerCmd,
			HttpServletRequest request) {
		return this.createDrawReportRedirect("periodpayout.html", request, headerCmd);
	}

	private String getSelectedName(DrawReportCommand cmd, boolean allowGroupSelection) {
		Locale userLocale = LocaleContextHolder.getLocale();
		String selectedName = null;
		String selectedPayeeId = cmd.getSelectedPayeeId();
		if (selectedPayeeId != null && !selectedPayeeId.isEmpty()) {
			selectedName = this.drawReportManager.getPayee(selectedPayeeId);
		} else if (allowGroupSelection) {
			String selectedGroupId = cmd.getSelectedGroupId();
			if (selectedGroupId != null && !selectedGroupId.isEmpty()) {
				selectedName = this.drawReportManager.getGroup(selectedGroupId);
			} else {
				selectedName = this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_FILTER_ALLGROUPS,
						userLocale);
			}
		} else {
			selectedName = this.messages.getHTMLDecodedMessage(Messages.Key.DRAW_REPORT_FILTER_ALLPAYEES, userLocale);
		}

		return selectedName;
	}

	private String getColorString(Color c) {
		return "#" + Integer.toHexString(c.getRGB() | -16777216).substring(2);
	}

	@RequestMapping(value = { "/drawreport/overview.html" }, method = { RequestMethod.GET })
	public ModelAndView overviewPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("drawreport/overview");
		DrawReportCommand headerCmd = null;
		DrawReportWebSettings settings = null;

		try {
			headerCmd = this.getCommand(request);
			settings = this.drawReportManager.getSettings(headerCmd.getId());
			headerCmd.setWorkflowObjectId(settings.getWorkflowObjectId());
			if (!settings.isAllowGroupSelection()) {
				headerCmd.setSelectedGroupId((String) null);
			}

			mav.addObject("assignedPercent", this.drawReportManager.getPayeesAssignedPercent(headerCmd));
			mav.addObject("outstandingBalancePercent", this.drawReportManager.getOutstandingBalancePercent(headerCmd));
			mav.addObject("averagePayoutPercents", this.drawReportManager.getAveragePayoutPercentByPeriod(headerCmd));
			mav.addObject("drawsVsCommissions", this.drawReportManager.getDrawsVsCommissionsByPeriod(headerCmd));
			mav.addObject("hasLogo", this.drawReportManager.getLogo(headerCmd.getId()) != null);
			mav.addObject("exportCommand", new DrawReportExportCommand());
			WebUtils.setSessionAttribute(request, "showExportToPdf", true);
			if (this.isWebModule(request)) {
				mav.addObject("viewableDraws", this.drawReportManager.getViewableDraws());
			}

			NoncacheHttpResponseSetter.setResponseNonCache(response);
			return this.populate(mav, headerCmd, settings);
		} catch (InvalidDrawException e) {
			return this.errorView(e.getMessageObject().getKey().toString());
		}
	}

	@RequestMapping(value = { "/drawreport/assignments.html" }, method = { RequestMethod.GET })
	public ModelAndView assignmentsPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("drawreport/assignments");
		DrawReportCommand headerCmd = null;
		DrawReportWebSettings settings = null;

		try {
			headerCmd = this.getCommand(request);
			settings = this.drawReportManager.getSettings(headerCmd.getId());
			if (!settings.isAllowGroupSelection()) {
				headerCmd.setSelectedGroupId((String) null);
			}

			headerCmd.setPageNumber(1);
			headerCmd.setRowsPerPage(settings.getRowsPerPage());
			headerCmd.setTotalPages(
					this.drawReportManager.getAssignmentsPageCount(headerCmd, settings.getRowsPerPage()));
			headerCmd.setSortColumn("PayeeID");
			headerCmd.setDescending(false);
			mav.addObject("assignments", this.drawReportManager.getAssignments(headerCmd, headerCmd.getPageNumber(),
					headerCmd.getRowsPerPage(), headerCmd.getSortColumn(), headerCmd.isDescending()));
			if (this.isWebModule(request)) {
				mav.addObject("viewableDraws", this.drawReportManager.getViewableDraws());
			}

			NoncacheHttpResponseSetter.setResponseNonCache(response);
			return this.populate(mav, headerCmd, settings);
		} catch (InvalidDrawException e) {
			return this.errorView(e.getMessageObject().getKey().toString());
		}
	}

	@RequestMapping(value = { "/drawreport/ytdpayout.html" }, method = { RequestMethod.GET })
	public ModelAndView ytdPayoutPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("drawreport/ytdpayout");
		DrawReportWebSettings settings = null;
		DrawReportCommand headerCmd = null;

		try {
			headerCmd = this.getCommand(request);
			settings = this.drawReportManager.getSettings(headerCmd.getId());
			if (!settings.isAllowGroupSelection()) {
				headerCmd.setSelectedGroupId((String) null);
			}

			headerCmd.setPageNumber(1);
			headerCmd.setRowsPerPage(settings.getRowsPerPage());
			headerCmd.setTotalPages(
					this.drawReportManager.getYTDPayoutDetailsPageCount(headerCmd, settings.getRowsPerPage()));
			headerCmd.setSortColumn("PayeeID");
			headerCmd.setDescending(false);
			mav.addObject("payoutdetail",
					this.drawReportManager.getYTDPayoutDetails(headerCmd, headerCmd.getPageNumber(),
							settings.getRowsPerPage(), headerCmd.getSortColumn(), headerCmd.isDescending()));
			DataRow totalsRow = this.drawReportManager.getYTDPayoutTotals(headerCmd);
			totalsRow.insert(0, this.getSelectedName(headerCmd, settings.isAllowGroupSelection()));
			mav.addObject("payouttotals", totalsRow);
			if (this.isWebModule(request)) {
				mav.addObject("viewableDraws", this.drawReportManager.getViewableDraws());
			}

			NoncacheHttpResponseSetter.setResponseNonCache(response);
			return this.populate(mav, headerCmd, settings);
		} catch (InvalidDrawException e) {
			return this.errorView(e.getMessageObject().getKey().toString());
		}
	}

	@RequestMapping(value = { "/drawreport/periodpayout.html" }, method = { RequestMethod.GET })
	public ModelAndView periodPayoutPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("drawreport/periodpayout");
		DrawReportCommand headerCmd = null;
		DrawReportWebSettings settings = null;

		try {
			headerCmd = this.getCommand(request);
			settings = this.drawReportManager.getSettings(headerCmd.getId());
			if (!settings.isAllowGroupSelection()) {
				headerCmd.setSelectedGroupId((String) null);
			}

			headerCmd.setPageNumber(1);
			headerCmd.setRowsPerPage(settings.getRowsPerPage());
			headerCmd.setTotalPages(
					this.drawReportManager.getByPeriodPayoutDetailsPageCount(headerCmd, settings.getRowsPerPage()));
			headerCmd.setSortColumn("PayeeID");
			headerCmd.setDescending(false);
			mav.addObject("payoutdetail",
					this.drawReportManager.getByPeriodPayoutDetails(headerCmd, headerCmd.getPageNumber(),
							settings.getRowsPerPage(), headerCmd.getSortColumn(), headerCmd.isDescending()));
			DataRow totalsRow = this.drawReportManager.getYTDPayoutTotals(headerCmd);
			totalsRow.insert(0, this.getSelectedName(headerCmd, settings.isAllowGroupSelection()));
			mav.addObject("payouttotals", totalsRow);
			if (this.isWebModule(request)) {
				mav.addObject("viewableDraws", this.drawReportManager.getViewableDraws());
			}

			NoncacheHttpResponseSetter.setResponseNonCache(response);
			return this.populate(mav, headerCmd, settings);
		} catch (InvalidDrawException var7) {
			return this.errorView(Messages.Key.DRAW_REPORT_ERROR_INVALIDDRAW.toString());
		}
	}

	private DrawReportCommand getCommand(HttpServletRequest request) throws InvalidDrawException {
		Integer drawID = null;
		if (this.hasTabObject(request)) {
			TabObject obj = this.getTabObject(request);
			drawID = this.getDrawID(obj);
		} else {
			String drawIdString = request.getParameter("id");
			if (drawIdString == null) {
				throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_INVALIDDRAW, new Object[0]));
			}

			drawID = Integer.parseInt(drawIdString);
		}

		if (!this.drawReportManager.exists(drawID)) {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		} else if (!this.drawReportManager.isViewable(drawID)) {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_LACK_OF_ACCESS, new Object[0]));
		} else {
			DrawReportCommand headerCmd = new DrawReportCommand();
			headerCmd.setId(drawID);
			headerCmd.setSelectedPayeeId(request.getParameter("selectedPayeeId"));
			headerCmd.setSelectedGroupId(request.getParameter("selectedGroupId"));
			headerCmd.setSelectedTemplate(request.getParameter("selectedTemplate"));
			headerCmd.setSelectedPeriod(request.getParameter("selectedPeriod"));
			headerCmd.setSelectedPeriodLevel(request.getParameter("selectedPeriodLevel"));
			return headerCmd;
		}
	}

	public ModelAndView errorView(String messageID) {
		ModelAndView mav = new ModelAndView("drawreport/index");
		mav.addObject("messageKey", messageID);
		return mav;
	}

	public ModelAndView populate(ModelAndView mav, DrawReportCommand cmd, DrawReportWebSettings settings)
			throws InvalidDrawException {
		int drawID = cmd.getId();
		int workflowObjectId = settings.getWorkflowObjectId();
		cmd.setWorkflowObjectId(workflowObjectId);
		Color reportColour = settings.getColor();
		cmd.setReportColour(this.getColorString(reportColour));
		if (Color.RGBtoHSB(reportColour.getRed(), reportColour.getGreen(), reportColour.getBlue(),
				(float[]) null)[2] < 0.7) {
			mav.addObject("reportForeColour", "white");
		} else {
			mav.addObject("reportForeColour", "black");
		}

		cmd.updateToken();
		mav.addObject("command", cmd);
		mav.addObject("payees", this.drawReportManager.getPayees(drawID, workflowObjectId));
		if (settings.isAllowGroupSelection()) {
			mav.addObject("groups", this.drawReportManager.getWorkflowGroups(workflowObjectId));
		}

		mav.addObject("calendar", this.drawReportManager.getCalendar(drawID));
		List<DrawTemplateName> templates = this.drawReportManager.getTemplates(drawID);
		mav.addObject("templates", templates);
		if (cmd.getSelectedTemplate() != null && !cmd.getSelectedTemplate().isEmpty() && templates != null
				&& templates.size() > 0) {
			int templateId = templates.get(0).getId();
			if (cmd.getSelectedTemplate() != null && !cmd.getSelectedTemplate().isEmpty()) {
				templateId = Integer.parseInt(cmd.getSelectedTemplate());
			}

			mav.addObject("periods", this.drawReportManager.getPeriods(drawID, templateId));
		} else {
			mav.addObject("periods", (Object) null);
		}

		return mav;
	}
}
