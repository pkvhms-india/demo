package com.varicent.BPM.domain;

public class BPMAlertNode extends BPMNode {
	private String subject;
	private String body;
	private AlertTypeEnum alertType;
	private BPMExternalEmail[] externalEmails;

	public BPMAlertNode(int nodeID, int swimLaneID, String name, BPMPath[] paths, String subject, String body,
			AlertTypeEnum alertType) {
		super(nodeID, swimLaneID, name, paths);
		this.subject = subject;
		this.body = body;
		this.alertType = alertType;
	}

	public String getSubject() {
		return this.subject;
	}

	public String getBody() {
		return this.body;
	}

	public AlertTypeEnum getAlertType() {
		return this.alertType;
	}

	public BPMExternalEmail[] getExternalEmails() {
		return this.externalEmails;
	}

	public void setExternalEmails(BPMExternalEmail[] externalEmails) {
		this.externalEmails = externalEmails;
	}

	public static class Parameters {
		public static final String RecipientName = "%recipientName%";
		public static final String FormInitiatorName = "%formInitiatorName%";
		public static final String ReportName = "%reportName%";
		public static final String ReportNameWithLink = "%reportNameWithLink%";
	}

	public static enum AlertTypeEnum {
		Email(0), InternalAndEmail(1), Internal(2);

		private int _value;

		private AlertTypeEnum(int value) {
			this._value = value;
		}

		public static AlertTypeEnum getAlertTypeEnum(int value) {
			switch (value) {
			case 0:
				return Email;
			case 1:
				return InternalAndEmail;
			case 2:
			default:
				return Internal;
			}
		}

		public int getValue() {
			return this._value;
		}
	}
}
