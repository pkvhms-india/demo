package com.varicent.core.view;

import java.awt.Color;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelXssfUtility extends ExcelUtility {
	private static int XSSFExcelRowLimit = 1048576;

	public ExcelXssfUtility(XSSFWorkbook wb) {
		super(wb);
	}

	@Override
	public void ApplyFillColour(CellStyle cellStyle, Color color, short foregroundStyle) {
		XSSFCellStyle xssfCellStyle = (XSSFCellStyle) cellStyle;
		XSSFColor xssfColor = new XSSFColor(color);
		xssfCellStyle.setFillForegroundColor(xssfColor);
		xssfCellStyle.setFillPattern(foregroundStyle);
	}

	@Override
	public void ApplyFontColour(Font font, Color color) {
		XSSFFont xssfFont = (XSSFFont) font;
		XSSFColor xssfColor = new XSSFColor(color);
		xssfFont.setColor(xssfColor);
	}

	@Override
	public int getRowLimit() {
		return XSSFExcelRowLimit;
	}
}
