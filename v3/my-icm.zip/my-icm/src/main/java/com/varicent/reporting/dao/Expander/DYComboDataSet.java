package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class DYComboDataSet {
	private String seriesName;
	private String primaryAxis;
	List<DYComboSet> sets;
	private int index;
	private int currentCategory;
	private ColumnLink link;
	DataTable data;
	private boolean isPercentage;
	private String axisCol;
	private String dispCol;
	private String valCol;

	public DYComboDataSet(String seriesName, String isPrimary, DataTable data, String axis, String display,
			String value, ColumnLink link) {
		this.seriesName = seriesName;
		this.primaryAxis = isPrimary.equals("1") ? "P" : "S";
		this.sets = new ArrayList();
		this.data = data;
		this.axisCol = axis;
		this.dispCol = display;
		this.valCol = value;
		this.link = link;
	}

	public String getAxisColumn() {
		return this.axisCol;
	}

	public String getValueColumn() {
		return this.valCol;
	}

	public String getDisplayColumn() {
		return this.dispCol;
	}

	public void add(DYComboSet set) {
		this.sets.add(set);
	}

	public String getName() {
		return this.seriesName;
	}

	public void sortSets() {
		Collections.sort(this.sets);
	}

	public void setLink(ColumnLink link) {
		this.link = link;
	}

	public void setPercentage(boolean isPerc) {
		this.isPercentage = isPerc;
	}

	public String getPrimaryAxis() {
		return this.primaryAxis;
	}

	public void writeDataSetElement(XMLStreamWriter writer, List<DYComboCategory> categories, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		DYComboCategory category = categories.get(this.currentCategory);
		if (this.index < this.sets.size() && category == this.sets.get(this.index).category
				&& this.index < this.data.getRows().size()) {
			this.sets.get(this.index).writeXMLElement(writer, this.index, this.data, scope, this.seriesName, this.link,
					this.isPercentage);
			++this.index;
		} else {
			ComboSet.writeEmptyXMLElement(writer);
		}

		++this.currentCategory;
	}

	public void writeDataSetStartElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters(
				"<dataset seriesName='" + this.seriesName + "' parentYAxis='" + this.primaryAxis + "' >");
	}

	public void writeDataSetElement(XMLStreamWriter writer, List<DYComboCategory> categories)
			throws XMLStreamException {
		DYComboCategory category = categories.get(this.currentCategory);
		if (this.index < this.sets.size() && category == this.sets.get(this.index).category) {
			this.sets.get(this.index).writeXMLElement(writer);
			++this.index;
		} else {
			DYComboSet.writeEmptyXMLElement(writer);
		}

		++this.currentCategory;
	}

	public void writeDataSetEndElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</dataset>");
	}
}
