package com.varicent.messages.domain;

import java.util.Date;

public class Message {
	private Date date;
	private Category category;
	private String id;
	private String from;
	private String summary;
	private Boolean isNew;

	public Message(Date date, Category category, String id, String from, String summary) {
		this.date = date;
		this.category = category;
		this.id = id;
		this.from = from;
		this.summary = summary;
		this.isNew = false;
	}

	public Message(Message message, Boolean isNew) {
		this.date = message.date;
		this.category = message.category;
		this.id = message.id;
		this.from = message.from;
		this.summary = message.summary;
		this.isNew = isNew;
	}

	public Date getDate() {
		return this.date;
	}

	public Category getCategory() {
		return this.category;
	}

	public String getId() {
		return this.id;
	}

	public String getFrom() {
		return this.from;
	}

	public String getSummary() {
		return this.summary;
	}

	public Boolean getIsNew() {
		return this.isNew;
	}

	public static enum Category {
		ADMIN_MESSAGE, DOCUMENT, SIGNOFF, INQUIRY_ASSIGNED, INQUIRY_OPEN, ADMIN_PAYEE_MESSAGE, INQUIRY_RETURNED,
		INQUIRY_ESCALATED, INQUIRY_RESUBMITTED, INQUIRY_COMMENTED, INQUIRY_CLOSED;

		public static Category toCategory(int i) {
			switch (i) {
			case 0:
				return ADMIN_MESSAGE;
			case 1:
				return DOCUMENT;
			case 2:
				return SIGNOFF;
			case 3:
				return INQUIRY_ASSIGNED;
			case 4:
				return INQUIRY_OPEN;
			case 5:
				return ADMIN_PAYEE_MESSAGE;
			case 6:
				return INQUIRY_RETURNED;
			case 7:
				return INQUIRY_ESCALATED;
			case 8:
				return INQUIRY_RESUBMITTED;
			case 9:
				return INQUIRY_COMMENTED;
			case 10:
				return INQUIRY_CLOSED;
			default:
				return ADMIN_MESSAGE;
			}
		}
	}
}
