package com.varicent.BPM.domain;

public class BPMPath {
	private int pathID;
	private String name;
	private int originNodeID;
	private int destinationNodeID;
	private boolean allMember;
	private boolean saveAndSubmit;
	private boolean allSubmit;
	private int reviewResult;

	public BPMPath(int pathID, String name, int originNodeID, int destinationNodeID, boolean allMember,
			boolean saveAndSubmit, boolean allSubmit, int reviewResult) {
		this.pathID = pathID;
		this.name = name;
		this.originNodeID = originNodeID;
		this.destinationNodeID = destinationNodeID;
		this.allMember = allMember;
		this.saveAndSubmit = saveAndSubmit;
		this.allSubmit = allSubmit;
		this.reviewResult = reviewResult;
	}

	public int getPathID() {
		return this.pathID;
	}

	public String getJavascriptName() {
		return this.name.replace("'", "\\'");
	}

	public String getName() {
		return this.name;
	}

	public int getOriginNodeID() {
		return this.originNodeID;
	}

	public int getDestinationNodeID() {
		return this.destinationNodeID;
	}

	public boolean isAllMember() {
		return this.allMember;
	}

	public boolean isSaveAndSubmit() {
		return this.saveAndSubmit;
	}

	public boolean isAllSubmit() {
		return this.allSubmit;
	}

	public int getReviewResult() {
		return this.reviewResult;
	}
}
