package com.varicent.draws.web;

import com.varicent.security.domain.CSRFCommand;

public abstract class DrawAssignmentCommand extends CSRFCommand {
	private int drawId;
	private int workflowObjectId;
	private String tabId;
	private String selectedPayeeId;
	private int selectedGroupId;
	private String clientLocale;
	private int pageNumber;
	private int totalPages;
	private String sortColumn;
	private boolean descending;
	private int rowsPerPage;

	public int getPageNumber() {
		return this.pageNumber;
	}

	public String getClientLocale() {
		return this.clientLocale;
	}

	public String getSortColumn() {
		return this.sortColumn;
	}

	public boolean isDescending() {
		return this.descending;
	}

	public void setClientLocale(String newLocale) {
		this.clientLocale = newLocale;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public void setDescending(boolean descending) {
		this.descending = descending;
	}

	public String getSelectedPayeeId() {
		return this.selectedPayeeId;
	}

	public int getSelectedGroupId() {
		return this.selectedGroupId;
	}

	public void setSelectedPayeeId(String selectedPayeeId) {
		this.selectedPayeeId = selectedPayeeId;
	}

	public void setSelectedGroupId(int selectedGroupId) {
		this.selectedGroupId = selectedGroupId;
	}

	public int getDrawId() {
		return this.drawId;
	}

	public void setDrawId(int drawId) {
		this.drawId = drawId;
	}

	public int getTotalPages() {
		return this.totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getWorkflowObjectId() {
		return this.workflowObjectId;
	}

	public void setWorkflowObjectId(int workflowObjectId) {
		this.workflowObjectId = workflowObjectId;
	}

	public int getRowsPerPage() {
		return this.rowsPerPage;
	}

	public String getTabId() {
		return this.tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}
}
