package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeAdd extends BinaryNode implements EvaluateNode {
	public NodeAdd(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal left = this.lhs.evaluate();
		BigDecimal right = this.rhs.evaluate();
		return left != null && right != null ? left.add(right) : null;
	}

	@Override
	public String getJSMathFunctionName() {
		return "add";
	}
}
