package com.varicent.BPM.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.stream.XMLStreamException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.support.StringMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.WebUtils;

import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.BPM.service.BPMManager;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.context.VaricentContext;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.HttpRequestUtils;
import com.varicent.reporting.domain.Rendering;
import com.varicent.reporting.service.ReportingManager;
import com.varicent.reporting.web.ReportingCommand;

@Controller("bpmViewController")
public class BPMViewController {
	public static final String VIEW = "bpm/view";
	public static final String VIEW_REDIRECT = "redirect:tokenlist.html";
	public static final String BPMTOKEN_ID_PARAM = "bpmTokenID";
	public static final String BPMTOKEN_VERSION_PARAM = "bpmTokenVersion";
	public static final String BPMTOKEN_COMPLETED_VIEW = "bpm/completedtokenhistorypage";
	public static final String INVALID_TOKEN_ERROR;
	private BPMManager bpmManager;
	private ReportingManager reportingManager;
	private final Messages messages;

	@Autowired
	public BPMViewController(BPMManager bpmManager, ReportingManager reportingManager, Messages messages) {
		this.bpmManager = bpmManager;
		this.reportingManager = reportingManager;
		this.messages = messages;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(String.class, new StringMultipartFileEditor());
	}

	@RequestMapping(value = { "/bpm/view.html" }, method = { RequestMethod.GET })
	public ModelAndView prepareView(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("bpm/view");
		this.populateMAV(mav, request, response);
		return mav;
	}

	private boolean populateMAV(ModelAndView mav, HttpServletRequest request, HttpServletResponse response) {
		boolean noError = true;
		if (this.hasTokenIDParam(request)) {
			if (WebUtils.getSessionAttribute(request, "error") != null) {
				mav.addObject("error", WebUtils.getSessionAttribute(request, "error"));
				noError = false;
			} else {
				try {
					BPMCommand command = this.getBPMCommand(request);
					mav.addObject("bpmCommand", command);
					mav.setViewName("bpm/view");
					BPMTokenView selectedToken = this.bpmManager.getBPMTokenView(command.getBPMTokenID());
					mav.addObject("selectedToken", selectedToken);
					BPMWorkflowView bpmview = this.bpmManager
							.getWorkflowView(this.bpmManager.getWorkFlowID(selectedToken.getTokenID()));
					mav.addObject("BPMView", bpmview);
					BPMNodeHistoryStatus[] BPMHistory = this.bpmManager
							.getBPMPendingTokenHistory(selectedToken.getTokenID());
					mav.addObject("BPMHistory", BPMHistory);
					if (selectedToken != null) {
						BPMPath[] paths = this.bpmManager.getPaths(command.getBPMTokenID());
						mav.addObject("paths", paths);
						int reportID = this.bpmManager.getReportID(command.getBPMTokenID());
						Map<String, Object> params = this.bpmManager.getWorkflowParams(command.getBPMTokenID());
						if (WebUtils.getSessionAttribute(request, "ParametersMap") != null) {
							Map<String, Object> webParams = (Map) WebUtils.getSessionAttribute(request,
									"ParametersMap");

							for (String key : webParams.keySet()) {
								params.put(key, webParams.get(key));
							}
						}

						ReportingCommand reportingCommand = new ReportingCommand();
						reportingCommand.setId(reportID);
						HashSet<Integer> submitted = (HashSet) WebUtils.getSessionAttribute(request,
								"SigStatusSubmitted");
						reportingCommand
								.setResetSigStatus(submitted == null || !submitted.contains(reportingCommand.getId()));
						Boolean retrieveBPMParameters = WebUtils.getSessionAttribute(request,
								"retrieveBPMParameters") == null
								|| (Boolean) WebUtils.getSessionAttribute(request, "retrieveBPMParameters");
						noError = this.populateReportModel(mav, reportingCommand, params,
								HttpRequestUtils.getVisibleTabIdWorkflowObjectIdMap(request), command.getBPMTokenID(),
								retrieveBPMParameters);
						WebUtils.setSessionAttribute(request, "showBatchExportToPdf",
								reportingCommand.getCanBatchExport());
						WebUtils.setSessionAttribute(request, "showExportToPdf",
								reportingCommand.getId() > 0 && reportingCommand.getCanExport());
						WebUtils.setSessionAttribute(request, "retrieveBPMParameters", (Object) null);
					} else {
						this.populateErrors(mav, INVALID_TOKEN_ERROR);
						noError = false;
					}
				} catch (DatabaseConcurrencyException var15) {
					this.populateErrors(mav, INVALID_TOKEN_ERROR);
					noError = false;
				}
			}
		} else {
			this.populateErrors(mav, INVALID_TOKEN_ERROR);
		}

		response.addHeader("Cache-Control", "no-cache");
		response.addHeader("Pragma", "no-cache");
		mav.addObject("bpmTokenlistStart", WebUtils.getSessionAttribute(request, "bpmTokenlistStart"));
		mav.addObject("hideSubhead", 1);
		WebUtils.setSessionAttribute(request, "error", (Object) null);
		WebUtils.setSessionAttribute(request, "ParametersMap", (Object) null);
		WebUtils.setSessionAttribute(request, "tokenId", (Object) null);
		return noError;
	}

	@RequestMapping(value = { "/bpm/reporting/searchField.do" }, method = { RequestMethod.POST })
	@ResponseBody
	public List<SelectOption> searchFieldJSON(HttpServletResponse response, @RequestParam String reportIdString,
			@RequestParam String searchString, @RequestParam String sourceTable, @RequestParam String sourceNameColumn,
			@RequestParam Map<String, Object> params) throws XMLStreamException, ReportOverLimitException {
		int reportId = Integer.parseInt(reportIdString);
		List<SelectOption> result = this.reportingManager.searchField(reportId, searchString, sourceTable,
				sourceNameColumn, params, this.bpmManager.getPendingWorkflowStatus());
		return result;
	}

	@RequestMapping(value = { "/bpm/reporting/getFiltered.do" }, method = { RequestMethod.POST })
	@ResponseBody
	public List<SelectOption> getFilteredJSON(HttpServletResponse response, @RequestParam String reportIdString,
			@RequestParam String[] restrictParams, @RequestParam String[] restrictValues,
			@RequestParam String sourceTable, @RequestParam String sourceIDColumn,
			@RequestParam String sourceNameColumn, @RequestParam String targetPL, @RequestParam String sortCol,
			@RequestParam String sortDescending) throws XMLStreamException, ReportOverLimitException {
		int reportId = Integer.parseInt(reportIdString);
		List<SelectOption> result = this.reportingManager.getFiltered(reportId, restrictParams, restrictValues,
				sourceTable, sourceIDColumn, sourceNameColumn, targetPL, sortCol, sortDescending,
				this.bpmManager.getPendingWorkflowStatus(), false);
		return result;
	}

	private void populateErrors(ModelAndView mav, String errorString) {
		mav.addObject("error", INVALID_TOKEN_ERROR);
		mav.addObject("historyerror", INVALID_TOKEN_ERROR);
	}

	@RequestMapping(value = { "/bpm/completedtokenhistorypage.html" }, method = { RequestMethod.GET })
	public ModelAndView historyTokenView(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("bpm/completedtokenhistorypage");
		int id = Integer.parseInt(request.getParameter("bpmTokenID"));
		BPMTokenView selectedToken = this.bpmManager.getBPMToken(id);
		if (selectedToken != null) {
			this.populateHistoryScope(mav, selectedToken);
			BPMNodeHistoryStatus[] history = this.bpmManager.getBPMPendingTokenHistory(id);
			if (history.length > 0) {
				mav.addObject("BPMHistory", history);
				mav.addObject("error", "");
			} else {
				BPMNodeHistoryStatus[] deletedTokenHistory = this.bpmManager.getBPMDeletedTokenHistory(id);
				if (deletedTokenHistory.length > 0) {
					mav.addObject("BPMHistory", deletedTokenHistory);
					mav.addObject("error", "");
				} else {
					mav.addObject("BPMHistory", history);
					mav.addObject("error", "emptyhistory");
				}
			}
		} else {
			mav.addObject("error", "emptyhistory");
		}

		response.addHeader("Cache-Control", "no-cache");
		response.addHeader("Pragma", "no-cache");
		return mav;
	}

	private void populateHistoryScope(ModelAndView mav, BPMTokenView selectedToken) {
		this.populateHistoryScope(mav, selectedToken.getReport(), selectedToken.getWorkflow(),
				selectedToken.getLastActor(), selectedToken.getLastModified());
	}

	private void populateHistoryScope(ModelAndView mav, String reportname, String workflowName, String submitBy,
			Date submitDate) {
		mav.addObject("reportname", reportname);
		mav.addObject("submitdate", submitDate);
		mav.addObject("BPMWorkflowName", workflowName);
		Payee submittingPayee = VaricentContext.getPayee(submitBy);
		String submitByLabel = submittingPayee == null ? submitBy : submittingPayee.getDisplayName();
		mav.addObject("submitby", submitByLabel);
	}

	@RequestMapping(value = { "/bpm/view.html" }, method = { RequestMethod.POST })
	public RedirectView processForm(@ModelAttribute("command") ReportingCommand cmd, HttpServletRequest request) {
		RedirectView redirect = new RedirectView("view.html");
		WebUtils.setSessionAttribute(request, "ParametersMap", this.getParams(request, true));
		redirect.setExposeModelAttributes(true);
		if (!cmd.checkAndUpdateToken()) {
			WebUtils.setSessionAttribute(request, "error", Messages.Key.BPM_ERROR_VIEW);
		} else if (this.hasTokenIDParam(request)) {
			int tokenId = Integer.parseInt(request.getParameter("bpmTokenID"));
			long tokenVersion = Long.parseLong(request.getParameter("bpmTokenVersion"));
			redirect.setUrl("view.html?bpmTokenID=" + tokenId);
			WebUtils.setSessionAttribute(request, "tokenId", tokenId);
			WebUtils.setSessionAttribute(request, "tokenVersion", tokenVersion);
			WebUtils.setSessionAttribute(request, "retrieveBPMParameters", false);
		} else {
			WebUtils.setSessionAttribute(request, "error", INVALID_TOKEN_ERROR);
		}

		for (String key : this.getParams(request, true).keySet()) {
			if (key.startsWith("SIG_STATUS_")) {
				HashSet<Integer> submitted = (HashSet) WebUtils.getSessionAttribute(request, "SigStatusSubmitted");
				if (submitted == null) {
					submitted = new HashSet();
				}

				submitted.add(cmd.getId());
				WebUtils.setSessionAttribute(request, "SigStatusSubmitted", submitted);
			}
		}

		return redirect;
	}

	private Map<String, Object> getParams(HttpServletRequest request, boolean post) {
		Map<String, Object> params = new HashMap();
		Enumeration<?> e = request.getParameterNames();

		while (e.hasMoreElements()) {
			String prefixedName = (String) e.nextElement();
			String value = request.getParameter(prefixedName).trim();
			this.addParams(prefixedName, post, params, value);
		}

		return params;
	}

	private void addParams(String prefixedName, boolean post, Map<String, Object> params, String value) {
		Assert.state("L_".length() == "P_".length());
		if (!prefixedName.equalsIgnoreCase("x") && !prefixedName.equalsIgnoreCase("y")) {
			String name = prefixedName.substring("L_".length());
			if (post) {
				if (prefixedName.startsWith("L_") && !params.containsKey(name)) {
					params.put(name, value);
				} else if (prefixedName.startsWith("P_")) {
					if (params.containsKey(name)) {
						params.remove(name);
					}

					params.put(name, value);
				} else if (!prefixedName.startsWith("IR_") && !prefixedName.startsWith("Edited_IR_")) {
					if (prefixedName.startsWith("Edited_DE_")) {
						params.put(prefixedName, value);
					} else if (prefixedName.startsWith("SIG_ID_")) {
						ArrayList<String> signatureIds = (ArrayList) params.get("SIGNATURE_IDS");
						if (signatureIds == null) {
							signatureIds = new ArrayList();
						}

						signatureIds.add(prefixedName.substring("SIG_ID_".length()));
						params.put("SIGNATURE_IDS", signatureIds);
					} else if (prefixedName.startsWith("SIG_STATUS_")) {
						params.put(prefixedName, value);
					}
				} else {
					params.put(prefixedName, value);
				}
			} else if (prefixedName.startsWith("L_")) {
				params.put(name, value);
			}

		}
	}

	private boolean hasTokenIDParam(HttpServletRequest request) {
		return request.getParameter("bpmTokenID") != null || WebUtils.getSessionAttribute(request, "tokenId") != null;
	}

	private BPMCommand getBPMCommand(HttpServletRequest request) throws DatabaseConcurrencyException {
		BPMCommand bc = new BPMCommand();
		int tokenID;
		long bpmTokenVersion;
		if (WebUtils.getSessionAttribute(request, "tokenId") == null) {
			tokenID = Integer.parseInt(request.getParameter("bpmTokenID"));
			bpmTokenVersion = this.bpmManager.getBPMTokenVersion(tokenID);
		} else {
			tokenID = (Integer) WebUtils.getSessionAttribute(request, "tokenId");
			bpmTokenVersion = (Long) WebUtils.getSessionAttribute(request, "tokenVersion");
		}

		bc.setBPMTokenID(tokenID);
		bc.setBPMTokenVersion(bpmTokenVersion);
		bc.updateToken();
		return bc;
	}

	private boolean populateReportModel(ModelAndView mav, ReportingCommand command, Map<String, Object> params,
			Map<Integer, Integer> visibleTabIdWorkflowObjectIdMap, int tokenID, Boolean retrieveBPMParameters) {
		boolean noError = true;
		command.addReferencesTable(this.reportingManager.getPayeeIDReferencedPort());
		command.updateToken();
		HashMap<String, Boolean> isViewableMap = this.bpmManager.getTokenLayoutVisibilityMap(tokenID);
		HashMap<String, Boolean> isEditableMap = this.bpmManager.getTokenLayoutEditabilityMap(tokenID);
		int formID = this.bpmManager.getFormID(tokenID);
		Rendering reportRendering = this.reportingManager.getRendering(command.getId(), params,
				visibleTabIdWorkflowObjectIdMap, isViewableMap, isEditableMap, formID, command, tokenID,
				retrieveBPMParameters);
		command.setCanExport(reportRendering.canExport());
		command.setCanBatchExport(command.getCanExport() && command.getPayeePicklistCount() == 1
				&& command.getPicklistPayeeIDs().size() > 0);
		mav.addObject("reportingCommand", command);
		if (reportRendering.getMessage() != null) {
			String message = reportRendering.getMessage().getKey().toString();
			mav.addObject("error", message);
			noError = false;
			if (reportRendering.getMessage().isInternalMessage()) {
				this.bpmManager.sendErrorToInitiator(tokenID,
						this.messages.getMessage(Messages.Key.BPM_ERROR_NODE_ACTION),
						this.messages.getMessage(reportRendering.getMessage()));
			}

			if (reportRendering.getMessage().getParams() != null) {
				mav.addObject("errorParams", reportRendering.getMessage().getParams());
			}
		}

		mav.addObject("reporting_styles", reportRendering.getStyles());
		mav.addObject("reporting_content", reportRendering.getContent());
		mav.addObject("javascript", reportRendering.getJavascript());
		this.cleanParams(params);
		mav.addObject("parameters", params);
		if (reportRendering.getParams() != null) {
			for (String name : reportRendering.getParams().keySet()) {
				if (!params.containsKey(name)) {
					params.put(name, reportRendering.getParams().get(name));
				}
			}
		}

		return noError;
	}

	@RequestMapping({ "/bpm/actionpath.do" })
	public ModelAndView actionPath(@ModelAttribute("bpmCommand") BPMCommand cmd,
			@ModelAttribute("reportingCommand") ReportingCommand rcmd, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			if (!cmd.checkAndUpdateToken()) {
				return new ModelAndView("bpm/view");
			}

			int tokenID = cmd.getBPMTokenID();
			long tokenVersion = cmd.getBPMTokenVersion();
			int pathID = Integer.parseInt(request.getParameter("bpmPathID"));
			this.bpmManager.updateBPMPreviousParameters(this.extractReportParameters(request), tokenID);
			this.bpmManager.moveToken(tokenID, tokenVersion, pathID, this.extractReportParameters(request));
		} catch (DatabaseConcurrencyException e) {
			ModelAndView mav = new ModelAndView("bpm/view");
			this.populateErrors(mav, e.getMessageObject().getKey().toString());
			return mav;
		}

		ModelAndView mav = new ModelAndView("redirect:tokenlist.html");
		return mav;
	}

	private void cleanParams(Map<String, Object> params) {
		ArrayList<String> signatureIDs = (ArrayList) params.get("SIGNATURE_IDS");
		if (signatureIDs != null) {
			for (String signatureId : signatureIDs) {
				params.remove("SIG_STATUS_" + signatureId);
				params.remove("SIG_ID_" + signatureId);
			}

			params.remove("SIGNATURE_IDS");
		}

	}

	@RequestMapping(value = { "/bpm/savesubmit.do" }, method = { RequestMethod.POST })
	public ModelAndView saveSubmit(@ModelAttribute("bpmCommand") BPMCommand cmd, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("bpm/view");
		if (!cmd.checkAndUpdateToken()) {
			return mav;
		} else {
			Map<String, Object> params = this.getParams(request, true);
			WebUtils.setSessionAttribute(request, "ParametersMap", params);
			boolean hasError = !this.populateMAV(mav, request, response);
			if (hasError) {
				return mav;
			} else {
				try {
					int tokenID = Integer.parseInt(request.getParameter("report_bpmTokenID"));
					long tokenVersion = Long.parseLong(request.getParameter("bpmTokenVersion"));
					int pathID = Integer.parseInt(request.getParameter("report_bpmPathID"));
					this.bpmManager.updateBPMPreviousParameters(this.extractReportParameters(request), tokenID);
					this.bpmManager.moveToken(tokenID, tokenVersion, pathID, params);
				} catch (DatabaseConcurrencyException e) {
					mav = new ModelAndView("bpm/view");
					mav.addObject("error", e.getMessageObject().getKey().toString());
					return mav;
				}

				mav = new ModelAndView("redirect:tokenlist.html");
				return mav;
			}
		}
	}

	HashMap<String, Object> extractReportParameters(HttpServletRequest request) {
		HashMap<String, Object> params = new HashMap();

		for (String key : this.getParams(request, true).keySet()) {
			if (!key.startsWith("DE_") && !key.startsWith("IR_") && !key.startsWith("Edited_")) {
				params.put(key, this.getParams(request, true).get(key));
			}
		}

		return params;
	}

	static {
		INVALID_TOKEN_ERROR = Messages.Key.BPM_TOKEN_ERROR_VIEW.toString();
	}
}
