package com.varicent.api;

public enum APIAuthenticationType {
	USERNAME_PASSWORD, SSO;
}
