package com.varicent.payeeledger.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.varicent.common.adjustment.dao.AdjustmentDao;
import com.varicent.common.calculation.dao.CalculationDao;
import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.dao.PlanDao;
import com.varicent.common.plan.domain.Plan;
import com.varicent.common.port.dao.PortDao;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.reference.dao.ReferenceDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.schema.dao.cached.SchemaDaoCachedImpl;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.DataRow;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.payeeledger.dao.PayeeLedgerDao;
import com.varicent.payeeledger.domain.TailoredReport;
import com.varicent.workflow.dao.WorkflowDao;

public abstract class AbstractJdbcLedgerDaoImpl implements PayeeLedgerDao {
	protected final RowMapper<Payee> payeeMapper = new RowMapper<Payee>() {
		@Override
		public Payee mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new Payee(rs.getString("PayeeID_"), rs.getString("Name_"));
		}
	};
	protected final RowMapper<Plan> planMapper = new RowMapper<Plan>() {
		@Override
		public Plan mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new Plan(rs.getString("CompPlanID"), rs.getString("Name"));
		}
	};
	protected final DataSource ds;
	protected final JdbcOperations operations;
	protected final AdjustmentDao adjustmentDao;
	protected final CalculationDao calculationDao;
	protected final ConfigDao configDao;
	protected final CustomizeDao customizeDao;
	protected final HistoryDao historyDao;
	protected final PayeeDao payeeDao;
	protected final PlanDao planDao;
	protected final ReferenceDao referenceDao;
	protected final TimeDao timeDao;
	protected final WorkflowDao workflowDao;
	protected final PortDao portDao;
	private final SchemaDao schemaDao;

	protected AbstractJdbcLedgerDaoImpl(DataSource ds, AdjustmentDao adjustmentDao, CalculationDao calculationDao,
			ConfigDao configDao, CustomizeDao customizeDao, HistoryDao historyDao, PayeeDao payeeDao, PlanDao planDao,
			ReferenceDao referenceDao, TimeDao timeDao, WorkflowDao workflowDao, SchemaDao schemaDao, PortDao portDao) {
		this.ds = ds;
		this.operations = Database.getOperations(ds);
		this.adjustmentDao = adjustmentDao;
		this.calculationDao = calculationDao;
		this.configDao = configDao;
		this.customizeDao = customizeDao;
		this.historyDao = historyDao;
		this.payeeDao = payeeDao;
		this.planDao = planDao;
		this.referenceDao = referenceDao;
		this.timeDao = timeDao;
		this.workflowDao = workflowDao;
		this.schemaDao = schemaDao;
		this.portDao = portDao;
	}

	@Override
	public String getCalendar(String planId) {
		QueryDefinition query = new QueryDefinition("CompPlan");
		Join joinReportList = new Join("ReportList", Join.Type.INNER);
		joinReportList.newConstraint("CompPlan", "ReportQueueID", Constraint.Operator.Equals, "ReportList",
				"ReportListID");
		query.joinWith(joinReportList);
		Join joinReport = new Join("Report", Join.Type.INNER);
		joinReport.newConstraint("ReportList", "ReportListID", Constraint.Operator.Equals, "Report", "ReportListID");
		query.joinWith(joinReport);
		Join joinCalc = new Join("Calculation", Join.Type.INNER);
		joinCalc.newConstraint("Report", "CalculationID", Constraint.Operator.Equals, "Calculation", "CalculationID");
		query.joinWith(joinCalc);
		Join joinCat = new Join("CalculationCategoryTime", Join.Type.LEFT);
		joinCat.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "CalculationCategoryTime",
				"CalculationID");
		query.joinWith(joinCat);
		Join tsJoin = new Join("TimeShift", Join.Type.LEFT);
		tsJoin.newConstraint("Calculation", "CalculationID", Constraint.Operator.Equals, "TimeShift", "CalculationID");
		query.joinWith(tsJoin);
		query.selectDistinct();
		query.select("Calculation", "Type");
		query.select("Calculation", "CalendarUsed");
		query.select("CalculationCategoryTime", "CalendarUsed", "CatCalendarUsed");
		query.select("TimeShift", "TimeID", "TimeShiftCalendarUsed");
		query.newConstraint("CompPlan", "CompPlanID", Constraint.Operator.Equals, planId);
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet result = this.operations.queryForRowSet(qb.toSql(query));
		String calendar = null;

		while (result.next()) {
			String cal;
			if (result.getInt("Type") == 4) {
				cal = result.getString("CatCalendarUsed");
			} else if (result.getInt("Type") == 2) {
				cal = result.getString("TimeShiftCalendarUsed");
			} else {
				cal = result.getString("CalendarUsed");
			}

			if (cal != null) {
				if (calendar == null) {
					calendar = cal;
				} else if (!calendar.equals(cal)) {
					return null;
				}
			}
		}

		return calendar;
	}

	@Override
	public final List<DataRow> getLedger(String planId, String payeeId, TimePeriod period, boolean repeatHeader) {
		return this.getLedger(planId, payeeId, period, repeatHeader, new SchemaDaoCachedImpl(this.schemaDao));
	}

	protected abstract List<DataRow> getLedger(String var1, String var2, TimePeriod var3, boolean var4, SchemaDao var5);

	@Override
	public Payee getPayee(String payeeId) {
		return this.payeeDao.getPayee(payeeId);
	}

	@Override
	public List<Payee> getPayees(String planId) {
		String idTable;
		String idColumn;
		if (TailoredReport.isReport(planId)) {
			idTable = "TailoredReport";
			idColumn = "ID";
		} else {
			idTable = "CompPlan";
			idColumn = "CompPlanID";
		}

		QueryDefinition query = new QueryDefinition(idTable);
		query.selectDistinct();
		query.select("Payee_", "PayeeID_");
		query.select("Payee_", "Name_");
		Join groupJoin = new Join("GroupMember_", Join.Type.INNER);
		groupJoin.newConstraint(idTable, "PayeeGroupID", Constraint.Operator.Equals, "GroupMember_", "PayeeGroupID_");
		query.joinWith(groupJoin);
		Join payeeJoin = new Join("Payee_", Join.Type.INNER);
		payeeJoin.newConstraint("GroupMember_", "PayeeID_", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(payeeJoin);
		if (planId != null) {
			query.newConstraint(idTable, idColumn, Constraint.Operator.Equals, planId);
		}

		query.orderBy("Payee_", "PayeeID_");
		QueryBuilder qb = Database.getQueryBuilder();
		List<Payee> result = this.operations.query(qb.toSql(query), this.payeeMapper);
		Set<String> visiblePayees = this.workflowDao.getAuthorizedPayeeIds(planId);
		List<Payee> payees = new ArrayList();
		if (!result.isEmpty()) {
			for (Payee payee : result) {
				if (visiblePayees.contains(payee.getId())) {
					payees.add(payee);
				}
			}
		}

		return payees;
	}

	@Override
	public final List<TimePeriod> getPeriods(String planId) {
		return this.getPeriods(planId, new SchemaDaoCachedImpl(this.schemaDao));
	}

	protected abstract List<TimePeriod> getPeriods(String var1, SchemaDao var2);

	@Override
	public Plan getPlan(String planId) {
		return this.planDao.getPlan(planId);
	}

	@Override
	public List<Plan> getPlans(String payeeId) {
		QueryDefinition query = new QueryDefinition("CompPlan");
		query.selectDistinct();
		query.select("CompPlan", "CompPlanID");
		query.select("CompPlan", "Name");
		if (payeeId != null) {
			Join join = new Join("GroupMember_", Join.Type.INNER);
			join.newConstraint("CompPlan", "PayeeGroupID", Constraint.Operator.Equals, "GroupMember_", "PayeeGroupID_");
			query.joinWith(join);
			query.newConstraint("GroupMember_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		}

		query.newConstraint("CompPlan", "InProduction", Constraint.Operator.Equals, 1);
		query.orderBy("CompPlan", "CompPlanID");
		QueryBuilder qb = Database.getQueryBuilder();
		List<Plan> result = this.operations.query(qb.toSql(query), this.planMapper);
		Set<String> visiblePlans = this.workflowDao.getAuthorizedPlanIds();
		List<Plan> plans = new ArrayList();
		if (!result.isEmpty()) {
			for (Plan plan : result) {
				if (visiblePlans.contains(plan.getId())) {
					plans.add(plan);
				}
			}
		}

		return plans;
	}

	@Override
	public Set<String> getAuthorizedPlanIds() {
		return this.workflowDao.getAuthorizedPlanIds();
	}
}
