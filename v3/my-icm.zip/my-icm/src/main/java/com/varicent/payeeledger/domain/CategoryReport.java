package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;

public class CategoryReport extends Report {
	private final String resultTable;
	private final String sourceTable;
	private final String payeeColumn;

	public CategoryReport(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, String resultTable, String sourceTable, String payeeColumn, boolean showHeader,
			boolean showPriorPeriods, boolean suppressEmptyReports, boolean suppressSummary) {
		super(reportId, calculationId, name, resultName, calendar, format, showHeader, showPriorPeriods,
				suppressEmptyReports, suppressSummary);
		this.resultTable = resultTable;
		this.sourceTable = sourceTable;
		this.payeeColumn = payeeColumn;
	}

	public String getResultTable() {
		return this.resultTable;
	}

	public String getSourceTable() {
		return this.sourceTable;
	}

	public String getPayeeColumn() {
		return this.payeeColumn;
	}

	public boolean hasPayeeColumn() {
		return this.payeeColumn != null;
	}
}
