package com.varicent.core.math.expressions;

public class AssignableString implements AssignableNode {
	private String name;
	private NodeString valueNode;

	public AssignableString(String name, String alias, int suffix) {
		this.name = name;
		this.valueNode = new NodeString("", alias, suffix);
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public EvaluateNode getNode() {
		return this.valueNode;
	}

	@Override
	public void setValue(Object value) {
		this.valueNode.setValue((String) value);
	}
}
