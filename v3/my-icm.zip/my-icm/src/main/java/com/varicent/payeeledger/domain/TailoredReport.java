package com.varicent.payeeledger.domain;

public class TailoredReport {
	private static final String ID_PREFIX = "R";
	private final String id;
	private final String name;

	public static boolean isReport(String planId) {
		return planId.startsWith("R");
	}

	public TailoredReport(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}
}
