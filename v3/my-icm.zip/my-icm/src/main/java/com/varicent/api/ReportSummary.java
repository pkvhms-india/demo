package com.varicent.api;

import java.util.ArrayList;
import java.util.Map;

public class ReportSummary {
	String name;
	String category;
	float summary;
	Map<String, ArrayList<Object>> data;

	public ReportSummary() {
	}

	public ReportSummary(String name, String category, float summary, Map<String, ArrayList<Object>> data) {
		this.name = name;
		this.category = category;
		this.summary = summary;
		this.data = data;
	}

	public String getName() {
		return this.name;
	}

	public String getCategory() {
		return this.category;
	}

	public float getSummary() {
		return this.summary;
	}

	public Map<String, ArrayList<Object>> getData() {
		return this.data;
	}
}
