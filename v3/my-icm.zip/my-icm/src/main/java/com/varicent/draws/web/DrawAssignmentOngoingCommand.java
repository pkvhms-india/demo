package com.varicent.draws.web;

import java.util.ArrayList;
import java.util.List;

import com.varicent.draws.domain.DrawAssignmentOngoing;

public class DrawAssignmentOngoingCommand extends DrawAssignmentCommand {
	private List<DrawAssignmentOngoing> ongoingAssignments = new ArrayList();
	private boolean hideInactivePayees;

	public List<DrawAssignmentOngoing> getOngoingAssignments() {
		return this.ongoingAssignments;
	}

	public void setOngoingAssignments(List<DrawAssignmentOngoing> ongoingAssignments) {
		this.ongoingAssignments = ongoingAssignments;
	}

	public boolean isHideInactivePayees() {
		return this.hideInactivePayees;
	}

	public void setHideInactivePayees(boolean hideInactivePayees) {
		this.hideInactivePayees = hideInactivePayees;
	}
}
