package com.varicent.customize.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.customize.service.CustomizeManager;

@Controller("customizeUpdateController")
@RequestMapping({ "/dataedit/edit.do" })
public class UpdateController extends EditController {
	@Autowired
	public UpdateController(CustomizeManager customizeManager, CustomizeValidator validator) {
		super(customizeManager, validator);
	}

	@Override
	protected void submitEdit(CustomizeCommand cmd, BindingResult result) throws DataSubmitException {
		if (!result.hasErrors() && cmd.checkAndUpdateToken()) {
			this.customizeManager.submitUpdate(cmd.getTable(), cmd.getOriginalDataRow(), cmd.getEditedDataRow());
		}

	}
}
