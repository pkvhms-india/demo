package com.varicent.draws.dao.jdbc;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.OrderItem;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectAggregate;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.NumericFormat;
import com.varicent.draws.dao.DrawReportDao;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.domain.DrawTemplate;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.draws.service.DrawAssignmentQuery;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.dao.jdbc.WorkflowQuery;
import com.varicent.workflow.domain.WorkflowObject;

@Repository("drawReportDao")
public class JdbcDrawReportDaoImpl implements DrawReportDao {
	private final JdbcOperations ops;
	private final TimeDao timeDao;
	private static final RowMapper<DataRow> assignmentsRowMapper = new RowMapper<DataRow>() {
		@Override
		public DataRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
			DataRow row = new DataRow();
			row.add(rs.getString("PayeeID"));
			row.add(rs.getString("Name"));
			row.add(rs.getString("TemplateName"));
			row.add(rs.getString("Start"));
			row.add(rs.getString("Ending"));
			return row;
		}
	};

	private static RowMapper<DataRow> getYTDDetailsRowMapper(final NumberFormat currencyFormat) {
		return new RowMapper<DataRow>() {
			@Override
			public DataRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
				DataRow row = new DataRow();
				row.add(rs.getString("PayeeID"));
				row.add(rs.getString("Name"));
				BigDecimal earnings = rs.getBigDecimal("Earnings");
				row.addCurrencyNumber(earnings == null ? BigDecimal.ZERO : earnings, currencyFormat);
				BigDecimal value = rs.getBigDecimal("Value");
				row.addCurrencyNumber(value == null ? BigDecimal.ZERO : value, currencyFormat);
				BigDecimal balance = rs.getBigDecimal("Balance");
				if (balance == null) {
					row.add((Object) null);
				} else {
					row.addCurrencyNumber(balance, currencyFormat);
				}

				BigDecimal payout = rs.getBigDecimal("Payout");
				row.addCurrencyNumber(payout == null ? BigDecimal.ZERO : payout, currencyFormat);
				return row;
			}
		};
	}

	private static RowMapper<DataRow> getByPeriodPayoutDetailsRowMapper(final NumberFormat currencyFormat) {
		return new RowMapper<DataRow>() {
			@Override
			public DataRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
				DataRow row = new DataRow();
				row.add(rs.getString("PayeeID"));
				row.add(rs.getString("Name"));
				row.add(rs.getString("Period"));
				BigDecimal earnings = rs.getBigDecimal("Earnings");
				row.addCurrencyNumber(earnings == null ? BigDecimal.ZERO : earnings, currencyFormat);
				BigDecimal amount = rs.getBigDecimal("Amount");
				row.addCurrencyNumber(amount == null ? BigDecimal.ZERO : amount, currencyFormat);
				BigDecimal value = rs.getBigDecimal("Value");
				row.addCurrencyNumber(value == null ? BigDecimal.ZERO : value, currencyFormat);
				BigDecimal balance = rs.getBigDecimal("Balance");
				if (balance == null) {
					row.add((Object) null);
				} else {
					row.addCurrencyNumber(balance, currencyFormat);
				}

				BigDecimal payout = rs.getBigDecimal("Payout");
				row.addCurrencyNumber(payout == null ? BigDecimal.ZERO : payout, currencyFormat);
				return row;
			}
		};
	}

	@Autowired
	public JdbcDrawReportDaoImpl(DataSource ds, TimeDao timeDao) {
		this.ops = Database.getOperations(ds);
		this.timeDao = timeDao;
	}

	@Override
	public boolean exists(int drawId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.selectCount();
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		return this.ops.queryForObject(qb.toSql(query), Integer.class) > 0;
	}

	@Override
	public String getCalendar(int drawID) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.select("DrawDefinition", "TimeID");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawID);
		List<String> result = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (result.size() > 0) {
			return result.get(0);
		} else {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		}
	}

	private String getLevel(int drawID) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.select("DrawDefinition", "Period");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawID);
		List<String> result = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (result.size() > 0) {
			return result.get(0);
		} else {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		}
	}

	private List<String> getTimeHierarchy(String calendar) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("Time_");
		query.select("Time_", "Level_");
		query.select("TimeParent", "Level_", "ParentLevel");
		query.select("TimeChild", "Level_", "ChildLevel");
		query.selectDistinct();
		Join parentJoin = new Join("Time_", "TimeParent", Join.Type.LEFT);
		parentJoin.newConstraint("TimeParent", "Name_", Constraint.Operator.Equals, "Time_", "Parent_");
		parentJoin.newConstraint("TimeParent", "TimeID_", Constraint.Operator.Equals, "Time_", "TimeID_");
		query.joinWith(parentJoin);
		Join childJoin = new Join("Time_", "TimeChild", Join.Type.LEFT);
		childJoin.newConstraint("TimeChild", "Parent_", Constraint.Operator.Equals, "Time_", "Name_");
		childJoin.newConstraint("TimeChild", "TimeID_", Constraint.Operator.Equals, "Time_", "TimeID_");
		query.joinWith(childJoin);
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, calendar);
		String bottomLevel = null;
		Map<String, String> levelToParentLevelMap = new HashMap();

		String level;
		for (SqlRowSet result = this.ops.queryForRowSet(qb.toSql(query)); result.next(); levelToParentLevelMap
				.put(level, result.getString("ParentLevel"))) {
			level = result.getString("Level_");
			if (result.getString("ChildLevel") == null) {
				bottomLevel = level;
			}
		}

		level = bottomLevel;

		List<String> hierarchy;
		for (hierarchy = new ArrayList(); level != null; level = levelToParentLevelMap.get(level)) {
			hierarchy.add(level);
		}

		return hierarchy;
	}

	private String getTemplateLevel(int templateId) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.select("DrawTemplate", "Level");
		query.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		List<String> templateLevels = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (templateLevels != null && templateLevels.size() != 1) {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		} else {
			return templateLevels.get(0);
		}
	}

	private String getLowestDrawLevel(int drawId, int templateId) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> timeHierarchy = this.getTimeHierarchy(this.getCalendar(drawId));
		String drawLevel = this.getLevel(drawId);
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.select("DrawTemplate", "Level");
		query.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		List<String> templateLevels = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (templateLevels != null && templateLevels.size() != 1) {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		} else {
			templateLevels.add(drawLevel);
			int minIndex = timeHierarchy.size() - 1;

			for (String templateLevel : templateLevels) {
				int index = timeHierarchy.indexOf(templateLevel);
				if (index >= 0 && index < minIndex) {
					minIndex = index;
				}
			}

			return timeHierarchy.get(minIndex);
		}
	}

	@Override
	public List<DrawTemplateName> getTemplates(int drawID) {
		return this.getTemplates(drawID, (Integer) null);
	}

	@Override
	public List<DrawTemplateName> getTemplates(int drawID, Integer templateId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = DrawAssignmentQuery.getDrawTemplatesQuery(drawID);
		if (templateId != null) {
			query.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		}

		return this.ops.query(qb.toSql(query), new RowMapper<DrawTemplateName>() {
			@Override
			public DrawTemplateName mapRow(ResultSet rs, int rowNumber) throws SQLException {
				DrawTemplate.TemplateType type = rs.getInt("Type") == 0 ? DrawTemplate.TemplateType.Recoverable
						: DrawTemplate.TemplateType.NonRecoverable;
				return new DrawTemplateName(rs.getInt("ID"), rs.getString("Name"), type);
			}
		});
	}

	@Override
	public List<Payee> getPayees(int drawID, int workflowObjectId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = getPayeesQuery(drawID, workflowObjectId);
		List<Payee> payees = this.ops.query(qb.toSql(query), new RowMapper<Payee>() {
			@Override
			public Payee mapRow(ResultSet rs, int rowNumber) throws SQLException {
				return new Payee(rs.getString("PayeeID_"), rs.getString("Name_"));
			}
		});
		return payees;
	}

	@Override
	public List<WorkflowGroupName> getWorflowGroups(int workflowObjectID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = DrawQuery.getWorkflowGroupsQuery(workflowObjectID);
		List<WorkflowGroupName> names = this.ops.query(qb.toSql(query), new RowMapper<WorkflowGroupName>() {
			@Override
			public WorkflowGroupName mapRow(ResultSet rs, int rowNumber) throws SQLException {
				return new WorkflowGroupName(rs.getInt("ID"), rs.getString("Name"));
			}
		});
		return names;
	}

	@Override
	public List<DataRow> getAssignments(int drawID, int templateId, String payeeId, String workflowGroupId, Date start,
			Date end, String sortColumn, boolean descending) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition(
				getAssignmentsQuery(drawID, templateId, payeeId, workflowGroupId, start, end), "DrawAssignments");
		if (sortColumn != null && !sortColumn.isEmpty()) {
			query.orderBy(sortColumn, descending);
		}

		return this.ops.query(qb.toSql(query), assignmentsRowMapper);
	}

	@Override
	public int getAssignmentsCount(int drawID, int templateId, String payeeId, String workflowGroupId, Date start,
			Date end) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = getAssignmentsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		QueryDefinition query = new QueryDefinition(inner, "DrawAssignments");
		query.selectCount();
		return (Integer) this.ops.queryForObject(qb.toSql(query), Integer.class);
	}

	@Override
	public List<DataRow> getAssignments(int drawID, int templateId, String payeeId, String workflowGroupId, Date start,
			Date end, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = getAssignmentsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		QueryDefinition query = DrawAssignmentQuery.getRowNumberQuery(inner, pageNumber, rowsPerPage,
				new String[] { sortColumn }, new boolean[] { descending });
		return this.ops.query(qb.toSql(query), assignmentsRowMapper);
	}

	private QueryDefinition getYTDPayoutDetailsQueryBase(int drawID, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) throws InvalidDrawException {
		String calendar = this.getCalendar(drawID);
		String level = this.getTemplateLevel(templateId);
		List<DrawTemplateName> templates = this.getTemplates(drawID, templateId);
		if (templates.size() == 0) {
			return null;
		} else {
			DrawTemplateName template = templates.get(0);
			QueryDefinition query = PayoutDetailsQuery.getYTDPayoutQuery(drawID, template, payeeId, workflowGroupId,
					calendar, level, start, end);
			return query;
		}
	}

	private QueryDefinition getYTDPayoutDetailsQuery(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end) throws InvalidDrawException {
		QueryDefinition ytdQueryUnion = this.getYTDPayoutDetailsQueryBase(drawID, templateId, payeeId, workflowGroupId,
				start, end);
		if (ytdQueryUnion == null) {
			return null;
		} else {
			DrawTemplateName template = this.getTemplates(drawID, templateId).get(0);
			QueryDefinition inner = new QueryDefinition(ytdQueryUnion, "YTDPayout");
			inner.select("YTDPayout", "PayeeID");
			inner.groupBy("YTDPayout", "PayeeID");
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Earnings", "Earnings"));
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Value", "Value"));
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Payout", "Payout"));
			QueryDefinition query = new QueryDefinition(inner, "YTDPayout");
			query.select("YTDPayout", "PayeeID");
			query.select("Payee_", "Name_", "Name");
			query.select("YTDPayout", "Earnings");
			query.select("YTDPayout", "Value");
			query.select("YTDPayout", "Payout");
			Join payeeJoin = new Join("Payee_", Join.Type.LEFT);
			payeeJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "YTDPayout", "PayeeID");
			query.joinWith(payeeJoin);
			if (template.getType().equals(DrawTemplate.TemplateType.Recoverable)) {
				query.select("DrawTemplateBalance", "Balance");
				Join join = new Join(PayoutDetailsQuery.getYTDDrawTemplateBalanceQuery(template, start, end),
						"DrawTemplateBalance", Join.Type.LEFT);
				join.newConstraint("DrawTemplateBalance", "PayeeID", Constraint.Operator.Equals, "YTDPayout",
						"PayeeID");
				query.joinWith(join);
			} else {
				query.select(Literal.newNullLiteral(), "Balance");
			}

			return query;
		}
	}

	private QueryDefinition getYTDPayoutTotalsQuery(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end) throws InvalidDrawException {
		QueryDefinition ytdQueryUnion = this.getYTDPayoutDetailsQueryBase(drawID, templateId, payeeId, workflowGroupId,
				start, end);
		if (ytdQueryUnion == null) {
			return null;
		} else {
			DrawTemplateName template = this.getTemplates(drawID, templateId).get(0);
			QueryDefinition inner = new QueryDefinition(ytdQueryUnion, "YTDPayout");
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Earnings", "Earnings"));
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Value", "Value"));
			inner.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDPayout", "Payout", "Payout"));
			QueryDefinition query = new QueryDefinition(inner, "YTDPayoutTotal");
			query.select("YTDPayoutTotal", "Earnings");
			query.select("YTDPayoutTotal", "Value");
			query.select("YTDPayoutTotal", "Payout");
			if (template.getType() == DrawTemplate.TemplateType.Recoverable) {
				query.select("YTDBalance", "Balance");
				QueryDefinition balanceQuery = new QueryDefinition(
						PayoutDetailsQuery.getYTDDrawTemplateBalanceQuery(template, start, end), "YTDBalance");
				balanceQuery
						.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "YTDBalance", "Balance", "Balance"));
				if (payeeId != null) {
					balanceQuery.newConstraint("YTDBalance", "PayeeID", Constraint.Operator.Equals, payeeId);
				} else if (workflowGroupId != null) {
					QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
					groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals,
							workflowGroupId);
					Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
					workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals,
							"YTDBalance", "PayeeID");
					balanceQuery.joinWith(workflowJoin);
				}

				Join join = new Join(balanceQuery, "YTDBalance", Join.Type.CROSS);
				query.joinWith(join);
			} else {
				query.select(Literal.newNullLiteral(), "Balance");
			}

			return query;
		}
	}

	@Override
	public int getYTDPayoutDetailsCount(int drawID, int templateId, String payeeId, String workflowGroupId, Date start,
			Date end) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = this.getYTDPayoutDetailsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		if (inner == null) {
			return 0;
		} else {
			QueryDefinition query = new QueryDefinition(inner, "YTDPayout");
			query.selectCount();
			return (Integer) this.ops.queryForObject(qb.toSql(query), Integer.class);
		}
	}

	@Override
	public List<DataRow> getYTDPayoutDetails(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end, String sortColumn, boolean descending) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.getYTDPayoutDetailsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		if (query == null) {
			return null;
		} else {
			if (sortColumn != null && !sortColumn.isEmpty()) {
				query.orderBy(sortColumn, descending);
			}

			NumberFormat currencyFormat = NumericFormat
					.getNumericCurrencyFormatter(this.getDrawReportWebSettings(drawID).getNumericStyle());
			currencyFormat.setRoundingMode(RoundingMode.HALF_UP);
			return this.ops.query(qb.toSql(query), getYTDDetailsRowMapper(currencyFormat));
		}
	}

	@Override
	public List<DataRow> getYTDPayoutDetails(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end, int pageNumber, int rowsPerPage, String sortColumn, boolean descending)
			throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = this.getYTDPayoutDetailsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		if (inner == null) {
			return null;
		} else {
			QueryDefinition query = DrawAssignmentQuery.getRowNumberQuery(inner, pageNumber, rowsPerPage,
					new String[] { sortColumn }, new boolean[] { descending });
			NumberFormat currencyFormat = NumericFormat
					.getNumericCurrencyFormatter(this.getDrawReportWebSettings(drawID).getNumericStyle());
			currencyFormat.setRoundingMode(RoundingMode.HALF_UP);
			return this.ops.query(qb.toSql(query), getYTDDetailsRowMapper(currencyFormat));
		}
	}

	@Override
	public DataRow getYTDPayoutTotals(int drawID, int templateId, String payeeId, String workflowGroupId, Date start,
			Date end) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.getYTDPayoutTotalsQuery(drawID, templateId, payeeId, workflowGroupId, start, end);
		if (query == null) {
			DataRow emptyResult = new DataRow();
			return emptyResult;
		} else {
			final NumberFormat currencyFormat = NumericFormat
					.getNumericCurrencyFormatter(this.getDrawReportWebSettings(drawID).getNumericStyle());
			currencyFormat.setRoundingMode(RoundingMode.HALF_UP);
			return this.ops.query(qb.toSql(query), new RowMapper<DataRow>() {
				@Override
				public DataRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
					DataRow row = new DataRow();
					BigDecimal earnings = rs.getBigDecimal("Earnings");
					row.addCurrencyNumber(earnings == null ? BigDecimal.ZERO : earnings, currencyFormat);
					BigDecimal value = rs.getBigDecimal("Value");
					row.addCurrencyNumber(value == null ? BigDecimal.ZERO : value, currencyFormat);
					BigDecimal balance = rs.getBigDecimal("Balance");
					row.addCurrencyNumber(balance == null ? BigDecimal.ZERO : balance, currencyFormat);
					BigDecimal payout = rs.getBigDecimal("Payout");
					row.addCurrencyNumber(payout == null ? BigDecimal.ZERO : payout, currencyFormat);
					return row;
				}
			}).get(0);
		}
	}

	private QueryDefinition getByPeriodPayoutDetailsQuery(int drawID, int templateId, Date start, Date end,
			String payeeId, String workflowGroupId) throws InvalidDrawException {
		String calendar = this.getCalendar(drawID);
		String level = this.getTemplateLevel(templateId);
		List<DrawTemplateName> templates = this.getTemplates(drawID, templateId);
		if (templates.size() == 0) {
			return null;
		} else {
			DrawTemplateName template = templates.get(0);
			QueryDefinition periodQuery = PayoutDetailsQuery.getByPeriodPayoutQuery(drawID, template, payeeId,
					workflowGroupId, calendar, level, start, end);
			if (periodQuery == null) {
				return null;
			} else {
				QueryDefinition query = new QueryDefinition(periodQuery, "PeriodPayout");
				query.select("PeriodPayout", "PayeeID");
				query.select("PeriodPayout", "Name");
				query.select("PeriodPayout", "Period");
				query.select("PeriodPayout", "PeriodEnd");
				query.select("PeriodPayout", "Amount");
				query.addSelect(new SelectAggregate(SelectAggregate.Type.SUM, "PeriodPayout", "Earnings", "Earnings"));
				query.select("PeriodPayout", "Value");
				query.select("PeriodPayout", "Balance");
				query.select("PeriodPayout", "Payout");
				query.groupBy("PeriodPayout", "PayeeID");
				query.groupBy("PeriodPayout", "Name");
				query.groupBy("PeriodPayout", "Period");
				query.groupBy("PeriodPayout", "PeriodEnd");
				query.groupBy("PeriodPayout", "Amount");
				query.groupBy("PeriodPayout", "Value");
				query.groupBy("PeriodPayout", "Balance");
				query.groupBy("PeriodPayout", "Payout");
				return query;
			}
		}
	}

	@Override
	public List<DataRow> getByPeriodPayoutDetails(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end, String sortColumn, boolean descending) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = this.getByPeriodPayoutDetailsQuery(drawID, templateId, start, end, payeeId,
				workflowGroupId);
		if (query == null) {
			return null;
		} else {
			if (sortColumn != null && !sortColumn.isEmpty()) {
				query.orderBy(sortColumn, descending);
				if (!sortColumn.equals("PeriodEnd")) {
					query.orderBy("PeriodEnd");
				}
			} else {
				query.orderBy("PayeeID_");
				query.orderBy("PeriodEnd");
			}

			NumberFormat currencyFormat = NumericFormat
					.getNumericCurrencyFormatter(this.getDrawReportWebSettings(drawID).getNumericStyle());
			currencyFormat.setRoundingMode(RoundingMode.HALF_UP);
			return this.ops.query(qb.toSql(query), getByPeriodPayoutDetailsRowMapper(currencyFormat));
		}
	}

	@Override
	public int getByPeriodPayoutDetailsCount(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = this.getByPeriodPayoutDetailsQuery(drawID, templateId, start, end, payeeId,
				workflowGroupId);
		if (inner == null) {
			return 0;
		} else {
			QueryDefinition query = new QueryDefinition(inner, "PeriodPayout");
			query.selectCount();
			return (Integer) this.ops.queryForObject(qb.toSql(query), Integer.class);
		}
	}

	@Override
	public List<DataRow> getByPeriodPayoutDetails(int drawID, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end, int pageNumber, int rowsPerPage, String sortColumn, boolean descending)
			throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition inner = this.getByPeriodPayoutDetailsQuery(drawID, templateId, start, end, payeeId,
				workflowGroupId);
		if (inner == null) {
			return null;
		} else {
			String[] sortColumns;
			boolean[] descendingColumns;
			if (sortColumn.equals("PeriodEnd")) {
				sortColumns = new String[] { sortColumn };
				descendingColumns = new boolean[] { descending };
			} else {
				sortColumns = new String[] { sortColumn, "PeriodEnd" };
				descendingColumns = new boolean[] { descending, false };
			}

			QueryDefinition query = DrawAssignmentQuery.getRowNumberQuery(inner, pageNumber, rowsPerPage, sortColumns,
					descendingColumns);
			NumberFormat currencyFormat = NumericFormat
					.getNumericCurrencyFormatter(this.getDrawReportWebSettings(drawID).getNumericStyle());
			currencyFormat.setRoundingMode(RoundingMode.HALF_UP);
			return this.ops.query(qb.toSql(query), getByPeriodPayoutDetailsRowMapper(currencyFormat));
		}
	}

	@Override
	public BigDecimal getPayeesAssignedPercent(int drawId, int templateId, int workflowObjectId, String payeeId,
			String workflowGroupId, Date start, Date end) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition allPayeesQuery = new QueryDefinition("Payee_");
		allPayeesQuery.selectCount();
		if (payeeId != null) {
			allPayeesQuery.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		} else if (workflowGroupId != null) {
			QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
			groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, workflowGroupId);
			Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_",
					"PayeeID_");
			allPayeesQuery.joinWith(workflowJoin);
		}

		BigDecimal total = new BigDecimal((Integer) this.ops.queryForObject(qb.toSql(allPayeesQuery), Integer.class));
		if (total.compareTo(BigDecimal.ZERO) == 0) {
			return BigDecimal.ZERO;
		} else {
			QueryDefinition assignmentsQuery = getNumAssignedQuery(drawId, templateId, payeeId, workflowGroupId, start,
					end);
			BigDecimal numAssigned = new BigDecimal(
					(Integer) this.ops.queryForObject(qb.toSql(assignmentsQuery), Integer.class));
			return numAssigned.divide(total, 4, RoundingMode.HALF_UP).movePointRight(2);
		}
	}

	@Override
	public BigDecimal getOutstandingBalancePercent(int drawId, int templateId, String payeeId, String workflowGroupId,
			Date start, Date end) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition assignmentsQuery = getNumAssignedQuery(drawId, templateId, payeeId, workflowGroupId, start,
				end);
		BigDecimal numAssigned = new BigDecimal(
				(Integer) this.ops.queryForObject(qb.toSql(assignmentsQuery), Integer.class));
		if (numAssigned.compareTo(BigDecimal.ZERO) == 0) {
			return BigDecimal.ZERO;
		} else {
			List<DrawTemplateName> templates = this.getTemplates(drawId, templateId);
			if (templates.size() == 0) {
				return BigDecimal.ZERO;
			} else {
				QueryDefinition negative = new QueryDefinition(
						PayoutDetailsQuery.getYTDDrawTemplateBalanceQuery(templates.get(0), start, end), "DrawResults");
				negative.selectCount();
				negative.newConstraint("DrawResults", "Balance", Constraint.Operator.GreaterThan, 0);
				if (payeeId != null) {
					negative.newConstraint("DrawResults", "PayeeID", Constraint.Operator.Equals, payeeId);
				} else if (workflowGroupId != null) {
					QueryDefinition workflowQuery = new QueryDefinition("WorkflowGroupMember");
					workflowQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals,
							workflowGroupId);
					Join workflowJoin = new Join(workflowQuery, "WorkflowGroupMember", Join.Type.INNER);
					workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals,
							"DrawResults", "PayeeID");
					negative.joinWith(workflowJoin);
				}

				BigDecimal numNegative = new BigDecimal(
						(Integer) this.ops.queryForObject(qb.toSql(negative), Integer.class));
				return numNegative.divide(numAssigned, 4, RoundingMode.HALF_UP).movePointRight(2);
			}
		}
	}

	@Override
	public Map<String, BigDecimal> getAveragePayoutPercentByPeriod(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		if (this.getTemplates(drawId, templateId).size() == 0) {
			return null;
		} else {
			QueryDefinition query = new QueryDefinition("Time_");
			query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, this.getCalendar(drawId));
			query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, this.getLevel(drawId));
			if (end != null) {
				query.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, end);
			}

			if (start != null) {
				query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, start);
			}

			query.select("DrawPayout", "Value_");
			query.select("DrawPayout", "Amount");
			query.select("Time_", "Name_");
			Join join = new Join(OverviewQuery.getAveragePercentPayoutByPeriod(drawId, templateId, payeeId,
					workflowGroupId, start, end), "DrawPayout", Join.Type.LEFT);
			join.newConstraint("DrawPayout", "Ending_", Constraint.Operator.GreaterThanEquals, "Time_", "Starting_");
			join.newConstraint("DrawPayout", "Ending_", Constraint.Operator.LessThanEquals, "Time_", "Ending_");
			query.joinWith(join);
			query.orderBy("Time_", "Starting_");
			Map<String, BigDecimal> averages = new LinkedHashMap();
			Map<String, Integer> counts = new HashMap();
			SqlRowSet rows = this.ops.queryForRowSet(qb.toSql(query));

			while (rows.next()) {
				String period = rows.getString("Name_");
				BigDecimal value = rows.getBigDecimal("Value_");
				BigDecimal maxAmount = rows.getBigDecimal("Amount");
				if (value == null) {
					value = BigDecimal.ZERO;
				}

				if (maxAmount == null || maxAmount.compareTo(BigDecimal.ZERO) == 0) {
					value = BigDecimal.ZERO;
					maxAmount = BigDecimal.ONE;
				}

				if (counts.containsKey(period)) {
					int count = counts.get(period);
					averages.put(period, averages.get(period).add(value.divide(maxAmount, RoundingMode.HALF_UP)));
					counts.put(period, count + 1);
				} else {
					averages.put(period, value.divide(maxAmount, RoundingMode.HALF_UP));
					counts.put(period, 1);
				}
			}

			for (String period : averages.keySet()) {
				averages.put(period, averages.get(period)
						.divide(new BigDecimal(counts.get(period)), RoundingMode.HALF_UP).movePointRight(2));
			}

			return averages;
		}
	}

	@Override
	public List<DataRow> getDrawsVsCommissionsByPeriod(int drawID, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		String calendar = this.getCalendar(drawID);
		String level = this.getLowestDrawLevel(drawID, templateId);
		if (this.getTemplates(drawID, templateId).size() == 0) {
			return null;
		} else {
			QueryDefinition periodQueryUnion = OverviewQuery.getDrawsAndCommissionsPayoutByPeriod(drawID, templateId,
					payeeId, workflowGroupId, start, end, level);
			QueryDefinition query = new QueryDefinition("Time_");
			query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, calendar);
			query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
			Join join = new Join(periodQueryUnion, "DrawsAndCommissions", Join.Type.LEFT);
			join.newConstraint("DrawsAndCommissions", "Name_", Constraint.Operator.Equals, "Time_", "Name_");
			query.joinWith(join);
			query.select("Time_", "Name_");
			query.select("DrawsAndCommissions", "Value");
			query.select("DrawsAndCommissions", "Payout");
			query.orderBy("Time_", "Starting_");
			if (start != null) {
				query.newConstraint("Time_", "Starting_", Constraint.Operator.GreaterThanEquals, start);
			}

			if (end != null) {
				query.newConstraint("Time_", "Ending_", Constraint.Operator.LessThanEquals, end);
			}

			return this.ops.query(qb.toSql(query), new RowMapper<DataRow>() {
				@Override
				public DataRow mapRow(ResultSet rs, int rowNumber) throws SQLException {
					DataRow row = new DataRow();
					row.add(rs.getString("Name_"));
					row.add(rs.getBigDecimal("Value"));
					row.add(rs.getBigDecimal("Payout"));
					return row;
				}
			});
		}
	}

	@Override
	public byte[] getLogo(int drawID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawReportWebSettings");
		query.select("DrawReportWebSettings", "Logo");
		query.newConstraint("DrawReportWebSettings", "BlockID", Constraint.Operator.Equals, drawID);
		List<byte[]> result = this.ops.query(qb.toSql(query), new RowMapper<byte[]>() {
			@Override
			public byte[] mapRow(ResultSet rs, int rowIndex) throws SQLException {
				return rs.getBytes("Logo");
			}
		});
		return result.size() == 0 ? null : (byte[]) result.get(0);
	}

	@Override
	public List<TimePeriod> getPeriods(int drawId, int templateId) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		String calendar = this.getCalendar(drawId);
		List<String> timeHierarchy = this.getTimeHierarchy(calendar);
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.select("DrawTemplate", "Level");
		query.selectDistinct();
		query.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		List<String> templateLevels = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		if (templateLevels.size() == 0) {
			return new ArrayList();
		} else {
			List<TimePeriod> result = new ArrayList();

			for (int i = timeHierarchy.size() - 1; i >= timeHierarchy.indexOf(templateLevels.get(0)) && i >= 0; --i) {
				result.addAll(this.timeDao.getTimePeriods(calendar, timeHierarchy.get(i), true));
			}

			return result;
		}
	}

	@Override
	public WorkflowGroupName getWorkflowGroup(int groupId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("WorkflowGroup");
		query.newConstraint("WorkflowGroup", "ID", Constraint.Operator.Equals, groupId);
		List<WorkflowGroupName> result = this.ops.query(qb.toSql(query), new RowMapper<WorkflowGroupName>() {
			@Override
			public WorkflowGroupName mapRow(ResultSet rs, int rowNumber) throws SQLException {
				return new WorkflowGroupName(rs.getInt("ID"), rs.getString("Name"));
			}
		});
		return result.size() == 0 ? null : (WorkflowGroupName) result.get(0);
	}

	@Override
	public DrawReportWebSettings getDrawReportWebSettings(int drawId) throws InvalidDrawException {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = getDrawReportWebSettingsQuery(drawId);
		List<DrawReportWebSettings> result = this.ops.query(qb.toSql(query), new RowMapper<DrawReportWebSettings>() {
			@Override
			public DrawReportWebSettings mapRow(ResultSet rs, int rowNumber) throws SQLException {
				Color reportColor = new Color(rs.getInt("R"), rs.getInt("G"), rs.getInt("B"));
				return new DrawReportWebSettings(rs.getInt("BlockID"), rs.getInt("WorkflowObjectID"),
						rs.getBoolean("allowGroupSelection"), rs.getInt("RowsPerPage"), reportColor,
						NumericFormat.Style.values()[rs.getInt("NumericStyle")]);
			}
		});
		if (result.size() > 0) {
			return result.get(0);
		} else {
			throw new InvalidDrawException(new Message(Messages.Key.DRAW_REPORT_ERROR_DOES_NOT_EXIST, new Object[0]));
		}
	}

	public static QueryDefinition getDrawReportWebSettingsQuery(int drawID) {
		QueryDefinition query = new QueryDefinition("DrawReportWebSettings");
		query.selectAll();
		query.newConstraint("DrawReportWebSettings", "BlockID", Constraint.Operator.Equals, drawID);
		return query;
	}

	public static QueryDefinition getPayeesQuery(int drawID, int workflowObjectID) {
		String payeeId = UserAccount.getCurrent().getPayeeId();
		QueryDefinition query = WorkflowQuery.getAuthorizedPayeeBaseQuery(payeeId);
		query.select("Payee_", "PayeeID_");
		query.select("Payee_", "Name_");
		query.selectDistinct();
		Join join = new Join("Payee_", Join.Type.INNER);
		join.newConstraint("DescendantMember", "PayeeID", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		query.newConstraint("WorkflowAssignment", "WorkflowObjectID", Constraint.Operator.Equals, workflowObjectID);
		return query;
	}

	public static QueryDefinition getOngoingTermQueryBase(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date periodStart, Date periodEnd) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentOngoingTerm");
		Join templateJoin = new Join("DrawTemplate", Join.Type.INNER);
		templateJoin.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, "DrawAssignmentOngoingTerm",
				"TemplateID");
		query.joinWith(templateJoin);
		Join definitionJoin = new Join("DrawDefinition", Join.Type.INNER);
		definitionJoin.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, "DrawTemplate",
				"BlockID");
		query.joinWith(definitionJoin);
		Join payeeJoin = new Join("Payee_", Join.Type.INNER);
		payeeJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "DrawAssignmentOngoingTerm",
				"PayeeID");
		query.joinWith(payeeJoin);
		if (workflowGroupId != null) {
			QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
			groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, workflowGroupId);
			Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_",
					"PayeeID_");
			query.joinWith(workflowJoin);
		}

		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "Time_", "TimeID_");
		timeJoin.newConstraint("DrawTemplate", "Level", Constraint.Operator.Equals, "Time_", "Level_");
		timeJoin.newConstraint("DrawAssignmentOngoingTerm", "StartDate", Constraint.Operator.GreaterThanEquals, "Time_",
				"Starting_");
		timeJoin.newConstraint("DrawAssignmentOngoingTerm", "StartDate", Constraint.Operator.LessThanEquals, "Time_",
				"Ending_");
		query.joinWith(timeJoin);
		Join endTimeJoin = new Join("Time_", "EndTime", Join.Type.LEFT);
		endTimeJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "EndTime", "TimeID_");
		endTimeJoin.newConstraint("DrawTemplate", "Level", Constraint.Operator.Equals, "EndTime", "Level_");
		endTimeJoin.newConstraint("DrawAssignmentOngoingTerm", "EndDate", Constraint.Operator.LessThanEquals, "EndTime",
				"Ending_");
		endTimeJoin.newConstraint("DrawAssignmentOngoingTerm", "EndDate", Constraint.Operator.GreaterThanEquals,
				"EndTime", "Starting_");
		query.joinWith(endTimeJoin);
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		query.newConstraint("DrawAssignmentOngoingTerm", "TemplateID", Constraint.Operator.Equals, templateId);
		if (payeeId != null) {
			query.newConstraint("DrawAssignmentOngoingTerm", "PayeeID", Constraint.Operator.Equals, payeeId);
		}

		if (periodStart != null && periodEnd != null) {
			OrClause endingConstraint = new OrClause();
			endingConstraint.newNullConstraint("EndTime", "Ending_", true);
			endingConstraint.newConstraint("EndTime", "Ending_", Constraint.Operator.GreaterThanEquals, periodStart);
			query.addConstraint(endingConstraint);
			query.newConstraint("DrawAssignmentOngoingTerm", "StartDate", Constraint.Operator.LessThanEquals,
					periodEnd);
		}

		return query;
	}

	public static QueryDefinition getFixedTermQueryBase(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date periodStart, Date periodEnd) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentFixedTerm");
		Join templateJoin = new Join("DrawTemplate", Join.Type.INNER);
		templateJoin.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, "DrawAssignmentFixedTerm",
				"TemplateID");
		query.joinWith(templateJoin);
		Join definitionJoin = new Join("DrawDefinition", Join.Type.INNER);
		definitionJoin.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, "DrawTemplate",
				"BlockID");
		query.joinWith(definitionJoin);
		Join payeeJoin = new Join("Payee_", Join.Type.INNER);
		payeeJoin.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, "DrawAssignmentFixedTerm", "PayeeID");
		query.joinWith(payeeJoin);
		if (workflowGroupId != null) {
			QueryDefinition groupQuery = new QueryDefinition("WorkflowGroupMember");
			groupQuery.newConstraint("WorkflowGroupMember", "GroupID", Constraint.Operator.Equals, workflowGroupId);
			Join workflowJoin = new Join(groupQuery, "WorkflowGroupMember", Join.Type.INNER);
			workflowJoin.newConstraint("WorkflowGroupMember", "PayeeID", Constraint.Operator.Equals, "Payee_",
					"PayeeID_");
			query.joinWith(workflowJoin);
		}

		Join startTimeJoin = new Join("Time_", Join.Type.INNER);
		startTimeJoin.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, "DrawDefinition", "TimeID");
		startTimeJoin.newConstraint("Time_", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		startTimeJoin.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, "DrawAssignmentFixedTerm",
				"StartDate");
		startTimeJoin.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals,
				"DrawAssignmentFixedTerm", "StartDate");
		query.joinWith(startTimeJoin);
		Join endTimeJoin = new Join("Time_", "EndTime", Join.Type.INNER);
		endTimeJoin.newConstraint("EndTime", "TimeID_", Constraint.Operator.Equals, "DrawDefinition", "TimeID");
		endTimeJoin.newConstraint("EndTime", "Level_", Constraint.Operator.Equals, "DrawTemplate", "Level");
		endTimeJoin.newConstraint("EndTime", "Ending_", Constraint.Operator.GreaterThanEquals,
				"DrawAssignmentFixedTerm", "EndDate");
		endTimeJoin.newConstraint("EndTime", "Starting_", Constraint.Operator.LessThanEquals, "DrawAssignmentFixedTerm",
				"EndDate");
		query.joinWith(endTimeJoin);
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		query.newConstraint("DrawAssignmentFixedTerm", "TemplateID", Constraint.Operator.Equals, templateId);
		if (payeeId != null) {
			query.newConstraint("DrawAssignmentFixedTerm", "PayeeID", Constraint.Operator.Equals, payeeId);
		}

		if (periodStart != null && periodEnd != null) {
			query.newConstraint("DrawAssignmentFixedTerm", "StartDate", Constraint.Operator.LessThanEquals, periodEnd);
			query.newConstraint("EndTime", "Ending_", Constraint.Operator.GreaterThanEquals, periodStart);
		}

		return query;
	}

	public static QueryDefinition getOngoingTermQuery(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date periodStart, Date periodEnd) {
		QueryDefinition query = getOngoingTermQueryBase(drawId, templateId, payeeId, workflowGroupId, periodStart,
				periodEnd);
		query.select("Payee_", "PayeeID_", "PayeeID");
		query.select("Payee_", "Name_", "Name");
		query.select("DrawTemplate", "Name", "TemplateName");
		query.select("Time_", "Name_", "Start");
		query.select("Time_", "Starting_", "StartDate");
		query.select("EndTime", "Name_", "Ending");
		query.select("EndTime", "Ending_", "EndDate");
		return query;
	}

	public static QueryDefinition getFixedTermQuery(int drawId, int templateId, String payeeId, String workflowGroupId,
			Date periodStart, Date periodEnd) {
		QueryDefinition query = getFixedTermQueryBase(drawId, templateId, payeeId, workflowGroupId, periodStart,
				periodEnd);
		query.select("Payee_", "PayeeID_");
		query.select("Payee_", "Name_");
		query.select("DrawTemplate", "Name", "TemplateName");
		query.select("Time_", "Name_", "Start");
		query.select("Time_", "Starting_", "StartDate");
		query.select("EndTime", "Name_", "Ending");
		query.select("EndTime", "Ending_", "EndDate");
		return query;
	}

	public static QueryDefinition getAssignmentsQuery(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) {
		QueryDefinition ongoing = getOngoingTermQuery(drawId, templateId, payeeId, workflowGroupId, start, end);
		ongoing.union(getFixedTermQuery(drawId, templateId, payeeId, workflowGroupId, start, end));
		return ongoing;
	}

	public static QueryDefinition getNumAssignedQuery(int drawId, int templateId, String payeeId,
			String workflowGroupId, Date start, Date end) {
		QueryDefinition ongoing = getOngoingTermQueryBase(drawId, templateId, payeeId, workflowGroupId, start, end);
		ongoing.select("Payee_", "PayeeID_");
		QueryDefinition fixed = getFixedTermQueryBase(drawId, templateId, payeeId, workflowGroupId, start, end);
		fixed.select("Payee_", "PayeeID_");
		ongoing.union(fixed);
		QueryDefinition inner = new QueryDefinition(ongoing, "assigned");
		inner.selectDistinct();
		QueryDefinition query = new QueryDefinition(inner, "result");
		query.selectCount();
		return query;
	}

	private List<Integer> getViewableDrawIDs() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition idQuery = WorkflowQuery.getViewableObjectsQuery(user.getPayeeId(),
				WorkflowObject.Type.DRAW_REPORT);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Integer> drawIds = this.ops.query(qb.toSql(idQuery), RowMapperUtil.getIntegerMapper());
		return drawIds;
	}

	@Override
	public boolean isViewableDraw(int drawId) {
		return this.getViewableDrawIDs().contains(drawId);
	}

	@Override
	public List<DrawName> getViewableDraws() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition idQuery = WorkflowQuery.getViewableObjectsQuery(user.getPayeeId(),
				WorkflowObject.Type.DRAW_REPORT);
		Join baseBlockJoin = new Join("BaseBlock", Join.Type.INNER);
		baseBlockJoin.newConstraint("BaseBlock", "BlockID", Constraint.Operator.Equals, "DrawReportWebSettings",
				"BlockID");
		idQuery.joinWith(baseBlockJoin);
		idQuery.select("BaseBlock", "Name");
		idQuery.addOrder(new OrderItem("BaseBlock", "Name", OrderItem.Direction.ASCENDING));
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(idQuery), new RowMapper<DrawName>() {
			@Override
			public DrawName mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new DrawName(rs.getInt("BlockID"), rs.getString("Name"));
			}
		});
	}
}
