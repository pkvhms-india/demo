package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.dao.DataAccessException;

import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.Format;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class TextControlExpander extends BaseExpander {
	public TextControlExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("TextControl")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("TextControl")) {
			this.streamReader.nextTag();
			XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String parameter = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("TextControl");
			writer.writeStartElement("Parameter");
			writer.writeCharacters("P_" + parameter);
			writer.writeEndElement();
			writer.writeStartElement("ParameterValue");
			Object paramValue = scope.getObject(parameter);
			if (scope.isNullDate(parameter)) {
				writer.writeCharacters("");
			} else {
				writer.writeCharacters(Format.asValueString(paramValue));
			}

			writer.writeEndElement();
			writer.writeStartElement("ReadOnly");
			writer.writeCharacters(editable ? "0" : "1");
			writer.writeEndElement();
			super.copyCurrentNode(writer);
			super.copyCurrentNode(writer);
			if (!this.streamReader.isEndElement()) {
				String sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
				String nameColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
				writer.writeStartElement("SourceTable");
				writer.writeCharacters(sourceName == null ? "" : sourceName);
				writer.writeEndElement();
				writer.writeStartElement("SourceNameColumn");
				writer.writeCharacters(nameColumn);
				writer.writeEndElement();
			}

			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}

	public static List<SelectOption> searchOptions(Scope scope, String sourceName, String nameColumn)
			throws DataAccessException, ReportOverLimitException {
		List<SelectOption> options = new ArrayList();
		if (sourceName != null && !sourceName.equals("")) {
			DataTable dataTable = scope.getDataTable(sourceName);

			for (DataRow row : dataTable.getRows()) {
				String name = row.getValue(dataTable.getColumnIndex(nameColumn));
				options.add(new SelectOption(name, name));
			}

			Collections.sort(options);
			return options;
		} else {
			return options;
		}
	}
}
