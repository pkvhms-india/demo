package com.varicent.core.database.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.varicent.core.database.Database;
import com.varicent.core.text.Format;

public class RowUtils {
	public static List<String> getFormattedRow(SqlRowSet data) {
		List<String> row = new ArrayList();
		int i = 0;

		for (int n = data.getMetaData().getColumnCount(); i < n; ++i) {
			row.add(Format.asValueString(data.getObject(i + 1)));
		}

		return row;
	}

	public static Object getObject(SqlRowSet data, String column) {
		String dbColumn = Database.getSyntax().toValidIdentifier(column);
		return data.getObject(dbColumn);
	}

	public static List<Object> getRow(SqlRowSet data) {
		List<Object> row = new ArrayList();
		int i = 0;

		for (int n = data.getMetaData().getColumnCount(); i < n; ++i) {
			row.add(data.getObject(i + 1));
		}

		return row;
	}

	private RowUtils() {
	}
}
