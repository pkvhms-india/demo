package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.Date;

import org.jdom.Element;

import com.varicent.core.util.Converter;

public class NodeDate extends JavascriptNode implements EvaluateNode {
	public static final String XmlNodeName = "Number";
	private Date value;

	public static NodeNumber fromXml(Element node, int suffix) {
		Element valueNode = (Element) node.getChildren().get(0);
		String value = valueNode.getText();
		BigDecimal decimal = new BigDecimal(value);
		return new NodeNumber(decimal, (String) null, suffix);
	}

	public NodeDate(Date Value, int suffix) {
		super(suffix);
		this.value = Value;
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal milliInDay = new BigDecimal(86400000);
		BigDecimal result = Converter.ConvertToBigDecimal(this.value.getTime());
		result = result.divide(milliInDay, 6);
		return result;
	}

	@Override
	public void reset() {
	}

	public void setValue(Date value) {
		this.value = value;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append(JavascriptUtil.getFunctionSigniture(this.getJSFunctionName(jsUtil)));
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.evaluate().toString());
		sb.append(";}");
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		assert false;

		return null;
	}
}
