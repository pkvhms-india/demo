package com.varicent.core.util;

public class Range<T> {
	public final T Start;
	public final T End;

	public Range(T start, T end) {
		this.Start = start;
		this.End = end;
	}
}
