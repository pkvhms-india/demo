package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

public class ExpressionEvaluator {
	private EvaluateNode tree;
	private AssignableNode[] variables;
	private List<AggregateNode> aggregateNodes;

	public ExpressionEvaluator(EvaluateNode tree, AssignableNode[] variables) {
		this(tree, variables, new ArrayList());
	}

	public ExpressionEvaluator(EvaluateNode tree, AssignableNode[] variables, List<AggregateNode> aggregateNodes) {
		this.tree = tree;
		this.variables = variables;
		this.aggregateNodes = aggregateNodes;
	}

	public BigDecimal evaluate() {
		return this.tree.evaluate();
	}

	public List<String> getVariables() {
		ArrayList<String> names = new ArrayList();

		for (AssignableNode variable : this.variables) {
			names.add(variable.getName());
		}

		return names;
	}

	public void reset() {
		this.tree.reset();
	}

	public void setValue(int indexOfVariable, BigDecimal value) {
		this.variables[indexOfVariable].setValue(value);
	}

	public void setValueOfString(int indexOfVariable, String value) {
		this.variables[indexOfVariable].setValue(value);
	}

	public boolean hasAggregate() {
		return this.aggregateNodes.size() > 0;
	}

	public void finalizeAggregates() {
		for (AggregateNode node : this.aggregateNodes) {
			node.finalize();
		}

	}

	public boolean evaluateExpression(DataTable data, int index, Scope scope) throws ReportOverLimitException {
		this.reset();
		List<String> variables = this.getVariables();
		int j = 0;

		for (int m = variables.size(); j < m; ++j) {
			this.setValue(j, this.GetVariableValue(variables.get(j), scope, data, index));
		}

		BigDecimal result = this.evaluate();
		return result.equals(BigDecimal.ONE);
	}

	public boolean evaluateExpressionWithSingleValue(BigDecimal value) {
		this.reset();
		List<String> variables = this.getVariables();
		int j = 0;

		for (int m = variables.size(); j < m; ++j) {
			this.setValue(j, value);
		}

		BigDecimal result = this.evaluate();
		return result.equals(BigDecimal.ONE);
	}

	private BigDecimal GetVariableValue(String variable, Scope scope, DataTable data, int index)
			throws ReportOverLimitException {
		String RowValuePrefix = "Source.";
		if (data != null && variable.startsWith("Source.")) {
			String columnName = variable.substring("Source.".length());
			return (BigDecimal) data.getObject(index, columnName);
		} else {
			return scope.isNull(variable) ? new BigDecimal(0) : (BigDecimal) scope.getObject(variable);
		}
	}
}
