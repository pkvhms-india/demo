package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.varicent.common.time.domain.Frequency;
import com.varicent.core.database.support.DataRow;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.SortColumn;

public class DataSetInfo {
	String sourceName;
	String displayColumn;
	String valueColumn;
	String sourceAlias;
	DataTable source;
	String renderType;
	String isPrimaryAxis;
	SortingInfo sortingInfo;
	ColumnLink link;

	public DataSetInfo(String sourceName, String displayColumn, String valueColumn, String sourceAlias,
			DataTable source, String renderType, String isPrimaryAxis, SortingInfo sortInfo, ColumnLink link) {
		this.sourceName = sourceName;
		this.displayColumn = displayColumn;
		this.valueColumn = valueColumn;
		this.sourceAlias = sourceAlias;
		this.source = source;
		this.renderType = renderType;
		this.isPrimaryAxis = isPrimaryAxis;
		this.sortingInfo = sortInfo;
		this.link = link;
	}

	public boolean matches(DataSetInfo other) {
		return this.sortingInfo.levelID.equals(other.sortingInfo.levelID)
				&& this.sortingInfo.timeID.equalsIgnoreCase(other.sortingInfo.timeID)
				&& this.source.getColumn(this.displayColumn).getType() == other.source.getColumn(other.displayColumn)
						.getType();
	}

	public static List<String> combineMatchingSets(List<DataSetInfo> sets, List<String> existingCategories,
			Scope scope) {
		DataTable merged = new DataTable("merged");
		DataSetInfo baseSet = sets.get(0);
		merged.addColumn(baseSet.displayColumn, baseSet.source.getColumn(baseSet.displayColumn).getType());
		HashMap<String, Integer> categoryCount = new HashMap();

		for (DataSetInfo set : sets) {
			if (!set.source.getRows().isEmpty()) {
				HashMap<String, Integer> temp = new HashMap();

				for (String category : existingCategories) {
					temp.put(category, -1);
				}

				for (DataRow row : set.source.getRows()) {
					String categoryName = row.getValue(set.source.getColumnIndex(set.displayColumn));
					if (temp.containsKey(categoryName)) {
						Integer tempInt = temp.get(categoryName);
						temp.remove(categoryName);
						temp.put(categoryName, tempInt + 1);
					} else {
						temp.put(categoryName, 1);
					}

					DataRow newRow = new DataRow();
					newRow.add(row.getObject(set.source.getColumnIndex(set.displayColumn)));
					merged.addRow(newRow);
				}

				for (String key : temp.keySet()) {
					if (temp.get(key) != -1) {
						if (categoryCount.containsKey(key)) {
							categoryCount.put(key, temp.get(key) + categoryCount.get(key));
						} else {
							existingCategories.add(key);
							categoryCount.put(key, temp.get(key));
						}
					}
				}
			}
		}

		if (baseSet.sortingInfo.levelID.equals("") && baseSet.sortingInfo.timeID.equals("")) {
			List<String> columns = new ArrayList();
			columns.add(baseSet.displayColumn);
			merged.sort(columns, baseSet.sortingInfo.sortDescending);
		} else {
			Frequency freq = new Frequency(baseSet.sortingInfo.timeID, baseSet.sortingInfo.levelID);
			SortColumn column = new SortColumn(baseSet.displayColumn, baseSet.sortingInfo.sortDescending, freq);
			List<SortColumn> columns = new ArrayList();
			columns.add(column);
			merged.sort(columns, scope.getCalendars());
		}

		ArrayList<String> categories = new ArrayList();

		for (DataRow row : merged.getRows()) {
			String categoryName = row.getValue(0);
			if (categoryCount.get(categoryName) != 0) {
				categories.add(categoryName);
				Integer tempCount = categoryCount.get(categoryName);
				categoryCount.remove(categoryName);
				categoryCount.put(categoryName, tempCount - 1);
			}
		}

		return categories;
	}
}
