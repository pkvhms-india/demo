package com.varicent.customize.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.varicent.customize.service.CustomizeManager;

@Controller
@RequestMapping({ "/dataedit/index.html" })
public class CustomizeController {
	private static final String VIEW = "customize/index";
	private final CustomizeManager customizeManager;
	private final CustomizeValidator validator;

	@Autowired
	public CustomizeController(CustomizeManager customizeManager, CustomizeValidator validator) {
		this.customizeManager = customizeManager;
		this.validator = validator;
	}

	@ModelAttribute("maxDataRows")
	public int getMaxDataRows() {
		return 100;
	}

	@ModelAttribute("tables")
	public Set<String> getTables() {
		return this.customizeManager.getViewableTables();
	}

	@RequestMapping(method = { RequestMethod.GET })
	public ModelAndView prepareView(HttpServletRequest request) throws ServletRequestBindingException {
		ModelAndView mav = new ModelAndView("customize/index");
		CustomizeCommand cmd = (CustomizeCommand) WebUtils.getSessionAttribute(request, "command");
		if (cmd == null) {
			cmd = new CustomizeCommand();
			if (request.getParameterMap().containsKey("table")) {
				String table = ServletRequestUtils.getStringParameter(request, "table");
				cmd.setTable(table);
				this.populateModel(mav, table, new ArrayList());
			}
		} else {
			BindingResult result = (BindingResult) WebUtils.getSessionAttribute(request, "errors");
			mav.addAllObjects(result.getModel());
			String table = cmd.getTable();
			if (table != null) {
				this.populateModel(mav, table, cmd.getFilterValues());
			}

			this.clearSession(request);
		}

		cmd.updateToken();
		mav.addObject("command", cmd);
		return mav;
	}

	@RequestMapping(method = { RequestMethod.POST })
	public ModelAndView processForm(@ModelAttribute("command") CustomizeCommand cmd, BindingResult result) {
		ModelAndView mav = new ModelAndView("customize/index");
		mav.addObject("command", cmd);
		if (!cmd.checkAndUpdateToken()) {
			return mav;
		} else {
			if (cmd.hasTableChanged()) {
				cmd.clear();
			} else {
				this.validator.validate(cmd, result);
			}

			String table = cmd.getTable();
			if (table != null) {
				this.populateModel(mav, table, (List) (result.hasErrors() ? new ArrayList() : cmd.getFilterValues()));
			}

			return mav;
		}
	}

	private void clearSession(HttpServletRequest request) {
		WebUtils.setSessionAttribute(request, "command", (Object) null);
		WebUtils.setSessionAttribute(request, "errors", (Object) null);
	}

	private void populateModel(ModelAndView mav, String table, List<String> filterValues) {
		mav.addObject("columns", this.customizeManager.getColumns(table));
		mav.addObject("rows", this.customizeManager.getData(table, filterValues));
		mav.addObject("pendingRows", this.customizeManager.getPendingRows(table, filterValues));
	}
}
