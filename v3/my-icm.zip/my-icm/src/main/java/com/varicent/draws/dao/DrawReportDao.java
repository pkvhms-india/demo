package com.varicent.draws.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.exceptions.InvalidDrawException;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawReportWebSettings;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.WorkflowGroupName;

public interface DrawReportDao {
	String getCalendar(int var1) throws InvalidDrawException;

	boolean exists(int var1);

	boolean isViewableDraw(int var1);

	List<DrawName> getViewableDraws();

	DrawReportWebSettings getDrawReportWebSettings(int var1) throws InvalidDrawException;

	byte[] getLogo(int var1);

	List<WorkflowGroupName> getWorflowGroups(int var1);

	WorkflowGroupName getWorkflowGroup(int var1);

	List<Payee> getPayees(int var1, int var2);

	List<DrawTemplateName> getTemplates(int var1);

	List<DrawTemplateName> getTemplates(int var1, Integer var2);

	List<TimePeriod> getPeriods(int var1, int var2) throws InvalidDrawException;

	List<DataRow> getAssignments(int var1, int var2, String var3, String var4, Date var5, Date var6, String var7,
			boolean var8);

	List<DataRow> getAssignments(int var1, int var2, String var3, String var4, Date var5, Date var6, int var7, int var8,
			String var9, boolean var10);

	int getAssignmentsCount(int var1, int var2, String var3, String var4, Date var5, Date var6);

	DataRow getYTDPayoutTotals(int var1, int var2, String var3, String var4, Date var5, Date var6)
			throws InvalidDrawException;

	List<DataRow> getYTDPayoutDetails(int var1, int var2, String var3, String var4, Date var5, Date var6, String var7,
			boolean var8) throws InvalidDrawException;

	List<DataRow> getYTDPayoutDetails(int var1, int var2, String var3, String var4, Date var5, Date var6, int var7,
			int var8, String var9, boolean var10) throws InvalidDrawException;

	int getYTDPayoutDetailsCount(int var1, int var2, String var3, String var4, Date var5, Date var6)
			throws InvalidDrawException;

	List<DataRow> getByPeriodPayoutDetails(int var1, int var2, String var3, String var4, Date var5, Date var6,
			String var7, boolean var8) throws InvalidDrawException;

	List<DataRow> getByPeriodPayoutDetails(int var1, int var2, String var3, String var4, Date var5, Date var6, int var7,
			int var8, String var9, boolean var10) throws InvalidDrawException;

	int getByPeriodPayoutDetailsCount(int var1, int var2, String var3, String var4, Date var5, Date var6)
			throws InvalidDrawException;

	BigDecimal getPayeesAssignedPercent(int var1, int var2, int var3, String var4, String var5, Date var6, Date var7);

	BigDecimal getOutstandingBalancePercent(int var1, int var2, String var3, String var4, Date var5, Date var6);

	Map<String, BigDecimal> getAveragePayoutPercentByPeriod(int var1, int var2, String var3, String var4, Date var5,
			Date var6) throws InvalidDrawException;

	List<DataRow> getDrawsVsCommissionsByPeriod(int var1, int var2, String var3, String var4, Date var5, Date var6)
			throws InvalidDrawException;
}
