package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeIsEmpty extends UnaryNode implements EvaluateNode {
	public NodeIsEmpty(List<EvaluateNode> args, int suffix) {
		super(args, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal test = this.arg.evaluate();
		return test == null ? BigDecimal.ONE : BigDecimal.ZERO;
	}

	@Override
	public void reset() {
		this.arg.reset();
	}

	@Override
	public String getJSMathFunctionName() {
		return "isEmpty";
	}
}
