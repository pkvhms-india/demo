package com.varicent.payeeledger.dao.jdbc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.varicent.common.adjustment.dao.AdjustmentDao;
import com.varicent.common.calculation.dao.CalculationDao;
import com.varicent.common.config.dao.ConfigDao;
import com.varicent.common.history.dao.HistoryDao;
import com.varicent.common.payee.dao.PayeeDao;
import com.varicent.common.plan.dao.PlanDao;
import com.varicent.common.plan.domain.Plan;
import com.varicent.common.port.dao.PortDao;
import com.varicent.common.reference.dao.ReferenceDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.common.time.domain.Frequency;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.payeeledger.domain.SummaryRow;
import com.varicent.payeeledger.domain.TailoredReport;
import com.varicent.workflow.dao.WorkflowDao;

@Repository("summaryLedgerDao")
public class JdbcSummaryLedgerDaoImpl extends AbstractJdbcLedgerDaoImpl {
	@Autowired
	public JdbcSummaryLedgerDaoImpl(DataSource ds, AdjustmentDao adjustmentDao, CalculationDao calculationDao,
			ConfigDao configDao, CustomizeDao customizeDao, HistoryDao historyDao, PayeeDao payeeDao, PlanDao planDao,
			ReferenceDao referenceDao, TimeDao timeDao, WorkflowDao workflowDao, SchemaDao schemaDao, PortDao portDao) {
		super(ds, adjustmentDao, calculationDao, configDao, customizeDao, historyDao, payeeDao, planDao, referenceDao,
				timeDao, workflowDao, schemaDao, portDao);
	}

	@Override
	public List<DataRow> getLedger(String planId, String payeeId, TimePeriod period, boolean repeatHeader,
			SchemaDao schemaDao) {
		if (TailoredReport.isReport(planId)) {
			return Collections.emptyList();
		} else {
			Set<String> authPayeeIds = this.workflowDao.getAuthorizedPayeeIds(planId);
			if (!authPayeeIds.contains(payeeId)) {
				return Collections.emptyList();
			} else {
				Plan plan = this.planDao.getPlan(planId);
				Frequency freq = this.timeDao.getFrequency(planId);
				List<TimePeriod> periods = this.timeDao.getTimePeriods(plan.getCalendar(), freq.getLevelId(), false);
				Date lockedDate = this.timeDao.getLockedDate(freq.getTimeId(), freq.getLevelId());
				ReportQuery reportQuery = new ReportQuery(this.ds, this.customizeDao, this.historyDao,
						this.referenceDao, this.timeDao, schemaDao);
				SummaryRowQuery rowQuery = new SummaryRowQuery(this.ds, reportQuery);
				List<SummaryRow> summary = rowQuery.getSummary(planId, payeeId, periods, lockedDate);
				BigDecimal totalEarnings = BigDecimal.ZERO;
				BigDecimal totalNetAdjustments = BigDecimal.ZERO;
				BigDecimal totalNetEarnings = BigDecimal.ZERO;
				BigDecimal totalPayment = BigDecimal.ZERO;

				for (SummaryRow row : summary) {
					totalEarnings = totalEarnings.add(row.getEarnings());
					totalNetAdjustments = totalNetAdjustments.add(row.getNetAdjustments());
					totalNetEarnings = totalNetEarnings.add(row.getNetEarnings());
					totalPayment = totalPayment.add(row.getPayment());
					row.addAdjustments(this.adjustmentDao.getManualAdjustments(planId, payeeId, row.getPeriod()));
				}

				BigDecimal totalPending = BigDecimal.ZERO;
				if (!summary.isEmpty()) {
					totalPending = summary.get(summary.size() - 1).getPending();
				}

				summary.add(new SummaryRow((Date) null, planId, payeeId, (TimePeriod) null, totalEarnings,
						totalNetAdjustments, totalNetEarnings, totalPending, totalPayment, true));
				return new ArrayList(summary);
			}
		}
	}

	@Override
	public List<TimePeriod> getPeriods(String planId, SchemaDao schemaDao) {
		return Collections.emptyList();
	}
}
