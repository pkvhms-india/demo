package com.varicent.core.exceptions;

public class InvalidNewPasswordException extends PasswordException {
	private static final long serialVersionUID = 1L;

	public InvalidNewPasswordException() {
	}

	public InvalidNewPasswordException(String message) {
		super(message);
	}

	public InvalidNewPasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidNewPasswordException(Throwable cause) {
		super(cause);
	}
}
