package com.varicent.core.math.expressions;

import java.math.BigDecimal;

public class AssignableNumber extends Assignable implements AssignableNode {
	public AssignableNumber(String name, String alias, int suffix) {
		super(name, alias, suffix);
	}

	@Override
	public void setValue(Object value) {
		if (value == null) {
			this.setNumericValue((BigDecimal) null);
		} else {
			this.setNumericValue((BigDecimal) value);
		}

	}
}
