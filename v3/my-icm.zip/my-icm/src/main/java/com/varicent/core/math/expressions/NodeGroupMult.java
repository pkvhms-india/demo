package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeGroupMult extends UnaryNode implements EvaluateNode, AggregateNode {
	private BigDecimal value = null;
	private boolean isFinalized;

	public NodeGroupMult(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.value;
		} else {
			BigDecimal argValue = this.arg.evaluate();
			if (this.value == null) {
				this.value = argValue;
			} else if (argValue != null) {
				this.value = this.value.multiply(argValue);
			}

			return this.value;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.value = null;
			this.arg.reset();
		}
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupMult";
	}
}
