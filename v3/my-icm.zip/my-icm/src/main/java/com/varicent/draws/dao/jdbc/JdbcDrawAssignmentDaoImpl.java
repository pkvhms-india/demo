package com.varicent.draws.dao.jdbc;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.CustomConstraint;
import com.varicent.common.query.domain.DeleteDefinition;
import com.varicent.common.query.domain.InsertDefinition;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrderItem;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.domain.UpdateDefinition;
import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.query.sql.delete.DeleteBuilder;
import com.varicent.common.query.sql.insert.InsertBuilder;
import com.varicent.common.query.sql.update.UpdateBuilder;
import com.varicent.common.query.xml.SourceDefinitionParser;
import com.varicent.common.time.dao.TimeDao;
import com.varicent.core.database.Database;
import com.varicent.core.database.support.RowMapperUtil;
import com.varicent.core.exceptions.DatabaseConcurrencyException;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.text.Parse;
import com.varicent.draws.dao.DrawAssignmentDao;
import com.varicent.draws.domain.DrawAssignmentFixedTerm;
import com.varicent.draws.domain.DrawAssignmentOngoing;
import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;
import com.varicent.draws.domain.DrawAssignmentWebSettings;
import com.varicent.draws.domain.DrawName;
import com.varicent.draws.domain.DrawSchedule;
import com.varicent.draws.domain.DrawTemplate;
import com.varicent.draws.domain.DrawTemplateName;
import com.varicent.draws.domain.PeriodAmount;
import com.varicent.draws.domain.WorkflowGroupName;
import com.varicent.draws.service.DrawAssignmentQuery;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.dao.jdbc.WorkflowQuery;
import com.varicent.workflow.domain.WorkflowObject;

@Repository("drawAssignmentDao")
public class JdbcDrawAssignmentDaoImpl implements DrawAssignmentDao {
	private final JdbcOperations ops;
	private final TimeDao timeDao;
	private final RowMapper<DrawAssignmentUnassignedPayee> payeeInfoMapper = new RowMapper<DrawAssignmentUnassignedPayee>() {
		@Override
		public DrawAssignmentUnassignedPayee mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new DrawAssignmentUnassignedPayee(rs.getString("PayeeID_"), rs.getString("Name_"),
					rs.getString("Title"), rs.getString("Parent"), rs.getString("ReportsTo"),
					rs.getDate("Date_Of_Hire"));
		}
	};
	private final RowMapper<DrawAssignmentWebSettings> drawAssignmentWebSettings = new RowMapper<DrawAssignmentWebSettings>() {
		@Override
		public DrawAssignmentWebSettings mapRow(ResultSet rs, int rowNumber) throws SQLException {
			SourceDefinition restriction = null;
			String resctrictionStr = rs.getString("Restriction");
			if (resctrictionStr != null) {
				try {
					restriction = SourceDefinitionParser.getSourceDefinition(resctrictionStr);
				} catch (XMLStreamException e) {
					throw new RuntimeException(e);
				}
			}

			return new DrawAssignmentWebSettings(rs.getInt("BlockID"), rs.getBoolean("AllowGroupSelection"),
					restriction, rs.getInt("WorkflowObjectID"), rs.getInt("RowsPerPage"),
					NumericFormat.Style.values()[rs.getInt("NumericStyle")]);
		}
	};
	private final RowMapper<DrawTemplateName> drawTemplateNameMapper = new RowMapper<DrawTemplateName>() {
		@Override
		public DrawTemplateName mapRow(ResultSet rs, int rowNumber) throws SQLException {
			DrawTemplate.TemplateType type = rs.getInt("Type") == 0 ? DrawTemplate.TemplateType.Recoverable
					: DrawTemplate.TemplateType.NonRecoverable;
			return new DrawTemplateName(rs.getInt("ID"), rs.getString("Name"), type);
		}
	};
	private final RowMapper<Payee> payeeMapper = new RowMapper<Payee>() {
		@Override
		public Payee mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new Payee(rs.getString("PayeeID_"), rs.getString("Name_"));
		}
	};
	private final RowMapper<WorkflowGroupName> workflowGroupNameMapper = new RowMapper<WorkflowGroupName>() {
		@Override
		public WorkflowGroupName mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new WorkflowGroupName(rs.getInt("ID"), rs.getString("Name"));
		}
	};
	private final RowMapper<Date> dateMapper = new RowMapper<Date>() {
		@Override
		public Date mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return rs.getDate(1);
		}
	};
	private final RowMapper<DrawTemplate> drawTemplateMapper = new RowMapper<DrawTemplate>() {
		@Override
		public DrawTemplate mapRow(ResultSet rs, int rowNumber) throws SQLException {
			int templateID = rs.getInt("ID");
			int drawID = rs.getInt("BlockID");
			String name = rs.getString("Name");
			String description = rs.getString("Description");
			int type = rs.getInt("Type");
			DrawTemplate.TemplateType templateType = type == 0 ? DrawTemplate.TemplateType.Recoverable
					: DrawTemplate.TemplateType.NonRecoverable;
			int duration = rs.getInt("Duration");
			int maxDuration = rs.getInt("MaxDuration");
			boolean ongoing = rs.getObject("Duration") == null;
			boolean canChangeDuration = rs.getObject("MaxDuration") != null;
			BigDecimal drawAmount = rs.getBigDecimal("DrawAmount");
			BigDecimal maxDrawAmout = rs.getBigDecimal("MaxDrawAmount");
			boolean canChangeDrawAmount = maxDrawAmout != null;
			boolean fixedAmount = drawAmount != null;
			String level = rs.getString("Level");
			return new DrawTemplate(templateID, name, drawID, description, templateType, duration, maxDuration, ongoing,
					drawAmount, maxDrawAmout, fixedAmount, canChangeDuration, canChangeDrawAmount, level);
		}
	};
	private final RowMapper<DrawSchedule> drawScheduleMapper = new RowMapper<DrawSchedule>() {
		@Override
		public DrawSchedule mapRow(ResultSet rs, int rowNumber) throws SQLException {
			BigDecimal amount = rs.getBigDecimal("Amount");
			int period = rs.getInt("Period");
			return new DrawSchedule(period, amount);
		}
	};

	@Autowired
	public JdbcDrawAssignmentDaoImpl(DataSource ds, TimeDao timeDao) {
		this.ops = Database.getOperations(ds);
		this.timeDao = timeDao;
	}

	@Override
	public List<WorkflowGroupName> getWorkflowGroups(int workflowObjectID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = DrawAssignmentQuery.getWorkflowGroupsQuery(workflowObjectID);
		List<WorkflowGroupName> names = this.ops.query(qb.toSql(query), this.workflowGroupNameMapper);
		List<WorkflowGroupName> nameSet = new LinkedList(names);
		return nameSet;
	}

	@Override
	public List<Payee> getFilterPayees(int workflowObjectID) {
		return this.getFilterPayees(workflowObjectID, (String) null);
	}

	private List<Payee> getFilterPayees(int workflowObjectID, String payeeId) {
		QueryDefinition query = DrawAssignmentQuery.getAvailablePayeesQuery(workflowObjectID);
		if (payeeId != null) {
			query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		}

		return this.getFilterPayees(query);
	}

	@Override
	public List<Payee> getFilterPayees(QueryDefinition restriction) {
		return this.getFilterPayees(restriction, (String) null);
	}

	private List<Payee> getFilterPayees(QueryDefinition restriction, String payeeId) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("Payee_");
		if (payeeId != null) {
			query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		}

		Join restrictionJoin = new Join(restriction, "CustomRestriction", Join.Type.INNER);
		restrictionJoin.newConstraint("CustomRestriction", "PayeeID_", Constraint.Operator.Equals, "Payee_",
				"PayeeID_");
		query.joinWith(restrictionJoin);
		List<Payee> names = this.ops.query(qb.toSql(query), this.payeeMapper);
		List<Payee> nameSet = new LinkedList(names);
		return nameSet;
	}

	@Override
	public boolean isViewablePayee(int workflowObjectID, String payeeId) {
		return this.getFilterPayees(workflowObjectID, payeeId).size() > 0;
	}

	@Override
	public boolean isViewablePayee(QueryDefinition restriction, String payeeId) {
		return this.getFilterPayees(restriction, payeeId).size() > 0;
	}

	@Override
	public List<DrawTemplateName> getDrawTemplates(int drawID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = DrawAssignmentQuery.getDrawTemplatesQuery(drawID);
		List<DrawTemplateName> templates = this.ops.query(qb.toSql(query), this.drawTemplateNameMapper);
		return templates;
	}

	@Override
	public DrawAssignmentWebSettings getSettings(int drawID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = DrawAssignmentQuery.getDrawAssignmentWebSettingsQuery(drawID);
		return this.ops.query(qb.toSql(query), this.drawAssignmentWebSettings).get(0);
	}

	@Override
	public String getPeriodName(Date startDate, String timeId, String level) {
		QueryDefinition query = new QueryDefinition("Time_");
		query.select("Time_", "Name_");
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		query.newConstraint("Time_", "Starting_", Constraint.Operator.LessThanEquals, startDate);
		query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, startDate);
		query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> result = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		return result.size() == 0 ? null : (String) result.get(0);
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(int groupID, int drawID, String effectiveDate,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = DrawAssignmentQuery.getUnAssignedPayeesQuery(groupID, drawID, lockedUntil,
				effectiveDate);
		query = DrawAssignmentQuery.getRowNumberQuery(query, pageNumber, rowsPerPage, new String[] { sortColumn },
				new boolean[] { descending });
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), this.payeeInfoMapper);
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> getUnAssignedPayees(QueryDefinition restriction, int drawID,
			String effectiveDate, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = new QueryDefinition("Payee_");
		Join join = new Join(restriction, "CustomRestriction", Join.Type.INNER);
		join.newConstraint("CustomRestriction", "PayeeID_", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		query = DrawAssignmentQuery.getUnAssignedPayeesQuery(query, drawID, lockedUntil);
		DrawAssignmentQuery.addPayeeInfoQuery(query, effectiveDate);
		query = DrawAssignmentQuery.getRowNumberQuery(query, pageNumber, rowsPerPage, new String[] { sortColumn },
				new boolean[] { descending });
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), this.payeeInfoMapper);
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> getUnAssignedPayeesAllGroups(int drawID, int workflowObjectID,
			String effectiveDate, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = DrawAssignmentQuery.getUnAssignedPayeesQueryAllGroups(drawID, workflowObjectID,
				lockedUntil, effectiveDate);
		query = DrawAssignmentQuery.getRowNumberQuery(query, pageNumber, rowsPerPage, new String[] { sortColumn },
				new boolean[] { descending });
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), this.payeeInfoMapper);
	}

	@Override
	public int getUnAssignedPayeesCount(int groupID, int drawID, String effectiveDate) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = DrawAssignmentQuery.getUnAssignedPayeesQuery(groupID, drawID, lockedUntil,
				effectiveDate);
		QueryDefinition countQuery = new QueryDefinition(query, "_inner");
		countQuery.selectCount();
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(countQuery), Integer.class);
	}

	@Override
	public int getUnAssignedPayeesCount(QueryDefinition restriction, int drawID, String effectiveDate) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = new QueryDefinition("Payee_");
		Join join = new Join(restriction, "CustomRestriction", Join.Type.INNER);
		join.newConstraint("CustomRestriction", "PayeeID_", Constraint.Operator.Equals, "Payee_", "PayeeID_");
		query.joinWith(join);
		query = DrawAssignmentQuery.getUnAssignedPayeesQuery(query, drawID, lockedUntil);
		DrawAssignmentQuery.addPayeeInfoQuery(query, effectiveDate);
		QueryDefinition countQuery = new QueryDefinition(query, "_inner");
		countQuery.selectCount();
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(countQuery), Integer.class);
	}

	@Override
	public int getUnAssignedPayeesAllGroupsCount(int drawID, int workflowObjectID, String effectiveDate) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = DrawAssignmentQuery.getUnAssignedPayeesQueryAllGroups(drawID, workflowObjectID,
				lockedUntil, effectiveDate);
		QueryDefinition countQuery = new QueryDefinition(query, "_inner");
		countQuery.selectCount();
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(countQuery), Integer.class);
	}

	@Override
	public DrawTemplate getDrawTemplate(int templateId) throws DatabaseConcurrencyException {
		QueryDefinition query = new QueryDefinition("DrawTemplate");
		query.selectAll();
		query.newConstraint("DrawTemplate", "ID", Constraint.Operator.Equals, templateId);
		QueryBuilder qb = Database.getQueryBuilder();
		List<DrawTemplate> result = this.ops.query(qb.toSql(query), this.drawTemplateMapper);
		if (result.isEmpty()) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			DrawTemplate template = result.get(0);
			if (!template.isFixedAmount()) {
				QueryDefinition scheduleQuery = new QueryDefinition("DrawSchedule");
				scheduleQuery.selectAll();
				scheduleQuery.newConstraint("DrawSchedule", "TemplateID", Constraint.Operator.Equals, template.getId());
				List<DrawSchedule> schedules = this.ops.query(qb.toSql(scheduleQuery), this.drawScheduleMapper);
				template.setSchedules(schedules);
			}

			return template;
		}
	}

	@Override
	public void assignToOngoing(String payeeId, int templateId, BigDecimal amount, Date startDate) {
		InsertDefinition insert = new InsertDefinition("DrawAssignmentOngoingTerm",
				new String[] { "PayeeID", "TemplateID", "StartDate", "Amount" });
		insert.addValue(payeeId);
		insert.addValue(templateId);
		insert.addValue(startDate);
		insert.addValue(amount);
		InsertBuilder ib = Database.getInsertBuilder();
		this.ops.update(ib.toSql(insert));
	}

	@Override
	public int assignToFixedterm(String payeeId, int templateId, Date startDate, Date endDate) {
		InsertDefinition insert = new InsertDefinition("DrawAssignmentFixedTerm",
				new String[] { "PayeeID", "TemplateID", "StartDate", "EndDate" });
		insert.addValue(payeeId);
		insert.addValue(templateId);
		insert.addValue(startDate);
		insert.addValue(endDate);
		InsertBuilder ib = Database.getInsertBuilder();
		this.ops.update(ib.toSql(insert));
		return (Integer) this.ops.queryForObject("SELECT SCOPE_IDENTITY()", Integer.class);
	}

	@Override
	public void addFixedTermPeriods(int assignmentID, Date periodStart, BigDecimal amount) {
		InsertDefinition insert = new InsertDefinition("DrawAssignmentFixedTermAmount",
				new String[] { "AssignmentID", "PeriodStart", "Amount" });
		insert.addValue(assignmentID);
		insert.addValue(periodStart);
		insert.addValue(amount);
		InsertBuilder ib = Database.getInsertBuilder();
		this.ops.update(ib.toSql(insert));
	}

	@Override
	public Date[] getPeriodStartStartingAt(Date startDate, int numOfPeriods, String level, String timeId) {
		QueryDefinition qd = new QueryDefinition("Time_");
		qd.select("Time_", "Starting_");
		qd.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		qd.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		qd.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, startDate);
		qd.orderBy("Starting_");
		qd.limitTo(numOfPeriods);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Date> periodStartDates = this.ops.query(qb.toSql(qd), this.dateMapper);
		Date[] result = new Date[numOfPeriods];
		return (Date[]) periodStartDates.toArray(result);
	}

	@Override
	public Date getPeriodEndDate(String timeId, String level, Date periodStart) {
		QueryDefinition qd = new QueryDefinition("Time_");
		qd.select("Time_", "Ending_");
		qd.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		qd.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		qd.newConstraint("Time_", "Starting_", Constraint.Operator.Equals, periodStart);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(qd), this.dateMapper).get(0);
	}

	private Date getLockedDate(int drawId) {
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.select("Time_", "Ending_");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "Time_", "TimeID_");
		query.joinWith(timeJoin);
		Join lockJoin = new Join("TimeCalendar", Join.Type.INNER);
		lockJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "TimeCalendar", "TimeID");
		lockJoin.newConstraint("Time_", "Name_", Constraint.Operator.Equals, "TimeCalendar", "LastLockedPeriod");
		query.joinWith(lockJoin);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Date> result = this.ops.query(qb.toSql(query), this.dateMapper);
		return result.size() == 0 ? null : (Date) result.get(0);
	}

	@Override
	public Date getCalendarStartDate(int drawId) {
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.select("Time_", "Starting_");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "Time_", "TimeID_");
		query.joinWith(timeJoin);
		query.orderBy("Time_", "Starting_");
		query.limitTo(1);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), this.dateMapper).get(0);
	}

	@Override
	public Date getCalendarEndDate(int drawId) {
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.select("Time_", "Ending_");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		Join timeJoin = new Join("Time_", Join.Type.INNER);
		timeJoin.newConstraint("DrawDefinition", "TimeID", Constraint.Operator.Equals, "Time_", "TimeID_");
		query.joinWith(timeJoin);
		query.orderBy("Time_", "Ending_", true);
		query.limitTo(1);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), this.dateMapper).get(0);
	}

	@Override
	public String getDrawTimeId(int drawId) {
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		query.select("DrawDefinition", "TimeID");
		QueryBuilder qb = Database.getQueryBuilder();
		List<String> result = this.ops.query(qb.toSql(query), RowMapperUtil.getStringMapper());
		return result.size() == 1 ? (String) result.get(0) : null;
	}

	@Override
	public String getEffectiveDateColumn(int drawId) {
		QueryDefinition query = new QueryDefinition("DrawDefinition");
		query.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		query.select("DrawDefinition", "EffectiveDateColumn");
		QueryBuilder qb = Database.getQueryBuilder();
		return (String) this.ops.queryForObject(qb.toSql(query), RowMapperUtil.getStringMapper());
	}

	@Override
	public List<DrawAssignmentUnassignedPayee> getUnAssignedListForPayee(String payeeID, int drawID,
			String effectiveDate) {
		Date lockedUntil = this.getLockedDate(drawID);
		QueryDefinition query = new QueryDefinition("Payee_");
		query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeID);
		DrawAssignmentQuery.addPayeeInfoQuery(query, effectiveDate);
		query = DrawAssignmentQuery.getUnAssignedPayeesQuery(query, drawID, lockedUntil);
		QueryBuilder qb = Database.getQueryBuilder();
		List<DrawAssignmentUnassignedPayee> payees = this.ops.query(qb.toSql(query), this.payeeInfoMapper);
		return payees;
	}

	@Override
	public void updateOngoing(DrawAssignmentOngoing ongoing, Date newStardDate, BigDecimal newDrawAmount)
			throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("DrawAssignmentOngoingTerm");
		update.set("StartDate", newStardDate);
		update.set("Amount", Literal.Type.DECIMAL, newDrawAmount);
		update.newConstraint("DrawAssignmentOngoingTerm", "AssignmentID", Constraint.Operator.Equals,
				ongoing.getAssignmentId());
		update.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentOngoingTerm", "_RowVersion", ongoing.getRowVersion()));
		UpdateBuilder ub = Database.getUpdateBuilder();
		if (this.ops.update(ub.toSql(update)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			this.UpdateOngoingRowVersion(ongoing, newStardDate);
		}
	}

	private void UpdateOngoingRowVersion(DrawAssignmentOngoing ongoing, Date newStardDate) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentOngoingTerm");
		query.select("DrawAssignmentOngoingTerm", "_RowVersion");
		query.newConstraint("DrawAssignmentOngoingTerm", "AssignmentID", Constraint.Operator.Equals,
				ongoing.getAssignmentId());
		QueryBuilder qb = Database.getQueryBuilder();
		byte[] rowVersionData = (byte[]) this.ops.queryForObject(qb.toSql(query), RowMapperUtil.getObjectMapper());
		ongoing.setRowVersion(this.getRowVersion(rowVersionData));
	}

	private void UpdateFixedTermRowVersion(DrawAssignmentFixedTerm fixedTerm) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentFixedTerm");
		query.select("DrawAssignmentFixedTerm", "_RowVersion");
		query.newConstraint("DrawAssignmentFixedTerm", "AssignmentID", Constraint.Operator.Equals,
				fixedTerm.getAssignmentId());
		QueryBuilder qb = Database.getQueryBuilder();
		byte[] rowVersionData = (byte[]) this.ops.queryForObject(qb.toSql(query), RowMapperUtil.getObjectMapper());
		fixedTerm.setRowVersion(this.getRowVersion(rowVersionData));
	}

	@Override
	public void UpdateFixedTermAmountRowVersion(int assignmentId, PeriodAmount periodAmount, Date newPeriodDate) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentFixedTermAmount");
		query.select("DrawAssignmentFixedTermAmount", "_RowVersion");
		query.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals, assignmentId);
		query.newConstraint("DrawAssignmentFixedTermAmount", "PeriodStart", Constraint.Operator.Equals, newPeriodDate);
		QueryBuilder qb = Database.getQueryBuilder();
		byte[] rowVersionData = (byte[]) this.ops.queryForObject(qb.toSql(query), RowMapperUtil.getObjectMapper());
		periodAmount.setRowVersion(this.getRowVersion(rowVersionData));
	}

	@Override
	public void clearOngoing(DrawAssignmentOngoing ongoing) throws DatabaseConcurrencyException {
		DeleteDefinition delete = new DeleteDefinition("DrawAssignmentOngoingTerm");
		delete.newConstraint("DrawAssignmentOngoingTerm", "AssignmentID", Constraint.Operator.Equals,
				ongoing.getAssignmentId());
		delete.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentOngoingTerm", "_RowVersion", ongoing.getRowVersion()));
		DeleteBuilder db = Database.getDeleteBuilder();
		if (this.ops.update(db.toSql(delete)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void setOngoingEndDate(DrawAssignmentOngoing ongoing, Date endDate) throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("DrawAssignmentOngoingTerm");
		update.set("EndDate", endDate);
		update.newConstraint("DrawAssignmentOngoingTerm", "AssignmentID", Constraint.Operator.Equals,
				ongoing.getAssignmentId());
		update.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentOngoingTerm", "_RowVersion", ongoing.getRowVersion()));
		UpdateBuilder ub = Database.getUpdateBuilder();
		if (this.ops.update(ub.toSql(update)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void updateFixedTermStartDate(DrawAssignmentFixedTerm fixedTerm, Date newStartDate)
			throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("DrawAssignmentFixedTerm");
		update.set("StartDate", newStartDate);
		update.newConstraint("DrawAssignmentFixedTerm", "AssignmentID", Constraint.Operator.Equals,
				fixedTerm.getAssignmentId());
		update.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentFixedTerm", "_RowVersion", fixedTerm.getRowVersion()));
		UpdateBuilder ub = Database.getUpdateBuilder();
		if (this.ops.update(ub.toSql(update)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			this.UpdateFixedTermRowVersion(fixedTerm);
		}
	}

	@Override
	public void terminateFixedTerm(DrawAssignmentFixedTerm fixedTerm, Date endDate)
			throws DatabaseConcurrencyException {
		this.setFixedTermEndDate(fixedTerm, endDate);
		DeleteDefinition delete = new DeleteDefinition("DrawAssignmentFixedTermAmount");
		delete.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals,
				fixedTerm.getAssignmentId());
		delete.newConstraint("DrawAssignmentFixedTermAmount", "PeriodStart", Constraint.Operator.GreaterThan, endDate);
		DeleteBuilder db = Database.getDeleteBuilder();
		if (this.ops.update(db.toSql(delete)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	private CustomConstraint getRowVersionConstraint(String table, String rowVersionColumn, long rowVersion) {
		return new CustomConstraint("CONVERT(BIGINT, " + table + "." + rowVersionColumn + ") = " + rowVersion);
	}

	@Override
	public void setFixedTermEndDate(DrawAssignmentFixedTerm fixedTerm, Date endDate)
			throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("DrawAssignmentFixedTerm");
		update.set("EndDate", endDate);
		update.newConstraint("DrawAssignmentFixedTerm", "AssignmentID", Constraint.Operator.Equals,
				fixedTerm.getAssignmentId());
		update.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentFixedTerm", "_RowVersion", fixedTerm.getRowVersion()));
		UpdateBuilder ub = Database.getUpdateBuilder();
		if (this.ops.update(ub.toSql(update)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			this.UpdateFixedTermRowVersion(fixedTerm);
		}
	}

	@Override
	public void deleteFixedTermPeriodAmount(int assignmentId, Date startDate, long rowVersion)
			throws DatabaseConcurrencyException {
		DeleteDefinition delete = new DeleteDefinition("DrawAssignmentFixedTermAmount");
		delete.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals, assignmentId);
		delete.newConstraint("DrawAssignmentFixedTermAmount", "PeriodStart", Constraint.Operator.Equals, startDate);
		delete.newCustomConstraint(
				this.getRowVersionConstraint("DrawAssignmentFixedTermAmount", "_RowVersion", rowVersion));
		DeleteBuilder db = Database.getDeleteBuilder();
		if (this.ops.update(db.toSql(delete)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void clearFixedTerm(int assignmentId, long rowVersion) throws DatabaseConcurrencyException {
		DeleteDefinition delete = new DeleteDefinition("DrawAssignmentFixedTerm");
		delete.newConstraint("DrawAssignmentFixedTerm", "AssignmentID", Constraint.Operator.Equals, assignmentId);
		delete.newCustomConstraint(this.getRowVersionConstraint("DrawAssignmentFixedTerm", "_RowVersion", rowVersion));
		DeleteBuilder db = Database.getDeleteBuilder();
		if (this.ops.update(db.toSql(delete)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		}
	}

	@Override
	public void updateFixedTermPeriodAmount(int assignmentId, PeriodAmount periodAmount, BigDecimal newAmount)
			throws DatabaseConcurrencyException {
		UpdateDefinition update = new UpdateDefinition("DrawAssignmentFixedTermAmount");
		update.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals, assignmentId);
		update.newConstraint("DrawAssignmentFixedTermAmount", "PeriodStart", Constraint.Operator.Equals,
				Parse.date(periodAmount.getPeriodStart()));
		update.newCustomConstraint(this.getRowVersionConstraint("DrawAssignmentFixedTermAmount", "_RowVersion",
				periodAmount.getRowVersion()));
		update.set("Amount", Literal.Type.DECIMAL, newAmount);
		UpdateBuilder ub = Database.getUpdateBuilder();
		if (this.ops.update(ub.toSql(update)) == 0) {
			throw new DatabaseConcurrencyException(
					new Message(Messages.Key.DRAW_ASSIGN_ERROR_CONCURRENCY, new Object[0]));
		} else {
			this.UpdateFixedTermAmountRowVersion(assignmentId, periodAmount, Parse.date(periodAmount.getPeriodStart()));
		}
	}

	@Override
	public int getNumberOfAvailablePeriods(String timeId, String level, Date starting) {
		QueryDefinition query = new QueryDefinition("Time_");
		query.newConstraint("Time_", "TimeID_", Constraint.Operator.Equals, timeId);
		query.newConstraint("Time_", "Level_", Constraint.Operator.Equals, level);
		query.newConstraint("Time_", "Ending_", Constraint.Operator.GreaterThanEquals, starting);
		query.selectCount();
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(query), Integer.class);
	}

	private List<PeriodAmount> getActivePeriodAmounts(int assignemntId, String timeId, String level, Date lockedDate,
			final NumberFormat currencyFormat) {
		QueryDefinition query = new QueryDefinition("DrawAssignmentFixedTermAmount");
		query.newConstraint("DrawAssignmentFixedTermAmount", "AssignmentID", Constraint.Operator.Equals, assignemntId);
		query.select("DrawAssignmentFixedTermAmount", "PeriodStart");
		query.select("DrawAssignmentFixedTermAmount", "Amount");
		query.select("DrawAssignmentFixedTermAmount", "_RowVersion");
		query.select(new Literal(Literal.Type.DATE, lockedDate), "LockedDate");
		query.select(new Literal(Literal.Type.STRING, timeId), "TimeID");
		query.select(new Literal(Literal.Type.STRING, level), "Level");
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(query), new RowMapper<PeriodAmount>() {
			@Override
			public PeriodAmount mapRow(ResultSet rs, int rowNumber) throws SQLException {
				Date periodStart = rs.getDate("PeriodStart");
				Date lockedDate = rs.getDate("LockedDate");
				boolean locked = lockedDate != null && !JdbcDrawAssignmentDaoImpl.this
						.getPeriodEndDate(rs.getString("TimeID"), rs.getString("Level"), periodStart).after(lockedDate);
				return new PeriodAmount(rs.getBigDecimal("Amount"), true, periodStart, locked, currencyFormat,
						JdbcDrawAssignmentDaoImpl.this.getRowVersion((byte[]) rs.getObject("_RowVersion")));
			}
		});
	}

	@Override
	public List<DrawAssignmentOngoing> getOngoingAssignmentsForPayee(String payeeId, int drawId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = new QueryDefinition("Payee_");
		query.select("Payee_", "Name_", "PayeeName");
		query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesQuery(query, drawId, timeId, activeOnly,
				lockedDate, pageNumber, rowsPerPage, sortColumn, descending);
		return this.getOngoingAssignments(newQuery, this.getSettings(drawId).getNumericStyle(), lockedDate);
	}

	@Override
	public List<DrawAssignmentOngoing> getOngoingPayees(int groupId, int drawId, boolean activeOnly, int pageNumber,
			int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByGroupId(timeId, groupId);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesQuery(query, drawId, timeId, activeOnly,
				lockedDate, pageNumber, rowsPerPage, sortColumn, descending);
		return this.getOngoingAssignments(newQuery, this.getSettings(drawId).getNumericStyle(), lockedDate);
	}

	@Override
	public int getOngoingPayeesCount(int groupId, int drawId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByGroupId(timeId, groupId);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesCountQuery(query, drawId, timeId, activeOnly,
				lockedDate);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(newQuery), Integer.class);
	}

	@Override
	public List<DrawAssignmentOngoing> getOngoingPayees(QueryDefinition restriction, int drawId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByRestrictionQuery(restriction);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesQuery(query, drawId, timeId, activeOnly,
				lockedDate, pageNumber, rowsPerPage, sortColumn, descending);
		return this.getOngoingAssignments(newQuery, this.getSettings(drawId).getNumericStyle(), lockedDate);
	}

	@Override
	public int getOngoingPayeesCount(QueryDefinition restriction, int drawId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByRestrictionQuery(restriction);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesCountQuery(query, drawId, timeId, activeOnly,
				lockedDate);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(newQuery), Integer.class);
	}

	@Override
	public List<DrawAssignmentOngoing> getOngoingPayeesAllGroups(int drawId, int workflowObjectId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryForAllGroups(workflowObjectId);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesQuery(query, drawId, timeId, activeOnly,
				lockedDate, pageNumber, rowsPerPage, sortColumn, descending);
		return this.getOngoingAssignments(newQuery, this.getSettings(drawId).getNumericStyle(), lockedDate);
	}

	@Override
	public int getOngoingPayeesAllGroupsCount(int drawId, int workflowObjectId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryForAllGroups(workflowObjectId);
		QueryDefinition newQuery = DrawAssignmentQuery.getOngoingPayeesCountQuery(query, drawId, timeId, activeOnly,
				lockedDate);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(newQuery), Integer.class);
	}

	@Override
	public List<DrawAssignmentFixedTerm> getFixedTermListForPayee(String payeeId, int drawId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = new QueryDefinition("Payee_");
		query.select("Payee_", "Name_", "PayeeName");
		query.newConstraint("Payee_", "PayeeID_", Constraint.Operator.Equals, payeeId);
		DrawAssignmentQuery.getFixedTermPayeeQuery(query, drawId, timeId, lockedDate, activeOnly, pageNumber,
				rowsPerPage, sortColumn, descending);
		List<DrawAssignmentFixedTerm> fixedTermList = this.getFixedTermAssignments(query, lockedDate,
				this.getSettings(drawId).getNumericStyle());
		return fixedTermList;
	}

	private List<DrawAssignmentOngoing> getOngoingAssignments(QueryDefinition query, NumericFormat.Style style,
			Date lockedDate) {
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet rs = this.ops.queryForRowSet(qb.toSql(query));
		Map<String, Date> levelLockedDateMap = new HashMap();
		List<DrawAssignmentOngoing> ongoingList = new LinkedList();

		while (rs.next()) {
			String level = rs.getString("Level");
			String timeId = rs.getString("TimeID");
			Date endDate = rs.getDate("EndDate");
			boolean isActive = endDate == null || lockedDate == null || endDate.after(lockedDate);
			Date levelLockedDate = null;
			if (!levelLockedDateMap.containsKey(level)) {
				levelLockedDateMap.put(level, this.timeDao.getLockedDate(timeId, level));
			}

			levelLockedDate = levelLockedDateMap.get(level);
			Date startDate = rs.getDate("StartDate");
			boolean lockedStartDate = levelLockedDate != null && !startDate.after(levelLockedDate);
			DrawAssignmentOngoing ongoing = new DrawAssignmentOngoing(rs.getInt("AssignmentID"),
					rs.getString("PayeeID"), rs.getString("PayeeName"), rs.getString("StartPeriod"), startDate, endDate,
					rs.getBigDecimal("Amount"), rs.getInt("TemplateID"), rs.getString("TemplateName"), timeId, level,
					isActive, lockedStartDate, rs.getBigDecimal("MaxDrawAmount") == null || lockedStartDate,
					this.getRowVersion((byte[]) rs.getObject("_RowVersion")), style);
			ongoingList.add(ongoing);
		}

		return ongoingList;
	}

	private List<DrawAssignmentFixedTerm> getFixedTermAssignments(QueryDefinition query, Date lockedDate,
			NumericFormat.Style style) {
		QueryBuilder qb = Database.getQueryBuilder();
		SqlRowSet rs = this.ops.queryForRowSet(qb.toSql(query));
		List<DrawAssignmentFixedTerm> fixedTermList = new LinkedList();
		NumberFormat currencyFormat = NumericFormat.getNumericCurrencyFormatter(style);
		Map<String, Date> levelLockedDateMap = new HashMap();

		while (rs.next()) {
			int assignmentId = rs.getInt("AssignmentID");
			String timeId = rs.getString("TimeID_");
			String level = rs.getString("Level");
			Object maxDuration = rs.getObject("MaxDuration");
			boolean canChangeDuration = maxDuration != null;
			Date endDate = rs.getDate("EndDate");
			boolean isActive = lockedDate == null || endDate.after(lockedDate);
			Date startDate = rs.getDate("StartDate");
			Date levelLockedDate = null;
			if (!levelLockedDateMap.containsKey(level)) {
				levelLockedDateMap.put(level, this.timeDao.getLockedDate(timeId, level));
			}

			levelLockedDate = levelLockedDateMap.get(level);
			boolean lockedStartDate = levelLockedDate != null && !startDate.after(levelLockedDate);
			DrawAssignmentFixedTerm fixedTermDraw = new DrawAssignmentFixedTerm(assignmentId, rs.getString("PayeeID"),
					rs.getString("PayeeName"), rs.getString("StartPeriod"), startDate, rs.getInt("TemplateID"),
					rs.getString("TemplateName"), timeId, level, rs.getBigDecimal("DrawAmount"), isActive,
					lockedStartDate, !canChangeDuration, rs.getObject("MaxDrawAmount") == null,
					this.getRowVersion((byte[]) rs.getObject("_RowVersion")), currencyFormat);
			List<PeriodAmount> periodAmounts = this.getActivePeriodAmounts(assignmentId, timeId, level, levelLockedDate,
					currencyFormat);
			if (canChangeDuration) {
				int maxDurationValue = (Integer) maxDuration;
				int availablePeriods = this.getNumberOfAvailablePeriods(timeId, level,
						Parse.date(periodAmounts.get(0).getPeriodStart()));
				int requiredPeriodsCount = Math.min(maxDurationValue, availablePeriods) - periodAmounts.size();

				for (int i = 0; i < requiredPeriodsCount; ++i) {
					periodAmounts.add(new PeriodAmount());
				}
			}

			fixedTermDraw.setPeriodAmounts(periodAmounts);
			fixedTermList.add(fixedTermDraw);
		}

		return fixedTermList;
	}

	private long getRowVersion(byte[] rowVersionData) {
		ByteBuffer rowVersionBuffer = ByteBuffer.wrap(rowVersionData);
		return rowVersionBuffer.getLong(rowVersionData[1]);
	}

	@Override
	public List<DrawAssignmentFixedTerm> getFixedTermPayees(int groupId, int drawId, boolean activeOnly, int pageNumber,
			int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByGroupId(timeId, groupId);
		QueryDefinition newQuery = DrawAssignmentQuery.getFixedTermPayeeQuery(query, drawId, timeId, lockedDate,
				activeOnly, pageNumber, rowsPerPage, sortColumn, descending);
		return new LinkedList(
				this.getFixedTermAssignments(newQuery, lockedDate, this.getSettings(drawId).getNumericStyle()));
	}

	@Override
	public int getFixedTermPayeesCount(int groupId, int drawId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByGroupId(timeId, groupId);
		QueryDefinition newQuery = DrawAssignmentQuery.getFixedTermPayeeCountQuery(query, drawId, timeId, lockedDate,
				activeOnly);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(newQuery), Integer.class);
	}

	@Override
	public List<DrawAssignmentFixedTerm> getFixedTermPayees(QueryDefinition restriction, int drawId, boolean activeOnly,
			int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByRestrictionQuery(restriction);
		QueryDefinition newQuery = DrawAssignmentQuery.getFixedTermPayeeQuery(query, drawId, timeId, lockedDate,
				activeOnly, pageNumber, rowsPerPage, sortColumn, descending);
		return new LinkedList(
				this.getFixedTermAssignments(newQuery, lockedDate, this.getSettings(drawId).getNumericStyle()));
	}

	@Override
	public int getFixedTermPayeesCount(QueryDefinition restriction, int drawId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryByRestrictionQuery(restriction);
		QueryDefinition newQuery = DrawAssignmentQuery.getFixedTermPayeeCountQuery(query, drawId, timeId, lockedDate,
				activeOnly);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(newQuery), Integer.class);
	}

	@Override
	public List<DrawAssignmentFixedTerm> getFixedTermPayeesAllGroups(int drawId, int workflowObjectId,
			boolean activeOnly, int pageNumber, int rowsPerPage, String sortColumn, boolean descending) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryForAllGroups(workflowObjectId);
		QueryDefinition newQuery = DrawAssignmentQuery.getFixedTermPayeeQuery(query, drawId, timeId, lockedDate,
				activeOnly, pageNumber, rowsPerPage, sortColumn, descending);
		return new LinkedList(
				this.getFixedTermAssignments(newQuery, lockedDate, this.getSettings(drawId).getNumericStyle()));
	}

	@Override
	public int getFixedTermPayeesAllGroupsCount(int drawId, int workflowObjectId, boolean activeOnly) {
		String timeId = this.getDrawTimeId(drawId);
		Date lockedDate = this.getLockedDate(drawId);
		QueryDefinition query = DrawAssignmentQuery.getPayeeQueryForAllGroups(workflowObjectId);
		QueryDefinition countQuery = DrawAssignmentQuery.getFixedTermPayeeCountQuery(query, drawId, timeId, lockedDate,
				activeOnly);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(countQuery), Integer.class);
	}

	@Override
	public boolean isViewableDrawAssignment(int drawId) {
		List<Integer> drawIds = this.getViewableDrawIds();
		return drawIds.contains(drawId);
	}

	private List<Integer> getViewableDrawIds() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition idQuery = WorkflowQuery.getViewableObjectsQuery(user.getPayeeId(),
				WorkflowObject.Type.DRAW_ASSIGNMENT);
		QueryBuilder qb = Database.getQueryBuilder();
		List<Integer> drawIds = this.ops.query(qb.toSql(idQuery), RowMapperUtil.getIntegerMapper());
		return drawIds;
	}

	@Override
	public String getDrawName(int drawId) {
		QueryDefinition qd = new QueryDefinition("BaseBlock");
		qd.select("BaseBlock", "Name");
		qd.newConstraint("BaseBlock", "BlockID", Constraint.Operator.Equals, drawId);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(qd), RowMapperUtil.getStringMapper()).get(0);
	}

	@Override
	public boolean exists(int drawId) {
		QueryDefinition qd = new QueryDefinition("DrawDefinition");
		qd.selectCount();
		qd.newConstraint("DrawDefinition", "BlockID", Constraint.Operator.Equals, drawId);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.queryForObject(qb.toSql(qd), Integer.class) > 0;
	}

	@Override
	public List<DrawName> getViewableDraws() {
		UserAccount user = UserAccount.getCurrent();
		QueryDefinition idQuery = WorkflowQuery.getViewableObjectsQuery(user.getPayeeId(),
				WorkflowObject.Type.DRAW_ASSIGNMENT);
		Join baseBlockJoin = new Join("BaseBlock", Join.Type.INNER);
		baseBlockJoin.newConstraint("BaseBlock", "BlockID", Constraint.Operator.Equals, "DrawAssignmentWebSettings",
				"BlockID");
		idQuery.joinWith(baseBlockJoin);
		idQuery.select("BaseBlock", "Name");
		idQuery.addOrder(new OrderItem("BaseBlock", "Name", OrderItem.Direction.ASCENDING));
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.query(qb.toSql(idQuery), new RowMapper<DrawName>() {
			@Override
			public DrawName mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new DrawName(rs.getInt("BlockID"), rs.getString("Name"));
			}
		});
	}

	@Override
	public boolean OverlappingAssignmentExistsForPayee(int drawId, String payeeId, Date startDate, Date endDate,
			Integer excludeAssignmentID, boolean isFixed) {
		QueryDefinition ongoingQuery = DrawAssignmentQuery.getFindOverlappingAssignmentQuery(drawId, payeeId, startDate,
				endDate, !isFixed ? excludeAssignmentID : null, "DrawAssignmentOngoingTerm");
		QueryDefinition fixedtermQuery = DrawAssignmentQuery.getFindOverlappingAssignmentQuery(drawId, payeeId,
				startDate, endDate, isFixed ? excludeAssignmentID : null, "DrawAssignmentFixedTerm");
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.queryForObject(qb.toSql(ongoingQuery), Integer.class) > 0
				|| this.ops.queryForObject(qb.toSql(fixedtermQuery), Integer.class) > 0;
	}

	@Override
	public Date getOngoingAssignmentEndDate(int assignmentID) {
		QueryBuilder qb = Database.getQueryBuilder();
		QueryDefinition query = new QueryDefinition("DrawAssignmentOngoingTerm");
		query.select("DrawAssignmentOngoingTerm", "EndDate");
		query.newConstraint("DrawAssignmentOngoingTerm", "AssignmentID", Constraint.Operator.Equals, assignmentID);
		return this.ops.query(qb.toSql(query), new RowMapper<Date>() {
			@Override
			public Date mapRow(ResultSet arg0, int arg1) throws SQLException {
				return arg0.getDate(1);
			}
		}).get(0);
	}

	@Override
	public boolean hasOpenOngoing(int drawId, String payeeId) {
		QueryDefinition query = DrawAssignmentQuery.getHasOpenOngoingQuery(drawId, payeeId);
		QueryBuilder qb = Database.getQueryBuilder();
		return this.ops.queryForObject(qb.toSql(query), Integer.class) > 0;
	}

	@Override
	public int getWorkflowObjectId(String id, WorkflowObject.Type type) {
		QueryDefinition query = WorkflowQuery.getWorkflowObjectIdQuery(id, type);
		QueryBuilder qb = Database.getQueryBuilder();
		return (Integer) this.ops.queryForObject(qb.toSql(query), Integer.class);
	}
}
