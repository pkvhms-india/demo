package com.varicent.core.database;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.util.Assert;

import com.varicent.common.query.sql.QueryBuilder;
import com.varicent.common.query.sql.delete.DeleteBuilder;
import com.varicent.common.query.sql.delete.SqlServerDeleteBuilder;
import com.varicent.common.query.sql.insert.FullInsertBuilder;
import com.varicent.common.query.sql.insert.InsertBuilder;
import com.varicent.common.query.sql.update.SqlServerUpdateBuilder;
import com.varicent.common.query.sql.update.UpdateBuilder;
import com.varicent.core.database.jdbc.SchemaAwareJdbcTemplate;
import com.varicent.core.database.portability.MicrosoftSqlSyntax;
import com.varicent.core.database.portability.MicrosoftUnicodeSqlSyntax;
import com.varicent.core.database.portability.SqlSyntax;

public class Database {
	private static final Pattern DATABASE_NAME_MSSQL = Pattern.compile(".+/([(\\w|\\p{L})\\.\\[\\]]+);?.*");
	private static final String PRODUCT_NAME_MSSQL = "sqlserver";
	private static final String PRODUCT_NAME_MSSQL_UNICODE = "sqlserverunicode";
	private static SqlSyntax syntax;
	private static String name;

	public static DeleteBuilder getDeleteBuilder() {
		if (syntax.isSqlServer()) {
			return new SqlServerDeleteBuilder();
		} else {
			Assert.state(false);
			return null;
		}
	}

	public static FullInsertBuilder getFullInsertBuilder() {
		return new FullInsertBuilder(syntax);
	}

	public static InsertBuilder getInsertBuilder() {
		return new InsertBuilder(syntax);
	}

	public static JdbcOperations getOperations(DataSource ds) {
		return new SchemaAwareJdbcTemplate(ds);
	}

	public static String getName() {
		return name;
	}

	public static QueryBuilder getQueryBuilder() {
		return new QueryBuilder(syntax);
	}

	public static SqlSyntax getSyntax() {
		return syntax;
	}

	public static UpdateBuilder getUpdateBuilder() {
		if (syntax.isSqlServer()) {
			return new SqlServerUpdateBuilder();
		} else {
			Assert.state(false);
			return null;
		}
	}

	public Database(String productName, String jdbcUrl) {
		if ("sqlserver".equalsIgnoreCase(productName)) {
			syntax = new MicrosoftSqlSyntax();
		} else if ("sqlserverunicode".equalsIgnoreCase(productName)) {
			syntax = new MicrosoftUnicodeSqlSyntax();
		} else {
			Assert.state(false);
			syntax = null;
		}

		name = this.extractName(jdbcUrl);
	}

	public static boolean tableExists(String dbNamespace, String tableName, JdbcOperations operations) {
		if (dbNamespace == null) {
			dbNamespace = syntax.getDefaultNameSpace();
		}

		String existsQuery = String.format(
				"SELECT COUNT(*) as Count from sys.tables Where name = N'%s' And SCHEMA_NAME(schema_id) = '%s'",
				tableName, dbNamespace);
		return operations.queryForObject(existsQuery.toString(), Integer.class) == 1;
	}

	public static List<String> getTableNamesLike(String tableName, JdbcOperations ops) {
		String tablesQuery = String.format("SELECT name from sysobjects where xtype ='U' and name like '%s", tableName);
		tablesQuery = tablesQuery + "%'";
		List<Map<String, Object>> returned = ops.queryForList(tablesQuery);
		List<String> tableNames = new ArrayList(returned.size());
		Iterator<Map<String, Object>> iter = returned.iterator();

		while (iter.hasNext()) {
			tableNames.add(iter.next().entrySet().iterator().next().getValue().toString());
		}

		return tableNames;
	}

	public static int rowCountOfTable(String tableName, JdbcOperations operations) {
		String countQuery = String.format("SELECT COUNT(*) as Count from %s", tableName);
		return (Integer) operations.queryForObject(countQuery.toString(), Integer.class);
	}

	private String extractName(String jdbcUrl) {
		Assert.isTrue(syntax != null);
		Matcher matcher;
		if (syntax.isSqlServer()) {
			matcher = DATABASE_NAME_MSSQL.matcher(jdbcUrl);
		} else {
			Assert.state(false);
			matcher = null;
		}

		if (matcher.matches()) {
			return matcher.group(1);
		} else {
			Assert.state(false);
			return null;
		}
	}
}
