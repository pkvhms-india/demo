package com.varicent.core.util;

import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;
import org.jdom.xpath.XPath;

public class XPathWrapper {
	public static List<?> selectNodes(Object context, String path, Namespace ns) throws JDOMException {
		XPath query = XPath.newInstance(path);
		query.addNamespace(ns);
		return query.selectNodes(context);
	}

	static List<?> selectNodes(Object context, String path) throws JDOMException {
		return XPath.selectNodes(context, path);
	}

	public static Object selectSingleNode(Object context, String path, Namespace ns) throws JDOMException {
		XPath query = XPath.newInstance(path);
		query.addNamespace(ns);
		return query.selectSingleNode(context);
	}

	public static Element selectSingleNodeUncached(Object context, String path, Namespace ns) throws JDOMException {
		XPath query = XPath.newInstance(path);
		query.addNamespace(ns);
		return (Element) query.selectSingleNode(context);
	}

	static Object selectSingleNode(Object context, String path) throws JDOMException {
		return XPath.selectSingleNode(context, path);
	}

	public static Element getElement(String path, Object obj, Namespace ns) throws JDOMException {
		return (Element) selectSingleNode(obj, path, ns);
	}

	public static Element[] getElements(String path, Object obj, Namespace ns) throws JDOMException {
		List<?> nodes = selectNodes(obj, path, ns);
		if (nodes == null) {
			return new Element[0];
		} else {
			List<Element> elements = new ArrayList();

			for (int i = 0; i < nodes.size(); ++i) {
				elements.add((Element) nodes.get(i));
			}

			return (Element[]) elements.toArray(new Element[elements.size()]);
		}
	}
}
