package com.varicent.draws.web;

public class PeriodAmountJson {
	private String periodAmount;

	public PeriodAmountJson(String periodAmount) {
		this.periodAmount = periodAmount;
	}

	public String getPeriodAmount() {
		return this.periodAmount;
	}

	public void setPeriodAmount(String periodAmount) {
		this.periodAmount = periodAmount;
	}
}
