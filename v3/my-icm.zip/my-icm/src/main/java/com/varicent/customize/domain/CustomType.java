package com.varicent.customize.domain;

public enum CustomType {
	TEXT, DATE, LIST, NUMERIC, EMAIL, URL, COMMENT;
}
