package com.varicent.core.database.portability;

import java.util.Date;

import org.apache.commons.lang.StringEscapeUtils;

import com.varicent.common.query.domain.Literal;
import com.varicent.core.text.Format;

public class MicrosoftUnicodeSqlSyntax extends MicrosoftSqlSyntax {
	@Override
	public String cast(String s) {
		return "N'" + StringEscapeUtils.escapeSql(s) + "'";
	}

	@Override
	public String toDatabaseType(Literal.Type type) {
		switch (type) {
		case INTEGER:
			return "INT";
		case DECIMAL:
			return "DECIMAL(28,14)";
		case DATE:
		case DATETIME:
			return "DATETIME";
		case STRING:
			return "NVARCHAR(100)";
		case LONG_STRING:
			return "NVARCHAR(1000)";
		case BLOB:
			return "VARBINARY(max)";
		default:
			return "NULL";
		}
	}

	@Override
	public String toDate(Object date) {
		return date == null ? "NULL" : this.cast(Format.asISODate((Date) date));
	}

	@Override
	protected SqlSyntax.DatabaseType getDatabaseType() {
		return SqlSyntax.DatabaseType.SQL_SERVER_UNICODE;
	}
}
