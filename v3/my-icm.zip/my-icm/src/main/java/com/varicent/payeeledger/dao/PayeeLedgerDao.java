package com.varicent.payeeledger.dao;

import java.util.List;
import java.util.Set;

import com.varicent.common.payee.domain.Payee;
import com.varicent.common.plan.domain.Plan;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;

public interface PayeeLedgerDao {
	String getCalendar(String var1);

	List<DataRow> getLedger(String var1, String var2, TimePeriod var3, boolean var4);

	Payee getPayee(String var1);

	List<Payee> getPayees(String var1);

	List<TimePeriod> getPeriods(String var1);

	Plan getPlan(String var1);

	List<Plan> getPlans(String var1);

	Set<String> getAuthorizedPlanIds();
}
