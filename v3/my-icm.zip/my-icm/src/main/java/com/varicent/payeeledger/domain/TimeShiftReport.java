package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;

public class TimeShiftReport extends ResultReport {
	public TimeShiftReport(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, String resultTable, String payeeColumn, boolean showHeader, boolean showPriorPeriods,
			boolean suppressEmptyReports, boolean suppressSummary) {
		super(reportId, calculationId, name, resultName, calendar, format, resultTable, payeeColumn, showHeader,
				showPriorPeriods, suppressEmptyReports, suppressSummary);
	}
}
