package com.varicent.core.database.support;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.util.Assert;

import com.varicent.common.port.domain.Port;
import com.varicent.common.port.domain.PortColumn;
import com.varicent.common.port.domain.PortSourceResolver;
import com.varicent.common.query.domain.AndClause;
import com.varicent.common.query.domain.Clause;
import com.varicent.common.query.domain.CustomConstraint;
import com.varicent.common.query.domain.DataField;
import com.varicent.common.query.domain.IConstraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SqlDataSource;
import com.varicent.common.query.domain.SubQueryConstraint;

public final class PortSourceMapper {
	private static QueryDefinition getEmptyQuery(Port port) {
		QueryDefinition query = new QueryDefinition();

		for (PortColumn column : port.getColumns()) {
			switch (column.getType()) {
			case 0:
			case 4:
				query.select(new Literal(Literal.Type.STRING, ""), column.getName());
				break;
			case 1:
				query.select(new Literal(Literal.Type.DATE, new Date()), column.getName());
				break;
			case 2:
				query.select(new Literal(Literal.Type.DECIMAL, new BigDecimal(0)), column.getName());
				break;
			case 3:
			default:
				query.select(new Literal(Literal.Type.INTEGER, 0), column.getName());
			}
		}

		query.addConstraint(new CustomConstraint("0=1"));
		return query;
	}

	public static Port getPort(String table, Map<String, Port> portMap) {
		Port port;
		for (port = null; isMappablePort(table, portMap); table = port.getSourceTable()) {
			port = portMap.get(table);
		}

		return port;
	}

	private static boolean isMappablePort(String source, Map<String, Port> portTableMap) {
		return isPort(source) && portTableMap.containsKey(source);
	}

	public static boolean isPort(String source) {
		return source != null && source.startsWith("_Port");
	}

	private static Clause mapClause(Clause clause, Map<String, Port> portMap, PortSourceResolver portResolver) {
		Clause mappedClause;
		if (clause instanceof AndClause) {
			mappedClause = new AndClause();
		} else {
			Assert.isTrue(clause instanceof OrClause);
			mappedClause = new OrClause();
		}

		for (IConstraint constraint : clause.getConstraints()) {
			IConstraint mappedConstraint = constraint;
			if (constraint instanceof SubQueryConstraint) {
				SubQueryConstraint subQueryConstraint = (SubQueryConstraint) constraint;
				QueryDefinition subQuery = subQueryConstraint.getRight();
				QueryDefinition mappedSubQuery = mapQuery(subQuery, portMap, portResolver);
				DataField dataField = subQueryConstraint.getLeft();
				if (dataField == null) {
					mappedConstraint = new SubQueryConstraint(subQueryConstraint.getOperator(), mappedSubQuery);
				} else {
					mappedConstraint = new SubQueryConstraint(dataField.getTable(), dataField.getColumn(),
							subQueryConstraint.getOperator(), mappedSubQuery);
				}
			}

			mappedClause.addConstraint(mappedConstraint);
		}

		return mappedClause;
	}

	private static List<Join> mapJoins(List<Join> joins, Map<String, Port> portMap, PortSourceResolver portResolver) {
		List<Join> mappedJoins = new ArrayList();

		for (Join join : joins) {
			SqlDataSource mappedSource = mapSource(join.getSource(), portMap, portResolver);
			Clause mappedClause = mapClause(join.getRestriction(), portMap, portResolver);
			join.setSource(mappedSource);
			join.setRestriction(mappedClause);
			mappedJoins.add(join);
		}

		return mappedJoins;
	}

	public static QueryDefinition mapQuery(QueryDefinition query, Map<String, Port> portMap,
			PortSourceResolver portResolver) {
		if (query != null) {
			SqlDataSource mappedSource = mapSource(query.getSource(), portMap, portResolver);
			List<Join> mappedJoins = mapJoins(query.getJoins(), portMap, portResolver);
			Clause mappedClause = mapClause(query.getRestriction(), portMap, portResolver);
			QueryDefinition mappedUnion = mapQuery(query.getUnion(), portMap, portResolver);
			QueryDefinition mappedQuery = new QueryDefinition();
			mappedQuery.addSelects(query.getSelect());
			mappedQuery.setSource(mappedSource);
			mappedQuery.joinWith(mappedJoins);
			mappedQuery.setRestriction(mappedClause);
			mappedQuery.addGroupItems(query.getGroup());
			mappedQuery.addOrderItems(query.getOrder());
			mappedQuery.limitTo(query.getLimit());
			if (query.isSelectDistinct()) {
				mappedQuery.selectDistinct();
			}

			if (query.hasUnion()) {
				mappedQuery.setUnionWith(mappedUnion);
			}

			query = mappedQuery;
		}

		return query;
	}

	private static SqlDataSource mapSource(SqlDataSource source, Map<String, Port> portMap,
			PortSourceResolver portResolver) {
		if (source != null) {
			if (source.isQuery()) {
				QueryDefinition mappedQuery = mapQuery(source.getQuery(), portMap, portResolver);
				source = new SqlDataSource(mappedQuery, source.getAlias());
			} else if (source.isTable()) {
				String table = source.getTable();
				if (isMappablePort(table, portMap)) {
					Port port = getPort(table, portMap);
					String alias = source.getAlias();
					if (!source.hasAlias()) {
						alias = table;
					}

					Port sourcePort = portMap.get(table);
					QueryDefinition mappedQuery;
					if (port.getSourceTable() == null) {
						mappedQuery = getEmptyQuery(sourcePort);
					} else {
						mappedQuery = new QueryDefinition(port.getSourceTable());
						if (sourcePort != null) {
							for (PortColumn portColumn : sourcePort.getColumns()) {
								mappedQuery.select(port.getSourceTable(),
										portResolver.getSourceColumn(table, portColumn.getName()),
										portColumn.getName());
							}
						} else {
							mappedQuery.selectAll();
						}
					}

					source = new SqlDataSource(mappedQuery, alias);
				}
			}
		}

		return source;
	}
}
