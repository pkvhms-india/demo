package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodePower extends BinaryNode implements EvaluateNode {
	public NodePower(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal base = this.lhs.evaluate();
		BigDecimal power = this.rhs.evaluate();
		if (base != null && power != null) {
			double x = base.doubleValue();
			double exponent = power.doubleValue();
			double result = Math.pow(x, exponent);
			return new BigDecimal(result);
		} else {
			return null;
		}
	}

	@Override
	public String getJSMathFunctionName() {
		return "power";
	}
}
