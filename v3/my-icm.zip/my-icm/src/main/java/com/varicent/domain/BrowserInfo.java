package com.varicent.domain;

public class BrowserInfo {
	private Type type;
	private String version;

	public BrowserInfo(Type type, String version) {
		this.type = type;
		this.version = version;
	}

	public Type getType() {
		return this.type;
	}

	public String getVersion() {
		return this.version;
	}

	public static enum Type {
		IE, FireFox, Safari, Chrome;
	}
}
