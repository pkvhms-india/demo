package com.varicent.payeeledger.domain;

import com.varicent.core.text.NumericFormat;

public class SortReport extends Report {
	private final String resultTable;
	private final String sourceTable;
	private final String payeeColumn;
	private final String firstSortColumn;

	public SortReport(int reportId, int calculationId, String name, String resultName, String calendar,
			NumericFormat format, String resultTable, String sourceTable, String payeeColumn, String firstSortColumn,
			boolean showHeader, boolean showPriorPeriods, boolean suppressEmptyReports, boolean suppressSummary) {
		super(reportId, calculationId, name, resultName, calendar, format, showHeader, showPriorPeriods,
				suppressEmptyReports, suppressSummary);
		this.resultTable = resultTable;
		this.sourceTable = sourceTable;
		this.payeeColumn = payeeColumn;
		this.firstSortColumn = firstSortColumn;
	}

	public String getFirstSortColumn() {
		return this.firstSortColumn;
	}

	public String getPayeeColumn() {
		return this.payeeColumn;
	}

	public String getResultTable() {
		return this.resultTable;
	}

	public String getSourceTable() {
		return this.sourceTable;
	}

	public boolean hasFirstSortColumn() {
		return this.firstSortColumn != null;
	}

	public boolean hasPayeeColumn() {
		return this.payeeColumn != null;
	}
}
