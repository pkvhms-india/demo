package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeGroupSum extends UnaryNode implements EvaluateNode, AggregateNode {
	private BigDecimal sum = null;
	private boolean isFinalized;

	public NodeGroupSum(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.sum;
		} else {
			BigDecimal value = this.arg.evaluate();
			if (value != null) {
				if (this.sum == null) {
					this.sum = value;
				} else {
					this.sum = this.sum.add(value);
				}
			}

			return this.sum;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.sum = null;
			this.arg.reset();
		}
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function");
		sb.append(" ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupSum";
	}
}
