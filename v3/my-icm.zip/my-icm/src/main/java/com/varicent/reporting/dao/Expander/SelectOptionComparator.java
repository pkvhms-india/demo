package com.varicent.reporting.dao.Expander;

import java.util.Comparator;

import com.varicent.common.ui.domain.SelectOption;

class SelectOptionComparator implements Comparator<SelectOption> {
	private boolean useDescription;
	private boolean useNumeric;

	public SelectOptionComparator(boolean useDescription, boolean useNumeric) {
		this.useDescription = useDescription;
		this.useNumeric = useNumeric;
	}

	@Override
	public int compare(SelectOption op1, SelectOption op2) {
		String c1 = this.useDescription ? op1.getName() : op1.getValue();
		String c2 = this.useDescription ? op2.getName() : op2.getValue();
		if (this.useNumeric) {
			try {
				Double d1 = Double.parseDouble(c1);
				Double d2 = Double.parseDouble(c2);
				return d1.compareTo(d2);
			} catch (NumberFormatException var7) {
			}
		}

		return c1.compareTo(c2);
	}
}
