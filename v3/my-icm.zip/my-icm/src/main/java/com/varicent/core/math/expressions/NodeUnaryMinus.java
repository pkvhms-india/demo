package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeUnaryMinus extends UnaryNode implements EvaluateNode {
	public NodeUnaryMinus(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal value = this.arg.evaluate();
		return value == null ? null : value.negate();
	}

	@Override
	public void reset() {
		this.arg.reset();
	}

	@Override
	public String getJSMathFunctionName() {
		return "unaryMinus";
	}
}
