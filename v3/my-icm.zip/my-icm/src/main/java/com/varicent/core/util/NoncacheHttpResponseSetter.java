package com.varicent.core.util;

import javax.servlet.http.HttpServletResponse;

public class NoncacheHttpResponseSetter {
	public static void setResponseNonCache(HttpServletResponse response) {
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "max-age=0,no-store, no-cache, must-revalidate,post-check=0,pre-check=0");
		response.setDateHeader("Expires", -1L);
	}
}
