package com.varicent.messages.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.varicent.messages.dao.MessagesDao;
import com.varicent.messages.domain.Message;

@Service("messagesManager")
@Transactional(readOnly = true)
public class MessagesManagerImpl implements MessagesManager {
	private final MessagesDao messagesDao;

	@Autowired
	public MessagesManagerImpl(MessagesDao messagesDao) {
		this.messagesDao = messagesDao;
	}

	@Override
	public List<Message> getMessages(int limit, Date start, Date end) {
		return this.messagesDao.getMessages(limit, start, end);
	}

	@Override
	public int getNewMessageCount() {
		return this.messagesDao.getNewMessageCount();
	}
}
