package com.varicent.core.math.expressions;

import java.math.BigDecimal;

import org.jdom.Element;

public class NodeNumber extends JavascriptNode implements EvaluateNode {
	public static final String XmlNodeName = "Number";
	String variableName;
	boolean javascriptFunctionCreated;
	private BigDecimal value;

	public static NodeNumber fromXml(Element node, int suffix) {
		Element valueNode = (Element) node.getChildren().get(0);
		String value = valueNode.getText();
		BigDecimal decimal = new BigDecimal(value);
		return new NodeNumber(decimal, (String) null, suffix);
	}

	public NodeNumber(BigDecimal Value, String variableName, int suffix) {
		super(suffix);
		this.value = Value;
		this.variableName = variableName;
	}

	@Override
	public BigDecimal evaluate() {
		return this.value;
	}

	@Override
	public void reset() {
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	@Override
	public boolean isJSFunctionCreated() {
		return this.javascriptFunctionCreated;
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		this.javascriptFunctionCreated = true;
		StringBuilder sb = new StringBuilder();
		sb.append(JavascriptUtil.getFunctionSigniture(this.getJSFunctionName(jsUtil)));
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		if (this.variableName == null) {
			sb.append(this.value.toString());
		} else {
			sb.append(jsUtil.getVariable(this.variableName));
		}

		sb.append(";}");
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		assert false;

		return null;
	}
}
