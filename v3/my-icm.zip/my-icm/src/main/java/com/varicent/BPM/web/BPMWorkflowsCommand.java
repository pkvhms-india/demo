package com.varicent.BPM.web;

import com.varicent.BPM.domain.BPMWorkflowView;

public class BPMWorkflowsCommand extends BPMPagedItemsCommand<BPMWorkflowView> {
	public static final String START_PARAM = "start";

	public BPMWorkflowsCommand(int start, int itemsPerPage, int totalItems, BPMWorkflowView[] items) {
		super(start, itemsPerPage, totalItems, items, String.format("index.html?%s=%%s", "start"));
	}
}
