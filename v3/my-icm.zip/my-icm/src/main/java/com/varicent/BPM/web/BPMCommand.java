package com.varicent.BPM.web;

import com.varicent.security.domain.CSRFCommand;

public class BPMCommand extends CSRFCommand {
	private int bpmTokenID;
	private long bpmTokenVersion;

	public int getBPMTokenID() {
		return this.bpmTokenID;
	}

	public void setBPMTokenID(int bpmTokenID) {
		this.bpmTokenID = bpmTokenID;
	}

	public long getBPMTokenVersion() {
		return this.bpmTokenVersion;
	}

	public void setBPMTokenVersion(long bpmTokenVersion) {
		this.bpmTokenVersion = bpmTokenVersion;
	}
}
