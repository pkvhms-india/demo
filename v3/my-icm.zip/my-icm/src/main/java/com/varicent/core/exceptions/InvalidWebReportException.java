package com.varicent.core.exceptions;

public class InvalidWebReportException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private static final String defaultMessage = "An error occurred while fetching reporting data.";

	public InvalidWebReportException() {
		super("An error occurred while fetching reporting data.");
	}

	public InvalidWebReportException(String message) {
		super(message);
	}

	public InvalidWebReportException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidWebReportException(Throwable cause) {
		super("An error occurred while fetching reporting data.", cause);
	}
}
