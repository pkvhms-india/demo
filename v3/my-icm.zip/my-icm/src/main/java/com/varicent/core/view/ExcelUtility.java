package com.varicent.core.view;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import com.varicent.core.util.XPathWrapper;
import com.varicent.reporting.domain.ui.ControlDisplayStyle;
import com.varicent.reporting.domain.ui.DataDisplayStyle;
import com.varicent.reporting.domain.ui.DataGridDisplayStyle;
import com.varicent.reporting.domain.ui.FixedGridDisplayStyle;
import com.varicent.reporting.domain.ui.ReportingCellStyle;
import com.varicent.reporting.domain.ui.ScalarDisplayStyle;
import com.varicent.reporting.domain.ui.WorkflowLinkDisplayStyle;

public abstract class ExcelUtility {
	private Workbook m_wb;
	private CreationHelper m_creationHelper;

	protected ExcelUtility(Workbook wb) {
		this.m_wb = wb;
		this.m_creationHelper = wb.getCreationHelper();
	}

	public static ExcelUtility getExcelSSUtility(Workbook wb) {
		return wb instanceof HSSFWorkbook ? new ExcelHssfUtility((HSSFWorkbook) wb)
				: new ExcelXssfUtility((XSSFWorkbook) wb);
	}

	public static Map<String, DataDisplayStyle> parseStyleDefinitions(Element webReport) throws JDOMException {
		Map<String, DataDisplayStyle> map = new HashMap();
		Namespace ns = Namespace.getNamespace("v", "http://varicent.com/WebReport/RenderXml");
		Element root = getElement("v:StyleDefinitions", webReport, ns);

		for (Element child : getElements("v:DataGridDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			DataDisplayStyle style = DataGridDisplayStyle.toDataGridDisplayStyle(child);
			map.put(styleName, style);
		}

		for (Element child : getElements("v:BaseDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			DataDisplayStyle style = DataDisplayStyle.toDataDisplayStyle(child);
			map.put(styleName, style);
		}

		for (Element child : getElements("v:FixedGridDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			FixedGridDisplayStyle style = FixedGridDisplayStyle.toFixedGridDisplayStyle(child);
			map.put(styleName, style);
		}

		for (Element child : getElements("v:ScalarDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			ScalarDisplayStyle style = ScalarDisplayStyle.toScalarDisplayStyle(child);
			map.put(styleName, style);
		}

		for (Element child : getElements("v:ControlDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			ControlDisplayStyle style = ControlDisplayStyle.toControlDisplayStyle(child);
			map.put(styleName, style);
		}

		for (Element child : getElements("v:WorkflowLinkDisplayStyle", root, ns)) {
			String styleName = getElement("v:StyleName", child, ns).getText();
			WorkflowLinkDisplayStyle style = WorkflowLinkDisplayStyle.toWorkflowLinkDisplayStyle(child);
			map.put(styleName, style);
		}

		return map;
	}

	public static String createSafeSheetName(String unsafeSheetName) {
		String sheetName = unsafeSheetName.replaceAll("[/\\\\*\\[\\]?:]", "_");
		if (sheetName.endsWith("'")) {
			sheetName = sheetName.substring(0, sheetName.length() - 2) + "_";
		}

		if (sheetName.length() > 31) {
			sheetName = sheetName.substring(0, 31);
		}

		return sheetName;
	}

	private static Element getElement(String path, Object obj, Namespace ns) throws JDOMException {
		return (Element) XPathWrapper.selectSingleNode(obj, path, ns);
	}

	private static Element[] getElements(String path, Object obj, Namespace ns) throws JDOMException {
		List<?> nodes = XPathWrapper.selectNodes(obj, path, ns);
		if (nodes == null) {
			return new Element[0];
		} else {
			List<Element> elements = new ArrayList();

			for (int i = 0; i < nodes.size(); ++i) {
				elements.add((Element) nodes.get(i));
			}

			return (Element[]) elements.toArray(new Element[elements.size()]);
		}
	}

	public abstract void ApplyFontColour(Font var1, Color var2);

	public abstract void ApplyFillColour(CellStyle var1, Color var2, short var3);

	public Font getFont(String fontName, short pointSize) {
		Font font = this.m_wb.createFont();

		try {
			font.setFontName(fontName);
			font.setFontHeightInPoints(pointSize);
		} catch (Exception var5) {
			font.setFontName("Tahoma");
		}

		return font;
	}

	public CellStyle createDataCellStyle(String dataFormat) {
		CellStyle cellStyle = this.createTextCellStyle();
		cellStyle.setDataFormat(this.m_creationHelper.createDataFormat().getFormat(dataFormat));
		return cellStyle;
	}

	public CellStyle createDataCellStyle(com.varicent.common.ui.domain.CellStyle style, String dataFormat) {
		CellStyle cellStyle = this.createTextCellStyle(style);
		cellStyle.setDataFormat(this.m_creationHelper.createDataFormat().getFormat(dataFormat));
		return cellStyle;
	}

	public CellStyle createDataCellStyle(com.varicent.common.ui.domain.CellStyle style, String dataFormat,
			Color parentBackColor) {
		CellStyle cellStyle = this.createTextCellStyle(style, parentBackColor);
		cellStyle.setDataFormat(this.m_creationHelper.createDataFormat().getFormat(dataFormat));
		return cellStyle;
	}

	public CellStyle createDataCellStyle(Font font, String dataFormat) {
		CellStyle cellStyle = this.createTextCellStyle(font);
		cellStyle.setDataFormat(this.m_creationHelper.createDataFormat().getFormat(dataFormat));
		return cellStyle;
	}

	public CellStyle createTextCellStyle() {
		return this.createExcelCellStyle((com.varicent.common.ui.domain.CellStyle) null, (Font) null, (Color) null);
	}

	public CellStyle createTextCellStyle(Font font) {
		return this.createExcelCellStyle((com.varicent.common.ui.domain.CellStyle) null, font, (Color) null);
	}

	public CellStyle createTextCellStyle(com.varicent.common.ui.domain.CellStyle style) {
		return this.createExcelCellStyle(style, (Font) null, (Color) null);
	}

	public CellStyle createTextCellStyle(com.varicent.common.ui.domain.CellStyle style, Color parentBackColor) {
		return this.createExcelCellStyle(style, (Font) null, parentBackColor);
	}

	private CellStyle createExcelCellStyle(com.varicent.common.ui.domain.CellStyle style, Font font,
			Color parentBackColor) {
		CellStyle newCellStyle = this.createBasicCellStyle(style, font, parentBackColor);
		if (style != null && style instanceof ReportingCellStyle) {
			try {
				ReportingCellStyle reportingCellStyle = (ReportingCellStyle) style;
				newCellStyle.setBorderTop(getLineStyle(reportingCellStyle.getBWTop()));
				newCellStyle.setBorderLeft(getLineStyle(reportingCellStyle.getBWLeft()));
				newCellStyle.setBorderBottom(getLineStyle(reportingCellStyle.getBWBottom()));
				newCellStyle.setBorderRight(getLineStyle(reportingCellStyle.getBWRight()));
			} catch (Exception e) {
				throw new RuntimeException("Error exporting to Excel", e);
			}
		}

		return newCellStyle;
	}

	private CellStyle createBasicCellStyle(com.varicent.common.ui.domain.CellStyle style, Font font,
			Color parentBackColor) {
		Font newFont = font;
		if (font == null) {
			newFont = this.m_wb.createFont();

			try {
				newFont.setFontName(style.getFont().getFamily());
			} catch (Exception var8) {
				newFont.setFontName("Tahoma");
			}

			newFont.setFontHeightInPoints((short) 10);
		}

		CellStyle cellStyle = this.m_wb.createCellStyle();
		cellStyle.setFont(newFont);
		if (style == null) {
			return cellStyle;
		} else {
			try {
				newFont.setFontHeightInPoints((short) Math.round(style.getFont().getSize()));
				newFont.setItalic(style.getFont().isItalic());
				newFont.setStrikeout(style.getFont().isStruckout());
				newFont.setUnderline((byte) (style.getFont().isUnderlined() ? 1 : 0));
				newFont.setBoldweight((short) (style.getFont().isBold() ? 700 : 400));
				this.ApplyFontColour(newFont, style.getColor());
				cellStyle.setAlignment(this.getAlignment(style.getAlignment()));
				if (!style.isTransparent()) {
					this.ApplyFillColour(cellStyle, style.getBackColor(), (short) 1);
				} else if (parentBackColor != null) {
					short fill = (short) (parentBackColor.getAlpha() == 0 ? 0 : 1);
					this.ApplyFillColour(cellStyle, parentBackColor, fill);
				}

				return cellStyle;
			} catch (Exception e) {
				throw new RuntimeException("Error exporting to Excel", e);
			}
		}
	}

	public CellStyle CloneCellStyle(CellStyle style) {
		CellStyle newStyle = this.m_wb.createCellStyle();
		newStyle.cloneStyleFrom(style);
		return newStyle;
	}

	public short getAlignment(com.varicent.common.ui.domain.CellStyle.Alignment alignment) {
		if (alignment == com.varicent.common.ui.domain.CellStyle.Alignment.CENTER) {
			return 2;
		} else if (alignment == com.varicent.common.ui.domain.CellStyle.Alignment.JUSTIFY) {
			return 5;
		} else {
			return (short) (alignment == com.varicent.common.ui.domain.CellStyle.Alignment.LEFT ? 1 : 3);
		}
	}

	public static void setBorderWidth(int width, CellStyle style) {
		try {
			style.setBorderTop(getLineStyle(width));
			style.setBorderLeft(getLineStyle(width));
			style.setBorderBottom(getLineStyle(width));
			style.setBorderRight(getLineStyle(width));
		} catch (Exception e) {
			throw new RuntimeException("Error exporting to Excel", e);
		}
	}

	private static short getLineStyle(float thickness) {
		if (thickness == 0.0F) {
			return 0;
		} else if (thickness == 1.0F) {
			return 1;
		} else {
			return (short) (thickness == 2.0F ? 2 : 5);
		}
	}

	public abstract int getRowLimit();
}
