package com.varicent.reporting.dao.Expander;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.util.Converter;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class MSXYZSourceExpander extends BaseExpander {
	private final BigDecimal DEFAULT_X_MIN;
	private final BigDecimal DEFAULT_X_MAX;
	private BigDecimal xMax;
	private BigDecimal xMin;
	private int currentDataSet;
	private int currentSet;
	private List<XYZDataSet> dataSets;
	private boolean isPercentage;
	private boolean isSYPercentage;
	private boolean isMinMaxSet;
	private Messages messages;
	private List<DataTable> data;

	public MSXYZSourceExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		this.DEFAULT_X_MIN = BigDecimal.ZERO;
		this.DEFAULT_X_MAX = BigDecimal.TEN;
		if (!this.streamReader.getLocalName().equals("MSXYZSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.xMax = this.DEFAULT_X_MAX;
			this.xMin = this.DEFAULT_X_MIN;
			this.currentDataSet = -1;
			this.currentSet = 0;
			this.dataSets = new ArrayList();
			this.data = new ArrayList();
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.currentDataSet != -2) {
			if (this.currentDataSet == -1) {
				this.initializeMSXYSource(writer, scope);
				++this.currentDataSet;
			}

			if (this.currentDataSet < this.dataSets.size()) {
				this.writeSet(writer, this.data, scope);
			} else {
				this.writeEndTags(writer);
				this.currentDataSet = -2;
			}

		}
	}

	private void writeSet(XMLStreamWriter writer, List<DataTable> data, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		XYZDataSet current = this.dataSets.get(this.currentDataSet);
		if (this.currentSet == 0) {
			current.writeStartElements(writer);
		}

		if (this.currentSet < current.sets.size()) {
			current.writeSet(writer, this.currentSet, data.get(this.currentDataSet), scope);
			++this.currentSet;
		} else {
			current.writeEndElement(writer);
			this.currentSet = 0;
			++this.currentDataSet;
		}

	}

	private void writeEndTags(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void initializeMSXYSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String sourceName = "";
		String xColumn = "";
		String yColumn = "";
		String zColumn = "";
		String sourceAlias = "";

		while (this.streamReader.getLocalName().equals("Source")) {
			this.streamReader.nextTag();
			sourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			xColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			yColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			zColumn = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			if (this.streamReader.getLocalName().equals("SourceAlias")) {
				sourceAlias = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			}

			ColumnLink link = null;
			if (this.streamReader.getLocalName().equals("Link")) {
				link = new ColumnLink(this.streamReader);
			}

			this.data.add(scope.getDataTable(sourceName).copy());
			this.dataSets.add(this.getDataSet(sourceName, xColumn, yColumn, zColumn, sourceAlias,
					scope.getDataTable(sourceName).copy(), link));
			this.streamReader.nextTag();
		}

		this.streamReader.nextTag();
		writer.writeStartElement("Xml");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");

		try {
			this.isSYPercentage = this.streamReader.getAttributeValue((String) null, "isSYPercentage").equals("1");
		} catch (NullPointerException var13) {
			this.isSYPercentage = this.isPercentage;
		}

		ChartExpander chartEx = new ChartExpander(this.streamReader, this.messages);
		chartEx.expandChartNode(writer);
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("customColors")) {
			this.expandColorsNode(writer);
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(writer);
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		String width = this.streamReader.getAttributeValue((String) null, "width");

		for (XYZDataSet dataSet : this.dataSets) {
			dataSet.setPercentage(this.isPercentage);
			dataSet.setSYPercentage(this.isSYPercentage);
		}

		this.createCategoriesNode(writer, Integer.parseInt(width));
		XMLStreamUtility.MoveStreamForwardToTag(this.streamReader, "MSXYZSource");
	}

	private XYZDataSet getDataSet(String sourceName, String xColumn, String yColumn, String zColumn, String sourceAlias,
			DataTable data, ColumnLink link) {
		String seriesName = sourceAlias != null && !sourceAlias.equals("") ? sourceAlias : sourceName;
		XYZDataSet dataSet = new XYZDataSet(seriesName, xColumn, yColumn, zColumn, link);
		BigDecimal _xMin = this.DEFAULT_X_MIN;
		BigDecimal _xMax = this.DEFAULT_X_MAX;

		for (int i = 0; i < data.getRows().size(); ++i) {
			BigDecimal x = data.getObject(i, xColumn) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(data.getObject(i, xColumn));
			BigDecimal y = data.getObject(i, yColumn) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(data.getObject(i, yColumn));
			BigDecimal z = data.getObject(i, zColumn) == null ? BigDecimal.ZERO
					: Converter.ConvertToBigDecimal(data.getObject(i, zColumn));
			if (!this.isMinMaxSet) {
				_xMax = x;
				_xMin = x;
				this.isMinMaxSet = true;
			} else {
				_xMax = _xMax.max(x);
				_xMin = _xMin.min(x);
			}

			dataSet.add(x.toPlainString(), y.toPlainString(), z.toPlainString());
		}

		this.xMax = this.xMax.max(_xMax);
		this.xMin = this.xMin.min(_xMin);
		return dataSet;
	}

	private void createCategoriesNode(XMLStreamWriter writer, int width) throws XMLStreamException {
		if (this.isPercentage) {
			this.xMax = this.xMax.multiply(new BigDecimal(100));
			this.xMin = this.xMin.multiply(new BigDecimal(100));
		}

		int numCategories = (int) Math.floor(width / 65);
		numCategories = Math.max(2, numCategories);
		BigDecimal increment = BigDecimal.ONE
				.max(this.xMax.subtract(this.xMin).divide(new BigDecimal(numCategories - 1), 6));
		BigDecimal xCurrent = this.xMin.subtract(this.xMin.remainder(increment));
		writer.writeCharacters("<categories verticalLineThickness='1' >");

		for (int i = 0; i < numCategories; ++i) {
			BigDecimal rounded = xCurrent.setScale(0, 6);
			writer.writeCharacters("<category ");
			writer.writeCharacters("label='" + rounded.toPlainString() + "' ");
			writer.writeCharacters("x='" + rounded.toPlainString() + "' ");
			writer.writeCharacters("showVerticalLine='1' />");
			xCurrent = xCurrent.add(increment);
		}

		writer.writeCharacters("</categories>");
	}
}
