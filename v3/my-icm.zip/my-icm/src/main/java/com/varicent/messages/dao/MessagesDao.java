package com.varicent.messages.dao;

import java.util.Date;
import java.util.List;

import com.varicent.core.util.MessageNavigation;
import com.varicent.messages.domain.Message;

public interface MessagesDao {
	int getNewMessageCount();

	List<Message> getMessages(int var1, Date var2, Date var3);

	Message getMessage(int var1, Message.Category var2, MessageNavigation.ListType var3, boolean var4);

	Message getMessageNext(Date var1, int var2, MessageNavigation.ListType var3, NextDirection var4);

	Message getInquiryMessageNext(Date var1, int var2, int var3, MessageNavigation.SubType var4, int var5,
			NextDirection var6);

	public static enum NextDirection {
		UP, DOWN;
	}
}
