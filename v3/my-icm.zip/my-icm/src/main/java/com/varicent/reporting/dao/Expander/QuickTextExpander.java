package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.Scope;

public class QuickTextExpander extends BaseExpander {
	public QuickTextExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("QuickTextDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("QuickTextDisplay")) {
			this.streamReader.nextTag();
			writer.writeStartElement("QuickTextDisplay");
			super.copyCurrentNode(writer);
			super.copyCurrentNode(writer);
			if (this.streamReader.getLocalName().equals("Link")) {
				LinkExpander link = new LinkExpander(this.streamReader);
				link.read(writer, scope, permitted, editable);
			}

			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
