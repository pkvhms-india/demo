package com.varicent.BPM.dao.jdbc;

import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.QueryDefinition;

public class BPMQuery {
	public static QueryDefinition getActionableReportsQuery(String payeeId) {
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		query.selectDistinct();
		query.select("BPMWorkflow", "WebReportID");
		Join swimLaneJoin = new Join("BPMSwimLane", Join.Type.INNER);
		swimLaneJoin.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, "BPMSwimLane",
				"WorkflowID");
		query.joinWith(swimLaneJoin);
		Join nodeJoin = new Join("BPMNode", Join.Type.INNER);
		nodeJoin.newConstraint("BPMSwimLane", "SwimLaneID", Constraint.Operator.Equals, "BPMNode", "SwimLaneID");
		query.joinWith(nodeJoin);
		Join tokenJoin = new Join("BPMToken", Join.Type.INNER);
		tokenJoin.newConstraint("BPMNode", "NodeID", Constraint.Operator.Equals, "BPMToken", "NodeID");
		query.joinWith(tokenJoin);
		Join tokenAssigneeJoin = new Join("BPMTokenAssignee", Join.Type.INNER);
		tokenAssigneeJoin.newConstraint("BPMToken", "TokenID", Constraint.Operator.Equals, "BPMTokenAssignee",
				"TokenID");
		query.joinWith(tokenAssigneeJoin);
		query.newConstraint("BPMTokenAssignee", "Assignee", Constraint.Operator.Equals, payeeId);
		return query;
	}

	public static QueryDefinition getInitializableReportsQuery(String payeeId) {
		QueryDefinition query = new QueryDefinition("BPMWorkflow");
		query.selectDistinct();
		query.select("BPMWorkflow", "WebReportID");
		Join initiatorJoin = new Join("BPMWorkflowInitiator", Join.Type.INNER);
		initiatorJoin.newConstraint("BPMWorkflow", "WorkflowID", Constraint.Operator.Equals, "BPMWorkflowInitiator",
				"WorkflowID");
		query.joinWith(initiatorJoin);
		query.newConstraint("BPMWorkflowInitiator", "PayeeID", Constraint.Operator.Equals, payeeId);
		return query;
	}
}
