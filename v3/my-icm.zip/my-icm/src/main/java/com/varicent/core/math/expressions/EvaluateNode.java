package com.varicent.core.math.expressions;

import java.math.BigDecimal;

public interface EvaluateNode {
	BigDecimal evaluate();

	void reset();
}
