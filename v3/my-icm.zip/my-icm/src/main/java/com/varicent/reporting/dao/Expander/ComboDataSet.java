package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;

class ComboDataSet {
	private String seriesName;
	private String renderType;
	private List<ComboSet> sets;
	private int index;
	private int currentCategory;
	private ColumnLink link;
	DataTable data;
	private boolean isPercentage;
	private String dispCol;
	private String valueCol;

	public ComboDataSet(String seriesName, String renderType, DataTable data, String displayCol, String valueCol,
			ColumnLink link) {
		this.seriesName = seriesName;
		this.renderType = renderType;
		this.sets = new ArrayList();
		this.data = data;
		this.dispCol = displayCol;
		this.valueCol = valueCol;
		this.link = link;
	}

	public Object getValue() {
		return this.valueCol;
	}

	public String getType() {
		return this.renderType;
	}

	public String getDisplay() {
		return this.dispCol;
	}

	public void add(ComboSet set) {
		this.sets.add(set);
	}

	public void sortSets() {
		Collections.sort(this.sets);
	}

	public String getName() {
		return this.seriesName;
	}

	public void setLink(ColumnLink link) {
		this.link = link;
	}

	public void setPercentage(boolean isPerc) {
		this.isPercentage = isPerc;
	}

	public void writeDataSetStartElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<dataset seriesName='" + this.seriesName + "' renderAs='" + this.renderType + "' >");
	}

	public void writeDataSetElement(XMLStreamWriter writer, List<ComboCategory> categories, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		ComboCategory category = categories.get(this.currentCategory);
		if (this.index < this.sets.size() && category == this.sets.get(this.index).category
				&& this.index < this.data.getRows().size()) {
			this.sets.get(this.index).writeXMLElement(writer, this.index, this.data, scope, this.seriesName, this.link,
					this.isPercentage);
			++this.index;
		} else {
			ComboSet.writeEmptyXMLElement(writer);
		}

		++this.currentCategory;
	}

	public void writeDataSetEndElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</dataset>");
	}
}
