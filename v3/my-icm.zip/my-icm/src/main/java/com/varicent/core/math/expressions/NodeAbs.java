package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeAbs extends UnaryNode implements EvaluateNode {
	public NodeAbs(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal argValue = this.arg.evaluate();
		return argValue == null ? null : argValue.abs();
	}

	@Override
	public void reset() {
		this.arg.reset();
	}

	@Override
	public String getJSMathFunctionName() {
		return "abs";
	}
}
