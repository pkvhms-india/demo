package com.varicent.messages.service;

import java.util.Date;
import java.util.List;

import com.varicent.messages.domain.Message;

public interface MessagesManager {
	int getNewMessageCount();

	List<Message> getMessages(int var1, Date var2, Date var3);
}
