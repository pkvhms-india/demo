package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

public class NodeDivide extends BinaryNode implements EvaluateNode {
	public NodeDivide(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal divisor = this.rhs.evaluate();
		BigDecimal lhsEvaluated = this.lhs.evaluate();
		if (divisor != null && lhsEvaluated != null) {
			return divisor.compareTo(BigDecimal.ZERO) == 0 ? divisor
					: lhsEvaluated.divide(divisor, new MathContext(28));
		} else {
			return null;
		}
	}

	@Override
	public String getJSMathFunctionName() {
		return "divide";
	}
}
