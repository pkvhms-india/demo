package com.varicent.core.system.windows;

import java.util.ArrayList;
import java.util.Collection;
import java.util.StringTokenizer;

public class MultiStringRegistryParser implements RegistryEntryParser {
	public static final String DELIM = "0";

	@Override
	public Object parse(String value) {
		StringTokenizer tokens = new StringTokenizer(value, "0");
		Collection<String> strs = new ArrayList();

		while (tokens.hasMoreTokens()) {
			String line = tokens.nextToken();
			line.trim();
			if (line.length() > 0 && line.lastIndexOf(92) == line.length() - 1) {
				line = line.substring(0, line.length() - 1);
				strs.add(line.substring(line.lastIndexOf(44) + 1));
			} else if (line.length() > 0 && !tokens.hasMoreTokens()) {
				strs.add(line.substring(line.lastIndexOf(44) + 1));
			}
		}

		return strs;
	}
}
