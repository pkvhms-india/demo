package com.varicent.draws.web.view;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.varicent.common.pdf.AbstractITextPdfView;
import com.varicent.common.pdf.PdfCell;
import com.varicent.common.pdf.PdfDocument;
import com.varicent.common.pdf.PdfImage;
import com.varicent.common.pdf.PdfTable;
import com.varicent.core.i18n.Messages;
import com.varicent.reporting.domain.WebReportPdfOptions;
import com.varicent.reporting.web.view.PdfWebReportReader;

@Component
public class OverviewPdfView extends AbstractITextPdfView {
	private final Messages messages;

	@Autowired
	public OverviewPdfView(Messages messages) {
		this.messages = messages;
	}

	PdfDocument makeDocument(Map<String, Object> model) {
		PdfDocument doc = new PdfDocument();
		doc.setExpandToFit(true);
		Map<String, String> map = (Map) model.get("chartsData");
		byte[] logo = (byte[]) model.get("logo");
		PdfTable table = new PdfTable(new float[] { 100.0F }, 500.0F,
				new WebReportPdfOptions(true, false, 100.0F, false, false, (String) null));
		if (logo != null) {
			PdfImage logoImg = new PdfImage(logo);
			PdfCell logoCell = new PdfCell();
			logoCell.setHorizontalAlign(PdfCell.HorizontalAlignment.Center);
			logoCell.setUseBorderPadding(true);
			logoCell.add(logoImg);
			table.add(0, 0, 1, logoCell);
		}

		PdfTable pieChartTable = new PdfTable(new float[] { 50.0F, 50.0F }, 500.0F,
				new WebReportPdfOptions(true, false, 100.0F, false, false, (String) null));
		PdfImage img1 = new PdfImage(PdfWebReportReader.getChartImage(map.get("onDrawsChart"), 550, 400));
		if (img1.getBytes() != null) {
			PdfCell cell1 = new PdfCell();
			cell1.setUseBorderPadding(true);
			cell1.add(img1);
			pieChartTable.add(0, 0, 1, cell1);
		}

		PdfImage img2 = new PdfImage(PdfWebReportReader.getChartImage(map.get("onDrawsChart2"), 550, 400));
		if (img2.getBytes() != null) {
			PdfCell cell2 = new PdfCell();
			cell2.setUseBorderPadding(true);
			cell2.add(img2);
			pieChartTable.add(1, 0, 1, cell2);
			PdfCell pieChartCell = new PdfCell();
			pieChartCell.add(pieChartTable);
			table.add(0, 1, 1, pieChartCell);
		}

		PdfImage img3 = new PdfImage(PdfWebReportReader.getChartImage(map.get("onDrawsChart3"), 550, 400));
		if (img3.getBytes() != null) {
			PdfCell cell3 = new PdfCell();
			cell3.setHorizontalAlign(PdfCell.HorizontalAlignment.Center);
			cell3.setUseBorderPadding(true);
			cell3.add(img3);
			table.add(0, 2, 1, cell3);
		}

		PdfImage img4 = new PdfImage(PdfWebReportReader.getChartImage(map.get("onDrawsChart4"), 550, 400));
		if (img4.getBytes() != null) {
			PdfCell cell4 = new PdfCell();
			cell4.setHorizontalAlign(PdfCell.HorizontalAlignment.Center);
			cell4.setUseBorderPadding(true);
			cell4.add(img4);
			table.add(0, 3, 1, cell4);
		}

		doc.add(table);
		return doc;
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document doc, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		PdfDocument pdfDoc = (PdfDocument) model.get("pdf");
		model.remove("pdf");
		pdfDoc.buildPdf(doc, writer, this.messages);
	}

	@Override
	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		PdfDocument pdfDoc = this.makeDocument(model);
		pdfDoc.addPdfMetadata(document);
		model.put("pdf", pdfDoc);
		super.buildPdfMetadata(model, document, request);
	}
}
