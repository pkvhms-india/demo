package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeComparison extends BinaryNode implements EvaluateNode {
	private Predicate<BigDecimal> comparison;
	JavascriptNode.ComparisonType comparisonType;

	public NodeComparison(List<EvaluateNode> arguments, Predicate<BigDecimal> comparison, int suffix,
			JavascriptNode.ComparisonType comparisonType) {
		super(arguments, suffix);
		this.comparison = comparison;
		this.comparisonType = comparisonType;
	}

	@Override
	public BigDecimal evaluate() {
		if (this.lhs instanceof NodeString) {
			assert this.rhs instanceof NodeString : "Comparison operands shall be of same type!";

			if (this.comparisonType == JavascriptNode.ComparisonType.Equal) {
				return ((NodeString) this.lhs).EqualEvaluate().equals(((NodeString) this.rhs).EqualEvaluate())
						? BigDecimal.ONE
						: BigDecimal.ZERO;
			} else if (this.comparisonType == JavascriptNode.ComparisonType.NotEqual) {
				return ((NodeString) this.lhs).EqualEvaluate().equals(((NodeString) this.rhs).EqualEvaluate())
						? BigDecimal.ZERO
						: BigDecimal.ONE;
			} else {
				return BigDecimal.ZERO;
			}
		} else {
			BigDecimal x = this.lhs.evaluate();
			BigDecimal y = this.rhs.evaluate();
			return this.comparison.test(x, y) ? BigDecimal.ONE : BigDecimal.ZERO;
		}
	}

	@Override
	public String getJSMathFunctionName() {
		switch (this.comparisonType) {
		case Equal:
			return "equal";
		case NotEqual:
			return "notEqual";
		case Greater:
			return "greater";
		case GreaterEq:
			return "greaterEq";
		case Less:
			return "less";
		default:
			return "lessEq";
		}
	}
}
