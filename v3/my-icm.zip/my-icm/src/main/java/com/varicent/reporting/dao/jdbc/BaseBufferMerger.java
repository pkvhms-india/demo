package com.varicent.reporting.dao.jdbc;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.JdbcOperations;

import com.varicent.common.concurrency.dao.ConcurrencyDao;
import com.varicent.common.port.domain.Port;
import com.varicent.common.port.domain.PortSourceResolver;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.ISelectItem;
import com.varicent.common.query.domain.Join;
import com.varicent.common.query.domain.OrClause;
import com.varicent.common.query.domain.OrderItem;
import com.varicent.common.query.domain.QueryDefinition;
import com.varicent.common.query.domain.SelectAll;
import com.varicent.common.query.domain.SelectCustom;
import com.varicent.common.query.domain.SelectItem;
import com.varicent.common.query.domain.SelectTableAll;
import com.varicent.common.query.domain.SqlDataSource;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.database.schema.TableDefinition;

public abstract class BaseBufferMerger {
	protected final ConcurrencyDao concurrencyDao;
	protected final SchemaDao schemaDao;
	protected final PortSourceResolver portResolver;
	protected final JdbcOperations operations;
	protected final MergeNameResolver mergeNameResolver;
	private List<String> bufferTables;

	public BaseBufferMerger(SchemaDao schemaDao, ConcurrencyDao concurrencyDao, Map<String, Port> portMap,
			JdbcOperations operations, List<String> bufferTables) {
		this.schemaDao = schemaDao;
		this.portResolver = new PortSourceResolver(portMap.values());
		this.operations = operations;
		this.mergeNameResolver = new MergeNameResolver(this.schemaDao, this.portResolver, this.getPrefix());
		this.concurrencyDao = concurrencyDao;
		this.bufferTables = bufferTables;
	}

	public abstract String getPrefix();

	public abstract String getBufferTable(String var1);

	public abstract boolean isBufferTable(String var1);

	public abstract QueryDefinition initializeQd(String var1);

	public void mergeWithBufferUpdate(QueryDefinition sourceQuery) {
		if (sourceQuery.getSource() == null || sourceQuery.getSource().getAlias() == null
				|| !this.isBufferTable(sourceQuery.getSource().getAlias())) {
			if (sourceQuery.getUnion() != null) {
				this.mergeWithBufferUpdate(sourceQuery.getUnion());
			}

			for (Join join : sourceQuery.getJoins()) {
				if (join.getSource().getSourceType() == SqlDataSource.Type.QUERY) {
					this.mergeWithBufferUpdate(join.getSource().getQuery());
				} else {
					String joinTable = join.getSource().getTable();
					if (this.needToMergeWithBuffer(joinTable)) {
						QueryDefinition innerSource = new QueryDefinition(joinTable);
						innerSource.selectAll();
						join.setSource(new SqlDataSource(innerSource, join.getSource().getName()));
						this.mergeWithTable(innerSource);
					}
				}
			}

			if (sourceQuery.getSource() != null) {
				if (sourceQuery.getSource().getSourceType() == SqlDataSource.Type.QUERY) {
					this.mergeWithBufferUpdate(sourceQuery.getSource().getQuery());
				} else {
					String sourceName = sourceQuery.getSource().getName();
					String sourceTable = sourceQuery.getSource().getTable();
					if (this.needToMergeWithBuffer(sourceTable)) {
						QueryDefinition innerSource = new QueryDefinition(sourceTable);
						innerSource.selectAll();
						sourceQuery.setSource(new SqlDataSource(innerSource, sourceName));
						this.mergeWithTable(innerSource);
					}
				}

			}
		}
	}

	public boolean needToMergeWithBuffer(String sourceName) {
		String table = sourceName.startsWith("_Port") ? this.portResolver.getSource(sourceName) : sourceName;
		if (table == null) {
			return false;
		} else {
			String bufferTable = this.getBufferTable(table);
			return !this.isBufferTable(table) && this.bufferTables.contains(bufferTable)
					&& !this.concurrencyDao.BufferTableEmpty(bufferTable);
		}
	}

	protected QueryDefinition baseBufferTableQuery(String table) {
		String bufferTable = this.getBufferTable(table);
		QueryDefinition ijqd = new QueryDefinition(bufferTable);
		String joinAlias = "_ja";
		String joinAlias2 = "_ja2";
		String idAlias = "_created_alias";
		Join selfJoin = new Join(bufferTable, joinAlias, Join.Type.LEFT);
		TableDefinition tableDef = this.schemaDao.getTable(table);
		QueryDefinition qd = this.initializeQd(bufferTable);

		for (ColumnDefinition colDef : tableDef.getColumns()) {
			if (colDef.isKey()) {
				ijqd.select(bufferTable, colDef.getName());
				ijqd.groupBy(colDef.getName());
			}
		}

		ijqd.select(bufferTable, "_Type");
		ijqd.groupBy("_Type");
		ijqd.selectMax(bufferTable, "_ID", idAlias);
		Join selfInnerJoin = new Join(ijqd, joinAlias2, Join.Type.INNER);

		for (ColumnDefinition colDef : tableDef.getColumns()) {
			String colName = colDef.getName();
			qd.select(bufferTable, colName);
			if (colDef.isKey()) {
				selfJoin.newConstraint(bufferTable, colName, Constraint.Operator.Equals, joinAlias, colName);
				selfInnerJoin.newConstraint(bufferTable, colName, Constraint.Operator.Equals, joinAlias2, colName);
			}
		}

		selfJoin.newConstraint(bufferTable, "_Type", Constraint.Operator.NotEquals, joinAlias, "_Type");
		selfInnerJoin.newConstraint(bufferTable, "_Type", Constraint.Operator.Equals, joinAlias2, "_Type");
		selfInnerJoin.newConstraint(bufferTable, "_ID", Constraint.Operator.Equals, joinAlias2, idAlias);
		qd.joinWith(selfJoin);
		qd.joinWith(selfInnerJoin);
		OrClause or = new OrClause();
		or.newNullConstraint(joinAlias, "_ID", true);
		or.newConstraint(joinAlias, "_Type", Constraint.Operator.Equals, BaseBufferMerger.Action.Insert.getValue());
		qd.addConstraint(or);
		return qd;
	}

	protected void mergeWithTable(QueryDefinition query) {
		String table = query.getSource().getTable();
		String tableAlias = query.getSource().getName();
		if (query.getSelect().size() == 1 && (query.getSelect().get(0) instanceof SelectTableAll
				|| query.getSelect().get(0) instanceof SelectAll)) {
			query.getSelect().clear();

			for (String colName : this.mergeNameResolver.getTableCols(table)) {
				query.select(tableAlias, colName);
			}
		}

		String bufferTable = this.mergeNameResolver.getSourceBufferTable(table);
		TableDefinition resolvedTableDef = this.schemaDao.getTable(table);
		QueryDefinition bufferTableWODup = this.baseBufferTableQuery(table);
		Join updateJoin = new Join(bufferTableWODup, bufferTable, Join.Type.LEFT);
		query.joinWith(updateJoin);
		QueryDefinition insertUnion = new QueryDefinition(bufferTableWODup, bufferTable);
		Join insertJoin = new Join(table, Join.Type.LEFT);
		insertUnion.joinWith(insertJoin);

		for (ISelectItem iSelectItem : query.getSelect()) {
			SelectItem selectItem = (SelectItem) iSelectItem;
			String unresolvedColName = selectItem.getColumn();
			insertUnion.select(bufferTable, this.mergeNameResolver.getTableCol(tableAlias, unresolvedColName),
					unresolvedColName);
		}

		query.union(insertUnion);
		List<OrderItem> orderBys = query.getOrder();

		for (OrderItem orderBy : orderBys) {
			insertUnion.orderBy(orderBy.getColumn(), orderBy.getDirection().equals(OrderItem.Direction.DESCENDING));
		}

		orderBys.clear();
		String firstKeyColumnName = resolvedTableDef.getKeyColumns().get(0).getName();
		insertUnion.newNullConstraint(table, firstKeyColumnName, true);

		for (ColumnDefinition resolvedColumn : resolvedTableDef.getColumns()) {
			String resolvedColName = resolvedColumn.getName();
			if (resolvedColumn.isKey()) {
				updateJoin.addConstraint(Constraint.newConstraint(tableAlias,
						this.mergeNameResolver.reverseLookup(table, resolvedColName), Constraint.Operator.Equals,
						bufferTable, resolvedColumn.getName()));
				insertJoin.addConstraint(
						Constraint.newConstraint(table, this.mergeNameResolver.reverseLookup(table, resolvedColName),
								Constraint.Operator.Equals, bufferTable, resolvedColumn.getName()));
			} else {
				String caseSelect = "CASE WHEN [" + bufferTable + "].[" + firstKeyColumnName + "] IS NULL THEN ["
						+ tableAlias + "].[" + resolvedColName + "] ELSE [" + bufferTable + "].[" + resolvedColName
						+ "] END";
				this.ReplaceSelect(query, tableAlias, resolvedColName, new SelectCustom(caseSelect, resolvedColName));
			}
		}

	}

	void ReplaceSelect(QueryDefinition qd, String table, String column, ISelectItem newSelect) {
		List<ISelectItem> selects = qd.getSelect();

		for (int i = 0; i < selects.size(); ++i) {
			if (selects.get(i) instanceof SelectItem) {
				SelectItem selectItem = (SelectItem) selects.get(i);
				if (selectItem.getTable().equals(table) && selectItem.getColumn().equals(column)) {
					selects.set(i, newSelect);
					break;
				}
			}
		}

	}

	static enum Action {
		Insert(0), Update(1);

		private int value;

		private Action(int value) {
			this.value = value;
		}

		public int getValue() {
			return this.value;
		}
	}

	class MergeNameResolver {
		private final PortSourceResolver portResolver;
		private final SchemaDao schemaDao;
		private final String prefix;

		public MergeNameResolver(SchemaDao schemaDao, PortSourceResolver portResolver, String prefix) {
			this.schemaDao = schemaDao;
			this.portResolver = portResolver;
			this.prefix = prefix;
		}

		public String getActualTable(String alias) {
			return alias.startsWith("_Port") ? this.portResolver.getSource(alias) : alias;
		}

		public String reverseLookup(String unresolvedTable, String resolvedColumn) {
			if (!unresolvedTable.startsWith("_Port")) {
				return resolvedColumn;
			} else {
				Map<String, String> portCols = this.portResolver.getSourceColumnMap(unresolvedTable);

				for (String key : portCols.keySet()) {
					if (portCols.get(key).equals(resolvedColumn)) {
						return key;
					}
				}

				return null;
			}
		}

		public String getSourceBufferTable(String table) {
			return this.prefix + this.getActualTable(table);
		}

		public Set<String> getTableCols(String table) {
			if (table.startsWith("_Port")) {
				return this.portResolver.getSourceColumnMap(table).keySet();
			} else {
				Set<String> colNames = new HashSet();

				for (ColumnDefinition col : this.schemaDao.getTable(table).getColumns()) {
					colNames.add(col.getName());
				}

				return colNames;
			}
		}

		public String getTableCol(String table, String col) {
			return table.startsWith("_Port") ? this.portResolver.getSourceColumn(table, col) : col;
		}
	}
}
