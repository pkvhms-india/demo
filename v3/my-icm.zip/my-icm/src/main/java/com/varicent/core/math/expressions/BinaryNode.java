package com.varicent.core.math.expressions;

import java.util.List;

import org.springframework.util.Assert;

public abstract class BinaryNode extends JavascriptNode {
	protected EvaluateNode lhs;
	protected EvaluateNode rhs;

	public BinaryNode(List<EvaluateNode> arguments, int suffix) {
		super(suffix);
		Assert.state(arguments.size() == 2);
		this.lhs = arguments.get(0);
		this.rhs = arguments.get(1);
	}

	public void reset() {
		this.lhs.reset();
		this.rhs.reset();
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		String function = this.getJSFunctionName(jsUtil);
		String resultVariable = this.getJSResultVariableName(jsUtil);
		String lhsVariable = ((JavascriptNode) this.lhs).getJSResultVariableName(jsUtil);
		String rhsVariable = ((JavascriptNode) this.rhs).getJSResultVariableName(jsUtil);
		sb.append(JavascriptUtil.getFunctionSigniture(function));
		sb.append(resultVariable);
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(lhsVariable);
		sb.append(", ");
		sb.append(rhsVariable);
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.lhs).toJavascript(jsUtil));
		sb.append(((JavascriptNode) this.rhs).toJavascript(jsUtil));
		return sb.toString();
	}
}
