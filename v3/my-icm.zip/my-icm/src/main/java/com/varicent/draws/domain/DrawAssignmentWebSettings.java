package com.varicent.draws.domain;

import java.io.Serializable;

import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.core.text.NumericFormat;

public class DrawAssignmentWebSettings implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private boolean allowGroupSelection;
	private SourceDefinition restriction;
	private int workflowObjectId;
	private int rowsPerPage;
	private NumericFormat.Style numericStyle;

	public DrawAssignmentWebSettings(int id, boolean allowGroupSelection, SourceDefinition restriction,
			int workflowObjectID, int rowsPerPage, NumericFormat.Style numericStyle) {
		this.id = id;
		this.allowGroupSelection = allowGroupSelection;
		this.restriction = restriction;
		this.workflowObjectId = workflowObjectID;
		this.rowsPerPage = rowsPerPage;
		this.numericStyle = numericStyle;
	}

	public boolean isUseRestriction() {
		return this.restriction != null;
	}

	public int getId() {
		return this.id;
	}

	public boolean isAllowGroupSelection() {
		return this.allowGroupSelection;
	}

	public NumericFormat.Style getNumericStyle() {
		return this.numericStyle;
	}

	public SourceDefinition getRestriction() {
		return this.restriction;
	}

	public int getWorkflowObjectId() {
		return this.workflowObjectId;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setAllowGroupSelection(boolean allowGroupSelection) {
		this.allowGroupSelection = allowGroupSelection;
	}

	public void setRestriction(SourceDefinition restriction) {
		this.restriction = restriction;
	}

	public void setWorkflowObjectId(int workflowObjectId) {
		this.workflowObjectId = workflowObjectId;
	}

	public int getRowsPerPage() {
		return this.rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}
}
