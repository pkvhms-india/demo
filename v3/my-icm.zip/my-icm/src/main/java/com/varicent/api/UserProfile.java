package com.varicent.api;

import org.codehaus.jackson.map.annotate.JsonRootName;

@JsonRootName("user")
public class UserProfile {
	private String pictureUrl;
	private String payeeID;
	private String payeeName;
	private String email;

	public UserProfile() {
	}

	public UserProfile(String payeeID, String payeeName, String email, String pictureUrl) {
		this.pictureUrl = pictureUrl;
		this.payeeID = payeeID;
		this.payeeName = payeeName;
		this.email = email;
	}

	public String getPictureUrl() {
		return this.pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getPayeeID() {
		return this.payeeID;
	}

	public void setPayeeID(String payeeID) {
		this.payeeID = payeeID;
	}

	public String getPayeeName() {
		return this.payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return String.format("{user:{payeeID:'%s', payeeName:'%s', email: '%s', pictureUrl:'%s'}}", this.payeeID,
				this.payeeName, this.email, this.pictureUrl);
	}
}
