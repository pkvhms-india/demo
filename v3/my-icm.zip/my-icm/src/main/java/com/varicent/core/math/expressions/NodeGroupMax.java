package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.util.List;

public class NodeGroupMax extends UnaryNode implements EvaluateNode, AggregateNode {
	private BigDecimal max = null;
	private boolean isFinalized;

	public NodeGroupMax(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		if (this.isFinalized) {
			return this.max;
		} else {
			BigDecimal value = this.arg.evaluate();
			if (value != null && (this.max == null || value.compareTo(this.max) > 0)) {
				this.max = value;
			}

			return this.max;
		}
	}

	@Override
	public void reset() {
		if (!this.isFinalized) {
			this.max = null;
			this.arg.reset();
		}
	}

	@Override
	public String toJavascript(JavascriptUtil jsUtil) {
		StringBuilder sb = new StringBuilder();
		sb.append("function ");
		sb.append(this.getJSFunctionName(jsUtil));
		sb.append("() {");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(" = ");
		sb.append(this.getJSMathFunctionName());
		sb.append("(");
		sb.append(this.getJSResultVariableName(jsUtil));
		sb.append(", ");
		sb.append(((JavascriptNode) this.arg).getJSResultVariableName(jsUtil));
		sb.append(");");
		sb.append("}");
		sb.append(((JavascriptNode) this.arg).toJavascript(jsUtil));
		return sb.toString();
	}

	@Override
	public String getJSMathFunctionName() {
		return "groupMax";
	}

	@Override
	public void finalize() {
		this.isFinalized = true;
	}
}
