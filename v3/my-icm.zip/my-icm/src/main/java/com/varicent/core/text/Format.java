package com.varicent.core.text;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.crypto.codec.Hex;

import com.varicent.core.Constants;
import com.varicent.reporting.domain.PRDateFormat;

public class Format {
	public static final Pattern REGEX_AMP = Pattern.compile("&amp;");
	public static final String PTN_OBJECT = "({0}) {1}";
	public static final String PTN_TIMESTAMP = "yyyyMMddHHmmss";

	public static String asFullDate(Date date) {
		Locale locale = LocaleContextHolder.getLocale();
		String pattern = DateTimeFormat.patternForStyle("F-", locale);
		pattern = pattern.replace(" d,", " dd,");
		DateTimeFormatter patternedFormat = DateTimeFormat.forPattern(pattern).withLocale(locale);
		return patternedFormat.print(new DateTime(date));
	}

	public static String asISODate(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		return dateFormat.format(date);
	}

	public static String asISODateTime(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		return dateFormat.format(date);
	}

	public static String asObjectString(String id, String name) {
		return MessageFormat.format("({0}) {1}", id, name);
	}

	public static String asFullLongDateTime(Date date) {
		String pattern = fullLongTimeFormat();
		return printDateTimeWithLongYear(pattern, date);
	}

	public static String asShortDate(Date date) {
		String pattern = getShortDateFormatString();
		return printDateTimeWithLongYear(pattern, date);
	}

	static String printDateTimeWithLongYear(String pattern, Date date) {
		String[] parts = pattern.split("/");
		pattern = "";

		for (int i = 0; i < parts.length; ++i) {
			if (parts[i].contains("yy")) {
				parts[i] = parts[i].replace("yy", "yyyy");
			} else if (parts[i].equals("M")) {
				parts[i] = "MM";
			} else if (parts[i].equals("d")) {
				parts[i] = "dd";
			}

			pattern = pattern + "/" + parts[i];
		}

		if (parts.length > 0) {
			pattern = pattern.substring(1);
		}

		return DateTimeFormat.forPattern(pattern).withLocale(LocaleContextHolder.getLocale()).print(new DateTime(date));
	}

	public static String asShortDateTime(Date date) {
		String pattern = shortDateTimeFormat();
		return printDateTimeWithLongYear(pattern, date);
	}

	public static String asTrimmedNumber(BigDecimal num) {
		String value = asValueString(num);
		value = value.trim();
		value = value.replace(new String(new char[] { ' ' }), "");
		return value;
	}

	public static String asTimestamp(Date date) {
		return DateTimeFormat.forPattern("yyyyMMddHHmmss").print(new DateTime(date));
	}

	public static String asValueString(Object o) {
		return asValueString(o, (NumericFormat) null);
	}

	public static String asValueString(Object o, NumericFormat format) {
		return asValueString(o, format, (PRDateFormat) null);
	}

	public static String asPRValueString(Object o, NumericFormat format, PRDateFormat dateFormat) {
		return asValueString(o, format, dateFormat);
	}

	static String asValueString(Object o, NumericFormat format, PRDateFormat dateFormat) {
		if (o == null) {
			return "";
		} else if (o instanceof BigDecimal) {
			BigDecimal value = (BigDecimal) o;
			if (format == null) {
				int scale = getScale(value.toPlainString());
				return scale > NumericFormat.DECIMAL_FIXED.getScale()
						? (new NumericFormat(NumericFormat.Style.NUMBER, scale)).asString(value)
						: NumericFormat.DECIMAL_FIXED.asString(value);
			} else {
				return format.asString(value);
			}
		} else if (o instanceof Date) {
			if (((Date) o).before(Constants.MIN_DATE)) {
				return "";
			} else {
				return dateFormat != null && !dateFormat.getDateStyle().equals(PRDateFormat.DateStyle.Date)
						? asShortDateTime((Date) o)
						: asShortDate((Date) o);
			}
		} else {
			return o.toString();
		}
	}

	public static String lengthSecureString(String s, int maxLength) {
		String secureString = s;
		if (s.length() > maxLength) {
			secureString = s.substring(0, maxLength);
		}

		return secureString;
	}

	public static String getShortDateFormatString() {
		return DateTimeFormat.patternForStyle("S-", LocaleContextHolder.getLocale());
	}

	public static String getMediumDateFormatString() {
		String dateFormat = DateTimeFormat.patternForStyle("S-", LocaleContextHolder.getLocale());
		if (dateFormat.indexOf("yyy") == -1) {
			dateFormat = dateFormat.replace("yy", "yyyy");
		}

		return dateFormat;
	}

	public static String getLongDateFormatString() {
		String dateFormat = DateTimeFormat.patternForStyle("L-", LocaleContextHolder.getLocale());
		if (dateFormat.indexOf("yyy") == -1) {
			dateFormat = dateFormat.replace("yy", "yyyy");
		}

		return dateFormat;
	}

	public static String fullLongTimeFormat() {
		return DateTimeFormat.patternForStyle("LL", LocaleContextHolder.getLocale());
	}

	public static String shortDateTimeFormat() {
		return DateTimeFormat.patternForStyle("SS", LocaleContextHolder.getLocale());
	}

	public static String getLongDateTimeFormat() {
		String dateFormat = DateTimeFormat.patternForStyle("SS", LocaleContextHolder.getLocale());
		if (dateFormat.indexOf("yyy") == -1) {
			dateFormat = dateFormat.replace("yy", "yyyy");
		}

		if (dateFormat.indexOf("a") == dateFormat.length() - 1) {
			dateFormat = dateFormat.replace("a", "AM/PM");
		}

		return dateFormat;
	}

	public static String sanitizeForChart(String in) {
		in = in.replace("%", "%25");
		in = in.replace("&", "%26");
		in = in.replace("<", "%26lt;");
		in = in.replace(">", "%26gt;");
		in = in.replace("'", "%26apos;");
		in = in.replace("\"", "%26quot;");
		in = in.replace("\\", "\\\\");
		return in;
	}

	public static String asMD5Hash(String in) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.reset();
			byte[] digestedName = md.digest(in.getBytes("UTF-8"));
			return new String(Hex.encode(digestedName));
		} catch (Exception var3) {
			throw new RuntimeException();
		}
	}

	private static int getScale(String value) {
		if (value.indexOf(46) == -1) {
			return 0;
		} else {
			int index = value.indexOf(46) + 1;
			int scale = value.length() - index;

			for (int i = value.length() - 1; i >= index; --i) {
				if (Character.digit(value.charAt(i), 10) != 0) {
					return scale;
				}

				--scale;
			}

			return scale;
		}
	}

	public static String escapeHtml(String value) {
		return value.replaceAll("&", "&amp;").replaceAll(">", "&gt;").replaceAll("<", "&lt;").replaceAll("\"", "&quot;")
				.replaceAll("'", "&apos;");
	}

	private Format() {
	}
}
