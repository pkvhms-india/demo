package com.varicent.draws.web.view;

import java.awt.Color;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import com.varicent.common.ui.domain.CellFont;
import com.varicent.common.ui.domain.CellStyle;
import com.varicent.core.database.support.DataRow;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.util.Excel;
import com.varicent.core.view.AbstractExcelView;
import com.varicent.core.view.ExcelUtility;

@Component
public class DrawReportExcelView extends AbstractExcelView {
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ExcelUtility excelUtil = ExcelUtility.getExcelSSUtility(workbook);
		Color reportColour = (Color) model.get("headerColor");
		Color reportForeColour;
		if (Color.RGBtoHSB(reportColour.getRed(), reportColour.getGreen(), reportColour.getBlue(),
				(float[]) null)[2] < 0.7) {
			reportForeColour = Color.white;
		} else {
			reportForeColour = Color.black;
		}

		CellStyle headerCellStyle = new CellStyle(new CellFont("Tahoma", 9.75F, (short) 1), reportForeColour,
				reportColour, CellStyle.Alignment.LEFT);
		CellStyle totalsCellStyle = new CellStyle(new CellFont("Tahoma", 9.75F, (short) 1), Color.black,
				new Color(14869218), CellStyle.Alignment.LEFT);
		CellStyle evenRowStyle = new CellStyle(CellFont.defaultFont(), Color.BLACK, Color.WHITE,
				CellStyle.Alignment.LEFT);
		CellStyle oddRowStyle = new CellStyle(CellFont.defaultFont(), Color.BLACK, new Color(14869218),
				CellStyle.Alignment.LEFT);
		org.apache.poi.ss.usermodel.CellStyle headerStyle = excelUtil.createTextCellStyle(headerCellStyle);
		org.apache.poi.ss.usermodel.CellStyle totalsStyle = excelUtil.createTextCellStyle(totalsCellStyle);
		org.apache.poi.ss.usermodel.CellStyle dataStyleEven = excelUtil.createTextCellStyle(evenRowStyle);
		org.apache.poi.ss.usermodel.CellStyle dataStyleOdd = excelUtil.createTextCellStyle(oddRowStyle);
		NumberFormat numberFormat = NumericFormat
				.getNumericCurrencyFormatter((NumericFormat.Style) model.get("numberStyle"));
		NumericFormat numericFormat = new NumericFormat((NumericFormat.Style) model.get("numberStyle"),
				numberFormat.getMinimumFractionDigits());
		String format = Excel.getNumberFormat(numericFormat);
		org.apache.poi.ss.usermodel.CellStyle numericTotalsStyle = excelUtil.createDataCellStyle(totalsCellStyle,
				format);
		org.apache.poi.ss.usermodel.CellStyle dataNumericStyleEven = excelUtil.createDataCellStyle(evenRowStyle,
				format);
		org.apache.poi.ss.usermodel.CellStyle dataNumericStyleOdd = excelUtil.createDataCellStyle(oddRowStyle, format);
		List<DataRow> datarows = (List) model.get("datarows");
		DataRow totalsRow = (DataRow) model.get("totalsrow");
		String[] headers = (String[]) model.get("excelHeaders");
		List<Boolean> visibilities = (List) model.get("visibilities");
		Sheet sheet = workbook.createSheet("Sheet 1");
		Row headerRow = sheet.createRow(0);
		int headerIndex = 0;

		for (int i = 0; i < headers.length; ++i) {
			if (i >= visibilities.size() || visibilities.get(i)) {
				Cell headerCell = headerRow.createCell(headerIndex);
				headerCell.setCellValue(headers[i]);
				headerCell.setCellStyle(headerStyle);
				++headerIndex;
			}
		}

		int rowIndex = 1;

		for (DataRow datarow : datarows) {
			Row row = sheet.createRow(rowIndex);
			++rowIndex;
			int colIndex = 0;

			for (int j = 0; j < datarow.getSize(); ++j) {
				if (j >= visibilities.size() || visibilities.get(j)) {
					Cell cell = row.createCell(colIndex);
					++colIndex;
					if (datarow.getObject(j) instanceof BigDecimal) {
						cell.setCellValue(((BigDecimal) datarow.getObject(j)).doubleValue());
						cell.setCellStyle(rowIndex % 2 == 0 ? dataNumericStyleEven : dataNumericStyleOdd);
					} else {
						cell.setCellValue(datarow.getValue(j));
						cell.setCellStyle(rowIndex % 2 == 0 ? dataStyleEven : dataStyleOdd);
					}
				}
			}
		}

		if (totalsRow != null) {
			Row row = sheet.createRow(rowIndex);
			int colIndex = 0;

			for (int j = 0; j < totalsRow.getSize(); ++j) {
				if (j <= 1 || j >= visibilities.size() || visibilities.get(j)) {
					Cell cell = row.createCell(colIndex);
					++colIndex;
					if (totalsRow.getObject(j) instanceof BigDecimal) {
						cell.setCellValue(((BigDecimal) totalsRow.getObject(j)).doubleValue());
						cell.setCellStyle(numericTotalsStyle);
					} else {
						cell.setCellValue(totalsRow.getValue(j));
						cell.setCellStyle(totalsStyle);
					}
				}
			}

		}
	}
}
