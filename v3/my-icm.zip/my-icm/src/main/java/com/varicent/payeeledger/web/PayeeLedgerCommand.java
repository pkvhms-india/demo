package com.varicent.payeeledger.web;

import org.apache.commons.lang.StringUtils;

import com.varicent.security.domain.CSRFCommand;

public class PayeeLedgerCommand extends CSRFCommand {
	private String planId;
	private String payeeId;
	private int periodIndex;
	private boolean excelError;
	private boolean doRetrieveRows;
	private boolean isXLSXExport;

	public String getPayeeId() {
		return this.payeeId;
	}

	public int getPeriodIndex() {
		return this.periodIndex;
	}

	public String getPlanId() {
		return this.planId;
	}

	public boolean hasPlanId() {
		return this.planId != null;
	}

	public void setPayeeId(String payee) {
		this.payeeId = StringUtils.defaultIfEmpty(payee, (String) null);
	}

	public void setPeriodIndex(int index) {
		this.periodIndex = index;
	}

	public void setPlanId(String plan) {
		this.planId = StringUtils.defaultIfEmpty(plan, (String) null);
	}

	public void clearExcelError() {
		this.excelError = false;
	}

	public void setExcelError(boolean excelError) {
		this.excelError = excelError;
	}

	public boolean hasExcelError() {
		return this.excelError;
	}

	public void setDoRetrieveRows(boolean doRetrieveRows) {
		this.doRetrieveRows = doRetrieveRows;
	}

	public boolean getDoRetrieveRows() {
		return this.doRetrieveRows;
	}

	public void setIsXLSXExport(boolean isXLSXExport) {
		this.isXLSXExport = isXLSXExport;
	}

	public boolean getIsXLSXExport() {
		return this.isXLSXExport;
	}
}
