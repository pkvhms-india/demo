package com.varicent.core.util;

import com.varicent.messages.domain.Message;

public class MessageNavigation {
	private Message nextOlder;
	private Message nextNewer;
	private ListType listType;

	public MessageNavigation(Message nextOlder, Message nextNewer, ListType listType) {
		this.nextOlder = nextOlder;
		this.nextNewer = nextNewer;
		this.listType = listType;
	}

	public Message getNextOlder() {
		return this.nextOlder;
	}

	public Message getNextNewer() {
		return this.nextNewer;
	}

	public ListType getListType() {
		return this.listType;
	}

	public static enum ListType {
		ADMIN_MESSAGE, INQUIRY, ALL;
	}

	public static enum SubType {
		UNASSIGNED, ASSIGNED, CREATED, LOG;
	}
}
