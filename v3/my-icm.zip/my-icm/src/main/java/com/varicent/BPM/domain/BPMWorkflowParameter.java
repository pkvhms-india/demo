package com.varicent.BPM.domain;

public class BPMWorkflowParameter {
	private int workflowID;
	private String paramName;
	private String value;
	private String paramType;
	private ValueType valueType;
	private boolean useDefaultValue;

	public BPMWorkflowParameter(int workflowID, String paramName, String value, String paramType,
			boolean useDefaultValue, ValueType valueType) {
		this.workflowID = workflowID;
		this.paramName = paramName;
		this.value = value;
		this.paramType = paramType;
		this.valueType = valueType;
		this.useDefaultValue = useDefaultValue;
	}

	public int getWorkflowID() {
		return this.workflowID;
	}

	public String getName() {
		return this.paramName;
	}

	public String getValue() {
		return this.value;
	}

	public String getParamType() {
		return this.paramType;
	}

	public ValueType getValueType() {
		return this.valueType;
	}

	public boolean getUseDefaultValue() {
		return this.useDefaultValue;
	}

	public static enum ValueType {
		Constant, Value;
	}
}
