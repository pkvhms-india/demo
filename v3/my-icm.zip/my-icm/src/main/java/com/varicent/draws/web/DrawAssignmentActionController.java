package com.varicent.draws.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.WebUtils;

import com.varicent.core.i18n.Message;
import com.varicent.core.util.NoncacheHttpResponseSetter;
import com.varicent.draws.domain.DrawAssignmentFixedTerm;
import com.varicent.draws.domain.DrawAssignmentOngoing;
import com.varicent.draws.domain.DrawAssignmentUnassignedPayee;
import com.varicent.draws.service.DrawAssignmentManager;

@Controller
public class DrawAssignmentActionController {
	private final DrawAssignmentManager drawAssignmentManager;

	@Autowired
	public DrawAssignmentActionController(DrawAssignmentManager drawAssignmentManager) {
		this.drawAssignmentManager = drawAssignmentManager;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Date.class, (String) null,
				new CustomDateEditor(new SimpleDateFormat("dd/MM/yyyy"), true));
	}

	@RequestMapping(value = { "/drawassignment/index.do" }, method = { RequestMethod.POST })
	public RedirectView redirectToIndex(@ModelAttribute("command") UnassignedDrawCommand drawCommand,
			HttpServletRequest request) {
		return this.getRedirectView(drawCommand, getIndexRedirect());
	}

	@RequestMapping(value = { "/drawassignment/unassigned/filter.do" }, method = { RequestMethod.POST })
	public RedirectView filterUnassignedView(@ModelAttribute("command") UnassignedDrawCommand drawCommand,
			HttpServletRequest request) {
		return this.getRedirectView(drawCommand, getUnassignedRedirect());
	}

	@RequestMapping(value = { "/drawassignment/ongoing/filter.do" }, method = { RequestMethod.POST })
	public RedirectView filterOngoingView(@ModelAttribute("command") DrawAssignmentOngoingCommand drawCommand,
			HttpServletRequest request) {
		return this.getRedirectView(drawCommand, getOngoingRedirect());
	}

	@RequestMapping(value = { "/drawassignment/fixedterm/filter.do" }, method = { RequestMethod.POST })
	public RedirectView filterFixedTermView(@ModelAttribute("command") DrawAssignmentFixedTermCommand drawCommand,
			HttpServletRequest request) {
		return this.getRedirectView(drawCommand, getFixedtermRedirect());
	}

	public RedirectView getRedirectView(HttpServletRequest request, DrawAssignmentCommand drawCommand,
			String redirectUrl) {
		WebUtils.setSessionAttribute(request, "command", drawCommand);
		RedirectView redirect = this.getRedirectView(drawCommand, redirectUrl);
		return redirect;
	}

	public RedirectView getRedirectView(DrawAssignmentCommand drawCommand, String redirectUrl) {
		String selectedPayeeId = drawCommand.getSelectedPayeeId();
		int selectedGroupId = drawCommand.getSelectedGroupId();
		RedirectView redirect = new RedirectView(redirectUrl, true);
		if (drawCommand.getTabId() != "") {
			redirect.addStaticAttribute("tabId", drawCommand.getTabId());
		}

		redirect.addStaticAttribute("id", drawCommand.getDrawId());
		if (selectedPayeeId != null && selectedPayeeId.length() != 0) {
			redirect.addStaticAttribute("selectedPayeeId", selectedPayeeId);
		}

		if (selectedGroupId != 0) {
			redirect.addStaticAttribute("selectedGroupId", selectedGroupId);
		}

		redirect.setExposeModelAttributes(true);
		return redirect;
	}

	@RequestMapping(value = { "/drawassignment/unassigned/assign.do" }, method = { RequestMethod.POST })
	public RedirectView assign(HttpServletRequest request, @ModelAttribute("command") UnassignedDrawCommand drawCommand,
			BindingResult result) {
		RedirectView redirect = this.getRedirectView(drawCommand, getUnassignedRedirect());
		if (!drawCommand.checkAndUpdateToken()) {
			return redirect;
		} else {
			List<Message> errors = new LinkedList();
			List<DrawAssignmentUnassignedPayee> updatedList = this.drawAssignmentManager.assignAndGetUnassigned(
					drawCommand.getUnassignedPayees(), drawCommand.getDrawId(), drawCommand.getWorkflowObjectId(),
					errors);
			if (errors.size() == 0) {
				return redirect;
			} else {
				drawCommand.setUnassignedPayees(updatedList);
				this.addSessionAttributes(request, drawCommand, result, errors);
				return redirect;
			}
		}
	}

	@RequestMapping(value = { "/drawassignment/ongoing/hideInactive.do" }, method = { RequestMethod.POST })
	public RedirectView hideInactiveOngoing(HttpServletRequest request,
			@ModelAttribute("command") DrawAssignmentOngoingCommand drawCommand) {
		RedirectView redirect = this.getRedirectView(request, drawCommand, getOngoingRedirect());
		return redirect;
	}

	@RequestMapping(value = { "/drawassignment/fixedterm/hideInactive.do" }, method = { RequestMethod.POST })
	public RedirectView hideInactiveFixedTerm(HttpServletRequest request,
			@ModelAttribute("command") DrawAssignmentFixedTermCommand drawCommand) {
		RedirectView redirect = this.getRedirectView(request, drawCommand, getFixedtermRedirect());
		return redirect;
	}

	@RequestMapping(value = { "/drawassignment/ongoing/save.do" }, method = { RequestMethod.POST })
	public RedirectView saveOngoing(HttpServletRequest request,
			@ModelAttribute("command") DrawAssignmentOngoingCommand drawCommand, BindingResult result) {
		RedirectView redirect = this.getRedirectView(drawCommand, getOngoingRedirect());
		if (!drawCommand.checkAndUpdateToken()) {
			return redirect;
		} else {
			List<Message> errors = new LinkedList();
			List<DrawAssignmentOngoing> ongoing = this.drawAssignmentManager.updateOngoingAssignmentsAndGetRemaining(
					drawCommand.getDrawId(), drawCommand.getWorkflowObjectId(), drawCommand.getOngoingAssignments(),
					errors, drawCommand.getPageNumber(), drawCommand.getRowsPerPage(), drawCommand.getSortColumn(),
					drawCommand.isDescending());
			if (errors.size() == 0) {
				return redirect;
			} else {
				drawCommand.setOngoingAssignments(ongoing);
				this.addSessionAttributes(request, drawCommand, result, errors);
				return redirect;
			}
		}
	}

	@RequestMapping(value = { "/drawassignment/fixedterm/save.do" }, method = { RequestMethod.POST })
	public RedirectView saveFixedTerm(HttpServletRequest request,
			@ModelAttribute("command") DrawAssignmentFixedTermCommand drawCommand, BindingResult result) {
		RedirectView redirect = this.getRedirectView(drawCommand, getFixedtermRedirect());
		if (!drawCommand.checkAndUpdateToken()) {
			return redirect;
		} else {
			List<Message> errors = new LinkedList();
			List<DrawAssignmentFixedTerm> fixedterm = this.drawAssignmentManager
					.updateFixedTermAssignmentsAndGetRemaining(drawCommand.getDrawId(),
							drawCommand.getWorkflowObjectId(), drawCommand.getFixedTermAssignments(), errors,
							drawCommand.getPageNumber(), drawCommand.getRowsPerPage(), drawCommand.getSortColumn(),
							drawCommand.isDescending());
			if (errors.size() == 0) {
				return redirect;
			} else {
				drawCommand.setFixedTermAssignments(fixedterm);
				this.addSessionAttributes(request, drawCommand, result, errors);
				return redirect;
			}
		}
	}

	private void addSessionAttributes(HttpServletRequest request, DrawAssignmentCommand drawCommand,
			BindingResult result, List<Message> errors) {
		for (Message message : errors) {
			result.reject(message.getKey().toString(), message.getParams(), (String) null);
		}

		WebUtils.setSessionAttribute(request, "command", drawCommand);
		WebUtils.setSessionAttribute(request, "errors", result);
	}

	@RequestMapping(value = { "/drawassignment/general/periodName.do" }, method = { RequestMethod.GET })
	@ResponseBody
	public PeriodStartJson getPeriodName(HttpServletResponse response, @RequestParam String date,
			@RequestParam String timeId, @RequestParam String level) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		return date == null ? new PeriodStartJson((String) null)
				: new PeriodStartJson(this.drawAssignmentManager.getPeriodName(date, timeId, level));
	}

	@RequestMapping(value = { "/drawassignment/general/fixedtermPage.do" }, method = { RequestMethod.GET })
	@ResponseBody
	public DrawAssignmentFixedTermCommand getFixedTermRows(HttpServletResponse response, @RequestParam int drawId,
			@RequestParam int workflowObjectId, @RequestParam String selectedPayeeId, @RequestParam int selectedGroupId,
			@RequestParam int pageNumber, @RequestParam int rowsPerPage, @RequestParam String sortColumn,
			@RequestParam boolean descending, @RequestParam boolean activeOnly) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		DrawAssignmentFixedTermCommand command = new DrawAssignmentFixedTermCommand();
		command.setFixedTermAssignments(this.drawAssignmentManager.getFixedTermPayees(drawId, workflowObjectId,
				selectedPayeeId, selectedGroupId, activeOnly, pageNumber, rowsPerPage, sortColumn, descending));
		return command;
	}

	@RequestMapping(value = { "/drawassignment/general/ongoingPage.do" }, method = { RequestMethod.GET })
	@ResponseBody
	public DrawAssignmentOngoingCommand getOngoingRows(HttpServletResponse response, @RequestParam int drawId,
			@RequestParam int workflowObjectId, @RequestParam String selectedPayeeId, @RequestParam int selectedGroupId,
			@RequestParam int pageNumber, @RequestParam int rowsPerPage, @RequestParam String sortColumn,
			@RequestParam boolean descending, @RequestParam boolean activeOnly) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		DrawAssignmentOngoingCommand command = new DrawAssignmentOngoingCommand();
		command.setOngoingAssignments(this.drawAssignmentManager.getOngoingPayees(drawId, workflowObjectId,
				selectedPayeeId, selectedGroupId, activeOnly, pageNumber, rowsPerPage, sortColumn, descending));
		return command;
	}

	@RequestMapping(value = { "/drawassignment/general/unassignedPage.do" }, method = { RequestMethod.GET })
	@ResponseBody
	public UnassignedDrawCommand getUnassignedRows(HttpServletResponse response, @RequestParam int drawId,
			@RequestParam int workflowObjectId, @RequestParam String selectedPayeeId, @RequestParam int selectedGroupId,
			@RequestParam int pageNumber, @RequestParam int rowsPerPage, @RequestParam String sortColumn,
			@RequestParam boolean descending) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		UnassignedDrawCommand command = new UnassignedDrawCommand();
		command.setUnassignedPayees(this.drawAssignmentManager.getUnAssignedPayees(drawId, workflowObjectId,
				selectedPayeeId, selectedGroupId, pageNumber, rowsPerPage, sortColumn, descending));
		return command;
	}

	@RequestMapping(value = { "/drawassignment/general/getPeriodAmount.do" }, method = { RequestMethod.GET })
	@ResponseBody
	public PeriodAmountJson getPeriodAmount(HttpServletResponse response, @RequestParam int drawId,
			@RequestParam int templateId, @RequestParam int periodIndex) {
		NoncacheHttpResponseSetter.setResponseNonCache(response);
		return new PeriodAmountJson(this.drawAssignmentManager.getPeriodAmount(drawId, templateId, periodIndex));
	}

	static String getIndexRedirect() {
		return getRedirectUrl("drawassignment/index");
	}

	static String getOngoingRedirect() {
		return getRedirectUrl("drawassignment/ongoing");
	}

	static String getFixedtermRedirect() {
		return getRedirectUrl("drawassignment/fixedterm");
	}

	static String getUnassignedRedirect() {
		return getRedirectUrl("drawassignment/unassigned");
	}

	private static String getRedirectUrl(String view) {
		return "/" + view + ".html";
	}
}
