package com.varicent.BPM.dao.jdbc;

import java.nio.ByteBuffer;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.stream.XMLStreamException;

import org.springframework.jdbc.core.RowMapper;

import com.varicent.BPM.domain.BPMAlertNode;
import com.varicent.BPM.domain.BPMConditionalPath;
import com.varicent.BPM.domain.BPMExternalEmail;
import com.varicent.BPM.domain.BPMNode;
import com.varicent.BPM.domain.BPMNodeHistoryStatus;
import com.varicent.BPM.domain.BPMPath;
import com.varicent.BPM.domain.BPMProcessNode;
import com.varicent.BPM.domain.BPMSwimLane;
import com.varicent.BPM.domain.BPMToken;
import com.varicent.BPM.domain.BPMTokenParameter;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflow;
import com.varicent.BPM.domain.BPMWorkflowParameter;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.common.payee.domain.Payee;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.xml.SourceDefinitionParser;
import com.varicent.core.context.VaricentContext;

public class BPMMapper {
	private static final RowMapper<BPMWorkflow> workflowMapper = new RowMapper<BPMWorkflow>() {
		@Override
		public BPMWorkflow mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMWorkflow(rs.getInt("WorkflowID"), rs.getString("Name"), rs.getInt("WebReportID"),
					rs.getBoolean("IsSingleInstance"), new BPMWorkflowParameter[0]);
		}
	};
	private static final RowMapper<BPMNodeHistoryStatus> BPMNodeHistoryStatusRowMapper = new RowMapper<BPMNodeHistoryStatus>() {
		@Override
		public BPMNodeHistoryStatus mapRow(ResultSet rs, int rowNumber) throws SQLException {
			String actorID = rs.getString("Actor");
			String forcingID = rs.getString("IsForcedBy");
			Payee actor = null;
			if (actorID != null) {
				actor = VaricentContext.getPayee(actorID);
			}

			if (actor == null) {
				actor = new Payee((String) null, actorID);
			}

			Payee forcing = null;
			if (forcingID != null) {
				forcing = VaricentContext.getPayee(forcingID);
			}

			if (forcing == null) {
				forcing = new Payee((String) null, forcingID);
			}

			return new BPMNodeHistoryStatus(rs.getInt("ID"), rs.getInt("WorkflowID"), rs.getString("NodeName"),
					rs.getString("Initiator"), actor, forcing, rs.getString("Action"), rs.getTimestamp("DateActioned"));
		}
	};
	private static final RowMapper<BPMTokenView> completedTokenViewMapper = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("ID"), rs.getString("Initiator"), rs.getString("LastActor"),
					rs.getTimestamp("InitiationDate"), rs.getTimestamp("CompletionDate"), rs.getString("WorkflowName"),
					rs.getString("WebReportName"));
		}
	};
	private static final RowMapper<BPMTokenView> completedTokenListViewMapper = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("ID"), rs.getString("Initiator"), rs.getString("InitiatorName"),
					rs.getTimestamp("InitiationDate"), rs.getTimestamp("CompletionDate"), rs.getString("WorkFlowName"));
		}
	};
	private static final RowMapper<BPMTokenView> completedTokenListViewWithRowMapper = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("ID"), rs.getString("Initiator"), rs.getString("InitiatorName"),
					rs.getTimestamp("InitiationDate"), rs.getTimestamp("CompletionDate"), rs.getString("WorkFlowName"),
					rs.getInt("ROW_NUMBER"));
		}
	};
	private static final RowMapper<BPMWorkflowParameter> workflowParamMapper = new RowMapper<BPMWorkflowParameter>() {
		@Override
		public BPMWorkflowParameter mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMWorkflowParameter(rs.getInt("WorkflowID"), rs.getString("ParamName"), rs.getString("Value"),
					rs.getString("ParamType"), rs.getBoolean("IsReportDefaultValue"),
					BPMWorkflowParameter.ValueType.values()[rs.getInt("ValueType")]);
		}
	};
	private static final RowMapper<BPMTokenParameter> tokenParameterMapper = new RowMapper<BPMTokenParameter>() {
		@Override
		public BPMTokenParameter mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenParameter(rs.getInt("TokenId"), rs.getString("ParamName"), rs.getString("ParamType"),
					rs.getString("Value"));
		}
	};
	private static final RowMapper<BPMSwimLane> swimLaneMapper = new RowMapper<BPMSwimLane>() {
		@Override
		public BPMSwimLane mapRow(ResultSet rs, int rowNumber) throws SQLException {
			String memberDefString = rs.getString("MemberDefinition");
			SourceDefinition memberDefinition;
			if (memberDefString != null && memberDefString != "") {
				try {
					memberDefinition = SourceDefinitionParser.getSourceDefinition(memberDefString);
				} catch (XMLStreamException e) {
					throw new RuntimeException(e);
				}
			} else {
				memberDefinition = null;
			}

			return new BPMSwimLane(rs.getInt("SwimLaneID"), rs.getInt("WorkflowID"), rs.getString("Name"),
					rs.getBoolean("IsSystemLane"), rs.getInt("Order") == 1, rs.getBoolean("IsByRestriction"),
					memberDefinition, new String[0]);
		}
	};
	private static final RowMapper<BPMToken> tokenMapper = new RowMapper<BPMToken>() {
		@Override
		public BPMToken mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMToken(rs.getInt("TokenID"), rs.getInt("FormID"), rs.getInt("NodeID"), rs.getString("OwnerID"),
					rs.getString("LastActorID"), rs.getInt("PathID"), rs.getBoolean("Waiting"),
					BPMMapper.getRowVersion((byte[]) rs.getObject("_RowVersion")));
		}
	};
	private static final RowMapper<BPMNode> nodeMapper = new RowMapper<BPMNode>() {
		@Override
		public BPMNode mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMNode(rs.getInt("NodeID"), rs.getInt("SwimLaneID"), rs.getString("Name"), new BPMPath[0]);
		}
	};
	private static final RowMapper<BPMAlertNode> alertNodeMapper = new RowMapper<BPMAlertNode>() {
		@Override
		public BPMAlertNode mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMAlertNode(rs.getInt("NodeID"), rs.getInt("SwimLaneID"), rs.getString("Name"), new BPMPath[0],
					rs.getString("Subject"), rs.getString("Body"),
					BPMAlertNode.AlertTypeEnum.getAlertTypeEnum(rs.getInt("AlertType")));
		}
	};
	private static final RowMapper<BPMProcessNode> processNodeMapper = new RowMapper<BPMProcessNode>() {
		@Override
		public BPMProcessNode mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMProcessNode(rs.getInt("NodeID"), rs.getInt("SwimLaneID"), rs.getString("Name"),
					new BPMPath[0], rs.getInt("SchedulerFolderID"));
		}
	};
	private static final RowMapper<BPMPath> pathMapper = new RowMapper<BPMPath>() {
		@Override
		public BPMPath mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMPath(rs.getInt("PathID"), rs.getString("Name"), rs.getInt("OriginNodeID"),
					rs.getInt("DestinationNodeID"), rs.getBoolean("AllMember"), rs.getBoolean("SaveAndSubmit"),
					rs.getBoolean("AllSubmit"), rs.getInt("ReviewResult"));
		}
	};
	private static final RowMapper<BPMConditionalPath> conditionalPathMapper = new RowMapper<BPMConditionalPath>() {
		@Override
		public BPMConditionalPath mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMConditionalPath(rs.getInt("PathID"), rs.getString("Name"), rs.getInt("OriginNodeID"),
					rs.getInt("DestinationNodeID"), rs.getBoolean("AllMember"), rs.getBoolean("SaveAndSubmit"),
					rs.getBoolean("AllSubmit"), rs.getInt("ReviewResult"), rs.getInt("Position"),
					rs.getString("Condition"), rs.getBoolean("IsDefault"));
		}
	};
	private static final RowMapper<BPMTokenView> tokenViewMapperWithRowNumbers = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("TokenID"), rs.getString("WorkflowName"), rs.getInt("WorkflowID"),
					rs.getString("Description"), rs.getString("NodeName"), rs.getString("OwnerID"),
					rs.getString("PayeeName"), rs.getString("ReportName"), rs.getTimestamp("CreatedAt"),
					rs.getTimestamp("LastModified"), rs.getInt("ROW_NUMBER"));
		}
	};
	private static final RowMapper<BPMTokenView> tokenViewMapper = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("TokenID"), rs.getString("WorkflowName"), rs.getInt("WorkflowID"),
					rs.getString("Description"), rs.getString("NodeName"), rs.getString("OwnerID"),
					rs.getString("PayeeName"), rs.getString("ReportName"), rs.getTimestamp("CreatedAt"),
					rs.getTimestamp("LastModified"));
		}
	};
	private static final RowMapper<BPMTokenView> tokenDeletedViewMapper = new RowMapper<BPMTokenView>() {
		@Override
		public BPMTokenView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMTokenView(rs.getInt("ID"), rs.getString("Initiator"), rs.getString("InitiatorName"),
					rs.getTimestamp("InitiationDate"), rs.getTimestamp("CompletionDate"), rs.getString("WorkFlowName"));
		}
	};
	private static final RowMapper<BPMWorkflowView> workflowViewMapperWithRowNumbers = new RowMapper<BPMWorkflowView>() {
		@Override
		public BPMWorkflowView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMWorkflowView(rs.getInt("WorkflowID"), rs.getString("Name"), rs.getString("Description"),
					rs.getInt("ROW_NUMBER"));
		}
	};
	private static final RowMapper<BPMWorkflowView> workflowViewMapper = new RowMapper<BPMWorkflowView>() {
		@Override
		public BPMWorkflowView mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMWorkflowView(rs.getInt("WorkflowID"), rs.getString("Name"), rs.getString("Description"));
		}
	};
	private static final RowMapper<BPMExternalEmail> externalEmailMapper = new RowMapper<BPMExternalEmail>() {
		@Override
		public BPMExternalEmail mapRow(ResultSet rs, int rowNumber) throws SQLException {
			return new BPMExternalEmail(rs.getString("Email"), rs.getBoolean("IsCC"));
		}
	};

	private static long getRowVersion(byte[] rowVersionData) {
		ByteBuffer rowVersionBuffer = ByteBuffer.wrap(rowVersionData);
		return rowVersionBuffer.getLong(rowVersionData[1]);
	}

	public static RowMapper<BPMWorkflow> getWorkflowMapper() {
		return workflowMapper;
	}

	public static RowMapper<BPMNodeHistoryStatus> getBPMNodeHistoryStatusRowMapper() {
		return BPMNodeHistoryStatusRowMapper;
	}

	public static RowMapper<BPMTokenView> getCompletedTokenListViewMapper() {
		return completedTokenListViewMapper;
	}

	public static RowMapper<BPMTokenView> getCompletedTokenListViewWithRowMapper() {
		return completedTokenListViewWithRowMapper;
	}

	public static RowMapper<BPMTokenView> getCompletedTokenViewMapper() {
		return completedTokenViewMapper;
	}

	public static RowMapper<BPMWorkflowParameter> GetWorkflowParameterMapper() {
		return workflowParamMapper;
	}

	public static RowMapper<BPMTokenParameter> GetTokenParameterMapper() {
		return tokenParameterMapper;
	}

	public static RowMapper<BPMSwimLane> getSwimLaneMapper() {
		return swimLaneMapper;
	}

	public static RowMapper<BPMToken> getTokenMapper() {
		return tokenMapper;
	}

	public static RowMapper<BPMNode> getNodeMapper() {
		return nodeMapper;
	}

	public static RowMapper<BPMAlertNode> getAlertNodeMapper() {
		return alertNodeMapper;
	}

	public static RowMapper<BPMProcessNode> getProcessNodeMapper() {
		return processNodeMapper;
	}

	public static RowMapper<BPMPath> getPathMapper() {
		return pathMapper;
	}

	public static RowMapper<BPMConditionalPath> getConditionalPathMapper() {
		return conditionalPathMapper;
	}

	public static RowMapper<BPMTokenView> getTokenViewMapperWithRowNumbers() {
		return tokenViewMapperWithRowNumbers;
	}

	public static RowMapper<BPMTokenView> getTokenViewMapper() {
		return tokenViewMapper;
	}

	public static RowMapper<BPMTokenView> getDeletedTokenViewMapper() {
		return tokenDeletedViewMapper;
	}

	public static RowMapper<BPMWorkflowView> getWorkflowViewMapperWithRowNumbers() {
		return workflowViewMapperWithRowNumbers;
	}

	public static RowMapper<BPMWorkflowView> getWorkflowViewMapper() {
		return workflowViewMapper;
	}

	public static RowMapper<BPMExternalEmail> getExternalEmailMapper() {
		return externalEmailMapper;
	}
}
