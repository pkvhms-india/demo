package com.varicent.customize.web;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.varicent.security.domain.CSRFCommand;

public class CustomizeCommand extends CSRFCommand {
	private String table;
	private boolean tableChanged;
	private List<String> filterValues = new ArrayList();
	private List<String> originalDataRow = new ArrayList();
	private List<String> editedDataRow = new ArrayList();

	public void clear() {
		this.tableChanged = false;
		this.filterValues.clear();
		this.originalDataRow.clear();
		this.editedDataRow.clear();
	}

	public List<String> getEditedDataRow() {
		return this.editedDataRow;
	}

	public List<String> getFilterValues() {
		return this.filterValues;
	}

	public List<String> getOriginalDataRow() {
		return this.originalDataRow;
	}

	public String getTable() {
		return this.table;
	}

	public boolean getTableChanged() {
		return this.tableChanged;
	}

	public boolean hasTableChanged() {
		return this.tableChanged;
	}

	public void setEditedDataRow(List<String> editedDataRow) {
		this.editedDataRow = editedDataRow;
	}

	public void setFilterValues(List<String> filterValues) {
		this.filterValues = filterValues;
	}

	public void setOriginalDataRow(List<String> originalDataRow) {
		this.originalDataRow = originalDataRow;
	}

	public void setTable(String table) {
		this.table = StringUtils.defaultIfEmpty(table, (String) null);
	}

	public void setTableChanged(boolean tableChanged) {
		this.tableChanged = tableChanged;
	}
}
