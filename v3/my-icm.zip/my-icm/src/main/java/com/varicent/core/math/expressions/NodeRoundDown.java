package com.varicent.core.math.expressions;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.List;

public class NodeRoundDown extends BinaryNode implements EvaluateNode {
	public NodeRoundDown(List<EvaluateNode> arguments, int suffix) {
		super(arguments, suffix);
	}

	@Override
	public BigDecimal evaluate() {
		BigDecimal scaleDecimal = this.rhs.evaluate();
		BigDecimal lhsEvaluated = this.lhs.evaluate();
		if (scaleDecimal != null && lhsEvaluated != null) {
			BigDecimal powOfTen = this.Power(scaleDecimal);
			BigDecimal intComponent = new BigDecimal(lhsEvaluated.toBigInteger());
			BigDecimal decComponentInPowOfTen = new BigDecimal(
					lhsEvaluated.remainder(new BigDecimal(1)).multiply(powOfTen).toBigInteger());
			BigDecimal decComponent = decComponentInPowOfTen.divide(powOfTen);
			return intComponent.add(decComponent);
		} else {
			return null;
		}
	}

	private BigDecimal Power(BigDecimal powerOfTen) {
		BigDecimal output = new BigDecimal(1);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		int scale = powerOfTen.round(mc).intValue();

		for (int i = 0; i < scale; ++i) {
			output = output.multiply(new BigDecimal(10));
		}

		return output;
	}

	@Override
	public String getJSMathFunctionName() {
		return "roundDown";
	}
}
