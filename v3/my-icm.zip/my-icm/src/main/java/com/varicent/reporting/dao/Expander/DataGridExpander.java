package com.varicent.reporting.dao.Expander;

import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.opensaml.xml.util.Base64;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.Assert;

import com.varicent.common.query.domain.Clause;
import com.varicent.common.query.domain.Constraint;
import com.varicent.common.query.domain.IConstraint;
import com.varicent.common.query.domain.Literal;
import com.varicent.common.query.domain.SourceDefinition;
import com.varicent.common.query.xml.SourceDefinitionParser;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.time.domain.Frequency;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.common.ui.dao.PickListDao;
import com.varicent.common.ui.domain.CellStyle;
import com.varicent.common.ui.domain.SelectOption;
import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.math.expressions.ExpressionEvaluator;
import com.varicent.core.math.expressions.JavascriptUtil;
import com.varicent.core.text.Format;
import com.varicent.core.text.NumericFormat;
import com.varicent.core.text.Parse;
import com.varicent.core.util.Converter;
import com.varicent.core.util.JavascriptFormatInfo;
import com.varicent.core.util.JavascriptNumberFormat;
import com.varicent.customize.dao.CustomizeDao;
import com.varicent.customize.domain.CustomType;
import com.varicent.reporting.dao.jdbc.DataFieldEdit;
import com.varicent.reporting.dao.jdbc.DataGridInputRule;
import com.varicent.reporting.dao.jdbc.RowFormInsert;
import com.varicent.reporting.dao.jdbc.ActionParser.ExpressionParser;
import com.varicent.reporting.domain.ColumnInfo;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.ComputedColumnInfo;
import com.varicent.reporting.domain.ComputedRowInfo;
import com.varicent.reporting.domain.ConditionalFormats;
import com.varicent.reporting.domain.DataGridInfo;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.PRDateFormat;
import com.varicent.reporting.domain.PicklistDisplayOptions;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.SortColumn;
import com.varicent.reporting.domain.WebReportTableEdit;
import com.varicent.reporting.domain.WebReportValidationRule;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.reporting.web.ReportingCommand;

public class DataGridExpander extends BaseExpander {
	static BigDecimal InquiryCopyColumnWidth = new BigDecimal(1);
	private int currentReadRow = 0;
	private int currentWrittenRow = 0;
	private PartitionTracker part;
	private boolean isError;
	private DataGridInfo gridInfo;
	private PickListDao picklistDao;
	private SchemaDao schemaDao;
	private ReportingCommand cmd;
	private Messages messages;
	private List<Boolean> colsToHide;
	private Map<String, Map<String, String>> optionsCache;
	private Map<String, Map<String, String>> picklistDescriptionCache;
	public static String LOCAL_SOURCE = "_Local_";
	public static String AUTO_GENERATE = "Auto-Generate";
	public static String BLANK = "Blank";

	public DataGridExpander(XMLStreamReader streamReader, CustomizeDao customizeDao, ReportingCommand cmd, int id,
			PickListDao picklistDao, SchemaDao schemaDao, boolean isError,
			HashMap<String, List<RowFormInsert>> tableInsertListMap,
			HashMap<String, List<DataFieldEdit>> tableEditListMap, Messages messages) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("DataGridDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.cmd = cmd;
			this.messages = messages;
			this.picklistDao = picklistDao;
			this.schemaDao = schemaDao;
			this.isError = isError;
			this.colsToHide = this.cmd.getColumnsToHideForGrid(id);
			this.gridInfo = new DataGridInfo();
			this.gridInfo.initialize(id, tableInsertListMap, tableEditListMap, isError);
			this.optionsCache = new HashMap();
			this.picklistDescriptionCache = new HashMap();
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		this.gridInfo.editable = editable;
		if (this.currentReadRow == 0) {
			this.initializeDataGrid(writer, scope);
			populateComputedColumns(this.gridInfo.computedColumnInfoMap, this.gridInfo.data);
			HashMap<String, Object> columnDefaultValueMap = new HashMap();

			for (ColumnInfo column : this.gridInfo.columnMap) {
				columnDefaultValueMap.put(column.getDisplayName(), column.getDefaultValue());
			}

			if (this.gridInfo.hasInputRow) {
				this.writeDataGridInputRow(writer, scope, columnDefaultValueMap);
				if (this.gridInfo.hiddenColumnMap.size() > 0) {
					writer.writeStartElement("HiddenInputRowColumns");

					for (String key : this.gridInfo.hiddenColumnMap.keySet()) {
						writer.writeStartElement("Column");
						writer.writeStartElement("Name");
						int editId = getEditId(this.gridInfo.name,
								scope.getTableFromSource(this.gridInfo.data.getTableName()), key,
								scope.getTableEditList());
						String inputName = "IR_" + Integer.toString(editId);
						writer.writeCharacters(inputName);
						writer.writeEndElement();
						writer.writeStartElement("DefaultValue");
						writer.writeCharacters(this.gridInfo.hiddenColumnMap.get(key));
						writer.writeEndElement();
						writer.writeEndElement();
					}

					writer.writeEndElement();
				}
			}

			if (!this.gridInfo.hideAllRows) {
				this.populateComputedRow(columnDefaultValueMap,
						scope.getTableFromSource(this.gridInfo.data.getTableName()));
			}
		}

		if (this.currentReadRow != -1) {
			if (!this.gridInfo.hideAllRows && !this.gridInfo.data.getRows().isEmpty()) {
				while (this.currentReadRow != this.gridInfo.data.getRows().size()) {
					this.part.setPartition(this.gridInfo.data, this.currentReadRow);
					if (this.part.getChangedPartitions().size() != 0) {
						for (DataGridSection section : this.gridInfo.sections) {
							String sectionName = section.getName();
							if (section.getFrequency() != null) {
								sectionName = sectionName + "." + section.getFrequency().getTimeId() + "."
										+ section.getFrequency().getLevelId();
							}

							if (this.part.getChangedPartitions().contains(sectionName)
									|| this.checkPreviousSorts(this.part.getChangedPartitions(), sectionName)) {
								section.generateSection(writer, this.part.getPreviousPartition(), scope,
										this.colsToHide, this.gridInfo.enableShowHideColumns,
										this.gridInfo.enableInquiryCopy, this.gridInfo.columnMap);
							}
						}

						if (this.gridInfo.showSectionHeader) {
							this.generateHeaderRow(writer, this.gridInfo.columnMap);
						}
					}

					List<String> suppressedValues = new ArrayList();
					List<String> writtenColumns = new ArrayList();

					for (ColumnInfo info : this.gridInfo.columnMap) {
						writtenColumns.add(info.getColumnName());
					}

					if (this.gridInfo.suppressPartitionValues && this.currentReadRow > 0) {
						for (String partition : this.part.getPartitions()) {
							if (this.part.getChangedPartitions().contains(partition)) {
								break;
							}

							writtenColumns.remove(partition);
							suppressedValues.add(partition);
						}
					}

					if (!writtenColumns.isEmpty()) {
						this.generateRow(writer, scope, suppressedValues);
						++this.currentWrittenRow;
						++this.currentReadRow;
						return;
					}

					++this.currentReadRow;
				}

				for (DataGridSection section : this.gridInfo.sections) {
					section.generateSection(writer, this.part.getCurrentPartition(), scope, this.colsToHide,
							this.gridInfo.enableShowHideColumns, this.gridInfo.enableInquiryCopy,
							this.gridInfo.columnMap);
				}

				if (this.gridInfo.computedRowInfoMap.size() > 0 && !this.isEmptyComputedRow()) {
					this.generateComputedRow(writer, scope);
				}

				this.writeEndElements(writer);
				this.currentReadRow = -1;
			} else {
				if (this.gridInfo.hasInputRow && this.gridInfo.computedRowInfoMap.size() > 0
						&& !this.isEmptyComputedRow()) {
					this.generateComputedRow(writer, scope);
				}

				this.writeEndElements(writer);
				this.currentReadRow = -1;
			}
		}
	}

	private boolean isEmptyComputedRow() {
		for (ComputedRowInfo computedRow : this.gridInfo.computedRowInfoMap.values()) {
			if (!computedRow.getValue().isEmpty()) {
				return false;
			}
		}

		return true;
	}

	public static int getEditId(String grid, String table, String column, List<WebReportTableEdit> edits) {
		for (WebReportTableEdit edit : edits) {
			if (edit.getDataGrid().equals(grid) && edit.getTable().equals(table) && edit.getColumn().equals(column)) {
				return edit.getEditId();
			}
		}

		return -1;
	}

	public static int findEditId(String grid, int reportId, String column, List<WebReportTableEdit> edits) {
		for (WebReportTableEdit edit : edits) {
			if (edit.getDataGrid().equals(grid) && edit.getReportId() == reportId
					&& edit.getColumn().startsWith(column)) {
				return edit.getEditId();
			}
		}

		return -1;
	}

	public static void populateComputedColumns(Map<String, ComputedColumnInfo> computedColumnInfoMap, DataTable data) {
		for (ComputedColumnInfo info : computedColumnInfoMap.values()) {
			populateComputedColumn(info, data);
		}

	}

	public static void populateComputedColumn(ComputedColumnInfo computedColumnInfo, DataTable data) {
		data.addColumn(computedColumnInfo.getComputedColumnName(), 3);
		if (computedColumnInfo.getEvaluator() != null && !computedColumnInfo.isSkipEvaluation()) {
			int computedColumnIndex = data.getColumnIndex(computedColumnInfo.getComputedColumnName());
			computedColumnInfo.getEvaluator().reset();
			int currentRow = 0;
			int size = data.getRows().size();
			List<String> computedColumnVariables = getUnPrefixedVariables(computedColumnInfo.getEvaluator());
			if (computedColumnInfo.getEvaluator().hasAggregate()) {
				while (currentRow != size) {
					for (int i = 0; i < computedColumnVariables.size(); ++i) {
						String variable = computedColumnVariables.get(i);
						Object val = data.getObject(currentRow, variable);
						computedColumnInfo.getEvaluator().setValue(i, getVariableValue(val));
					}

					computedColumnInfo.getEvaluator().evaluate();
					++currentRow;
				}

				computedColumnInfo.getEvaluator().finalizeAggregates();
				currentRow = 0;
			}

			for (; currentRow != size; ++currentRow) {
				computedColumnInfo.getEvaluator().reset();

				for (int i = 0; i < computedColumnVariables.size(); ++i) {
					String variable = computedColumnVariables.get(i);
					Object val = data.getObject(currentRow, variable);
					computedColumnInfo.getEvaluator().setValue(i, getVariableValue(val));
				}

				BigDecimal result = computedColumnInfo.getEvaluator().evaluate();
				if (result != null) {
					data.getRow(currentRow).insert(computedColumnIndex, result);
				} else {
					data.getRow(currentRow).insert(computedColumnIndex, new BigDecimal(0));
				}
			}
		}

	}

	private void populateComputedRow(HashMap<String, Object> columnValueMap, String mainTable) {
		if (this.gridInfo.computedRowInfoMap.size() != 0) {
			int currentRow = 0;

			for (int size = this.gridInfo.data.getRows().size(); currentRow != size; ++currentRow) {
				for (ComputedRowInfo computedRow : this.gridInfo.computedRowInfoMap.values()) {
					if (computedRow.getEvaluator() != null) {
						ExpressionEvaluator evaluator = computedRow.getEvaluator();
						List<String> variables = getUnPrefixedVariables(evaluator);

						for (int i = 0; i < variables.size(); ++i) {
							String variable = variables.get(i);
							Object val = this.gridInfo.data.getObject(currentRow, variable);
							evaluator.setValue(i, getVariableValue(val));
						}

						BigDecimal result = evaluator.evaluate();
						if (result != null) {
							computedRow.setComputedValue(result);
						} else {
							computedRow.setComputedValue(new BigDecimal(0));
						}
					}
				}
			}

			if (this.gridInfo.hasInputRow && this.calculateInputRow()) {
				for (ComputedRowInfo computedRow : this.gridInfo.computedRowInfoMap.values()) {
					if (computedRow.getEvaluator() != null) {
						ExpressionEvaluator evaluator = computedRow.getEvaluator();

						for (int i = 0; i < evaluator.getVariables().size(); ++i) {
							String variable = evaluator.getVariables().get(i);
							if (columnValueMap.containsKey(variable)) {
								Object val = columnValueMap.get(variable);
								evaluator.setValue(i, getVariableValue(val));
							} else {
								evaluator.setValue(i, new BigDecimal(0));
							}
						}

						BigDecimal result = evaluator.evaluate();
						if (result != null) {
							computedRow.setComputedValue(result);
						} else {
							computedRow.setComputedValue(new BigDecimal(0));
						}
					}
				}
			}

		}
	}

	static BigDecimal getVariableValue(Object val) {
		BigDecimal value = null;
		if (val instanceof BigDecimal) {
			value = (BigDecimal) val;
		} else if (val instanceof Date) {
			BigDecimal milliInDay = new BigDecimal(86400000);
			value = Converter.ConvertToBigDecimal(((Date) val).getTime());
			value = value.divide(milliInDay, 6);
		} else if (val != null && !val.equals("")) {
			if (val instanceof Integer) {
				int intValue = (Integer) val;
				value = new BigDecimal(intValue);
			} else {
				value = Parse.parseDecimal(val.toString(), false);
			}
		} else {
			value = null;
		}

		return value;
	}

	public static Map<String, String> convertListToMap(List<SelectOption> optionList) {
		if (optionList == null) {
			return null;
		} else {
			Map<String, String> tm = new LinkedHashMap();

			for (SelectOption s : optionList) {
				tm.put(s.getValue(), s.getName());
			}

			return tm;
		}
	}

	private boolean checkPreviousSorts(java.util.Set<String> changedPartitions, String section) {
		if (!this.gridInfo.sortColumnIndex.containsKey(section)) {
			return false;
		} else {
			int orderIndex = this.gridInfo.sortColumnIndex.get(section);

			for (String key : this.gridInfo.sortColumnIndex.keySet()) {
				if (this.gridInfo.sortColumnIndex.get(key) < orderIndex && this.gridInfo.sortColumnIndex.get(key) >= 0
						&& changedPartitions.contains(key)) {
					return true;
				}
			}

			return false;
		}
	}

	public static DataGridInfo getDataGridInfo(String xml, Scope scope, SchemaDao schemaDao)
			throws XMLStreamException, ReportOverLimitException {
		return getDataGridInfo((DataGridInfo) null, xml, (XMLStreamReader) null, scope, schemaDao, false, 1, 1,
				(String) null, false, false);
	}

	public static DataGridInfo getDataGridInfo(DataGridInfo grid, String xml, XMLStreamReader streamReader, Scope scope,
			SchemaDao schemaDao, Boolean hideAllRows, int startLine, int rowsRequested, String sortColumn,
			Boolean sortDescending, Boolean isTotalRowCount) throws XMLStreamException, ReportOverLimitException {
		if (grid == null) {
			grid = new DataGridInfo();
		}

		XMLStreamReader sr = null;
		if (xml != null) {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			sr = factory.createXMLStreamReader(new StringReader(xml));
			sr.nextTag();
		} else {
			sr = streamReader;
		}

		sr.nextTag();
		grid.name = XMLStreamUtility.getCurrentNodeValue(sr);
		grid.dataSourceName = XMLStreamUtility.getCurrentNodeValue(sr);
		grid.gridType = XMLStreamUtility.getCurrentNodeValue(sr);
		grid.timeID = XMLStreamUtility.getCurrentNodeValue(sr);
		sr.nextTag();
		populateSortColumns(grid, sr);
		sr.nextTag();
		grid.paginated = false;
		if (sr.getLocalName().equals("Paginated")) {
			grid.paginated = XMLStreamUtility.getCurrentNodeValue(sr).equals("True");
		}

		if (sr.getLocalName().equals("DefaultPageSize")) {
			grid.defaultPageSize = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
		}

		grid.showOnlyInputRow = false;
		if (sr.getLocalName().equals("ShowOnlyInputRow")) {
			grid.showOnlyInputRow = XMLStreamUtility.getCurrentNodeValue(sr).equals("True");
		}

		grid.atTop = false;
		if (sr.getLocalName().equals("InputRowAtTop")) {
			grid.atTop = XMLStreamUtility.getCurrentNodeValue(sr).equals("True");
		}

		grid.hideAllRows = grid.showOnlyInputRow && grid.gridType.equals("InputRow");
		grid.inputRowAtTop = grid.atTop && grid.gridType.equals("InputRow");
		grid.hasInputRow = grid.gridType.equals("InputRow");
		grid.isVertical = false;
		if (sr.getLocalName().equals("IsVertical")) {
			grid.isVertical = XMLStreamUtility.getCurrentNodeValue(sr).equals("True") && grid.hasInputRow;
		}

		scope.addIsVerticalPair(grid.id, grid.isVertical);
		grid.freezeTopRow = false;
		if (sr.getLocalName().equals("FreezeTopRow")) {
			grid.freezeTopRow = XMLStreamUtility.getCurrentNodeValue(sr).equals("True");
		}

		sr.nextTag();
		if (sortColumn != null) {
			grid.sortColumns.add(new SortColumn(sortColumn, sortDescending, (Frequency) null));
		}

		DataTable data = scope.getDataTable(grid.dataSourceName, grid.hideAllRows, grid.paginated, startLine,
				rowsRequested, grid.sortColumns, isTotalRowCount).copy();
		grid.needsHeader = grid.hasInputRow || !data.getRows().isEmpty();
		if (grid.paginated && rowsRequested == 1 && !scope.isIgnorePagination()) {
			data = new DataTable(data.getTableName(), data.getColumns());
		}

		if (!grid.paginated) {
			data.sort(grid.sortColumns, scope.getCalendars());
		}

		grid.data = data;
		grid.tableName = scope.getTableFromSource(grid.data.getTableName());
		grid.merger = scope.getBufferMerger(grid.data.getTableName());
		pouplateColumnMap(scope, grid, sr);
		sr.nextTag();
		List<ColumnDefinition> tableColumns = null;
		if (grid.hasInputRow) {
			tableColumns = schemaDao.getColumns(grid.tableName);
		}

		populateHiddenColumnInfo(grid, scope, sr, tableColumns);
		JavascriptUtil jsUtil = new JavascriptUtil(grid.id, grid.columnFormatInfoMap);
		int javascriptExpressionSuffix = populateComputedColumnInfo(scope, grid, sr, jsUtil);
		Collections.sort(grid.columnMap, new Comparator<ColumnInfo>() {
			@Override
			public int compare(ColumnInfo arg0, ColumnInfo arg1) {
				return arg0.getOrder() - arg1.getOrder();
			}
		});
		javascriptExpressionSuffix = populateComputedRow(grid, sr, jsUtil, javascriptExpressionSuffix);
		populateComputedColumns(grid.computedColumnInfoMap, grid.data);
		populateSections(grid, sr);
		populateValidationRules(grid, sr, jsUtil, javascriptExpressionSuffix);
		grid.showSectionHeader = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		grid.suppressPartitionValues = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		grid.enableExportToExcel = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		if (!grid.needsHeader && grid.data.getRows().isEmpty()) {
			grid.enableExportToExcel = false;
		}

		grid.suppressHeader = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		grid.enableShowHideColumns = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		if (!grid.needsHeader && grid.enableShowHideColumns && grid.data.getRows().isEmpty()) {
			grid.enableShowHideColumns = grid.hideAllRows || grid.hasInputRow;
		}

		grid.enableInquiryCopy = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr))
				&& scope.inquiryEnabledForReport();
		grid.styleName = XMLStreamUtility.getCurrentNodeValue(sr);
		return grid;
	}

	private static void pouplateColumnMap(Scope scope, DataGridInfo wgi, XMLStreamReader sr)
			throws XMLStreamException, ReportOverLimitException {
		for (; sr.getEventType() == 1; XMLStreamUtility.MoveStreamForwardToTag(sr, "Column", "ColumnMap", true)) {
			sr.nextTag();
			String columnName = XMLStreamUtility.getCurrentNodeValue(sr);
			int order = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
			String displayName = XMLStreamUtility.getCurrentNodeValue(sr);
			String width = XMLStreamUtility.getCurrentNodeValue(sr);
			ColumnLink link = null;
			if (sr.getLocalName().equals("Link")) {
				link = new ColumnLink(sr);
			}

			NumericFormat numericFormat = null;
			if (sr.getLocalName().equals("NumericFormat")) {
				numericFormat = NumericFormat.ReadNumericFormatFromXml(sr);
			}

			Frequency referencedFrequency = null;
			if (sr.getLocalName().equals("Frequency")) {
				sr.nextTag();
				String columnTimeID = XMLStreamUtility.getCurrentNodeValue(sr);
				String levelID = XMLStreamUtility.getCurrentNodeValue(sr);
				sr.nextTag();
				referencedFrequency = new Frequency(columnTimeID, levelID);
			}

			ConditionalFormats formats = new ConditionalFormats();
			if (sr.getLocalName().equals("ConditionalFormats")) {
				sr.nextTag();

				while (sr.getEventType() == 1 && sr.getLocalName().equals("ConditionalFormat")) {
					formats.addConditionalFormat(sr);
				}

				sr.nextTag();
			}

			String headerStyleName = null;
			if (sr.getLocalName().equals("HeaderStyleName")) {
				headerStyleName = XMLStreamUtility.getCurrentNodeValue(sr);
			}

			String initiallyShow = XMLStreamUtility.getCurrentNodeValue(sr);
			PRDateFormat dateFormat = null;
			if (sr.getLocalName().equals("DateFormat")) {
				dateFormat = PRDateFormat.ReadPRDateFormatFromXml(sr);
			}

			if (sr.getLocalName().equals("PicklistFilter")) {
				sr.nextTag();
				XMLStreamUtility.getCurrentNodeValue(sr);
				SourceDefinition filterDef = SourceDefinitionParser.getSourceDefinition(sr);
				replaceLocalVariables(filterDef.getQuery().getRestriction(), scope);
				wgi.filters.put(columnName, filterDef);
				sr.nextTag();
				sr.nextTag();
				XMLStreamUtility.getCurrentNodeValue(sr);
				sr.nextTag();
			}

			Object defaultVal = null;
			if (wgi.hasInputRow) {
				if (sr.getLocalName().equals("DefaultValue")) {
					String defaultValue = XMLStreamUtility.getCurrentNodeValue(sr);
					if (defaultValue.startsWith(LOCAL_SOURCE)) {
						defaultValue = defaultValue.substring(LOCAL_SOURCE.length());
						Literal.Type type = scope.getLiteralType(defaultValue);
						if (type == Literal.Type.STRING) {
							defaultVal = scope.getString(defaultValue);
						} else if (type == Literal.Type.DECIMAL) {
							defaultVal = scope.getDecimal(defaultValue);
						} else if (type == Literal.Type.DATETIME) {
							defaultVal = scope.getDateTime(defaultValue);
						}
					} else if (defaultValue.equals(AUTO_GENERATE)) {
						defaultVal = AUTO_GENERATE;
					} else if (wgi.data.getColumn(columnName).getType() == 3) {
						defaultVal = BigDecimal.ZERO;
					}
				} else if (wgi.data.getColumn(columnName).getType() == 3) {
					defaultVal = BigDecimal.ZERO;
				}

				if (wgi.isError && wgi.tableInsertListMap != null
						&& wgi.tableInsertListMap.containsKey(wgi.tableName)) {
					for (RowFormInsert insert : wgi.tableInsertListMap.get(wgi.tableName)) {
						if (insert.getColumn().equals(columnName) && insert.getDataGrid().equals(wgi.name)
								&& insert.isEdited()) {
							defaultVal = insert.getValue();
							wgi.columnInsertMap.put(columnName, insert);
							break;
						}
					}
				}
			}

			Boolean isEditable = false;
			if (sr.getLocalName().equals("IsEditable")) {
				isEditable = "true".equals(XMLStreamUtility.getCurrentNodeValue(sr));
			}

			PicklistDisplayOptions picklistOptions = null;
			if (sr.getLocalName().equals("PicklistDisplayOptions")) {
				sr.nextTag();
				String picklistDescription = XMLStreamUtility.getCurrentNodeValue(sr);
				int picklistSortOrder = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
				Boolean hideKey = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
				Boolean hideDescription = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
				Boolean sortByID = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
				picklistOptions = new PicklistDisplayOptions(picklistDescription, hideKey, sortByID, picklistSortOrder,
						hideDescription);
				sr.nextTag();
			}

			CustomType colType;
			if (!wgi.hasInputRow && !isEditable) {
				colType = getColumnType(wgi.data.getColumn(columnName), referencedFrequency);
			} else {
				colType = scope.getTableColumnType(wgi.data.getTableName(), columnName);
			}

			boolean useRowTextAlignment = false;
			if (sr.getLocalName().equals("UseRowTextAlignment")) {
				useRowTextAlignment = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
			}

			CellStyle.Alignment headerAlignment = CellStyle.Alignment.LEFT;
			if (!useRowTextAlignment && sr.getLocalName().equals("HeaderTextAlignment")) {
				headerAlignment = getHeaderTextAlignment(sr);
			}

			boolean wrapText = false;
			if (sr.getLocalName().equals("WrapText")) {
				wrapText = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
			}

			int maxWidth = 0;
			if (sr.getLocalName().equals("MaxWidth")) {
				maxWidth = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
			}

			CellStyle.VerticalAlignment verticalAlignment = CellStyle.VerticalAlignment.MIDDLE;
			if (sr.getLocalName().equals("VerticalAlignment")) {
				verticalAlignment = getVerticalAlignment(sr);
			}

			wgi.columnMap.add(new ColumnInfo(columnName, displayName, new BigDecimal(width), headerStyleName, link,
					numericFormat, dateFormat, formats, referencedFrequency, ColumnInfo.getType(colType),
					new Boolean(initiallyShow), defaultVal, isEditable, picklistOptions, order, useRowTextAlignment,
					headerAlignment, wrapText, maxWidth, verticalAlignment));
			if (numericFormat != null) {
				wgi.columnFormatInfoMap.put(displayName, JavascriptNumberFormat.getNumberFormat(numericFormat));
			}

			wgi.columnNameDisplayNameMap.put(columnName, displayName);
			if (referencedFrequency != null) {
				List<TimePeriod> columnPeriods = scope.getTimePeriods(referencedFrequency.getTimeId(),
						referencedFrequency.getLevelId());
				Map<String, Integer> periodToRank = new Hashtable();
				int i = 0;

				for (TimePeriod period : columnPeriods) {
					periodToRank.put(period.getName(), i);
					++i;
				}

				wgi.columnPeriodToRank.put(columnName, periodToRank);
			}
		}

	}

	private static void populateHiddenColumnInfo(DataGridInfo wgi, Scope scope, XMLStreamReader sr,
			List<ColumnDefinition> tableColumns) throws XMLStreamException, ReportOverLimitException {
		if (sr.getLocalName().equals("HiddenInputRowColumnMap")) {
			String defaultVal = "";
			sr.nextTag();

			while (sr.getEventType() == 1) {
				sr.nextTag();
				String columnName = XMLStreamUtility.getCurrentNodeValue(sr);
				String defaultValue = XMLStreamUtility.getCurrentNodeValue(sr);
				if (defaultValue.startsWith(LOCAL_SOURCE)) {
					defaultValue = defaultValue.substring(LOCAL_SOURCE.length());
					Literal.Type type = scope.getLiteralType(defaultValue);
					if (type == Literal.Type.STRING) {
						defaultVal = scope.getString(defaultValue);
					} else if (type == Literal.Type.DECIMAL) {
						defaultVal = scope.getDecimal(defaultValue).toPlainString();
					} else if (type == Literal.Type.DATETIME) {
						defaultVal = Format.asValueString(scope.getDateTime(defaultValue));
					}
				} else if (defaultValue.equals(AUTO_GENERATE)) {
					defaultVal = AUTO_GENERATE;
				} else if (defaultValue.equals(BLANK) && tableColumns != null
						&& getDefinition(tableColumns, columnName).isNumeric()) {
					defaultVal = "0";
				} else if (!defaultValue.equals("") && !defaultValue.equals(BLANK)) {
					Assert.state(false);
				} else {
					defaultVal = "";
				}

				wgi.hiddenColumnMap.put(columnName, defaultVal);
				sr.nextTag();
			}

			sr.nextTag();
		}

	}

	private static int populateComputedColumnInfo(Scope scope, DataGridInfo grid, XMLStreamReader sr,
			JavascriptUtil jsUtil) throws XMLStreamException, ReportOverLimitException {
		HashMap<String, ComputedColumnInfo> computedColumnInfoMap = new HashMap();
		int javascriptExpressionSuffix = 0;
		if (sr.getLocalName().equals("ComputedColumns")) {
			sr.nextTag();

			while (sr.getLocalName().equals("ComputedColumn")) {
				ColumnInfo computedColumn = getComputedColumnInfo(sr, scope);
				String computedColumnName = computedColumn.getDisplayName();
				grid.columnMap.add(computedColumn);
				XMLStreamUtility.MoveStreamForwardToTag(sr, "Expression");
				ExpressionParser computedColumnExpression = new ExpressionParser();
				ExpressionEvaluator evaluator = computedColumnExpression.getExpression(sr,
						grid.columnNameDisplayNameMap, javascriptExpressionSuffix);
				javascriptExpressionSuffix = computedColumnExpression.getSuffix();
				String variableJavascript = computedColumnExpression.getJavascriptVariableDeclaration(jsUtil);
				String functionJavascript = computedColumnExpression.getJavascriptFunctions(jsUtil, true);
				ComputedColumnInfo computedColumnInfo = new ComputedColumnInfo(computedColumnName, variableJavascript,
						functionJavascript, computedColumnExpression.getStartSuffix(),
						computedColumnExpression.getSuffix(), evaluator, false, computedColumn.getNumericFormat(),
						computedColumn.getOrder());
				computedColumnInfoMap.put(computedColumnName, computedColumnInfo);
				sr.nextTag();
			}

			sr.nextTag();
		}

		grid.computedColumnInfoMap = computedColumnInfoMap;
		return javascriptExpressionSuffix;
	}

	public static int populateComputedRow(DataGridInfo wgi, XMLStreamReader sr, JavascriptUtil jsUtil,
			int javascriptExpressionSuffix) throws XMLStreamException {
		wgi.computedRowInfoMap = new HashMap();
		if (sr.getLocalName().equals("ComputedRow")) {
			sr.nextTag();

			while (sr.getEventType() == 1) {
				sr.nextTag();
				String columnName = XMLStreamUtility.getCurrentNodeValue(sr);
				String columnDisplayName = XMLStreamUtility.getCurrentNodeValue(sr);
				String cellValue = XMLStreamUtility.getCurrentNodeValue(sr);
				int valueType = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
				NumericFormat numericFormat = null;
				if (sr.getLocalName().equals("NumericFormat")) {
					numericFormat = NumericFormat.ReadNumericFormatFromXml(sr);
				}

				boolean isFormula = valueType == 1;
				boolean skip = false;
				ExpressionEvaluator evaluator = null;
				ExpressionParser parser = null;
				if (isFormula) {
					parser = new ExpressionParser();
					evaluator = parser.getExpression(sr, wgi.columnNameDisplayNameMap, javascriptExpressionSuffix);
					javascriptExpressionSuffix = parser.getSuffix();

					for (String variable : evaluator.getVariables()) {
						if (!wgi.columnNameDisplayNameMap.containsKey(variable)) {
							skip = true;
						}
					}
				}

				ComputedRowInfo rowInfo = new ComputedRowInfo(columnName, columnDisplayName, cellValue, isFormula,
						evaluator, skip);
				if (parser != null) {
					rowInfo.setVariableJavascript(parser.getJavascriptVariableDeclaration(jsUtil));
					rowInfo.setFunctionJavascript(parser.getJavascriptFunctions(jsUtil, false));
					rowInfo.setJavascriptStartSuffix(parser.getStartSuffix());
					rowInfo.setJavascriptEndSuffix(parser.getSuffix());
					rowInfo.setNumericFormat(numericFormat);
					if (numericFormat != null) {
						rowInfo.setJavascriptFormatInfo(JavascriptNumberFormat.getNumberFormat(numericFormat));
					}
				}

				wgi.computedRowInfoMap.put(columnName, rowInfo);
				sr.nextTag();
			}

			sr.nextTag();
		}

		return javascriptExpressionSuffix;
	}

	private static void populateSections(DataGridInfo wgi, XMLStreamReader sr) throws XMLStreamException {
		wgi.sections = new ArrayList();
		sr.nextTag();
		if (sr.getLocalName().equals("Section")) {
			while (sr.getEventType() == 1) {
				wgi.sections.add(new DataGridSection(sr));
				sr.nextTag();
			}
		}

	}

	private static void populateValidationRules(DataGridInfo wgi, XMLStreamReader sr, JavascriptUtil jsUtil,
			int javascriptExpressionSuffix) throws XMLStreamException {
		sr.nextTag();
		if (sr.getLocalName().equals("ValidationRules")) {
			sr.nextTag();

			while (sr.getEventType() == 1) {
				sr.nextTag();
				XMLStreamUtility.getCurrentNodeValue(sr);
				String errorMessage = XMLStreamUtility.getCurrentNodeValue(sr);
				ExpressionEvaluator evaluator = null;
				ExpressionParser parser = new ExpressionParser();
				evaluator = parser.getExpression(sr, wgi.columnNameDisplayNameMap, javascriptExpressionSuffix);
				javascriptExpressionSuffix = parser.getSuffix();
				WebReportValidationRule rule = new WebReportValidationRule(evaluator, errorMessage,
						parser.getStartSuffix(), parser.getSuffix(), parser.getJavascriptVariableDeclaration(jsUtil),
						parser.getJavascriptFunctions(jsUtil, false), false);
				wgi.validationRules.add(rule);
				sr.nextTag();
			}

			sr.nextTag();
		}

	}

	private static void populateSortColumns(DataGridInfo wgi, XMLStreamReader sr) throws XMLStreamException {
		int sortOrder = 0;

		while (sr.getEventType() == 1) {
			sr.nextTag();
			String column = XMLStreamUtility.getCurrentNodeValue(sr);
			String sortDescending = XMLStreamUtility.getCurrentNodeValue(sr);
			String timeId = XMLStreamUtility.getCurrentNodeValue(sr);
			String levelId = XMLStreamUtility.getCurrentNodeValue(sr);
			boolean sortDesc = Boolean.parseBoolean(sortDescending);
			Frequency freq = null;
			if (!timeId.equals("")) {
				freq = new Frequency(timeId, levelId);
			}

			wgi.sortColumns.add(new SortColumn(column, sortDesc, freq));
			wgi.sortColumnIndex.put(column, sortOrder);
			++sortOrder;
			sr.nextTag();
		}

	}

	private void initializeDataGrid(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		getDataGridInfo(this.gridInfo, (String) null, this.streamReader, scope, this.schemaDao,
				this.gridInfo.hideAllRows, 1, 1, (String) null, false, false);
		if (!this.gridInfo.needsHeader) {
			this.currentReadRow = -1;
			this.streamReader.nextTag();
		} else {
			this.writeXmlOutput(writer, scope, this.gridInfo.suppressPartitionValues,
					this.gridInfo.enableExportToExcel);
			this.initializePartitions(scope, this.gridInfo.timeID, this.gridInfo.sortColumns);
		}
	}

	private void initializePartitions(Scope scope, String timeID, List<SortColumn> sortColumns) {
		List<String> partitionColumns = new ArrayList();

		for (SortColumn sortColumn : sortColumns) {
			if (this.gridInfo.data.getColumn(sortColumn.getColumnName()).isNumeric()) {
				break;
			}

			partitionColumns.add(sortColumn.getColumnName());
		}

		this.part = new PartitionTracker((String[]) partitionColumns.toArray(new String[partitionColumns.size()]),
				timeID, scope);
		if (!this.gridInfo.data.getRows().isEmpty()) {
			this.part.setPartition(this.gridInfo.data, 0);
		}

	}

	private void writeXmlOutput(XMLStreamWriter writer, Scope scope, boolean suppressPartitionValues,
			boolean enableExportToExcel) throws XMLStreamException {
		writer.writeStartElement("DataGridDisplay");
		writer.writeStartElement("ReportID");
		writer.writeCharacters(Integer.toString(scope.getReportID()));
		writer.writeEndElement();
		writer.writeStartElement("Name");
		writer.writeCharacters(this.gridInfo.name);
		writer.writeEndElement();
		writer.writeStartElement("Paginated");
		writer.writeCharacters(this.gridInfo.paginated ? "true" : "false");
		writer.writeEndElement();
		writer.writeStartElement("FreezeTopRow");
		writer.writeCharacters(this.gridInfo.freezeTopRow ? "true" : "false");
		writer.writeEndElement();
		writer.writeStartElement("DataGrid");
		writer.writeStartElement("SuppressPartitionValues");
		writer.writeCharacters(Boolean.toString(suppressPartitionValues).toLowerCase());
		writer.writeEndElement();
		writer.writeStartElement("DataGridID");
		writer.writeCharacters(String.valueOf(this.gridInfo.id));
		writer.writeEndElement();
		writer.writeStartElement("DataGridDisplayTooltip");
		writer.writeCharacters(
				this.messages.getMessage(Messages.Key.DRAW_REPORT_DROPDOWN_TITLE, LocaleContextHolder.getLocale()));
		writer.writeEndElement();
		writer.writeStartElement("EnableExportToExcel");
		writer.writeCharacters(this.gridInfo.enableExportToExcel ? "true" : "false");
		writer.writeEndElement();
		writer.writeStartElement("ExportToExcelName");
		writer.writeCharacters(
				this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_NAME, LocaleContextHolder.getLocale()));
		writer.writeEndElement();
		writer.writeStartElement("ExportToExcelXLS");
		writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_EXTENSION_XLS,
				LocaleContextHolder.getLocale()));
		writer.writeEndElement();
		writer.writeStartElement("ExportToExcelXLSX");
		writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_EXPORTEXCEL_EXTENSION_XLSX,
				LocaleContextHolder.getLocale()));
		writer.writeEndElement();
		writer.writeStartElement("EnableShowHideColumns");
		writer.writeCharacters(this.gridInfo.enableShowHideColumns ? "true" : "false");
		writer.writeEndElement();
		writer.writeStartElement("DataGridName");
		writer.writeCharacters(this.gridInfo.name);
		writer.writeEndElement();
		this.generateHeaderRow(writer, this.gridInfo.columnMap);
	}

	private static CellStyle.Alignment getHeaderTextAlignment(XMLStreamReader streamReader) throws XMLStreamException {
		String alignmentString = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (alignmentString.equalsIgnoreCase("JUSTIFY")) {
			return CellStyle.Alignment.JUSTIFY;
		} else if (alignmentString.equalsIgnoreCase("LEFT")) {
			return CellStyle.Alignment.LEFT;
		} else if (alignmentString.equalsIgnoreCase("CENTER")) {
			return CellStyle.Alignment.CENTER;
		} else {
			return alignmentString.equalsIgnoreCase("RIGHT") ? CellStyle.Alignment.RIGHT : CellStyle.Alignment.LEFT;
		}
	}

	private static CellStyle.VerticalAlignment getVerticalAlignment(XMLStreamReader streamReader)
			throws XMLStreamException {
		String alignmentString = XMLStreamUtility.getCurrentNodeValue(streamReader);
		if (alignmentString.equalsIgnoreCase("TOP")) {
			return CellStyle.VerticalAlignment.TOP;
		} else if (alignmentString.equalsIgnoreCase("MIDDLE")) {
			return CellStyle.VerticalAlignment.MIDDLE;
		} else {
			return alignmentString.equalsIgnoreCase("BOTTOM") ? CellStyle.VerticalAlignment.BOTTOM
					: CellStyle.VerticalAlignment.MIDDLE;
		}
	}

	private static CustomType getColumnType(ColumnDefinition columnDefinition, Frequency fc) {
		if (columnDefinition.getType() != 3 && columnDefinition.getType() != 4) {
			if (columnDefinition.getType() == 12) {
				return CustomType.TEXT;
			} else {
				return columnDefinition.getType() != 91 && columnDefinition.getType() != 93 ? CustomType.TEXT
						: CustomType.DATE;
			}
		} else {
			return CustomType.NUMERIC;
		}
	}

	private static ColumnDefinition getDefinition(List<ColumnDefinition> definitions, String column) {
		for (ColumnDefinition def : definitions) {
			if (def.getName().equals(column)) {
				return def;
			}
		}

		return null;
	}

	private void writeDataGridInputRow(XMLStreamWriter writer, Scope scope,
			HashMap<String, Object> columnDefaultValueMap) throws XMLStreamException {
		writer.writeStartElement("DataGridInfo");
		writer.writeStartElement("DataGridType");
		writer.writeCharacters(this.gridInfo.editable ? this.gridInfo.gridType : "Readonly");
		writer.writeEndElement();
		writer.writeStartElement("IsVertical");
		writer.writeCharacters(this.gridInfo.isVertical && this.gridInfo.editable ? "True" : "False");
		writer.writeEndElement();
		List<WebReportTableEdit> tableEditList = scope.getTableEditList();
		if (this.gridInfo.isVertical) {
			writer.writeStartElement("VerticalInputInfo");

			for (ColumnInfo info : this.gridInfo.columnMap) {
				if (!this.isComputedColumn(info)) {
					writer.writeStartElement("VerticalTableRow");
					this.writeHeaderCell(writer, info, false);
					this.generateInputRowColumn(writer, tableEditList, info,
							scope.getTableFromSource(this.gridInfo.data.getTableName()), this.gridInfo.filters,
							columnDefaultValueMap);
					writer.writeEndElement();
				}
			}

			writer.writeEndElement();
		} else if (this.gridInfo.gridType.equals("InputRow")) {
			writer.writeStartElement("InputRowAtTop");
			writer.writeCharacters(this.gridInfo.inputRowAtTop ? "True" : "False");
			writer.writeEndElement();
			if (this.gridInfo.enableInquiryCopy && !this.gridInfo.hideAllRows) {
				addBlankInquiryElement(writer);
			}

			if (this.gridInfo.gridType.equals("InputRow")) {
				writer.writeStartElement("SourceTable");
				String maintable = scope.getTableFromSource(this.gridInfo.data.getTableName());
				writer.writeCharacters(maintable);
				writer.writeEndElement();
				writer.writeStartElement("Columns");

				for (ColumnInfo column : this.gridInfo.columnMap) {
					writer.writeStartElement("Column");
					this.generateInputRowColumn(writer, tableEditList, column, maintable, this.gridInfo.filters,
							columnDefaultValueMap);
					writer.writeEndElement();
				}

				writer.writeEndElement();
			}
		}

		writer.writeEndElement();
	}

	private void generateInputRowColumn(XMLStreamWriter writer, List<WebReportTableEdit> tableEditList,
			ColumnInfo column, String maintable, Map<String, SourceDefinition> filters,
			HashMap<String, Object> columnDefaultValueMap) throws XMLStreamException {
		String inputName = "";
		if (!this.isComputedColumn(column)) {
			int editId = getEditId(this.gridInfo.name, maintable, column.getColumnName(), tableEditList);
			inputName = "IR_" + Integer.toString(editId);
			if (this.gridInfo.columnInsertMap.containsKey(column.getColumnName())
					&& this.gridInfo.columnInsertMap.get(column.getColumnName()).isEdited()) {
				inputName = "Edited_" + inputName;
			}
		}

		writer.writeStartElement("InputName");
		if (!column.isUseRowTextAlignment()) {
			writer.writeAttribute("TextAlignment", column.getHeaderTextAlignment().toString().toLowerCase());
		}

		writer.writeCharacters(inputName);
		writer.writeEndElement();
		writer.writeStartElement("InitiallyShow");
		writer.writeCharacters(
				(new Boolean(!this.gridInfo.enableShowHideColumns || column.getInitiallyShow())).toString());
		writer.writeEndElement();
		new ArrayList();
		List<SelectOption> options = this.picklistDao.getWebReportOptions(maintable, column.getColumnName(),
				filters.get(column.getColumnName()), this.gridInfo.merger, column.getPicklistOptions());
		writer.writeStartElement("InputType");
		NumericFormat numericFormat = NumericFormat.DECIMAL_FIXED;
		if (this.isComputedColumn(column)) {
			String cellValue = "";
			String rawValue = "";
			BigDecimal result = new BigDecimal(0);
			ComputedColumnInfo computedColumnInfo = this.gridInfo.computedColumnInfoMap.get(column.getColumnName());
			if (this.calculateInputRow()) {
				computedColumnInfo.getEvaluator().reset();
				List<String> variables = getUnPrefixedVariables(computedColumnInfo.getEvaluator());

				for (int i = 0; i < variables.size(); ++i) {
					String variable = variables.get(i);
					if (columnDefaultValueMap.containsKey(variable)) {
						computedColumnInfo.getEvaluator().setValue(i,
								getVariableValue(columnDefaultValueMap.get(variable)));
					} else {
						computedColumnInfo.getEvaluator().setValue(i, new BigDecimal(0));
					}
				}

				result = computedColumnInfo.getEvaluator().evaluate();
				cellValue = Format.asPRValueString(result, numericFormat, column.getDateFormat());
				rawValue = getRawValue(numericFormat, result);
			}

			columnDefaultValueMap.remove(column.getColumnName());
			columnDefaultValueMap.put(column.getColumnName(), result);
			writer.writeCharacters("Text");
			writer.writeEndElement();
			writer.writeStartElement("RawValue");
			writer.writeCharacters(rawValue);
			writer.writeEndElement();
			writer.writeStartElement("Value");
			writer.writeCharacters(cellValue);
			writer.writeEndElement();
		} else {
			String cellValue = Format.asPRValueString(column.getDefaultValue(), numericFormat,
					new PRDateFormat(PRDateFormat.DateStyle.Date));
			if (options != null && !AUTO_GENERATE.equals(column.getDefaultValue())) {
				writer.writeCharacters("Picklist");
				writer.writeEndElement();
				writer.writeStartElement("Options");

				for (SelectOption option : options) {
					writer.writeStartElement("Option");
					writer.writeStartElement("Value");
					writer.writeCharacters(option.getValue());
					writer.writeEndElement();
					writer.writeStartElement("DisplayValue");
					if (column.getPicklistOptions() != null && column.getPicklistOptions().getHideDescription()
							&& !column.getPicklistOptions().getHideKey()) {
						writer.writeCharacters("(" + option.getValue() + ")");
					} else if (column.getPicklistOptions() != null && column.getPicklistOptions().getHideKey()) {
						writer.writeCharacters(option.getName());
					} else {
						writer.writeCharacters("(" + option.getValue() + ") " + option.getName());
					}

					writer.writeEndElement();
					if (option.getValue().equals(column.getDefaultValue())) {
						writer.writeStartElement("IsDefault");
						writer.writeCharacters("true");
						writer.writeEndElement();
					}

					writer.writeEndElement();
				}

				writer.writeEndElement();
			} else if (AUTO_GENERATE.equals(column.getDefaultValue())) {
				writer.writeCharacters(AUTO_GENERATE);
				writer.writeEndElement();
			} else if (column.getType().equals("DATE")) {
				writer.writeCharacters("DatePicker");
				writer.writeEndElement();
				writer.writeStartElement("Value");
				writer.writeCharacters(cellValue);
				writer.writeEndElement();
			} else if (column.getType().equals("COMMENT")) {
				writer.writeCharacters("CommentBox");
				writer.writeEndElement();
				writer.writeStartElement("Value");
				writer.writeCharacters(cellValue);
				writer.writeEndElement();
			} else {
				writer.writeCharacters("TextBox");
				writer.writeEndElement();
				writer.writeStartElement("Value");
				writer.writeCharacters(cellValue);
				writer.writeEndElement();
			}
		}

	}

	boolean calculateInputRow() {
		for (RowFormInsert insert : this.gridInfo.columnInsertMap.values()) {
			if (insert.isEdited()) {
				return true;
			}
		}

		return false;
	}

	public static void replaceLocalVariables(Clause root, Scope scope) throws ReportOverLimitException {
		for (IConstraint item : root.getConstraints()) {
			if (item instanceof Clause) {
				replaceLocalVariables((Clause) item, scope);
			} else if (item instanceof Constraint) {
				Constraint c = (Constraint) item;
				if (c.getRight() instanceof Literal && ((Literal) c.getRight()).getType() == Literal.Type.STRING) {
					Object variable = ((Literal) c.getRight()).getValue();
					String variableName = "";
					if (variable != null) {
						variableName = (String) variable;
					}

					if (variableName.startsWith(LOCAL_SOURCE)) {
						variableName = variableName.replace(LOCAL_SOURCE, "");
						Object localVal = scope.getObject(variableName);
						Scope.Type type = scope.getType(variableName);
						if (type == Scope.Type.DECIMAL) {
							c.setRight(Literal.newLiteral((BigDecimal) localVal));
						} else if (type == Scope.Type.STRING) {
							c.setRight(Literal.newLiteral((String) localVal));
						} else if (type == Scope.Type.DATE) {
							c.setRight(Literal.newLiteral((Date) localVal));
						}
					}
				}
			}
		}

	}

	private boolean isComputedColumn(ColumnInfo column) {
		return this.gridInfo.computedColumnInfoMap != null
				&& this.gridInfo.computedColumnInfoMap.containsKey(column.getColumnName());
	}

	public static String getRawValue(NumericFormat numericFormat, Object val, String cellValue,
			String originalColumnName, Map<String, Map<String, Integer>> columnPeriodToRank) {
		String rawValue = "";
		if (cellValue.length() > 0 && columnPeriodToRank.containsKey(originalColumnName)) {
			Map<String, Integer> periodToRank = columnPeriodToRank.get(originalColumnName);
			Object theVal = periodToRank.get(cellValue);
			if (theVal != null) {
				rawValue = theVal.toString();
			}
		} else {
			rawValue = getRawValue(numericFormat, val);
		}

		return rawValue;
	}

	private static String getRawValue(NumericFormat numericFormat, Object val) {
		if (!(val instanceof BigDecimal)) {
			return ExpanderUtilities.getRawValueAsString(val);
		} else {
			BigDecimal bd;
			if (numericFormat != null && numericFormat.getStyle() == NumericFormat.Style.PERCENT) {
				int scale = numericFormat.getScale();
				scale += 2;
				bd = (new BigDecimal(val.toString())).setScale(scale, RoundingMode.HALF_UP);
			} else {
				bd = new BigDecimal(val.toString());
			}

			return ExpanderUtilities.getRawValueAsString(bd);
		}
	}

	private static ColumnInfo getComputedColumnInfo(XMLStreamReader sr, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		sr.nextTag();
		String columnName = XMLStreamUtility.getCurrentNodeValue(sr);
		int order = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
		String width = XMLStreamUtility.getCurrentNodeValue(sr);
		ColumnLink link = null;
		if (sr.getLocalName().equals("Link")) {
			link = new ColumnLink(sr);
		}

		NumericFormat numericFormat = null;
		if (sr.getLocalName().equals("NumericFormat")) {
			numericFormat = NumericFormat.ReadNumericFormatFromXml(sr);
		}

		ConditionalFormats formats = new ConditionalFormats();
		if (sr.getLocalName().equals("ConditionalFormats")) {
			sr.nextTag();

			while (sr.getEventType() == 1) {
				formats.addConditionalFormat(sr);
			}

			sr.nextTag();
		}

		String headerStyleName = null;
		if (sr.getLocalName().equals("HeaderStyleName")) {
			headerStyleName = XMLStreamUtility.getCurrentNodeValue(sr);
		}

		String initiallyShow = XMLStreamUtility.getCurrentNodeValue(sr);
		CellStyle.Alignment headerAlignment = CellStyle.Alignment.LEFT;
		boolean useRowTextAlignment = false;
		if (sr.getLocalName().equals("UseRowTextAlignment")) {
			useRowTextAlignment = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
			headerAlignment = getHeaderTextAlignment(sr);
		}

		boolean wrapText = false;
		if (sr.getLocalName().equals("WrapText")) {
			wrapText = Boolean.parseBoolean(XMLStreamUtility.getCurrentNodeValue(sr));
		}

		int maxWidth = 0;
		if (sr.getLocalName().equals("MaxWidth")) {
			maxWidth = Integer.parseInt(XMLStreamUtility.getCurrentNodeValue(sr));
		}

		CellStyle.VerticalAlignment verticalAlignment = CellStyle.VerticalAlignment.MIDDLE;
		if (sr.getLocalName().equals("VerticalAlignment")) {
			verticalAlignment = getVerticalAlignment(sr);
		}

		return new ColumnInfo(columnName, columnName, new BigDecimal(width), headerStyleName, link, numericFormat,
				(PRDateFormat) null, formats, (Frequency) null, ColumnInfo.Type.NUMERIC, new Boolean(initiallyShow), "",
				false, (PicklistDisplayOptions) null, order, useRowTextAlignment, headerAlignment, wrapText, maxWidth,
				verticalAlignment);
	}

	private void generateHeaderRow(XMLStreamWriter writer, List<ColumnInfo> columnMap) throws XMLStreamException {
		if (this.gridInfo.hasInputRow || this.gridInfo.needsHeader) {
			writer.writeStartElement("DataRow");
			writer.writeStartElement("DataGridHeader");
			if (this.gridInfo.suppressHeader) {
				writer.writeAttribute("SuppressHeader", "True");
			} else {
				writer.writeAttribute("SuppressHeader", "False");
			}

			if (this.gridInfo.enableInquiryCopy && !this.gridInfo.hideAllRows) {
				writer.writeAttribute("EnableInquiryCopy", "True");
				writer.writeAttribute("InquiryCopyColumnWidth", InquiryCopyColumnWidth.toString());
			} else {
				writer.writeAttribute("EnableInquiryCopy", "False");
			}

			writer.writeStartElement("FreezeTopRow");
			writer.writeCharacters(this.gridInfo.freezeTopRow ? "true" : "false");
			writer.writeEndElement();
			int counter = 0;
			boolean firstVisibleColumnVisited = false;

			for (ColumnInfo info : columnMap) {
				if (this.colsToHide != null && this.colsToHide.size() > counter) {
					Boolean hide = this.colsToHide.get(counter);
					if (hide != null && hide) {
						++counter;
						continue;
					}
				}

				++counter;
				this.writeHeaderCell(writer, info, firstVisibleColumnVisited);
				firstVisibleColumnVisited = true;
			}

			writer.writeEndElement();
			writer.writeEndElement();
		}
	}

	private void writeHeaderCell(XMLStreamWriter writer, ColumnInfo info, boolean firstVisibleColumnVisited)
			throws XMLStreamException {
		writer.writeStartElement("HeaderCell");
		if (this.gridInfo.enableInquiryCopy && !this.gridInfo.hideAllRows && !firstVisibleColumnVisited) {
			writer.writeAttribute("Width", info.getWidth().subtract(InquiryCopyColumnWidth).toString());
		} else {
			writer.writeAttribute("Width", info.getWidth().toString());
		}

		if (info.getHeaderStyleName() != null) {
			writer.writeAttribute("HeaderStyleName", info.getHeaderStyleName());
		}

		writer.writeStartElement("HeaderValue");
		Locale locale = LocaleContextHolder.getLocale();
		Messages.Key key = this.messages.hasKey("column." + info.getDisplayName());
		if (key != null) {
			writer.writeCharacters(this.messages.getMessage(key, locale));
		} else {
			writer.writeCharacters(info.getDisplayName());
		}

		writer.writeEndElement();
		if (!this.gridInfo.sortColumnIndex.containsKey(info.getColumnName())) {
			writer.writeStartElement("CanSort");
			writer.writeCharacters("true");
			writer.writeEndElement();
		}

		NumericFormat numericFormat = info.getNumericFormat();
		if (numericFormat != null) {
			writer.writeStartElement("NumericStyle");
			writer.writeCharacters("" + numericFormat.getStyle().ordinal());
			writer.writeEndElement();
			writer.writeStartElement("Precision");
			writer.writeCharacters("" + numericFormat.getScale());
			writer.writeEndElement();
		}

		writer.writeStartElement("Type");
		writer.writeCharacters(info.getType());
		writer.writeEndElement();
		if (info.getDateFormat() != null) {
			writer.writeStartElement("DateStyle");
			writer.writeCharacters("" + info.getDateFormat().getDateStyle().ordinal());
			writer.writeEndElement();
		}

		writer.writeStartElement("WrapText");
		writer.writeCharacters((new Boolean(info.WrapText())).toString());
		writer.writeEndElement();
		writer.writeStartElement("MaxWidth");
		writer.writeCharacters((new Integer(info.MaxWidth())).toString());
		writer.writeEndElement();
		writer.writeStartElement("VerticalAlignment");
		writer.writeCharacters(info.getVerticalAlignment().toString().toLowerCase());
		writer.writeEndElement();
		writer.writeStartElement("InitiallyShow");
		writer.writeCharacters(
				(new Boolean(!this.gridInfo.enableShowHideColumns || info.getInitiallyShow())).toString());
		writer.writeEndElement();
		writer.writeEndElement();
	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeEndElement();
		writer.writeStartElement("StyleName");
		writer.writeCharacters(this.gridInfo.styleName);
		writer.writeEndElement();
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void generateRow(XMLStreamWriter writer, Scope scope, List<String> suppressedValues)
			throws XMLStreamException, ReportOverLimitException {
		String dataSourceName = this.gridInfo.data.getTableName();
		String srcTable = scope.getTableFromSource(dataSourceName);
		writer.writeStartElement("DataRow");
		writer.writeStartElement("Row");
		writer.writeAttribute("index", Integer.toString(this.currentWrittenRow % 2));
		if (this.gridInfo.data.getColumnIndex("_IsPending") >= 0) {
			String isPending = Boolean
					.toString((Integer) this.gridInfo.data.getObject(this.currentReadRow, "_IsPending") == 1);
			writer.writeStartElement("IsPending");
			writer.writeCharacters(isPending);
			writer.writeEndElement();
		}

		if (this.gridInfo.enableInquiryCopy) {
			writer.writeStartElement("InquiryCopyCell");
			if (this.currentReadRow == 0) {
				writer.writeAttribute("Width", InquiryCopyColumnWidth.toString());
			}

			String className = scope.getString("Workflow Form ID").isEmpty() ? "copy" : "disabledCopy";
			writer.writeStartElement("ClassName");
			writer.writeCharacters(className);
			writer.writeEndElement();
			writer.writeStartElement("Tooltip");
			writer.writeCharacters(this.messages.getMessage(Messages.Key.WEBREPORT_COPY_INQUIRY_TOOLTIP));
			writer.writeEndElement();
			writer.writeEndElement();
		}

		int counter = 0;
		boolean firstVisibleColumnVisited = false;
		Iterator i$ = this.gridInfo.columnMap.iterator();

		while (true) {
			ColumnInfo columnInfo;
			Boolean hide;
			do {
				if (!i$.hasNext()) {
					writer.writeEndElement();
					writer.writeEndElement();
					return;
				}

				columnInfo = (ColumnInfo) i$.next();
				if (this.colsToHide == null || this.colsToHide.size() <= counter) {
					break;
				}

				hide = this.colsToHide.get(counter++);
			} while (hide != null && hide);

			writer.writeStartElement("Cell");
			if (this.currentReadRow == 0) {
				if (this.gridInfo.enableInquiryCopy && !firstVisibleColumnVisited) {
					writer.writeAttribute("Width", columnInfo.getWidth().subtract(InquiryCopyColumnWidth).toString());
				} else {
					writer.writeAttribute("Width", columnInfo.getWidth().toString());
				}
			}

			firstVisibleColumnVisited = true;
			String dsAliasedColumnName = columnInfo.getColumnName();
			String dbColumnName = scope.getDBColumnName(dataSourceName, dsAliasedColumnName);
			String style = columnInfo.getConditionalStyle(this.gridInfo.data, this.currentReadRow, scope);
			if (style != null) {
				writer.writeStartElement("StyleName");
				writer.writeCharacters(style);
				writer.writeEndElement();
			} else if (!columnInfo.isUseRowTextAlignment()) {
				writer.writeAttribute("TextAlignment", columnInfo.getHeaderTextAlignment().toString().toLowerCase());
			}

			writer.writeStartElement("WrapText");
			writer.writeCharacters((new Boolean(columnInfo.WrapText())).toString());
			writer.writeEndElement();
			writer.writeStartElement("MaxWidth");
			writer.writeCharacters((new Integer(columnInfo.MaxWidth())).toString());
			writer.writeEndElement();
			writer.writeStartElement("VerticalAlignment");
			writer.writeCharacters(columnInfo.getVerticalAlignment().toString().toLowerCase());
			writer.writeEndElement();
			writer.writeStartElement("InitiallyShow");
			writer.writeCharacters(
					(new Boolean(!this.gridInfo.enableShowHideColumns || columnInfo.getInitiallyShow())).toString());
			writer.writeEndElement();
			Object val = suppressedValues.contains(dsAliasedColumnName) ? ""
					: this.gridInfo.data.getObject(this.currentReadRow, dsAliasedColumnName);
			NumericFormat numericFormat = columnInfo.determineNumericFormat(this.gridInfo.data, this.currentReadRow,
					scope);
			if (numericFormat == null) {
				numericFormat = NumericFormat.DECIMAL_FIXED;
			}

			String cellValue = columnInfo.isEditable()
					? Format.asPRValueString(val, numericFormat, new PRDateFormat(PRDateFormat.DateStyle.Date))
					: Format.asPRValueString(val, numericFormat, columnInfo.getDateFormat());
			writer.writeStartElement("IsEditable");
			writer.writeCharacters(Boolean.toString(columnInfo.isEditable() && this.gridInfo.editable));
			writer.writeEndElement();
			if (columnInfo.isEditable()) {
				writer.writeStartElement("InputName");
				String hashCode = Base64
						.encodeBytes((byte[]) this.gridInfo.data.getObject(this.currentReadRow, "_HashAlias"));
				int editId = getEditId(this.gridInfo.name, srcTable, dbColumnName, scope.getTableEditList());
				String editName = "DE_" + Integer.toString(editId) + "_" + Integer.toString(this.gridInfo.id) + "_"
						+ hashCode;
				String defaultString = null;
				if (this.isError && this.gridInfo.tableEditListMap != null
						&& this.gridInfo.tableEditListMap.get(srcTable) != null) {
					for (DataFieldEdit edit : this.gridInfo.tableEditListMap.get(srcTable)) {
						String currentRowHash = Base64
								.encodeBytes((byte[]) this.gridInfo.data.getRow(this.currentReadRow)
										.getObject(this.gridInfo.data.getColumnIndex("_HashAlias")));
						if (edit.getDataGrid().equals(this.gridInfo.name)
								&& edit.getEncodedHashByte().equals(currentRowHash)
								&& dbColumnName.equals(edit.getColumn())) {
							defaultString = edit.getNewValue();
							editName = "Edited_" + editName;
							break;
						}
					}
				}

				writer.writeCharacters(editName);
				writer.writeEndElement();
				writer.writeStartElement("InputType");
				Map<String, String> options = null;
				if (srcTable != null) {
					String key = srcTable + columnInfo.getColumnName();
					if (this.optionsCache.containsKey(key)) {
						options = this.optionsCache.get(key);
					} else {
						options = convertListToMap(this.picklistDao.getWebReportOptions(srcTable, dbColumnName,
								this.gridInfo.filters.get(columnInfo.getColumnName()), this.gridInfo.merger,
								columnInfo.getPicklistOptions()));
						this.optionsCache.put(key, options);
					}
				}

				if (options == null) {
					if (columnInfo.getType().equals("DATE")) {
						writer.writeCharacters("DatePicker");
						writer.writeEndElement();
						if (defaultString != null) {
							writer.writeStartElement("Value");
							writer.writeCharacters(defaultString);
							writer.writeEndElement();
						}
					} else if (columnInfo.getType().equals("COMMENT")) {
						writer.writeCharacters("CommentBox");
						writer.writeEndElement();
						if (defaultString != null) {
							writer.writeStartElement("Value");
							writer.writeCharacters(defaultString);
							writer.writeEndElement();
						}
					} else {
						writer.writeCharacters("TextBox");
						writer.writeEndElement();
						if (defaultString != null) {
							writer.writeStartElement("Value");
							writer.writeCharacters(defaultString);
							writer.writeEndElement();
						}
					}
				} else {
					writer.writeCharacters("Picklist");
					writer.writeEndElement();
					writer.writeStartElement("Options");
					String pickDescription = null;
					if (this.gridInfo.filters.get(columnInfo.getColumnName()) != null
							&& columnInfo.getPicklistOptions() != null && !options.containsKey(cellValue)) {
						if (this.picklistDescriptionCache.containsKey(columnInfo.getColumnName())) {
							pickDescription = this.picklistDescriptionCache.get(columnInfo.getColumnName())
									.get(cellValue);
						} else {
							Map<String, String> allPicklistOptions = convertListToMap(this.picklistDao
									.getWebReportOptions(srcTable, dbColumnName, (SourceDefinition) null,
											this.gridInfo.merger, columnInfo.getPicklistOptions()));
							this.picklistDescriptionCache.put(columnInfo.getColumnName(), allPicklistOptions);
							if (!options.containsKey(cellValue)) {
								pickDescription = allPicklistOptions.get(cellValue);
							}
						}
					}

					if (pickDescription != null) {
						writer.writeStartElement("Option");
						writer.writeStartElement("Value");
						writer.writeCharacters(cellValue);
						writer.writeEndElement();
						writer.writeStartElement("DisplayValue");
						if (columnInfo.getPicklistOptions() != null
								&& columnInfo.getPicklistOptions().getHideDescription()
								&& !columnInfo.getPicklistOptions().getHideKey()) {
							writer.writeCharacters("(" + cellValue + ")");
						} else if (columnInfo.getPicklistOptions() != null
								&& columnInfo.getPicklistOptions().getHideKey()) {
							writer.writeCharacters(pickDescription);
						} else {
							writer.writeCharacters("(" + cellValue + ") " + pickDescription);
						}

						writer.writeEndElement();
						if (defaultString == null) {
							writer.writeStartElement("IsDefault");
							writer.writeCharacters("true");
							writer.writeEndElement();
						}

						writer.writeEndElement();
					}

					for (Map.Entry<String, String> entry : options.entrySet()) {
						String pickID = entry.getKey();
						String pickDes = entry.getValue();
						writer.writeStartElement("Option");
						writer.writeStartElement("Value");
						writer.writeCharacters(pickID);
						writer.writeEndElement();
						writer.writeStartElement("DisplayValue");
						if (columnInfo.getPicklistOptions() != null
								&& columnInfo.getPicklistOptions().getHideDescription()
								&& !columnInfo.getPicklistOptions().getHideKey()) {
							writer.writeCharacters("(" + pickID + ")");
						} else if (columnInfo.getPicklistOptions() != null
								&& columnInfo.getPicklistOptions().getHideKey()) {
							writer.writeCharacters(pickDes);
						} else {
							writer.writeCharacters("(" + pickID + ") " + pickDes);
						}

						writer.writeEndElement();
						if (defaultString == null) {
							if (pickID.equals(cellValue)) {
								writer.writeStartElement("IsDefault");
								writer.writeCharacters("true");
								writer.writeEndElement();
							}
						} else if (pickID.equals(defaultString)) {
							writer.writeStartElement("IsDefault");
							writer.writeCharacters("true");
							writer.writeEndElement();
						}

						writer.writeEndElement();
					}

					writer.writeEndElement();
				}
			}

			if (columnInfo.getType().equals("NUMERIC")) {
				NumericFormat cellSpecificNumericFormat = columnInfo.determineNumericFormat(this.gridInfo.data,
						this.currentReadRow, scope);
				if (cellSpecificNumericFormat != null) {
					writer.writeStartElement("Precision");
					writer.writeCharacters(String.valueOf(cellSpecificNumericFormat.getScale()));
					writer.writeEndElement();
					writer.writeStartElement("Type");
					writer.writeCharacters(String.valueOf(cellSpecificNumericFormat.getStyle().ordinal()));
					writer.writeEndElement();
				}
			}

			writer.writeStartElement("Value");
			writer.writeCharacters(cellValue);
			writer.writeEndElement();
			String rawValue = getRawValue(numericFormat, val, cellValue, dsAliasedColumnName,
					this.gridInfo.columnPeriodToRank);
			writer.writeStartElement("RawValue");
			writer.writeCharacters(rawValue);
			writer.writeEndElement();
			if (columnInfo.getLink() != null) {
				columnInfo.getLink().generateLink(writer, this.currentReadRow, this.gridInfo.data, scope);
			}

			writer.writeEndElement();
		}
	}

	private void generateComputedRow(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		writer.writeStartElement("DataRow");
		writer.writeStartElement("ComputedRow");
		writer.writeStartElement("ComputedRowID");
		writer.writeCharacters("computed_row_" + this.gridInfo.id);
		writer.writeEndElement();
		if (this.gridInfo.enableInquiryCopy) {
			addBlankInquiryElement(writer);
		}

		int counter = 0;
		boolean firstVisibleColumnVisited = false;

		for (ColumnInfo columnInfo : this.gridInfo.columnMap) {
			if (this.colsToHide != null && this.colsToHide.size() > counter) {
				Boolean hide = this.colsToHide.get(counter++);
				if (hide != null && hide) {
					continue;
				}
			}

			writer.writeStartElement("Cell");
			if (this.currentReadRow == 0) {
				if (this.gridInfo.enableInquiryCopy && !firstVisibleColumnVisited) {
					writer.writeAttribute("Width", columnInfo.getWidth().subtract(InquiryCopyColumnWidth).toString());
				} else {
					writer.writeAttribute("Width", columnInfo.getWidth().toString());
				}
			}

			firstVisibleColumnVisited = true;
			if (!columnInfo.isUseRowTextAlignment()) {
				writer.writeAttribute("TextAlignment", columnInfo.getHeaderTextAlignment().toString().toLowerCase());
			}

			writer.writeStartElement("WrapText");
			writer.writeCharacters(Boolean.toString(columnInfo.WrapText()));
			writer.writeEndElement();
			writer.writeStartElement("MaxWidth");
			writer.writeCharacters((new Integer(columnInfo.MaxWidth())).toString());
			writer.writeEndElement();
			writer.writeStartElement("VerticalAlignment");
			writer.writeCharacters(columnInfo.getVerticalAlignment().toString().toLowerCase());
			writer.writeEndElement();
			String originalColumnName = columnInfo.getColumnName();
			writer.writeStartElement("InitiallyShow");
			writer.writeCharacters(
					(new Boolean(!this.gridInfo.enableShowHideColumns || columnInfo.getInitiallyShow())).toString());
			writer.writeEndElement();
			ComputedRowInfo rowInfo = this.gridInfo.computedRowInfoMap.get(originalColumnName);
			String cellValue = rowInfo.getValue();
			Object val = cellValue;
			NumericFormat numericFormat = null;
			if (rowInfo.getEvaluator() != null) {
				val = rowInfo.getComputedValue();
				numericFormat = rowInfo.getNumericFormat();
				cellValue = Format.asPRValueString(val, numericFormat, (PRDateFormat) null);
			}

			writer.writeStartElement("IsEditable");
			writer.writeCharacters(Boolean.toString(false));
			writer.writeEndElement();
			writer.writeStartElement("Value");
			writer.writeCharacters(cellValue);
			writer.writeEndElement();
			String rawValue = getRawValue(numericFormat, val);
			writer.writeStartElement("RawValue");
			writer.writeCharacters(rawValue);
			writer.writeEndElement();
			writer.writeEndElement();
		}

		writer.writeEndElement();
		writer.writeEndElement();
	}

	public String getJavascript(Scope scope) throws ReportOverLimitException {
		JavascriptUtil jsUtil = new JavascriptUtil(this.gridInfo.id, this.gridInfo.columnFormatInfoMap);
		StringBuilder sb = new StringBuilder();
		sb.append(jsUtil.getCommonVariableDeclerations());
		if (this.gridInfo.computedColumnInfoMap != null && !this.gridInfo.isVertical) {
			for (ComputedColumnInfo computedColumnInfo : this.gridInfo.computedColumnInfoMap.values()) {
				sb.append(computedColumnInfo.getVariableJavascript());
			}
		}

		int rowCellEvaluationCount = 0;

		for (ComputedRowInfo rowInfo : this.gridInfo.computedRowInfoMap.values()) {
			if (rowInfo.getVariableJavascript() != null) {
				sb.append(rowInfo.getVariableJavascript());
				++rowCellEvaluationCount;
			}
		}

		int validationRuleCount = this.gridInfo.validationRules.size();
		if (validationRuleCount > 0) {
			for (WebReportValidationRule rule : this.gridInfo.validationRules) {
				sb.append(rule.getVariableJavascript());
			}
		}

		sb.append(jsUtil.getHeaderIndexJSFunction());
		sb.append(jsUtil.getRowValueJSFunction());
		sb.append(jsUtil.getPopulateHeadersFunction(this.gridInfo.isVertical));
		if (this.gridInfo.computedColumnInfoMap != null && !this.gridInfo.isVertical) {
			for (ComputedColumnInfo computedColumnInfo : this.gridInfo.computedColumnInfoMap.values()) {
				sb.append(computedColumnInfo.getFunctionJavascript());
			}
		}

		int[] startSuffices = new int[rowCellEvaluationCount];
		int[] endSuffices = new int[rowCellEvaluationCount];
		JavascriptFormatInfo[] formattingInfo = new JavascriptFormatInfo[rowCellEvaluationCount];
		String[] columnNames = new String[rowCellEvaluationCount];
		int i = 0;

		for (ComputedRowInfo rowInfo : this.gridInfo.computedRowInfoMap.values()) {
			if (rowInfo.getFunctionJavascript() != null) {
				sb.append(rowInfo.getFunctionJavascript());
				startSuffices[i] = rowInfo.getJavascriptStartSuffix();
				endSuffices[i] = rowInfo.getJavascriptEndSuffix();
				columnNames[i] = rowInfo.getDisplayColumnName();
				formattingInfo[i] = rowInfo.getJavascriptFormatInfo();
				++i;
			}
		}

		if (validationRuleCount > 0) {
			for (WebReportValidationRule rule : this.gridInfo.validationRules) {
				sb.append(rule.getFunctionJavascript());
			}
		}

		if (this.gridInfo.computedColumnInfoMap != null && !this.gridInfo.isVertical) {
			for (ComputedColumnInfo computedColumnInfo : this.gridInfo.computedColumnInfoMap.values()) {
				NumericFormat numericFormat = computedColumnInfo.determineNumericFormat(this.gridInfo.data,
						this.currentReadRow, scope);
				if (numericFormat == null) {
					numericFormat = NumericFormat.DECIMAL_FIXED;
				}

				JavascriptFormatInfo jsNumberFormat = JavascriptNumberFormat.getNumberFormat(numericFormat);
				sb.append(jsUtil.getComputedColumnEvaluationFunction(computedColumnInfo.getStartSuffix(),
						computedColumnInfo.getEndSuffix(), jsNumberFormat, computedColumnInfo.getComputedColumnName(),
						computedColumnInfo.getOrder()));
			}
		}

		boolean hasComputedRowCell = rowCellEvaluationCount > 0 && !this.gridInfo.hideAllRows;
		if (hasComputedRowCell) {
			sb.append(jsUtil.getComputedRowEvaluationFunction(startSuffices, endSuffices, columnNames, formattingInfo));
		}

		this.getDataGridEvaluationJavascript(jsUtil, sb, hasComputedRowCell);
		int[] startValidationRuleSuffices = new int[validationRuleCount];
		int[] endValidationRuleSufficed = new int[validationRuleCount];
		String[] errorMessages = new String[validationRuleCount];
		i = 0;

		for (WebReportValidationRule rule : this.gridInfo.validationRules) {
			startValidationRuleSuffices[i] = rule.getStartSuffix();
			endValidationRuleSufficed[i] = rule.getEndSuffix();
			errorMessages[i] = rule.getErrorMessage();
			++i;
		}

		if (validationRuleCount > 0) {
			sb.append(jsUtil.getValidationFunction(startValidationRuleSuffices, endValidationRuleSufficed,
					this.gridInfo.isVertical, errorMessages));
		}

		this.getDataGridValidationJavascript(jsUtil, sb, validationRuleCount > 0);
		List<DataGridInputRule> inputRules = scope.getInputRules(this.gridInfo.name);
		sb.append(jsUtil.getValidateRowInputRuleFunction(inputRules, scope, this.gridInfo.data.getTableName(),
				this.gridInfo.columnNameDisplayNameMap, this.gridInfo.isVertical));
		return sb.toString();
	}

	private void getDataGridEvaluationJavascript(JavascriptUtil jsUtil, StringBuilder sb, boolean hasComputedRowCell) {
		String evaluationFunctionName = "evaluate" + this.gridInfo.id;
		sb.append(JavascriptUtil.getFunctionSigniture(evaluationFunctionName));
		if (this.gridInfo.computedColumnInfoMap != null && !this.gridInfo.isVertical) {
			for (ComputedColumnInfo computedColumnInfo : this.gridInfo.computedColumnInfoMap.values()) {
				sb.append(jsUtil.getComputedColumnEvaluationFunctionName(computedColumnInfo.getOrder()));
				sb.append("();");
			}
		}

		if (hasComputedRowCell) {
			sb.append("evaluateComputedRow");
			sb.append(this.gridInfo.id);
			sb.append("();");
		}

		sb.append("}");
	}

	private void getDataGridValidationJavascript(JavascriptUtil jsUtil, StringBuilder sb, boolean hasValidationRules) {
		String evaluationFunctionName = "validate" + this.gridInfo.id;
		sb.append(JavascriptUtil.getFunctionSigniture(evaluationFunctionName));
		if (hasValidationRules) {
			sb.append("validateRules");
			sb.append(this.gridInfo.id);
			sb.append("();");
		}

		sb.append("}");
	}

	public int getDataDridId() {
		return this.gridInfo.id;
	}

	public boolean hasValidationRule() {
		return this.gridInfo.validationRules.size() > 0;
	}

	public void AddComputedRowMappings(HashMap<String, String> computedRowResultNameMap) {
		JavascriptUtil jsUtil = new JavascriptUtil(this.gridInfo.id, this.gridInfo.columnFormatInfoMap);

		for (ComputedRowInfo computedRow : this.gridInfo.computedRowInfoMap.values()) {
			if (computedRow.getEvaluator() != null) {
				computedRowResultNameMap.put("CompRow_" + this.gridInfo.name + "." + computedRow.getDisplayColumnName(),
						jsUtil.getResultPrefix() + computedRow.getJavascriptEndSuffix());
			}
		}

	}

	public static List<String> getUnPrefixedVariables(ExpressionEvaluator evaluator) {
		ArrayList<String> names = new ArrayList();
		List<String> variables = evaluator.getVariables();
		String pfx = "Source.";

		for (String variable : variables) {
			if (variable.startsWith(pfx)) {
				names.add(variable.replace(pfx, ""));
			} else {
				names.add(variable);
			}
		}

		return names;
	}

	public HashMap<String, Map<String, String>> getColumnNameDisplayNameMaping() {
		HashMap<String, Map<String, String>> mapping = new HashMap();
		mapping.put(this.gridInfo.name, this.gridInfo.columnNameDisplayNameMap);
		return mapping;
	}

	public static int getTotalGridRows(Scope scope, String sourceName) throws ReportOverLimitException {
		DataTable table = scope.getDataTable(sourceName, false, false, -1, -1, (List) null, true);
		return table.getRows().size() == 0 ? 0 : (Integer) table.getObject(0, 0);
	}

	public static void addBlankInquiryElement(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeStartElement("BlankInquiryCopyCell");
		writer.writeAttribute("Width", InquiryCopyColumnWidth.toString());
		writer.writeEndElement();
	}

	class PartitionTracker {
		private String[] columnNames;
		private String calID;
		private Partition currentPartition;
		private Partition previousPartition;
		private Scope scope;

		public PartitionTracker(String[] columnNames, String calID, Scope scope) {
			this.columnNames = columnNames;
			this.calID = calID;
			this.scope = scope;
			this.currentPartition = DataGridExpander.this.new Partition();
			this.previousPartition = DataGridExpander.this.new Partition();
		}

		public void setPartition(DataTable table, int rowIndex) {
			this.previousPartition = this.currentPartition;
			this.currentPartition = DataGridExpander.this.new Partition();

			for (String column : this.columnNames) {
				if (table.getObject(rowIndex, column) instanceof Date) {
					Date date = (Date) table.getObject(rowIndex, column);
					if (!this.calID.isEmpty()) {
						for (String level : this.scope.getLevels(this.calID)) {
							if (!level.equals("Total")) {
								TimePeriod period = this.scope.getPeriod(this.calID, date, level);
								if (period != null) {
									this.currentPartition.addColumn(column + "." + this.calID + "." + level,
											period.getName());
								}
							}
						}
					}
				}

				this.currentPartition.addColumn(column, table.getValue(rowIndex, column));
			}

		}

		public String[] getPartitions() {
			return this.columnNames;
		}

		public Partition getCurrentPartition() {
			return this.currentPartition;
		}

		public Partition getPreviousPartition() {
			return this.previousPartition;
		}

		public java.util.Set<String> getChangedPartitions() {
			return this.currentPartition.getChangedPartitions(this.previousPartition);
		}
	}

	public class Partition {
		List<ColumnValuePair> partitionValues = new ArrayList();

		public String[] getColumns() {
			String[] columns = new String[this.partitionValues.size()];
			int i = 0;

			for (int n = this.partitionValues.size(); i < n; ++i) {
				columns[i] = this.partitionValues.get(i).Column;
			}

			return columns;
		}

		public String getValue(String columnName) {
			for (ColumnValuePair column : this.partitionValues) {
				if (column.Column.equals(columnName)) {
					return column.Value;
				}
			}

			return null;
		}

		public void addColumn(String columnName, String value) {
			this.partitionValues.add(new ColumnValuePair(columnName, value));
		}

		public java.util.Set<String> getChangedPartitions(Partition other) {
			java.util.Set<String> changedColumns = new HashSet();
			int i = 0;

			for (int n = this.partitionValues.size(); i < n; ++i) {
				ColumnValuePair column1 = this.partitionValues.get(i);
				if (other.partitionValues.size() <= i) {
					changedColumns.add(column1.Column);
					break;
				}

				ColumnValuePair column2 = other.partitionValues.get(i);
				if (!column1.Column.equals(column2.Column) || !column1.Value.equals(column2.Value)) {
					changedColumns.add(column1.Column);
					changedColumns.add(column2.Column);
				}
			}

			for (int j = i; j < other.partitionValues.size(); ++j) {
				ColumnValuePair column = other.partitionValues.get(j);
				changedColumns.add(column.Column);
			}

			return changedColumns;
		}

		class ColumnValuePair {
			public final String Column;
			public final String Value;

			public ColumnValuePair(String column, String value) {
				this.Column = column;
				this.Value = value;
			}
		}
	}
}
