package com.varicent.reporting.dao.Expander;

import java.util.ArrayList;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.BPM.dao.BPMDao;
import com.varicent.BPM.dao.jdbc.JdbcBPMDaoImpl;
import com.varicent.BPM.domain.BPMTokenView;
import com.varicent.BPM.domain.BPMWorkflowView;
import com.varicent.common.concurrency.dao.ConcurrencyDao;
import com.varicent.common.schema.dao.SchemaDao;
import com.varicent.common.schema.dao.jdbc.JdbcSchemaDaoImpl;
import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Format;
import com.varicent.reporting.dao.ReportingDao;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;
import com.varicent.security.domain.UserAccount;

public class WorkflowLinkExpander extends BaseExpander {
	private final BPMDao BPMdao;
	private final SchemaDao schemaDao;
	private final Messages message;

	public WorkflowLinkExpander(XMLStreamReader streamReader, DataSource ds, Messages messages) {
		super(streamReader);
		this.schemaDao = new JdbcSchemaDaoImpl(ds);
		this.BPMdao = new JdbcBPMDaoImpl(ds, this.schemaDao, (ReportingDao) null, (ConcurrencyDao) null);
		this.message = messages;
		if (!streamReader.getLocalName().equals("WorkflowLinkControl")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("WorkflowLinkControl")) {
			writer.writeStartElement("WorkflowLinkControl");
			this.streamReader.nextTag();
			String name = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String status = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String enableHeadersString = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeStartElement("EnableHeaders");
			writer.writeCharacters(enableHeadersString);
			writer.writeEndElement();
			boolean enableHeaders = Integer.parseInt(enableHeadersString) == 1;
			String payeeID = UserAccount.getCurrent().getPayeeId();
			this.streamReader.nextTag();
			writer.writeStartElement("ColumnHeaders");

			ArrayList<String> columns;
			String nextColumnName;
			for (columns = new ArrayList(); this.streamReader.getLocalName().equals("Column"); columns
					.add(nextColumnName)) {
				nextColumnName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
				if (enableHeaders) {
					writer.writeStartElement("Column");
					writer.writeCharacters(this.getTranslatedColumnName(nextColumnName));
					writer.writeEndElement();
				}
			}

			this.streamReader.nextTag();
			writer.writeEndElement();
			if (status.equals("Available")) {
				this.BuildXmlAvailableView(payeeID, columns, writer);
			} else if (status.equals("Pending")) {
				this.BuildXmlPendingView(payeeID, columns, writer);
			} else {
				this.BuildXmlDefaultView(payeeID, columns, writer);
			}

			super.copyCurrentNode(writer);
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}

	private void BuildXmlDefaultView(String payeeID, ArrayList<String> columns, XMLStreamWriter writer)
			throws XMLStreamException {
		BPMTokenView[] totalHistory = this.BPMdao.getCompletedTokenViews(payeeID);

		for (BPMTokenView param : totalHistory) {
			writer.writeStartElement("WorkflowLink");

			for (String column : columns) {
				writer.writeStartElement("Cell");
				if (column.equals("WorkflowName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getWorkflow());
					writer.writeEndElement();
				} else if (column.equals("Initiator")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getPayee());
					writer.writeEndElement();
				} else if (column.equals("InitiatorName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getPayeeName());
					writer.writeEndElement();
				} else if (column.equals("DateOfInitiation")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(Format.asFullLongDateTime(param.getCreatedAt()));
					writer.writeEndElement();
				} else {
					if (!column.equals("DateOfCompletion")) {
						throw new XMLStreamException("WorkflowLink column not recognized.");
					}

					writer.writeStartElement("Value");
					writer.writeCharacters(Format.asFullLongDateTime(param.getLastModified()));
					writer.writeEndElement();
				}

				writer.writeStartElement("URL");
				String url = "../bpm/completedtokenhistorypage.html?bpmTokenID=" + param.getTokenID();
				writer.writeCharacters(url);
				writer.writeEndElement();
				writer.writeEndElement();
			}

			writer.writeEndElement();
		}

	}

	private void BuildXmlAvailableView(String payeeID, ArrayList<String> columns, XMLStreamWriter writer)
			throws XMLStreamException {
		BPMWorkflowView[] initiatable = this.BPMdao.getInitiatableWorkflows(payeeID);

		for (BPMWorkflowView param : initiatable) {
			writer.writeStartElement("WorkflowLink");

			for (String column : columns) {
				writer.writeStartElement("Cell");
				if (column.equals("WorkflowName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getName());
					writer.writeEndElement();
				} else {
					if (!column.equals("WorkflowDescription")) {
						throw new XMLStreamException("WorkflowLink column not recognized.");
					}

					writer.writeStartElement("Value");
					writer.writeCharacters(param.getDescription());
					writer.writeEndElement();
				}

				writer.writeStartElement("URL");
				String url = "../bpm/initialize.html?workflowID=" + param.getWorkflowID();
				writer.writeCharacters(url);
				writer.writeEndElement();
				writer.writeEndElement();
			}

			writer.writeEndElement();
		}

	}

	private void BuildXmlPendingView(String payeeID, ArrayList<String> columns, XMLStreamWriter writer)
			throws XMLStreamException {
		BPMTokenView[] pending = this.BPMdao.getBPMTokenViews(payeeID);

		for (BPMTokenView param : pending) {
			writer.writeStartElement("WorkflowLink");

			for (String column : columns) {
				writer.writeStartElement("Cell");
				if (column.equals("ReportName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getReport());
					writer.writeEndElement();
				} else if (column.equals("ActionName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getNodeName());
					writer.writeEndElement();
				} else if (column.equals("SubmittedBy")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getPayee());
					writer.writeEndElement();
				} else if (column.equals("SubmittedByName")) {
					writer.writeStartElement("Value");
					writer.writeCharacters(param.getPayeeName());
					writer.writeEndElement();
				} else {
					if (!column.equals("DateReceived")) {
						throw new XMLStreamException("WorkflowLink column not recognized.");
					}

					writer.writeStartElement("Value");
					writer.writeCharacters(Format.asFullLongDateTime(param.getLastModified()));
					writer.writeEndElement();
				}

				writer.writeStartElement("URL");
				String url = "../bpm/view.html?bpmTokenID=" + param.getTokenID();
				writer.writeCharacters(url);
				writer.writeEndElement();
				writer.writeEndElement();
			}

			writer.writeEndElement();
		}

	}

	private String getTranslatedColumnName(String column) {
		String name = new String();
		if (column.equals("WorkflowName")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_WORKFLOWNAME,
					LocaleContextHolder.getLocale());
		} else if (column.equals("WorkflowDescription")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_WORKFLOWDESCRIPTION,
					LocaleContextHolder.getLocale());
		} else if (column.equals("ReportName")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_REPORTNAME,
					LocaleContextHolder.getLocale());
		} else if (column.equals("ActionName")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_ACTIONNAME,
					LocaleContextHolder.getLocale());
		} else if (column.equals("SubmittedBy")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_SUBMITTEDBY,
					LocaleContextHolder.getLocale());
		} else if (column.equals("SubmittedByName")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_SUBMITTEDBYNAME,
					LocaleContextHolder.getLocale());
		} else if (column.equals("DateReceived")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_DATERECEIVED,
					LocaleContextHolder.getLocale());
		} else if (column.equals("Initiator")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_INITIATOR,
					LocaleContextHolder.getLocale());
		} else if (column.equals("InitiatorName")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_INITIATORNAME,
					LocaleContextHolder.getLocale());
		} else if (column.equals("DateOfInitiation")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_DATEOFCREATION,
					LocaleContextHolder.getLocale());
		} else if (column.equals("DateOfCompletion")) {
			name = this.message.getMessage(Messages.Key.WORKFLOWLINK_HEADERS_DATEOFDELETION,
					LocaleContextHolder.getLocale());
		}

		return name;
	}
}
