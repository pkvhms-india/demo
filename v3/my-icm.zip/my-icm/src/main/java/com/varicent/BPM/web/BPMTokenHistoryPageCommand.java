package com.varicent.BPM.web;

import com.varicent.BPM.domain.BPMTokenView;

public class BPMTokenHistoryPageCommand extends BPMPagedItemsCommand<BPMTokenView> {
	public final String NOT_AVAILABLE = "";
	private int startPage;

	public BPMTokenHistoryPageCommand(int start, int itemsPerPage, int totalItems, BPMTokenView[] items) {
		super(start, itemsPerPage, totalItems, items, "completedtokenhistorylistpage.html?start=%s");
		this.startPage = start;
	}

	@Override
	public String getNextURL() {
		return Math.ceil((double) this.getTotalItems() * (double) 1.0F / this.getItemsPerPage()) != this.startPage
				&& this.getTotalItems() != 0 ? this.getURL(this.startPage + 1) : "";
	}

	@Override
	public String getPrevURL() {
		return this.startPage == 1 ? "" : this.getURL(this.startPage - 1);
	}
}
