package com.varicent.reporting.dao.Expander;

import java.util.Date;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.text.Format;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class DateScalarExpander extends BaseExpander {
	public DateScalarExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("DateScalarDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		if (this.streamReader.getLocalName().equals("DateScalarDisplay")) {
			this.streamReader.nextTag();
			XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String source = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			String modeString = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			int mode = Integer.parseInt(modeString);
			Date value = null;
			if (!scope.isNull(source) && !scope.isNullDate(source)) {
				value = scope.getDateTime(source);
			}

			String formatString = "";
			Long rawValue = Long.MIN_VALUE;
			String formattedValue;
			if (value == null) {
				formattedValue = "";
			} else {
				if (mode == 1) {
					formattedValue = Format.asShortDate(value);
					formatString = Format.getShortDateFormatString();
				} else {
					formattedValue = Format.asFullDate(value);
					formatString = Format.getLongDateFormatString();
				}

				rawValue = value.getTime();
			}

			writer.writeStartElement("DateScalarDisplay");
			writer.writeStartElement("SourceData");
			writer.writeCharacters(formattedValue);
			writer.writeEndElement();
			writer.writeStartElement("RawValue");
			writer.writeCharacters(Long.toString(rawValue));
			writer.writeEndElement();
			writer.writeStartElement("DateFormatString");
			writer.writeCharacters(formatString);
			writer.writeEndElement();
			if (this.streamReader.getLocalName().equals("Link")) {
				LinkExpander link = new LinkExpander(this.streamReader);
				link.read(writer, scope, permitted, editable);
			}

			writer.writeStartElement("StyleName");
			String styleName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
			writer.writeCharacters(styleName);
			writer.writeEndElement();
			writer.writeEndElement();
			this.streamReader.nextTag();
		}
	}
}
