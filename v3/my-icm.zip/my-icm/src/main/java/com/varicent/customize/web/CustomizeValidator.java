package com.varicent.customize.web;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import com.varicent.core.database.schema.Schema;
import com.varicent.core.i18n.Message;
import com.varicent.core.i18n.Messages;
import com.varicent.core.text.Parse;
import com.varicent.core.util.Validation;
import com.varicent.customize.domain.CustomColumn;
import com.varicent.customize.domain.CustomType;
import com.varicent.customize.service.CustomizeManager;

@Component
public class CustomizeValidator {
	private final CustomizeManager customizeManager;

	@Autowired
	public CustomizeValidator(CustomizeManager customizeManager) {
		this.customizeManager = customizeManager;
	}

	public void validate(CustomizeCommand cmd, Errors errors) {
		List<CustomColumn> columns = this.customizeManager.getColumns(cmd.getTable());
		this.validateForm(cmd.getTable(), columns, cmd.getFilterValues(), errors);
		this.validateForm(cmd.getTable(), columns, cmd.getEditedDataRow(), errors);
	}

	private void validateForm(String tableName, List<CustomColumn> columns, List<String> values, Errors errors) {
		if (!values.isEmpty()) {
			int i = 0;

			for (int n = columns.size(); i < n; ++i) {
				CustomColumn column = columns.get(i);
				String value = values.get(i);
				if (!value.equals("")) {
					int schemaType = column.getSchemaType();
					CustomType customType = column.getType();
					if (Schema.isValid(value, schemaType, false) && Validation.isValid(customType, value)) {
						if (schemaType == 93 || schemaType == 91) {
							Date date = Parse.date(value);
							if (!this.customizeManager.isDateValidForTable(column.getName(), date, tableName)) {
								errors.rejectValue("editedDataRow",
										Messages.Key.WEBFORMS_ERROR_SUBMIT_DATE_LOCKED_NOT_IN_CALENDAR.toString(),
										new Object[] { value, column.getDisplayName(), tableName }, "");
							}
						}
					} else {
						errors.rejectValue("filterValues", GetErrorMessage(customType).toString(),
								new Object[] { column.getDisplayName() }, "");
					}
				}
			}

		}
	}

	public static Messages.Key GetErrorMessage(CustomType customType) {
		switch (customType) {
		case COMMENT:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_COMMENT;
		case EMAIL:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_EMAIL;
		case TEXT:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_TEXT;
		case URL:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_URL;
		case NUMERIC:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_NUMERIC;
		case DATE:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE_DATE;
		default:
			return Messages.Key.CUSTOMIZE_ERROR_VALUE;
		}
	}

	public static Message getErrorMessage(CustomType customType, boolean internal, String value, String col,
			String table) {
		switch (customType) {
		case COMMENT:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_COMMENT, new Object[] { col, table });
		case EMAIL:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_EMAIL, new Object[] { col, table });
		case TEXT:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_TEXT, new Object[] { col, table });
		case URL:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_URL, new Object[] { col, table });
		case NUMERIC:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_NUMERIC, new Object[] { col, table });
		case DATE:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE_DATE, new Object[] { col, table });
		default:
			return new Message(false, Messages.Key.CUSTOMIZE_ERROR_FIELD_VALUE, new Object[] { col, table });
		}
	}
}
