package com.varicent.payeeledger.web;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.Assert;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.varicent.common.config.service.ConfigManager;
import com.varicent.common.tab.domain.Tab;
import com.varicent.common.tab.domain.TabObject;
import com.varicent.common.time.domain.TimePeriod;
import com.varicent.core.database.support.DataRow;
import com.varicent.payeeledger.domain.TailoredReport;
import com.varicent.payeeledger.service.PayeeLedger;
import com.varicent.security.domain.UserAccount;
import com.varicent.workflow.domain.WorkflowObject;
import com.varicent.workflow.service.WorkflowManager;
import com.varicent.workflow.web.InquiryCommand;

public abstract class AbstractPayeeLedgerController {
	private static final String ACTIVE_TAB_ATTRIBUTE = "activeTab";
	private static final String SHOW_INQUIRY = "showInquiry";
	protected final PayeeLedger payeeLedger;
	protected final ConfigManager configManager;
	protected final WorkflowManager workflowManager;

	protected AbstractPayeeLedgerController(PayeeLedger payeeLedger, ConfigManager configManager,
			WorkflowManager workflowManager) {
		this.payeeLedger = payeeLedger;
		this.configManager = configManager;
		this.workflowManager = workflowManager;
	}

	private String getObjectId(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		if (!activeTab.isCompensationPlan() && !activeTab.isTailoredReport()) {
			Assert.state(false, "Invalid tab.");
			return null;
		} else {
			TabObject tabObject = (TabObject) activeTab;
			return tabObject.getObjectId();
		}
	}

	@ModelAttribute("type")
	public abstract String getType();

	protected abstract String getView();

	private boolean hasObjectId(HttpServletRequest request) {
		Tab activeTab = (Tab) WebUtils.getSessionAttribute(request, "activeTab");
		if (activeTab == null) {
			return false;
		} else {
			return activeTab.isCompensationPlan() || activeTab.isTailoredReport();
		}
	}

	@ModelAttribute("manualSubmit")
	public boolean isManualSubmit() {
		return this.configManager.isLedgerManualSubmit();
	}

	protected void populateModel(ModelAndView mav, PayeeLedgerCommand cmd, HttpServletRequest request) {
		if (!cmd.hasPlanId() && this.hasObjectId(request)) {
			cmd.setPlanId(this.getObjectId(request));
		}

		cmd.updateToken();
		mav.addObject("command", cmd);
		mav.addObject("inquiryCommand", new InquiryCommand());
		String planId = cmd.getPlanId();
		String payeeId = cmd.getPayeeId();
		mav.addObject("plans", this.payeeLedger.getPlans(planId == null ? null : payeeId));
		mav.addObject("excelError", cmd.hasExcelError());
		if (planId != null && this.payeeLedger.getViewablePlans().contains(planId)) {
			mav.addObject("payees", this.payeeLedger.getPayees(planId));
			List<TimePeriod> periods = this.payeeLedger.getPeriods(planId);
			mav.addObject("periods", periods);
			mav.addObject("isSelf", UserAccount.getCurrent().getPayeeId().equals(payeeId));
			mav.addObject("canAdjust", this.workflowManager.canAdjust(planId));
			boolean inquiriesEnabled = this.workflowManager.inquiriesEnabled(planId,
					TailoredReport.isReport(planId) ? WorkflowObject.Type.TAILORED_REPORT
							: WorkflowObject.Type.COMP_PLAN);
			mav.addObject("inquiriesEnabled", inquiriesEnabled);
			mav.addObject("defaultCategories", this.workflowManager.getDefaultCategories().values());
			mav.addObject("inquiryCategories", this.workflowManager.getUserDefinedCategories().values());
			TimePeriod selectedPeriod = null;
			if (cmd.getPeriodIndex() >= 0 && periods.size() > 0) {
				selectedPeriod = periods.get(cmd.getPeriodIndex());
			}

			boolean hasRows = false;
			if (this.isManualSubmit() && !cmd.getDoRetrieveRows()) {
				mav.addObject("rows", new ArrayList());
			} else {
				List<DataRow> rows = this.payeeLedger.getLedger(cmd.getPlanId(), cmd.getPayeeId(), selectedPeriod,
						true);
				mav.addObject("rows", rows);
				hasRows = !rows.isEmpty();
			}

			boolean showInquiry = inquiriesEnabled && planId != null && !planId.isEmpty() && hasRows;
			WebUtils.setSessionAttribute(request, "showInquiry", showInquiry);
		} else {
			mav.addObject("rows", new ArrayList());
		}

	}

	@RequestMapping(method = { RequestMethod.GET })
	public ModelAndView prepareView(HttpServletRequest request) throws ServletRequestBindingException {
		ModelAndView mav = new ModelAndView(this.getView());
		PayeeLedgerCommand cmd = (PayeeLedgerCommand) WebUtils.getSessionAttribute(request, "command");
		WebUtils.setSessionAttribute(request, "command", (Object) null);
		if (cmd == null) {
			cmd = new PayeeLedgerCommand();
			if (request.getParameterMap().containsKey("plan")) {
				cmd.setPlanId(ServletRequestUtils.getStringParameter(request, "plan"));
				cmd.setPayeeId(ServletRequestUtils.getStringParameter(request, "payee"));
				if (request.getParameterMap().containsKey("period")) {
					cmd.setPeriodIndex(ServletRequestUtils.getIntParameter(request, "period"));
				}
			}

			cmd.setExcelError(ServletRequestUtils.getBooleanParameter(request, "error", false));
		}

		cmd.setIsXLSXExport(false);
		this.populateModel(mav, cmd, request);
		return mav;
	}

	@RequestMapping(method = { RequestMethod.POST })
	public ModelAndView processForm(@ModelAttribute("command") PayeeLedgerCommand cmd, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView(this.getView());
		cmd.setIsXLSXExport(false);
		this.populateModel(mav, cmd, request);
		return mav;
	}
}
