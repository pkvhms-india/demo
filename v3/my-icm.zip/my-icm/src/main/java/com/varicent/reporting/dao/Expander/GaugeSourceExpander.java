package com.varicent.reporting.dao.Expander;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;

import com.varicent.core.exceptions.ReportOverLimitException;
import com.varicent.core.i18n.Messages;
import com.varicent.reporting.domain.ColumnLink;
import com.varicent.reporting.domain.DataTable;
import com.varicent.reporting.domain.Scope;
import com.varicent.reporting.domain.XMLStreamUtility;

public class GaugeSourceExpander extends BaseExpander {
	String minValueSourceName;
	String maxValueSourceName;
	String currentValueSourceName;
	String trendpointValueSourceName;
	BigDecimal lowerLimit;
	BigDecimal upperLimit;
	BigDecimal currentValue;
	BigDecimal trendpointValue;
	DataTable data;
	private Messages messages;
	boolean hasLink;
	boolean isAngular;
	boolean isCylinder;
	boolean isPercentage;
	ColumnLink link;
	String pointerdefinition = "";
	GaugeType gaugetype;

	public GaugeSourceExpander(XMLStreamReader stream, Messages messages) {
		super(stream);
		if (!this.streamReader.getLocalName().equals("AngularGaugeSource")
				&& !this.streamReader.getLocalName().equals("CylinderGaugeSource")
				&& !this.streamReader.getLocalName().equals("HLinearGaugeSource")) {
			throw new RuntimeException("Unexpected Node.");
		} else {
			this.messages = messages;
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException, ReportOverLimitException {
		this.initializeGaugeSource(writer, scope);
		this.writeEndElements(writer);
	}

	private void writeEndElements(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("</chart>");
		writer.writeEndElement();
		this.streamReader.nextTag();
	}

	private void initializeGaugeSource(XMLStreamWriter writer, Scope scope)
			throws XMLStreamException, ReportOverLimitException {
		this.streamReader.nextTag();
		this.minValueSourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.maxValueSourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.currentValueSourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.trendpointValueSourceName = XMLStreamUtility.getCurrentNodeValue(this.streamReader);
		this.lowerLimit = scope.isNull(this.minValueSourceName) ? BigDecimal.ZERO
				: scope.getDecimal(this.minValueSourceName);
		this.upperLimit = scope.isNull(this.maxValueSourceName) ? BigDecimal.ZERO
				: scope.getDecimal(this.maxValueSourceName);
		this.currentValue = scope.isNull(this.currentValueSourceName) ? BigDecimal.ZERO
				: scope.getDecimal(this.currentValueSourceName);
		this.hasLink = false;
		if (!StringUtils.isBlank(this.trendpointValueSourceName)) {
			this.trendpointValue = scope.isNull(this.trendpointValueSourceName) ? BigDecimal.ZERO
					: scope.getDecimal(this.trendpointValueSourceName);
		}

		writer.writeStartElement("Xml");
		this.writeChartNodeBegin(writer);
		this.currentValue = this.isPercentage ? this.currentValue.multiply(new BigDecimal(100)) : this.currentValue;
		StringBuilder value = this.getSetValue(scope);
		StringBuilder style = this.getChartStyle();
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		this.streamReader.nextTag();
		if (this.streamReader.getLocalName().equals("Link")) {
			this.link = new ColumnLink(this.streamReader);

			String linkurl;
			try {
				linkurl = this.link.getLinkAttribute(scope);
			} catch (UnsupportedEncodingException e) {
				throw new XMLStreamException(e);
			}

			switch (this.gaugetype) {
			case ANGULAR:
				value.append("link='");
				value.append(linkurl);
				value.append("' /> </dials>");
				break;
			case HILINEAR:
				value.append("link='");
				value.append(linkurl);
				value.append("' /> </pointers>");
				break;
			case CYLINDER:
				value.append("</value>");
			}
		} else {
			switch (this.gaugetype) {
			case ANGULAR:
				value.append("/> </dials>");
				break;
			case HILINEAR:
				value.append("/> </pointers>");
				break;
			case CYLINDER:
				value.append("</value>");
			}
		}

		writer.writeCharacters(value.toString());
		writer.writeCharacters(style.toString());
		this.streamReader.nextTag();
	}

	private void writeChartNodeBegin(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeCharacters("<chart ");
		String captureAttribute = "exportDialogMessage='"
				+ this.messages.getMessage(Messages.Key.WEBREPORT_FUSION_CAPTURING, LocaleContextHolder.getLocale())
				+ "' ";
		writer.writeCharacters(captureAttribute);
		writer.writeCharacters("showBorder='0' ");
		writer.writeCharacters("bgColor='#FFFFFF' ");
		writer.writeCharacters("bgAlpha='0' ");
		writer.writeCharacters("exportAction='save' ");
		writer.writeCharacters("exportAtClient='0' ");
		writer.writeCharacters("exportEnabled='1' ");
		writer.writeCharacters("exportFormats='JPG=JPG' ");
		writer.writeCharacters("exportShowMenuItem='0' ");
		writer.writeCharacters("exportHandler='Placeholder' ");
		this.isPercentage = this.streamReader.getAttributeValue((String) null, "isPercentage").equals("1");
		this.lowerLimit = this.isPercentage ? this.lowerLimit.multiply(new BigDecimal(100)) : this.lowerLimit;
		this.upperLimit = this.isPercentage ? this.upperLimit.multiply(new BigDecimal(100)) : this.upperLimit;
		if (this.isPercentage && this.trendpointValue != null) {
			this.trendpointValue = this.trendpointValue.multiply(new BigDecimal(100));
		}

		String[] attributeNames = new String[] { "lowerLimitDisplay", "upperLimitDisplay", "limitLabelFillColor",
				"lowerLimit", "upperLimit", "showValue", "numberPrefix", "numberSuffix", "trendValueDistance",
				"valueBelowPivot", "valuePadding", "showLimits", "showToolTip", "showTickMarks", "showTickValues",
				"adjustTM", "gaugeStartAngle", "gaugeEndAngle", "cylFillColor", "chartLeftMargin", "chartRightMargin",
				"chartTopMargin", "chartBottomMargin", "decimals", "decimalSeparator", "thousandSeparator",
				"formatNumberScale", "showShadow", "showBorder", "showGaugeBorder", "gaugeBorderColor",
				"ticksBelowGauge", "valueAbovePointer", "pointerOnTop", "pointerRadius", "gaugeFillMix" };

		for (String attributeName : attributeNames) {
			if (attributeName.equals("lowerLimit")) {
				writer.writeCharacters("lowerLimit='" + this.valueToString(this.lowerLimit) + "' ");
			} else if (attributeName.equals("upperLimit")) {
				writer.writeCharacters("upperLimit='" + this.valueToString(this.upperLimit) + "' ");
			} else {
				String currentAttributeValue = this.streamReader.getAttributeValue((String) null, attributeName);
				if (currentAttributeValue != null) {
					try {
						String toWrite = URLDecoder.decode(currentAttributeValue, "UTF-8");
						toWrite = toWrite.replaceAll("%", "%25");
						toWrite = toWrite.replaceAll("'", "&apos;");
						toWrite = attributeName + "='" + toWrite + "' ";
						writer.writeCharacters(toWrite);
					} catch (UnsupportedEncodingException var7) {
						writer.writeCharacters(attributeName + "='" + currentAttributeValue + "' ");
					}
				}
			}
		}

		writer.writeCharacters(">");
		this.streamReader.nextTag();
	}

	private StringBuilder getSetValue(Scope scope) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		if (this.streamReader.getLocalName().equals("pointers")) {
			sb.append("<pointers>");
			this.streamReader.nextTag();
			sb.append("<pointer value='" + this.currentValue.toString() + "' ");
			String[] pointerAttributes = new String[2];
			pointerAttributes[0] = this.streamReader.getAttributeValue((String) null, "showValue");
			pointerAttributes[1] = this.streamReader.getAttributeValue((String) null, "toolText");
			if (pointerAttributes[0] != null) {
				sb.append("showValue='" + pointerAttributes[0] + "' ");
			}

			if (pointerAttributes[1] != null) {
				try {
					pointerAttributes[1] = URLDecoder.decode(pointerAttributes[1], "UTF-8");
					pointerAttributes[1] = pointerAttributes[1].replaceAll("%", "%25").replaceAll("'", "&apos;");
				} catch (UnsupportedEncodingException var6) {
				}

				sb.append("toolText='" + pointerAttributes[1] + "' ");
			}

			this.gaugetype = GaugeSourceExpander.GaugeType.HILINEAR;
			this.streamReader.nextTag();
			this.streamReader.nextTag();
		} else if (this.streamReader.getLocalName().equals("dials")) {
			sb.append("<dials>");
			this.streamReader.nextTag();
			sb.append("<dial value='" + this.currentValue.toString() + "' ");
			String[] dialAttributes = new String[3];
			dialAttributes[0] = this.streamReader.getAttributeValue((String) null, "rearExtension");
			dialAttributes[1] = this.streamReader.getAttributeValue((String) null, "showValue");
			dialAttributes[2] = this.streamReader.getAttributeValue((String) null, "toolText");
			if (dialAttributes[0] != null) {
				sb.append("rearExtension='" + dialAttributes[0] + "' ");
			}

			if (dialAttributes[1] != null) {
				sb.append("showValue='" + dialAttributes[1] + "' ");
			}

			if (dialAttributes[2] != null) {
				try {
					dialAttributes[2] = URLDecoder.decode(dialAttributes[2], "UTF-8");
					dialAttributes[2] = dialAttributes[2].replaceAll("%", "%25").replaceAll("'", "&apos;");
				} catch (UnsupportedEncodingException var5) {
				}

				sb.append("toolText='" + dialAttributes[2] + "' ");
			}

			this.gaugetype = GaugeSourceExpander.GaugeType.ANGULAR;
			this.streamReader.nextTag();
			this.streamReader.nextTag();
		} else {
			this.gaugetype = GaugeSourceExpander.GaugeType.CYLINDER;
			if (this.streamReader.getLocalName().equals("target")) {
				this.streamReader.nextTag();
				this.streamReader.nextTag();
				if (this.trendpointValue != null) {
					sb.append("<target>");
					sb.append(this.trendpointValue.toString());
					sb.append("</target>");
				}
			}

			sb.append("<value>");
			sb.append(this.currentValue.toString());
		}

		this.streamReader.nextTag();
		return sb;
	}

	private StringBuilder getChartStyle() throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		if (this.streamReader.getLocalName().equals("colorRange")) {
			sb.append("<colorRange>");
			this.streamReader.nextTag();

			while (this.streamReader.getLocalName().equals("color")) {
				sb.append("<color ");
				String[] colorAttributes = new String[4];
				colorAttributes[0] = this.streamReader.getAttributeValue((String) null, "minValue");
				colorAttributes[1] = this.streamReader.getAttributeValue((String) null, "maxValue");
				colorAttributes[2] = this.streamReader.getAttributeValue((String) null, "label");
				colorAttributes[3] = this.streamReader.getAttributeValue((String) null, "code");
				if (colorAttributes[0] != null) {
					sb.append("minValue='" + colorAttributes[0] + "' ");
				}

				if (colorAttributes[1] != null) {
					sb.append("maxValue='" + colorAttributes[1] + "' ");
				}

				if (colorAttributes[2] != null) {
					try {
						String toWrite = URLDecoder.decode(colorAttributes[2], "UTF-8");
						toWrite = toWrite.replaceAll("%", "%25");
						toWrite = toWrite.replaceAll("'", "&apos;");
						toWrite = "label='" + toWrite + "' ";
						sb.append(toWrite);
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					}
				}

				if (colorAttributes[3] != null) {
					sb.append("code='" + colorAttributes[3] + "' ");
				}

				sb.append("/>");
				this.streamReader.nextTag();
				this.streamReader.nextTag();
			}

			sb.append("</colorRange>");
		}

		if (this.streamReader.getLocalName() != "styles") {
			this.streamReader.nextTag();
			if (this.streamReader.getLocalName().equals("trendpoints")) {
				sb.append("<trendpoints>");
				this.streamReader.nextTag();
				if (this.streamReader.getLocalName().equals("point")) {
					String[] pointAttributes = new String[7];

					try {
						pointAttributes[0] = URLDecoder
								.decode(this.streamReader.getAttributeValue((String) null, "displayValue"), "UTF-8");
						pointAttributes[0] = pointAttributes[0].replaceAll("%", "%25").replaceAll("'", "&apos;");
					} catch (UnsupportedEncodingException var5) {
						pointAttributes[0] = this.streamReader.getAttributeValue((String) null, "displayValue");
					}

					pointAttributes[1] = this.streamReader.getAttributeValue((String) null, "color");
					pointAttributes[2] = this.streamReader.getAttributeValue((String) null, "dashed");
					pointAttributes[3] = this.streamReader.getAttributeValue((String) null, "thickness");
					pointAttributes[4] = this.streamReader.getAttributeValue((String) null, "useMarker");
					pointAttributes[5] = this.streamReader.getAttributeValue((String) null, "showOnTop");
					pointAttributes[6] = this.streamReader.getAttributeValue((String) null, "valueInside");
					sb.append("<point ");
					sb.append("value='" + this.trendpointValue.toString() + "' ");
					if (pointAttributes[0] != null) {
						sb.append("displayValue='" + pointAttributes[0] + "' ");
					}

					if (pointAttributes[1] != null) {
						sb.append("color='" + pointAttributes[1] + "' ");
					}

					if (pointAttributes[2] != null) {
						sb.append("dashed='" + pointAttributes[2] + "' ");
					}

					if (pointAttributes[3] != null) {
						sb.append("thickness='" + pointAttributes[3] + "' ");
					}

					if (pointAttributes[4] != null) {
						sb.append("useMarker='" + pointAttributes[4] + "' ");
					}

					if (pointAttributes[5] != null) {
						sb.append("showOnTop='" + pointAttributes[5] + "' ");
					}

					if (pointAttributes[6] != null) {
						sb.append("valueInside='" + pointAttributes[6] + "' ");
					}

					sb.append("/>");
					this.streamReader.nextTag();
				}

				sb.append("</trendpoints>");
				this.streamReader.nextTag();
				this.streamReader.nextTag();
			}
		}

		StylesExpander styleEx = new StylesExpander(this.streamReader);
		styleEx.expandStylesNode(sb);
		return sb;
	}

	private String valueToString(Object value) {
		if (value == null) {
			return "";
		} else {
			return value instanceof BigDecimal ? ((BigDecimal) value).toPlainString() : value.toString();
		}
	}

	static enum GaugeType {
		ANGULAR, HILINEAR, CYLINDER;
	}
}
