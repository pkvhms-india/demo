package com.varicent.core.math.expressions;

public interface AggregateNode {
	void finalize();

	int getSuffix();
}
