package com.varicent.reporting.dao.Expander;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.varicent.reporting.domain.Scope;

public class SubmitButtonExpander extends BaseExpander {
	public SubmitButtonExpander(XMLStreamReader streamReader) {
		super(streamReader);
		if (!streamReader.getLocalName().equals("SubmitButtonDisplay")) {
			throw new RuntimeException("Unexpected Node.");
		}
	}

	@Override
	public void read(XMLStreamWriter writer, Scope scope, boolean permitted, boolean editable)
			throws XMLStreamException {
		if (this.streamReader.getLocalName().equals("SubmitButtonDisplay")) {
			super.copyCurrentNode(writer);
		}
	}
}
