package com.varicent.draws.domain;

import java.awt.Color;
import java.io.Serializable;

import com.varicent.core.text.NumericFormat;

public class DrawReportWebSettings implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private int workflowObjectId;
	private boolean allowGroupSelection;
	private int rowsPerPage;
	private Color color;
	private byte[] logo;
	private NumericFormat.Style numericStyle;

	public DrawReportWebSettings(int id, int workflowObjectId, boolean allowGroupSelection, int rowsPerPage,
			Color color, NumericFormat.Style numericStyle) {
		this(id, workflowObjectId, allowGroupSelection, rowsPerPage, color, (byte[]) null, numericStyle);
	}

	public DrawReportWebSettings(int id, int workflowObjectId, boolean allowGroupSelection, int rowsPerPage,
			Color color, byte[] logo, NumericFormat.Style numericStyle) {
		this.id = id;
		this.workflowObjectId = workflowObjectId;
		this.allowGroupSelection = allowGroupSelection;
		this.rowsPerPage = rowsPerPage;
		this.color = color;
		this.logo = logo;
		this.numericStyle = numericStyle;
	}

	public int getId() {
		return this.id;
	}

	public NumericFormat.Style getNumericStyle() {
		return this.numericStyle;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWorkflowObjectId() {
		return this.workflowObjectId;
	}

	public void setWorkflowObjectId(int workflowObjectId) {
		this.workflowObjectId = workflowObjectId;
	}

	public boolean isAllowGroupSelection() {
		return this.allowGroupSelection;
	}

	public void setAllowGroupSelection(boolean allowGroupSelection) {
		this.allowGroupSelection = allowGroupSelection;
	}

	public int getRowsPerPage() {
		return this.rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public Color getColor() {
		return this.color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public byte[] getLogo() {
		return this.logo;
	}

	public void setLogo(byte[] logo) {
		this.logo = logo;
	}
}
