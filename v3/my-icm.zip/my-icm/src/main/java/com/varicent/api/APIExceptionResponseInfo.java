package com.varicent.api;

public class APIExceptionResponseInfo {
	private APIExceptionResponse apiException;
	private int httpStatusCode;

	public APIExceptionResponseInfo(APIExceptionResponse apiException, int httpStatusCode) {
		this.apiException = apiException;
		this.httpStatusCode = httpStatusCode;
	}

	public APIExceptionResponse getAPIExceptionResponse() {
		return this.apiException;
	}

	public int getHttpStatusCode() {
		return this.httpStatusCode;
	}
}
