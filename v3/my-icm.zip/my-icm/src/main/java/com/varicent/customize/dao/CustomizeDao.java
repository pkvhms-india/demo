package com.varicent.customize.dao;

import java.util.List;
import java.util.Set;

import com.varicent.core.database.schema.ColumnDefinition;
import com.varicent.core.exceptions.DataSubmitException;
import com.varicent.customize.domain.CustomColumn;
import com.varicent.customize.domain.CustomRow;
import com.varicent.customize.domain.CustomType;
import com.varicent.customize.domain.EditRow;

public interface CustomizeDao {
	List<CustomColumn> getColumns(String var1);

	CustomType getColumnType(ColumnDefinition var1);

	CustomType getColumnType(String var1, String var2);

	List<CustomRow> getData(String var1, List<String> var2);

	List<EditRow> getPendingRows(String var1, List<String> var2);

	List<EditRow> getPendingUpdates(String var1, List<String> var2);

	Set<String> getViewableTables();

	void submitInsert(String var1, List<String> var2) throws DataSubmitException;

	void submitUpdate(String var1, List<String> var2, List<String> var3) throws DataSubmitException;

	String getCustomTableType(String var1);

	boolean isEffectiveDated(String var1);
}
